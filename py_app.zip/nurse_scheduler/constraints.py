# -*- coding: utf-8 -*-
"""제약 검증기 (설계서 §1 하드, §2 소프트).

배정 로직(generator)과 검증 리포트(Step 10)가 같은 함수를 재사용한다(부록 B).
모든 검증은 '완성된 grid'(None 없음)를 전제로 한다.
"""
from __future__ import annotations

import math
from typing import Dict, List, Optional

from .calendar_utils import DayInfo, DAY_WEEKDAY, holiday_count, min_staff_for
from .models import (
    MonthSchedule, Shift, Staff, Violation,
    DAY_WORK_SHIFTS, DESIGNATED_KEY, LONG_ABSENCE_SHIFTS, NIGHT_SHIFTS,
    PRN_LIKE_SHIFTS, REST_SHIFTS, WORK_SHIFTS,
)


def night_blocks(sch: MonthSchedule, sid: str) -> List[tuple]:
    """(start, end) 야간블록 목록 (0-based, 양끝 포함).

    전월에서 이어지는 블록은 이월분만큼 start를 앞으로 당겨 표현한다(길이 계산이
    맞아떨어지게). 1일자 기준이면 start<0이 되고, 월중 전입자는 입사일에서 당긴
    값이라 0 이상일 수도 있다 — 어느 쪽이든 소비하는 쪽은 길이(end-start+1)와
    max(start,0)만 쓴다."""
    blocks = []
    d = 0
    nd = sch.num_days
    grid = sch.grid[sid]
    co = sch.carryover[sid]
    base = sch.month_start_day.get(sid, 0)  # 월중 전입자는 입사일이 '이번 달 첫날'
    while d < nd:
        if grid[d] in NIGHT_SHIFTS:
            start = d
            while d + 1 < nd and grid[d + 1] in NIGHT_SHIFTS:
                d += 1
            end = d
            if start == base and co.trailing_night_count > 0:
                start = base - co.trailing_night_count  # 전월 이월 연결
            blocks.append((start, end))
        d += 1
    # 월초 시작 전 이월블록이 이번달에 야간 없이 끝난 경우는 검증 대상 아님
    return blocks


# ---------------------------------------------------------------- 하드 제약

def check_h1_min_staff(sch: MonthSchedule, days: List[DayInfo],
                       min_cfg: Dict) -> List[Violation]:
    """H1-1(미달)/H1-4(초과) — 최소인력은 하한이자 상한이다: 그 인원만큼만 근무하고
    남는 인원은 배정하지 않는다(권장이 아니라 하드 규칙). 원티드 요청/리더 고정
    배정처럼 사람이 직접 지정한 칸은 존중되므로 드물게 초과가 남을 수 있다.

    ⚠ prn만 반일 코드(8AH·9AH·9H*)를 0.5로 세므로 합계가 실수가 된다. 그래서 상한은
    'need를 넘으면'이 아니라 **'need+1 이상이면'**으로 본다. 반일이 한 칸이라도 끼면
    합계가 x.5가 되어 need에 정확히 못 맞추기 때문이다 — 최소 3에 반일 1명이 있으면
    2.5(미달) 아니면 3.5(초과)뿐이라, 예전 기준으로는 **사람이 고칠 수 없는 하드 위반**이
    근무표에 상시로 붙는다. 반일 코드는 엔진이 배정하지 않는 읽기 전용이라 엔진이
    그 칸을 치울 수도 없다."""
    out = []
    for d, di in enumerate(days):
        mins = min_staff_for(di, min_cfg)
        for key, shift in (("D", Shift.D), ("E", Shift.E),
                           ("N", Shift.N), ("prn", Shift.PRN)):
            have = sch.count_shift(d, shift)
            need = mins.get(key, 0)
            if have < need:
                out.append(Violation(
                    "H1-1", "hard",
                    f"{d+1}일 {key} 인원 {have:g}명 < 최소 {need}명", day=d))
            elif have >= need + 1:
                out.append(Violation(
                    "H1-4", "hard",
                    f"{d+1}일 {key} 인원 {have:g}명 > 최소인력 {need}명(상한 초과)", day=d))
    return out


def check_h1_designated(sch: MonthSchedule, days: List[DayInfo],
                        min_cfg: Dict) -> List[Violation]:
    """H1-6: 그날 근무 중인 '지정' 가능자가 최소인력 표의 '지정' 값 이상이어야 한다.

    D/E/N/prn과 달리 **상한은 없다.** 지정은 별도의 근무가 아니라 이미 D·E·N·prn 중
    하나를 서고 있는 사람에게 붙는 표시라, 상한을 두면 "지정 가능자가 셋인데 오늘 셋 다
    근무해서 위반"이라는, 고치려면 멀쩡한 사람을 쉬게 해야 하는 위반이 생긴다.

    지정을 안 쓰는 병동은 값이 0이라 이 검사가 통째로 지나간다 — 기존 근무표는 그대로다.
    """
    out = []
    for d, di in enumerate(days):
        need = min_staff_for(di, min_cfg).get(DESIGNATED_KEY, 0)
        if not need:
            continue
        have = sch.designated_count(d)
        if have < need:
            out.append(Violation(
                "H1-6", "hard",
                f"{d+1}일 지정 인원 {have}명 < 최소 {need}명", day=d))
    return out


def check_h1_shift_rules(sch: MonthSchedule, days: List[DayInfo],
                         leader_8a_as_prn: bool) -> List[Violation]:
    # 8A·9A·10A에서 두 가지 제한을 걷어냈다(파트장 요청).
    #
    # 1) **평일만**이 아니다. 예전엔 주말 8A가 하드 위반이었는데(DayInfo.allows_8a),
    #    파트장 상근이 평일 중심일 뿐 주말에 못 서는 근무가 아니다. 자동으로 넣어주는
    #    기본값만 평일로 남겼다(DayInfo.auto_8a).
    # 2) **파트장/리더 전용**이 아니다. 간호사도 설 수 있고 prn으로 센다
    #    (PRN_LIKE_SHIFTS) — 시작시각만 다른 같은 근무라 파트장 눈에는 한 덩어리다.
    #    엔진이 간호사에게 새로 배정하지는 않는다. 그 사람이 설 수 있는 근무인지는
    #    아래 H1-3(가능근무 칸)가 그대로 본다.
    out = []
    for s in sch.staff:
        for d in range(sch.num_days):
            v = sch.grid[s.id][d]
            if v in (Shift.A8, Shift.A9, Shift.A10):
                if s.is_leader and not leader_8a_as_prn:
                    out.append(Violation("H1-2", "hard",
                                         f"{s.id}(리더) {v} 운용 미설정 병동",
                                         staff_id=s.id, day=d))
            if v is not None and v not in REST_SHIFTS and v != Shift.EDU and v != Shift.TW:
                allowed = v in s.allowed_shifts or \
                    (v in (Shift.A8, Shift.A9, Shift.A10) and s.is_leader and leader_8a_as_prn)
                if not allowed:
                    out.append(Violation("H1-3", "hard",
                                         f"{s.id} {d+1}일 {v} 허용범위 밖",
                                         staff_id=s.id, day=d))
    return out


def check_h1_level_balance(sch: MonthSchedule, days: List[DayInfo]) -> List[Violation]:
    """H1-5: D/E/N 각 시간대(근무유형)마다 그날 배정 인원이 1명 이상이면 그중
    숙련도(레벨) 4 또는 5 이상이 최소 1명 포함돼야 한다(prn은 제외, 절대 레벨
    기준 — 파트별 상대기준인 S6과는 별개)."""
    out = []
    for d in range(sch.num_days):
        for key, shift in (("D", Shift.D), ("E", Shift.E), ("N", Shift.N)):
            levels = []
            for s in sch.staff:
                if s.is_partjang:
                    continue
                v = sch.grid[s.id][d]
                if v == shift or (shift == Shift.N and v == Shift.NK):
                    levels.append(s.level)
            if levels and not any(lv >= 4 for lv in levels):
                out.append(Violation(
                    "H1-5", "hard",
                    f"{d+1}일 {key} 근무에 숙련도 4 이상이 한 명도 없음(배정 {len(levels)}명)",
                    day=d))
    return out


def check_h2_nk_quota(sch: MonthSchedule) -> List[Violation]:
    out = []
    target = 14 if sch.month == 2 else 15
    for s in sch.staff:
        if s.is_nk:
            n = sch.nights_in_month(s.id)
            if n != target:
                out.append(Violation(
                    "H2-2", "hard",
                    f"NK {s.id} 야간 {n}일 (목표 {target}일)", staff_id=s.id))
    return out


def check_h2_night_blocks(sch: MonthSchedule, params) -> List[Violation]:
    """일반 간호사: H2-3(2일 블록, 목표가 홀수면 3일도 허용), H2-4(단독야간 금지,
    월말 예외), H2-5(블록 후 OFF 2일). 야간전담(NK)은 기존대로 ≤3일/≥2일(월말 단독 예외)."""
    out = []
    nd = sch.num_days
    # 월 야간목표(night_quota_low/high) 중 하나라도 홀수면 2일 블록만으로는 정확히
    # 못 채우므로 일반 간호사도 3일 블록까지 허용한다(기본 4/6은 둘 다 짝수라 기존과 동일).
    gen_max_len = 3 if (params.night_quota_low % 2
                        or params.night_quota_high % 2) else 2
    for s in sch.staff:
        # 가능근무에 3N을 적은 사람은 그 사람만 3일 블록까지 허용한다(파트장 확인).
        # 소프트로만 두면 아무 효과가 없다 — 하드가 2일에서 막으니 3일 블록이 아예
        # 만들어지지 않고, 3N을 적어도 근무표가 한 칸도 안 바뀐다.
        s_max_len = max(gen_max_len, s.night_block_pref)
        for (start, end) in night_blocks(sch, s.id):
            length = end - start + 1
            if s.is_nk:
                if length > 3:
                    out.append(Violation("H2-3", "hard",
                                         f"{s.id} 야간 연속 {length}일 (>3)",
                                         staff_id=s.id, day=max(start, 0)))
                if length < 2 and end != nd - 1:
                    out.append(Violation("H2-4", "hard",
                                         f"{s.id} {end+1}일 단독 야간(월말 아님)",
                                         staff_id=s.id, day=end))
            else:
                if length > s_max_len:
                    out.append(Violation("H2-3", "hard",
                                         f"{s.id} 야간 연속 {length}일 (>{s_max_len}, "
                                         f"{s_max_len}일 블록까지만 허용)",
                                         staff_id=s.id, day=max(start, 0)))
                if length < 2 and end != nd - 1:
                    out.append(Violation("H2-4", "hard",
                                         f"{s.id} {end+1}일 단독 야간(월말 아님)",
                                         staff_id=s.id, day=end))
            if length >= 2:
                for k in (1, 2):
                    d = end + k
                    if d < nd and sch.grid[s.id][d] not in REST_SHIFTS:
                        out.append(Violation(
                            "H2-5", "hard",
                            f"{s.id} 야간블록({end+1}일 종료) 후 {d+1}일 휴식 미확보",
                            staff_id=s.id, day=d))
    return out


def check_h2_night_cap(sch: MonthSchedule, base_cap: int) -> List[Violation]:
    out = []
    for s in sch.staff:
        if s.is_nk or s.is_partjang:
            continue
        n = sch.nights_in_month(s.id)
        cap = sch.night_cap(s.id, base_cap)
        if n > cap:
            out.append(Violation("H2-6", "hard",
                                 f"{s.id} 월 야간 {n}일 > 상한 {cap}일",
                                 staff_id=s.id))
        # n > base_cap 이지만 cap 이내인 경우는 H2-9 완화 적용분 — sch.logs에 기록됨
    return out


def night_quota_options(staff: Staff, params) -> tuple:
    """그 사람이 이번 달에 설 수 있는 야간 횟수 후보 — H6-4가 정확히 이 중 하나를 요구한다.

    보통은 하한/상한 두 가지(기본 4·6)다. **3N인 사람은 상한 하나뿐이다.**

    3일 블록으로 만들 수 있는 합은 3·6·9…뿐이라 하한 4를 못 맞춘다. 두 가지를 다
    열어두면 엔진이 4를 고른 순간 3일 블록이 불가능해져(3+? 로는 4가 안 된다) 2일
    블록으로 되돌아가고, 3N을 적은 사람에게 3N이 반영되지 않는다 — 오류도 경고도
    없이 그냥 안 되는, 이 프로젝트가 제일 싫어하는 부류다. 그래서 후보를 상한으로
    좁혀 6(=3+3)만 남긴다(파트장 확인).
    """
    lo, hi = params.night_quota_low, params.night_quota_high
    if staff.night_block_pref >= 3:
        return (hi,)
    return (lo, hi)


def check_h6_night_quota(sch: MonthSchedule, params) -> List[Violation]:
    """H6-4: 일반 간호사(야간 가능자)는 월 야간을 정확히 하한 또는 상한만
    (기본 4일 또는 6일, params.night_quota_low/high로 조정 가능, 야간전담 제외).
    3N인 사람은 상한만 — night_quota_options 참고."""
    out = []
    for s in sch.staff:
        if s.is_nk or s.is_partjang:
            continue
        if not s.can(Shift.N):
            continue
        n = sch.nights_in_month(s.id)
        opts = night_quota_options(s, params)
        if n not in opts:
            allowed = "일 또는 ".join(str(x) for x in opts) + "일"
            out.append(Violation("H6-4", "hard",
                                 f"{s.id} 월 야간 {n}일 ({allowed}만 허용)",
                                 staff_id=s.id))
    return out


def _day_work_blocks(sch: MonthSchedule, sid: str) -> List[tuple]:
    """(start, end) D/E/prn 연속근무 블록 목록 (0-based, 양끝 포함).

    전월에서 이어지는 경우 이월 carryover.consecutive_work_days만큼 시작점을
    앞으로 당겨 표현한다(night_blocks()와 동일 관례)."""
    blocks = []
    d = 0
    nd = sch.num_days
    grid = sch.grid[sid]
    co = sch.carryover[sid]
    base = sch.month_start_day.get(sid, 0)  # 월중 전입자는 입사일이 '이번 달 첫날'
    while d < nd:
        if grid[d] in DAY_WORK_SHIFTS:
            start = d
            while d + 1 < nd and grid[d + 1] in DAY_WORK_SHIFTS:
                d += 1
            end = d
            if start == base and co.last_shift_type in DAY_WORK_SHIFTS:
                start = base - co.consecutive_work_days
            blocks.append((start, end))
        d += 1
    return blocks


#: prn 계열이 섞인 주간 블록은 이만큼까지 이어도 된다(그 외는 4일).
DAY_BLOCK_MAX = 4
DAY_BLOCK_MAX_WITH_PRN = 5


def _day_block_cap(sch: MonthSchedule, sid: str, start: int, end: int) -> int:
    """이 블록의 연속근무 상한 — prn 계열이 하루라도 끼어 있으면 5일, 아니면 4일.

    prn·8A·9A·10A는 D/E보다 가볍게 보는 근무라 닷새를 이어도 된다는 판단이다
    (파트장 요청). '전부 prn일 때만'이 아니라 '하나라도 끼면'인 것도 요청대로다.

    전월에서 이어진 블록은 start가 음수가 될 수 있다(night_blocks와 같은 관례) —
    그 구간의 근무코드는 이번 달 그리드에 없으므로 0일부터 본다. 이월분이 prn이었는지는
    알 수 없지만, 모른다고 상한을 올려주면 못 본 것을 근거로 완화하는 셈이 된다."""
    row = sch.grid[sid]
    for d in range(max(start, 0), end + 1):
        if row[d] in PRN_LIKE_SHIFTS:
            return DAY_BLOCK_MAX_WITH_PRN
    return DAY_BLOCK_MAX


def check_h6_day_block_length(sch: MonthSchedule) -> List[Violation]:
    """H6-1: D/E/prn 연속근무 블록 길이는 3~4일만 (1~2일 단독, 5일 이상 금지).

    다만 블록 바로 다음날이 야간(N/NK)으로 이어지면 야간 시작 직전 준비 근무로
    보고 1~2일 단독은 예외로 허용한다 — "며칠 연속 주간근무"라는 규칙 취지가
    아니라 "야간 전환 직전에 낀 어중간한 하루짜리 조각"을 잡으려던 것인데,
    바로 야간으로 이어지면 그런 어중간함이 아니라는 판단(파트장 요청 반영).
    5일 이상 초과는 이 예외와 무관하게 여전히 위반이다."""
    out = []
    nd = sch.num_days
    for s in sch.staff:
        if s.is_partjang or s.is_nk:
            continue
        for (start, end) in _day_work_blocks(sch, s.id):
            length = end - start + 1
            cap = _day_block_cap(sch, s.id, start, end)
            if length > cap:
                out.append(Violation("H6-1", "hard",
                                     f"{s.id} 주간근무 연속 {length}일 (3~{cap}일만 허용)",
                                     staff_id=s.id, day=max(start, 0)))
            elif length < 3:
                next_is_night = end + 1 < nd and sch.grid[s.id][end + 1] in NIGHT_SHIFTS
                if not next_is_night:
                    out.append(Violation("H6-1", "hard",
                                         f"{s.id} 주간근무 연속 {length}일 (3~4일만 허용)",
                                         staff_id=s.id, day=max(start, 0)))
    return out


def check_h2_no_night(sch: MonthSchedule) -> List[Violation]:
    out = []
    for s in sch.staff:
        if not s.no_night:
            continue
        for d, v in enumerate(sch.grid[s.id]):
            if v in NIGHT_SHIFTS:
                out.append(Violation("H2-7", "hard",
                                     f"{s.id}(야간불가) {d+1}일 {v} 배정",
                                     staff_id=s.id, day=d))
    return out


def check_h2_patterns(sch: MonthSchedule) -> List[Violation]:
    """H2-8 금지패턴: ND/NE/N-8A/N-prn, NOD류, ONO. N=NK 포함."""
    out = []
    nd = sch.num_days
    day_work = {Shift.D, Shift.E, Shift.A8, Shift.A9, Shift.A10, Shift.PRN}
    for s in sch.staff:
        for d in range(nd):
            cur = sch.effective(s.id, d)
            p1 = sch.effective(s.id, d - 1)
            p2 = sch.effective(s.id, d - 2)
            if p1 in NIGHT_SHIFTS and cur in day_work:
                out.append(Violation("H2-8", "hard",
                                     f"{s.id} {d+1}일 N→{cur} 패턴",
                                     staff_id=s.id, day=d))
            if p2 in NIGHT_SHIFTS and p1 in REST_SHIFTS and cur in day_work:
                out.append(Violation("H2-8", "hard",
                                     f"{s.id} {d+1}일 N-O-{cur} 패턴",
                                     staff_id=s.id, day=d))
            # ONO: 단독야간이 휴무 사이에 낀 경우 (월말 단독은 다음날이 없어 제외)
            if (cur in NIGHT_SHIFTS and d + 1 < nd
                    and sch.effective(s.id, d - 1) in REST_SHIFTS
                    and sch.effective(s.id, d + 1) in REST_SHIFTS):
                # 전월에서 이어진 블록이면 단독이 아님(월중 전입자는 입사일 기준)
                base = sch.month_start_day.get(s.id, 0)
                if not (d == base and sch.carryover[s.id].trailing_night_count > 0):
                    out.append(Violation("H2-8", "hard",
                                         f"{s.id} {d+1}일 O-N-O 패턴",
                                         staff_id=s.id, day=d))
    return out


def check_h3_consecutive(sch: MonthSchedule, max_consecutive_work: int = 5) -> List[Violation]:
    """H3-1: 연속근무는 max_consecutive_work일 이하.

    파트장은 대상이 아니다 — assign_partjang()이 캘린더 기준(평일 8A)으로 고정
    배정하는 별도 역할이라 이 하드 규칙이 적용되는 candidate 선택 경로
    (can_assign_day/can_assign_night_block)를 아예 거치지 않는다. 기존
    기본값(5)이 마침 표준 평일 근무일수(월~금)와 같아서 우연히 드러나지 않았을
    뿐, 상한을 4 이하로 낮추면 파트장의 정상적인 5일 연속 평일 근무가 항상
    위반으로 잡히는 오탐이 된다 — 다른 하드 규칙들(H1-5/H4-2 등)과 동일하게
    파트장을 제외한다. NK(야간전담)도 이 경로를 타지 않고(assign_nk가 별도
    블록 계획으로 직접 배정) 블록 길이가 항상 2~3일이라 실질적 영향은 없지만,
    다른 규칙들과의 일관성을 위해 함께 제외한다."""
    out = []
    for s in sch.staff:
        if s.is_partjang or s.is_nk:
            continue
        for d in range(sch.num_days):
            if sch.effective(s.id, d) in WORK_SHIFTS:
                run = sch.work_run_ending(s.id, d)
                if run > max_consecutive_work:
                    out.append(Violation(
                        "H3-1", "hard",
                        f"{s.id} {d+1}일 기준 연속근무 {run}일 (>{max_consecutive_work})",
                        staff_id=s.id, day=d))
    return out


def check_h3_links(sch: MonthSchedule) -> List[Violation]:
    out = []
    for s in sch.staff:
        for d in range(1, sch.num_days):
            p = sch.effective(s.id, d - 1)
            c = sch.effective(s.id, d)
            if p == Shift.E and c in (Shift.D, Shift.PRN):
                out.append(Violation("H3-2", "hard",
                                     f"{s.id} {d+1}일 E→{c} 연결 금지",
                                     staff_id=s.id, day=d))
    return out


def check_h6_eod(sch: MonthSchedule) -> List[Violation]:
    """H6-3: EOD(이브닝-오프-데이) 금지 — E → 휴식 1일 → D 패턴 금지."""
    out = []
    for s in sch.staff:
        for d in range(sch.num_days):
            p2 = sch.effective(s.id, d - 2)
            p1 = sch.effective(s.id, d - 1)
            c = sch.effective(s.id, d)
            if p2 == Shift.E and p1 in REST_SHIFTS and c == Shift.D:
                out.append(Violation("H6-3", "hard",
                                     f"{s.id} {d+1}일 E-O-D(EOD) 패턴",
                                     staff_id=s.id, day=d))
    return out


def check_h4_min_off(sch: MonthSchedule, days: List[DayInfo]) -> List[Violation]:
    out = []
    lower = max(8, holiday_count(days) - 1)
    for s in sch.staff:
        if s.is_partjang or s.is_nk:
            continue
        off = sch.offs_in_month(s.id)
        if off < lower:
            out.append(Violation("H4-1", "hard",
                                 f"{s.id} 월 OFF {off}일 < 하한 {lower}일",
                                 staff_id=s.id))
    return out


#: 원치 않는(신청하지 않은) 연속 오프 상한 — 이 일수까지만 허용.
OFF_RUN_MAX_UNWANTED = 4
#: 신청 여부와 무관한 연속 오프 상한. 본인이 원티드로 전부 신청한 구간이라도 이보다
#: 길면 안 된다(파트장 요청) — 2주를 통째로 비우면 그 사람의 근무·야간 몫이 남은
#: 사람들에게 쏠리고, 돌아온 뒤 감각도 끊긴다. 15일부터 위반이다.
OFF_RUN_MAX = 14


def check_h4_off_run_length(sch: MonthSchedule) -> List[Violation]:
    """H4-2(원치 않는 연속 오프) / H4-3(신청했어도 너무 긴 연속 오프).

    H4-2: 원치 않는 연속 OFF/휴가(REST_SHIFTS)는 4일까지만 허용, 5일 이상이면 안 된다.
    H4-3: 신청 여부와 무관하게 15일 이상 이어지면 안 된다.

    두 번호를 나눈 이유는 **화면 색이 달라야 하기 때문**이다. H4-2는 최선노력 규칙이라
    노란 '추가 검토'로 뜬다 — 구조적으로 0을 못 만드는 달이 있어서다. H4-3은 다르다.
    파트장이 원티드표에서 그 구간을 나눠 신청하면 바로 없어지므로, 빨간 '필수 위반'으로
    떠서 눈에 걸려야 한다(_BEST_EFFORT_RULES에 넣지 않는 이유).

    본인이 실제로 신청/승인받은 구간(sch.wanted에 전부 포함된 연속 구간)은 원하는
    장기휴가로 보고 대상에서 뺀다 — 알고리즘이 그냥 채워 넣은 비자발적 장기휴식만
    잡아낸다.

    '휴'(휴직)는 쉬는 날이 아니라 '그 기간은 이 병동 인원이 아님'을 뜻하므로 아예
    세지 않고 구간을 끊는다. 월중 전입자의 입사 전 날짜와 휴직 발생 이후 날짜가
    전부 이 코드인데, 이걸 오프로 세면 "1~20일 연속 오프 20일"처럼 고칠 수도 없는
    위반이 사람마다 하나씩 붙는다(실제로 그랬다)."""
    out = []
    nd = sch.num_days
    for s in sch.staff:
        if s.is_partjang or s.is_nk:
            continue
        d = 0
        while d < nd:
            v = sch.grid[s.id][d]
            # 장기 부재(휴직·출산휴가 등)는 오프런에 넣지 않는다 — 파트장이 지정한
            # 부재를 '원치 않는 장기 OFF'로 잡으면 사람이 고칠 수도 없는 위반이 상시로
            # 붙는다. 예전엔 휴직(Shift.LEAVE)만 뺐는데, 출산휴가·육아휴직처럼 여러 날
            # 이어지는 코드가 들어오면서 같은 문제가 생겨 집합으로 넓혔다.
            if v in LONG_ABSENCE_SHIFTS or v not in REST_SHIFTS:
                d += 1
                continue
            start = d
            while d < nd and sch.grid[s.id][d] not in LONG_ABSENCE_SHIFTS \
                    and sch.grid[s.id][d] in REST_SHIFTS:
                d += 1
            end = d - 1
            length = end - start + 1
            if length >= OFF_RUN_MAX_UNWANTED + 1:
                wanted_all = all((s.id, dd) in sch.wanted for dd in range(start, end + 1))
                if not wanted_all:
                    out.append(Violation(
                        "H4-2", "hard",
                        f"{s.id} {start+1}~{end+1}일 연속 오프 {length}일 "
                        f"(원치 않는 연속 오프는 {OFF_RUN_MAX_UNWANTED}일까지만 허용, "
                        f"{OFF_RUN_MAX_UNWANTED + 1}일 이상이면 안 됨)",
                        staff_id=s.id, day=start))
                    continue
            # H4-3: 본인이 신청한 구간이라도 너무 길면 안 된다.
            if length > OFF_RUN_MAX:
                out.append(Violation(
                    "H4-3", "hard",
                    f"{s.id} {start+1}~{end+1}일 연속 오프 {length}일 — 신청한 "
                    f"휴가라도 연속 {OFF_RUN_MAX}일까지만 됩니다. 원티드표에서 이 구간을 "
                    "나눠 신청해주세요.",
                    staff_id=s.id, day=start))
    return out


SLEEP_OFF_NIGHT_THRESHOLD = 6  # 이 횟수 이상 야간을 서면 수면오프 1개


def check_h7_sleep_off(sch: MonthSchedule) -> List[Violation]:
    """H7-1: 월 야간(N/NK)이 6회 이상이면 수면오프(S/) 1개를 받는다.

    S/는 오프 하루를 대신 차지한다 — 근무일을 줄이는 게 아니라, 원래 오프였을
    하루가 S/로 바뀐다. 잔휴(연차 잔액)는 OFF만 차감하고 S/는 차감하지 않으므로,
    결과적으로 야간을 많이 선 사람의 잔휴가 하루 덜 깎이는 것이 이 규칙의 실질이다.

    파트장·야간전담(NK)은 제외한다 — 실제 병동 근무표(A9 2026-09, 42명)를 대조해
    보면 일반 간호사는 야간 6회에 S/ 1개가 8명 전원 예외 없이 붙는 반면, 야간을
    15회 서는 NK 2명은 S/가 0개다. 야간전담은 애초에 야간이 상시 업무라 이 보상의
    대상이 아니라는 뜻으로 읽었다.

    개수는 **정확히 1개**다 — 야간을 12회 서도 2개가 되지 않는다(파트장 확인).
    S/는 원티드로 신청할 수 없으므로(excel_input._WANTED_BLOCKED_CODES) 2개 이상은
    수기 편집으로만 생기며, 그때도 알려줘야 한다.

    기준 미만인데 S/가 있는 경우도 잡는다 — 야간 6회를 채우지 못한 사람에게 붙은
    S/는 근무일 하루가 근거 없이 사라진 것이라, 그대로 두면 그 사람만 조용히 덜
    일하게 된다."""
    out = []
    for s in sch.staff:
        if s.is_partjang or s.is_nk:
            continue
        nights = sch.nights_in_month(s.id)
        have = sum(1 for v in sch.grid[s.id] if v is Shift.SLEEP_OFF)
        want = 1 if nights >= SLEEP_OFF_NIGHT_THRESHOLD else 0
        if have == want:
            continue
        if want and not have:
            msg = (f"{s.id} 월 야간 {nights}회인데 수면오프(S/)가 없음 "
                   f"(야간 {SLEEP_OFF_NIGHT_THRESHOLD}회 이상이면 S/ 1개)")
        elif want:
            msg = (f"{s.id} 수면오프(S/) {have}개 — 야간이 몇 회든 1개입니다 "
                   f"(월 야간 {nights}회)")
        else:
            msg = (f"{s.id} 수면오프(S/) {have}개인데 월 야간이 {nights}회 "
                   f"({SLEEP_OFF_NIGHT_THRESHOLD}회 이상일 때만 붙습니다)")
        out.append(Violation("H7-1", "hard", msg, staff_id=s.id))
    return out


def check_h5_carryover(sch: MonthSchedule) -> List[Violation]:
    out = []
    for s in sch.staff:
        co = sch.carryover[s.id]
        # 이월정보는 '이번 달 첫날'에 붙는다 — 월중 전입자는 그게 입사일이다
        # (generator.apply_carryover()가 쓰는 month_start()와 같은 기준점).
        base = sch.month_start_day.get(s.id, 0)
        for k in range(base, base + co.night_block_remaining_off):
            if k < sch.num_days and sch.grid[s.id][k] not in REST_SHIFTS:
                out.append(Violation("H5-1", "hard",
                                     f"{s.id} 전월 야간 후 이월 OFF({k+1}일) 미확보",
                                     staff_id=s.id, day=k))
        if co.trailing_night_count == 1:
            # H5-2: 월말 단독야간 → 이번달 첫날부터 이어 2~3일 블록 완성
            if base < sch.num_days and sch.grid[s.id][base] not in NIGHT_SHIFTS:
                out.append(Violation("H5-2", "hard",
                                     f"{s.id} 전월 말 단독야간 미연결({base+1}일 야간 아님)",
                                     staff_id=s.id, day=base))
    return out


def all_hard_checks(sch: MonthSchedule, days: List[DayInfo], params) -> List[Violation]:
    out: List[Violation] = []
    out += check_h1_min_staff(sch, days, params.min_staff)
    out += check_h1_designated(sch, days, params.min_staff)
    out += check_h1_shift_rules(sch, days, params.leader_8a_as_prn)
    out += check_h1_level_balance(sch, days)
    out += check_h2_nk_quota(sch)
    out += check_h2_night_blocks(sch, params)
    out += check_h2_night_cap(sch, params.max_nights)
    out += check_h2_no_night(sch)
    out += check_h2_patterns(sch)
    out += check_h3_consecutive(sch, getattr(params, "max_consecutive_work", 5))
    out += check_h3_links(sch)
    out += check_h4_min_off(sch, days)
    out += check_h4_off_run_length(sch)
    out += check_h5_carryover(sch)
    out += check_h6_night_quota(sch, params)
    out += check_h6_day_block_length(sch)
    out += check_h6_eod(sch)
    out += check_h7_sleep_off(sch)
    return out


# ---------------------------------------------------------------- 소프트 제약

def _spread(values: List[int]) -> int:
    return (max(values) - min(values)) if values else 0


def _senior_pool_threshold(pool: List[Staff]) -> Optional[int]:
    """근무유형별 '고랩' 상대 레벨 기준선 (S6).

    파트마다 숙련도 분포가 달라 절대 레벨(예: Lv3+)을 고정하면 고레벨이
    적은 파트는 항상 위반이 나거나 순환이 불가능해진다. 대신 그 근무를
    할 수 있는 인력 풀 중 상위 30%를 '고랩군'으로 삼되, 그 결과 인원이
    3명 미만이면(순환을 못 돌릴 만큼 적으면) 최소 3명이 될 때까지(또는
    풀 전체를 다 쓸 때까지) 기준을 자동으로 넓힌다."""
    if not pool:
        return None
    levels = sorted((s.level for s in pool), reverse=True)
    n = len(levels)
    k = min(n, max(3, math.ceil(n * 0.3)))
    return levels[k - 1]


def check_soft(sch: MonthSchedule, days: List[DayInfo], params) -> List[Violation]:
    out: List[Violation] = []
    nd = sch.num_days
    generals = [s for s in sch.staff if not (s.is_partjang or s.is_nk)]
    night_eligible = [s for s in generals if s.can(Shift.N)]

    # S1: 일반 야간블록 간격 하한 7일
    for s in night_eligible:
        blocks = night_blocks(sch, s.id)
        for i in range(1, len(blocks)):
            gap = blocks[i][0] - blocks[i - 1][1] - 1
            if gap < 7:
                out.append(Violation("S1", "soft",
                                     f"{s.id} 야간블록 간격 {gap}일 (<7)",
                                     staff_id=s.id, day=blocks[i][0]))

    # S10: 근무일이 비정상적으로 적은 사람 — 원티드 오프는 최선노력이라 하드 제약이 없고
    # 월 OFF는 '하한'만 검사하므로(H4-1), 원티드표 한 행에 오프 표시를 쭉 붙여넣는 실수가
    # 그대로 통과해 그 사람이 한 달 통째로 빠져도 아무 표시가 안 났다. 배정 규칙을 바꾸는
    # 대신(많이 쉬는 것 자체는 위반이 아니다) 눈에 띄게 알려서 실수를 잡을 수 있게 한다.
    if len(generals) >= 3:
        workdays = {s.id: sch.workdays_in_month(s.id) for s in generals}
        vals = sorted(workdays.values())
        median = vals[len(vals) // 2] if len(vals) % 2 else (vals[len(vals) // 2 - 1] + vals[len(vals) // 2]) / 2
        for sid, wd in workdays.items():
            if wd == 0:
                out.append(Violation("S10", "soft",
                                     f"{sid} 이번 달 근무일 0일 — 오프 신청이 전부 반영됐습니다. "
                                     "원티드표에 오프 표시를 잘못 붙여넣지 않았는지 확인하세요.",
                                     staff_id=sid))
            elif median >= 8 and wd * 2 < median:
                out.append(Violation("S10", "soft",
                                     f"{sid} 근무일 {wd}일 — 다른 인원 중앙값({median:g}일)의 절반 미만입니다. "
                                     "오프 신청이나 휴가 표기를 확인하세요.",
                                     staff_id=sid))

    # S11: 신입(Lv1)끼리 같은 밤에 몰리지 않게 — 그 밤 병동의 대응 능력이 떨어진다.
    # 야간전담(NK)은 야간이 상시 업무라 이 판정에서 뺀다(파트장은 애초에 야간이 없다).
    # 소프트라 배정을 막지는 않는다 — 다른 후보가 없으면 그대로 배정되고 여기 표시만 남는다.
    for d in range(nd):
        lv1 = [s.id for s in generals
               if s.level == 1 and sch.grid[s.id][d] in NIGHT_SHIFTS]
        if len(lv1) >= 2:
            out.append(Violation(
                "S11", "soft",
                f"{d+1}일 야간에 숙련도 1 인원이 {len(lv1)}명 함께 배정 "
                f"({', '.join(lv1)}) — 신입끼리 같은 밤은 피하는 것이 좋습니다",
                day=d))

    # S12: 가능근무에 적은 야간 블록 선호(2N/3N)와 다른 길이로 배정된 경우.
    # 하드(H2-3)는 '상한'만 정한다 — 3N인 사람에게 3일이 허용될 뿐, 2일로 배정돼도
    # 하드 위반은 아니다. 그래서 여기서 남겨야 파트장이 "3N을 적었는데 왜 2일이지"를
    # 확인할 수 있다. 반대로 2N인 사람에게 3일이 가는 것도(목표가 홀수인 달에는
    # 가능하다) 같은 이유로 남긴다.
    for s in night_eligible:
        if not s.night_block_pref_set:
            continue              # 안 적은 사람은 대상이 아니다(위 주석 참고)
        for (start, end) in night_blocks(sch, s.id):
            length = end - start + 1
            if length < 2:
                continue          # 단독 야간은 H2-4가 이미 하드로 잡는다
            if length != s.night_block_pref:
                out.append(Violation(
                    "S12", "soft",
                    f"{s.id} {max(start, 0)+1}일 야간 {length}일 블록 "
                    f"(가능근무에 적은 선호는 {s.night_block_pref}일)",
                    staff_id=s.id, day=max(start, 0)))

    # S2/S3/S4/S5: 균등분배 지표 (편차 2 초과 시 soft 위반으로 기록)
    if night_eligible:
        sp = _spread([sch.nights_in_month(s.id) for s in night_eligible])
        if sp > 2:
            out.append(Violation("S2", "soft", f"야간 횟수 편차 {sp}일 (>2)"))
    if generals:
        sp = _spread([sch.offs_in_month(s.id) for s in generals])
        if sp > 2:
            out.append(Violation("S3", "soft", f"OFF 편차 {sp}일 (>2)"))
        sp = _spread([sch.workdays_in_month(s.id) for s in generals])
        if sp > 2:
            out.append(Violation("S4", "soft", f"총 근무일수 편차 {sp}일 (>2)"))
        weekend_days = [d for d, di in enumerate(days) if di.day_type != DAY_WEEKDAY]
        if weekend_days:
            woffs = [sum(1 for d in weekend_days
                         if sch.effective(s.id, d) in REST_SHIFTS)
                     for s in generals]
            sp = _spread(woffs)
            if sp > 2:
                out.append(Violation("S5", "soft", f"주말 OFF 편차 {sp}일 (>2)"))

    # S6: D/E/prn/N(확장) 각 근무 고랩(상대 상위 30%, 최소 3명 확보) 최소 1명
    senior_pools = {
        "D": [s for s in sch.staff if not s.is_partjang and s.can(Shift.D)],
        "E": [s for s in sch.staff if not s.is_partjang and s.can(Shift.E)],
        "prn": [s for s in sch.staff if not s.is_partjang and s.can(Shift.PRN)],
        "N": [s for s in sch.staff
              if not s.is_partjang and (s.is_nk or s.can(Shift.N))],
    }
    senior_threshold = {key: _senior_pool_threshold(pool)
                        for key, pool in senior_pools.items()}
    for d in range(nd):
        for key, shift in (("D", Shift.D), ("E", Shift.E),
                           ("prn", Shift.PRN), ("N", Shift.N)):
            workers = []
            for s in sch.staff:
                if s.is_partjang:
                    continue
                v = sch.grid[s.id][d]
                if shift == Shift.N and v in NIGHT_SHIFTS:
                    workers.append(s)
                elif shift == Shift.PRN and v in PRN_LIKE_SHIFTS:
                    workers.append(s)
                elif shift not in (Shift.N, Shift.PRN) and v == shift:
                    workers.append(s)
            th = senior_threshold[key]
            if workers and th is not None and not any(s.level >= th for s in workers):
                out.append(Violation("S6", "soft",
                                     f"{d+1}일 {key} 고랩(Lv{th}+) 없음", day=d))

    # S7: 퐁당퐁당 (O-근무-O)
    for s in generals:
        for d in range(nd):
            cur = sch.effective(s.id, d)
            if (cur in WORK_SHIFTS and cur not in NIGHT_SHIFTS
                    and sch.effective(s.id, d - 1) in REST_SHIFTS
                    and sch.effective(s.id, d + 1) in REST_SHIFTS):
                boundary = (d == 0 or d == nd - 1)
                out.append(Violation("S7", "soft",
                                     f"{s.id} {d+1}일 O-{cur}-O 퐁당퐁당"
                                     + (" (월경계)" if boundary else " (월중)"),
                                     staff_id=s.id, day=d))

    # S7-2: 2일짜리 고립 근무블록 (O-근무-근무-O)
    for s in generals:
        for d in range(nd - 1):
            cur = sch.effective(s.id, d)
            nxt = sch.effective(s.id, d + 1)
            if (cur in WORK_SHIFTS and cur not in NIGHT_SHIFTS
                    and nxt in WORK_SHIFTS and nxt not in NIGHT_SHIFTS
                    and sch.effective(s.id, d - 1) in REST_SHIFTS
                    and sch.effective(s.id, d + 2) in REST_SHIFTS):
                boundary = (d == 0 or d + 1 == nd - 1)
                out.append(Violation("S7-2", "soft",
                                     f"{s.id} {d+1}~{d+2}일 O-{cur}{nxt}-O 2일블록 고립"
                                     + (" (월경계)" if boundary else " (월중)"),
                                     staff_id=s.id, day=d))

    # S8: 신청 OFF 전날 야간 배제
    for (sid, d) in sorted(sch.requested_off):
        if d - 1 >= 0 and sch.effective(sid, d - 1) in NIGHT_SHIFTS:
            out.append(Violation("S8", "soft",
                                 f"{sid} 신청 OFF({d+1}일) 전날 야간 배정",
                                 staff_id=sid, day=d - 1))

    # S9: 일반 야간 3일 블록 수 (2일 우선 권장 — 정보성)
    three = sum(1 for s in night_eligible
                for (a, b) in night_blocks(sch, s.id) if b - a + 1 >= 3)
    if three:
        out.append(Violation("S9", "info", f"일반 간호사 3일 야간블록 {three}건 (2일 우선 권장)"))

    return out

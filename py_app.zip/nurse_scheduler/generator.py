# -*- coding: utf-8 -*-
"""근무표 생성 알고리즘 (설계서 §4 Step 0~9)."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from .calendar_utils import (
    DayInfo, DAY_WEEKDAY, build_calendar, holiday_count, min_staff_for,
)
from .constraints import (DAY_BLOCK_MAX, DAY_BLOCK_MAX_WITH_PRN, NIGHT_GAP_MIN,
                          OFF_RUN_MAX, _senior_pool_threshold, night_quota_options)
from .fairness import mix_gain, ward_band_share
from .models import (LEVEL_STAT_KEY, 
    Carryover, COUNTED_WORK_SHIFTS, MonthSchedule, Request, Shift, Staff,
    DAY_WORK_SHIFTS, DESIGNATED_KEY, LEAVE_SHIFTS, NIGHT_SHIFTS, PRN_LIKE_SHIFTS,
    REST_SHIFTS,
    WORK_SHIFTS, parse_shift,
)

# S6 고랩 판정용 근무유형 키 (constraints.check_soft의 S6와 동일 매핑)
# 표는 models.LEVEL_STAT_KEY 한 벌이다 — MonthSchedule의 증분 카운터와 여기 후보 점수가
# 같은 키로 세야 한다(따로 적으면 한쪽만 바뀌어 조용히 다른 값을 센다).
_SENIOR_SHIFT_KEY = LEVEL_STAT_KEY

# 근무유형별 레벨평균 소프트 튜닝의 가중치 — 무작위 tiebreak(0~1 균등분포)에 이
# 비율만큼만 격차를 얹어서, "항상 목표에 가장 가까운 후보"로 결정론적으로
# 쏠리지 않고 확률적으로만 살짝 선호하게 한다. 결정론적 tiebreak으로 두면
# 매일 같은 사람이 반복 선택돼 그 사람의 다른 근무일 가용성이 소진되면서
# 오히려 최소인력(H1-1) 위반이 늘어나는 부작용이 회귀 테스트로 확인됐다.
_LEVEL_NUDGE_WEIGHT = 0.15
#: 고연차(Lv4+·야간리더)의 월 야간 목표 합이 달의 밤 수의 몇 배가 되게 상한(6)을 주는가 — H1-5가 매일
#: 밤 고연차 한 명을 요구하므로 1.0으로는 틈이 난다(compute_night_targets).
_SENIOR_NIGHT_SLACK = 1.3
#: 시드마다 다른 탐색 전략 — 시드는 원래 후보 순서(셔플)와 동점 처리(난수)만 바꾸는데, 같은 전략의
#: 시드를 더 돌리는 것보다 전략이 다른 시드를 섞는 쪽이 같은 시간에 더 다른 후보를 만든다. 점수표가
#: 시드를 견주므로 어떤 전략이 그 달에 해로우면 그 시드가 안 뽑힐 뿐이다.
#:   W 주말·공휴일에 주말 몫을 블록 이어가기보다 먼저(주간 채우기)   S 주간 채우기에서 그 조의 Lv4+ 확보(H1-5)를
#:   숙련도·주말·형평성보다 먼저   B 1~2일째 주간 블록 이어가기를 모든 날에서 먼저(짧은 블록 H6-1을 줄임)
#:   L 그날 조 구성(레벨 띠) 가중치 ×3   '-' 기본(전략 없음)
#: 쉼표로 나눈 목록을 시드 번호 % 길이로 고른다. 기본 9개는 앞 셋이 기본 생성(시드 0·1·2), 아홉이 꼼꼼히
#: 찾기다. 기준선 201개×9시드 실측(docs/report_v0.86/bench/strategy_mix9_*.json, 2026-10-30)으로 정했다 —
#: 전략 섞기 9회는 같은 전략 9회보다 운영 필수 83→76·숙련도 1258→1213(전체 −0.4%, 공평성 +0.3%)이고, 앞 셋
#: "-,W,S"는 "-,-,W"보다 숙련도 −3.6%(운영 필수 같음, 달 단위 64 좋아짐·37 나빠짐). 전부 W로 두면 운영 필수
#: 92→95, L·BW는 효과 없음. NS_STRATEGY_MIX로 바꿔 비교한다(tools/bench_strategy.py). 사용자 결정 2026-10-30.
import os as _os
_STRATEGY_MIX = [x.strip() for x in _os.environ.get("NS_STRATEGY_MIX", "-,W,S,SW,SB,BW,-,-,-").split(",")]


def _strategy_for_seed(seed: int) -> frozenset:
    return frozenset(c for c in _STRATEGY_MIX[seed % len(_STRATEGY_MIX)] if c in "WSBL")


def strategy_label(seed: int) -> str:
    """점수표에 보이는 전략 글자(없으면 '-') — 어느 시드가 어떤 규칙으로 찾았는지 사용자가 볼 수 있게."""
    return "".join(c for c in "WSBL" if c in _strategy_for_seed(seed)) or "-"

#: 그날 조 평균을 맞추는 쪽의 가중치(_day_level_gap). 월 누적(_LEVEL_NUDGE_WEIGHT)보다
#: 세게 준다 — 월 누적은 이미 맞아 있는 경우가 많아 사실상 난수와 구분이 안 되는데,
#: 날짜별 쏠림은 바로 그 상태에서 생기기 때문이다. 다만 하드 규칙과 형평성(S2~S5)을
#: 침해하면 안 되므로 여전히 **최하위 동점 처리**에 얹는다(난수 0~1 위의 보정값).
#:
#: 값은 실측으로 골랐다. 샘플 병동(40명)에 실제 비율의 원티드를 섞어 10개월(2026-09~
#: 2027-06, 신청 920건)을 돌리고 0 / 0.3 / 0.6 / 1.0 / 1.5 / 2.0 / 3.0을 비교했다:
#:
#:                     0(끔)    1.0     1.5~3.0
#:   D조 레벨 폭        1.70    1.45    1.50~1.60
#:   D조 표준편차       0.429   0.354   0.356~0.375
#:   D에 고랩 없는 날   1.70    0.80    1.00~1.30
#:   하드 위반          52.0    50.8    49.8~50.0
#:   원티드 반영        902     910     905~908   (/920)
#:   근무일·OFF 편차   5.3·6.4  5.4·6.5  오차 범위
#:
#: 1.0에서 가장 좋고 그 위로는 더 나아지지 않는다(오히려 조금 나빠진다). 형평성
#: (근무일·OFF 편차)과 원티드 반영이 안 나빠지는 것을 같이 확인했다 — 레벨만 보고
#: 당기면 그 둘이 밀리는데, 최하위 동점 처리라 그렇지 않았다.
#:
#: ⚠ **주간 후보에만 넣었다.** 야간은 2~3일 블록으로 묶여 배정돼서 같은 보정을 넣으면
#: 블록 전체가 끌려간다 — 실측에서도 야간 지표는 전혀 안 움직였다(N폭 1.88 그대로).
#: 야간 쏠림은 따로 볼 문제다(파트장 요청 범위 밖).
_DAY_LEVEL_NUDGE_WEIGHT = 1.0
#: 야간판 _DAY_LEVEL_NUDGE_WEIGHT. 값은 아래에서 따로 잰다 — 주간 값을 그대로 쓰면 안 된다.
#:
#: v0.84에서 날짜별 보정을 넣을 때 야간은 일부러 뺐다("블록이 통째로 끌려간다").
#: 그 뒤 실측해 보니 야간 조의 날짜별 레벨 편차가 **무작위 배정과 구별되지 않았다** —
#: 같은 사람·같은 조 인원으로 날짜만 섞은 기준선 대비 0.97배(NK를 빼면 1.04배로
#: 오히려 더 나빴다). 주간은 같은 기준에서 0.84·0.86이다. 즉 야간에는 고르게 하는
#: 힘이 사실상 없었고, 1.00 근처로 보이던 것은 NK 두 명(Lv5·Lv4)이 매일 밤을
#: 받쳐준 결과였다. 같은 달 안에서 [1,2,2,2,3,3]인 밤과 [4,5,5,5,5,5]인 밤이
#: 사흘 차이로 나왔다.
#:
#: 블록이 끌려가는 문제는 **블록이 걸치는 날들의 평균 격차**를 쓰는 것으로 다룬다
#: (하루만 보면 첫날에만 맞추고 나머지 날은 방치된다).
#:
#: 값은 실측으로 골랐다. 샘플 병동(40명)에 실제 비율의 원티드를 섞어 12개월
#: (2026-09~2027-08)을 돌렸다:
#:
#:                     0(끔)   0.6     1.0     1.5
#:   야간 일별 편차      0.501   0.438   0.432   0.420
#:   근무별 평균 폭      0.310   0.301   0.295   0.320
#:   H1-5               19      18      23      25
#:   하드 계            596     624     618     590
#:
#: 0.6이 일별 편차로는 제일 좋았지만 **쓰지 않는다.** 인원이 적은 병동에서
#: 원티드가 반려된다 — 14명 병동(야간 가능자 소수)에서 신청 오프 한 건이
#: "생성 중 최소인력(H1-1) 충족 불가"로 돌아갔다. 야간 조는 5~6명뿐이라 한 명이
#: 평균을 크게 흔들어 보정값이 난수 tiebreak(0~1)을 압도하고, 그러면 매일 같은
#: 사람이 뽑혀 그 사람의 가용성이 소진되면서 엉뚱하게 최소인력이 깨진다.
#:
#: 0 / 0.1 / 0.2 / 0.3 / 0.45 / 0.6으로 재 보니 **0.2부터 그 반려가 나타난다** —
#: 완만한 트레이드오프가 아니라 절벽이다. 그래서 0.1을 쓴다. 레벨 고르기보다
#: 원티드 반영이 먼저다(파트장에게 바로 보이는 손해다).
#:
#: ⚠ 0.1로는 야간 편차가 많이 안 내려간다. 더 내리려면 가중치가 아니라 배정 구조를
#: 손봐야 한다 — 야간은 2~3일 블록 + 휴식 2일로 묶여 있어 '한 칸 바꾸기'가 안 되므로,
#: 고연차 블록을 먼저 깔아 달을 타일링하는 식의 사전 배치가 필요하다.
_NIGHT_DAY_LEVEL_NUDGE_WEIGHT = 0.1

#: 밤에 고연차가 비는 자리에서만, 간격(S1)이 이만큼은 되는 고연차에게 예외를 준다
#: (assign_nights의 senior_rescue 설명). 7일 기준은 constraints.NIGHT_GAP_MIN.
NIGHT_GAP_RESCUE_MIN = 5


@dataclass
class Params:
    nk_count: int = 0
    min_staff: Dict[str, Dict[str, int]] = field(default_factory=dict)
    leader_8a_as_prn: bool = False
    max_nights: int = 6            # H2-6 (입력키: off_max_per_month)
    holidays: List[str] = field(default_factory=list)
    substitute_holidays: List[str] = field(default_factory=list)
    advanced_track_staff: List[str] = field(default_factory=list)
    max_requests_per_person: int = 20  # §5 (입력엑셀에서는 안 받고 고정값만 씀)
    prn_cap_extra: int = 2             # 확정 #7: 하루 prn 최대 = 최소+2
    # B팀(신입) 이름만 — 스케줄링에는 전혀 관여하지 않고 출력 시 이름만 표시(§team_b)
    team_b_names: List[str] = field(default_factory=list)
    # H6-4 월 야간목표 하한/상한(일반 간호사, 야간전담 제외) — 기본 4/6일(2일블록만).
    # 상한을 홀수로 올리면(예: 7) 2일 블록만으로는 못 채우므로 3일 블록도 자동 허용된다
    # (assign_nights/_can_night_block 참고) — off_max_per_month(H2-6 상한)도 함께 올려야
    # 실제로 그 인원까지 배정될 수 있다.
    night_quota_low: int = 4
    night_quota_high: int = 6
    # H3-1 안전 규칙 — 연속근무 허용 일수 상한(이 값을 넘는 연속근무는 절대 배정하지
    # 않는다). 기본 5일(기존 동작과 동일). 병동별로 4일까지만 허용하고 싶으면 병동인력표(옛 입력①)
    # "설정" 시트의 "연속근무제한" 칸을 4로 바꾸면 된다 — 낮출수록 배치 자유도가
    # 줄어 §H6-1(주간 3~4일 블록) 등 최선노력 규칙이 더 자주 못 지켜질 수 있다.
    max_consecutive_work: int = 5

    @classmethod
    def from_dict(cls, d: dict) -> "Params":
        return cls(
            nk_count=int(d.get("nk_count", 0)),
            min_staff=d.get("min_staff", {}),
            leader_8a_as_prn=bool(d.get("leader_8a_as_prn", False)),
            max_nights=int(d.get("off_max_per_month",
                                 d.get("max_nights_per_month", 6))),
            holidays=d.get("holidays", []),
            substitute_holidays=d.get("substitute_holidays", []),
            advanced_track_staff=d.get("advanced_track_staff", []),
            max_requests_per_person=int(d.get("max_requests_per_person", 20)),
            prn_cap_extra=int(d.get("prn_cap_extra", 2)),
            team_b_names=d.get("team_b_names", []),
            night_quota_low=int(d.get("night_quota_low", 4)),
            night_quota_high=int(d.get("night_quota_high", 6)),
            max_consecutive_work=int(d.get("max_consecutive_work", 5)),
        )


class InputError(Exception):
    pass


def _nk_block_plan(total: int, start_with_three: bool = True) -> List[int]:
    """NK 월 목표 야간일수를 2일/3일 블록으로 최대한 비슷한 비율로 나눈다(S10 최선 근사).

    2*a + 3*b = total 을 만족하는 조합 중 |a-b|(2일/3일 블록 개수차)가 최소인 것을 고른다.
    (예: 15 → 2일 3개+3일 3개 정확히 1:1, 14 → 2일 4개+3일 2개가 최선의 근사)

    start_with_three: NK 인원이 여럿일 때 서로 다른 값을 줘서 근무/휴식 위상을
    엇갈리게 한다 — 위상이 같으면 여러 NK가 동시에 OFF인 날이 생겨 그날 일반
    간호사가 야간을 더 메워야 해 다른 근무 최소인력이 부족해지기 쉽다.
    """
    best = None
    for b in range(0, total // 3 + 1):
        rem = total - 3 * b
        if rem < 0 or rem % 2 != 0:
            continue
        a = rem // 2
        diff = abs(a - b)
        if best is None or diff < best[0]:
            best = (diff, a, b)
    if best is None:
        return [total] if total > 0 else []
    _, a, b = best
    plan: List[int] = []
    while a > 0 or b > 0:
        if start_with_three:
            if b > 0:
                plan.append(3)
                b -= 1
            if a > 0:
                plan.append(2)
                a -= 1
        else:
            if a > 0:
                plan.append(2)
                a -= 1
            if b > 0:
                plan.append(3)
                b -= 1
    return plan


class Generator:
    def __init__(self, config: dict,
                 fixed_cells: Optional[Dict[Tuple[str, int], Shift]] = None,
                 seed: int = 0):
        self.cfg = config
        self.fixed_cells = fixed_cells or {}
        self.seed = seed
        self.year = int(config["year"])
        self.month = int(config["month"])
        self.params = Params.from_dict(config.get("params", {}))
        self.staff = self._parse_staff(config["staff"])
        orig_order = {s.id: i for i, s in enumerate(self.staff)}  # 셔플 전 원본 순서
        import random
        self.rng = random.Random(seed)
        if seed:
            # 재시도 시 후보 순서·동순위 결정을 바꿔 다른 해를 찾는다 (Step 10 재시도)
            self.rng.shuffle(self.staff)
        carry = {sid: Carryover.from_dict(v)
                 for sid, v in (config.get("prev_month_carryover") or {}).items()
                 if sid in {s.id for s in self.staff}}
        self.sch = MonthSchedule(self.year, self.month, self.staff, carry,
                                 team_b=self.params.team_b_names)
        # 출력용 순서 고정 — self.staff는 seed>0일 때 섞여 있으므로, 출력 정렬은
        # 리스트 순서 대신 이 매핑을 참조해야 원본 입력 순서를 그대로 유지한다.
        self.sch.orig_staff_order = orig_order
        self.days: List[DayInfo] = build_calendar(
            self.year, self.month, self.params.holidays,
            self.params.substitute_holidays)
        self.sch.set_weekend_days(
            {i for i, di in enumerate(self.days) if di.day_type != DAY_WEEKDAY})
        self.requests: List[Request] = [
            Request(staff_id=r["staff_id"], date=r["date"],
                    type=parse_shift(r["type"]),
                    priority=int(r.get("priority", 1)))
            for r in (config.get("requests") or [])
        ]
        # 월중 전입자의 이번 달 첫 근무일(0-based). 입사 전 날짜는 우리 병동 소속이
        # 아니므로 배정에서 빼고, 잔휴도 재직 구간(입사일~말일)의 휴일수만 적립한다.
        # {staff_id: day_index} — 월초(1일자) 전입이나 계속 근무자는 여기 없다.
        self.transfer_in_day: Dict[str, int] = {}
        for sid, ds in (config.get("transfer_in_dates") or {}).items():
            if sid not in {s.id for s in self.staff}:
                continue
            try:
                y, m, d = (int(x) for x in str(ds)[:10].split("-"))
            except (TypeError, ValueError):
                continue
            if (y, m) == (self.year, self.month) and 1 < d <= self.sch.num_days:
                self.transfer_in_day[sid] = d - 1
        # 제약검사(constraints)는 Generator를 모르고 sch만 받으므로, month_start()와
        # 같은 기준점을 sch에도 실어 보낸다 — 안 그러면 월중 전입자의 이월 연결이
        # 검사 쪽에서만 끊겨, 생성기는 정상으로 보는 배치를 검사기가 위반으로 찍는다.
        self.sch.month_start_day = dict(self.transfer_in_day)
        self.nk_target = 14 if self.month == 2 else 15
        self.senior_threshold: Dict[str, Optional[int]] = {}
        # 근무유형(D/E/N/prn)별 평균 숙련도가 서로 골고루 맞춰지도록(요청사항) —
        # 병동 전체 평균(파트장 제외)을 목표로 두고, 배정 중 누적 평균-목표 격차가
        # 가장 작아지는 후보를 동점 상황에서 우선한다(최하위 우선순위 — 다른 배정
        # 기준을 침해하지 않음, H1-5와 같은 설계). 결과는 화면/출력 하단의
        # 레벨평균 표시(프론트엔드에서 그리드로부터 직접 계산)로 확인할 수 있다.
        self._staff_by_id = {s.id: s for s in self.staff}
        self._band_share = ward_band_share(self.staff)   # 조 구성 선호(mix_gain)의 병동 비율
        self._min_by_day: Dict[int, Dict[str, int]] = {}
        # 이 시도의 탐색 전략 — 시드마다 다르다(_strategy_for_seed, 파일 머리의 _STRATEGY_MIX). 점수표가
        # 시드를 견주므로, 어떤 전략이 그 달에 해로우면(주말을 고르게 하다 최소인력·지정이 깨지는 식) 그
        # 시드가 안 뽑힐 뿐이다. 그래서 전략은 '기본에 켜는 것'이 아니라 '시드 하나에 켜는 것'이다 — 전부
        # W로 켰을 때는 기준선 201개에서 운영 필수가 92→95로 늘고 샘플 명단에서 지정 0명인 날이 생겼다.
        self._strategy = _strategy_for_seed(seed)
        self._weekend_first = "W" in self._strategy
        self._senior_first = "S" in self._strategy
        self._block_first = "B" in self._strategy
        self._day_nudge_w = _DAY_LEVEL_NUDGE_WEIGHT * (3.0 if "L" in self._strategy else 1.0)
        self.holiday_count: int = holiday_count(self.days)
        # 레벨 내림차순(파트장 제외) — _lv3_guard_ok가 첫 매치에서 끝내기 위한 순서.
        # 같은 레벨끼리의 순서는 답(불리언)에 영향이 없다.
        self._staff_by_level_desc = sorted(
            (s for s in self.staff if not s.is_partjang), key=lambda s: -s.level)
        generals_for_avg = [s for s in self.staff if not s.is_partjang]
        self._shift_level_target = (
            sum(s.level for s in generals_for_avg) / len(generals_for_avg)
            if generals_for_avg else 0.0)

    def _shift_level_stats(self, key: str) -> Tuple[float, int]:
        """key 근무유형에 현재 배정된 인원(파트장 제외)의 레벨 합·인원수.

        예전엔 매번 그리드 전체를 훑었다. 생성기 안에서 손으로 더하고 빼는 증분
        방식은 수리(repair)가 셀을 지우고 다시 채울 때 어긋나 특정 후보를 계속
        선호하게 만드는 드리프트가 났기 때문이다(회귀 테스트로 발견). 지금은
        MonthSchedule이 모든 셀 쓰기를 가로채는 훅(_on_cell_change) 한 곳에서만
        갱신하므로 드리프트가 날 길이 없고, 스캔(인원×일수)이 조회 한 번이 됐다 —
        40명 병동에서 생성 시간의 절반이 이 스캔이었다. 값은 스캔과 같아야 한다
        (tests/test_level_stats_counters.py가 무작위 변경 뒤 스캔과 대조한다)."""
        return self.sch.level_stats(key)

    def _day_level_gap(self, cur_levels: List[int], level: int) -> float:
        """이 사람을 그날 그 조에 넣으면 조 평균이 병동 평균에서 얼마나 멀어지는가.

        작을수록 좋다. 조가 비어 있으면(첫 배정) 0을 돌려준다 — 첫 사람은 비교할
        대상이 없고, 여기서 레벨을 고르기 시작하면 H1-5(Lv4+ 확보)와 싸운다."""
        if not cur_levels:
            return 0.0
        new_avg = (sum(cur_levels) + level) / (len(cur_levels) + 1)
        return abs(new_avg - self._shift_level_target)

    def _night_block_level_gap(self, level: int, d: int, length: int) -> float:
        """이 사람을 d일부터 length일 야간 블록에 넣으면, 그 날들의 조 평균이
        병동 평균에서 평균 얼마나 멀어지는가. 작을수록 좋다.

        주간(_day_level_gap)과 달리 **여러 날을 한꺼번에** 본다 — 야간은 블록으로
        배정되므로 첫날만 맞추면 둘째·셋째 날은 아무도 안 보는 채로 남는다.
        비어 있는 날은 0으로 둔다(첫 사람은 비교 대상이 없고, 여기서 레벨을
        고르기 시작하면 H1-5와 싸운다 — _day_level_gap과 같은 이유).
        """
        gaps = []
        for k in range(length):
            day = d + k
            if day >= self.sch.num_days:
                break
            cur = [x.level for x in self.staff
                   if not x.is_partjang and self.sch.grid[x.id][day] in NIGHT_SHIFTS]
            gaps.append(self._day_level_gap(cur, level))
        if not gaps:
            return 0.0
        # 0~1로 가둔다. 이 값은 난수 tiebreak(0~1 균등분포) **위에** 얹는 보정이라,
        # 1을 넘으면 난수를 압도해 선택이 결정론적이 된다 — 그러면 매일 같은 사람이
        # 뽑혀 그 사람의 가용성이 소진되고, 엉뚱하게 최소인력(H1-1)이 깨진다.
        # 실제로 가두지 않았을 때 14명 병동에서 원티드 오프 한 건이 "최소인력 충족
        # 불가"로 반려됐다. 야간 조는 인원이 적어(5~6명) 한 명이 평균을 크게 흔들기
        # 때문에 주간보다 이 값이 쉽게 커진다.
        return min(1.0, sum(gaps) / len(gaps))

    def _level_gap_given(self, stats: Tuple[float, int], level: int,
                         weight: int = 1) -> float:
        """stats(=_shift_level_stats 결과)에 이 레벨을 weight만큼 더하면 병동
        전체 평균과의 격차가 얼마나 되는지 — 작을수록(0에 가까울수록) 그
        근무유형의 평균을 목표에 가깝게 만드는 배정이라는 뜻."""
        total, cnt = stats
        new_cnt = cnt + weight
        if new_cnt == 0:
            return 0.0
        new_avg = (total + level * weight) / new_cnt
        return abs(new_avg - self._shift_level_target)

    # ------------------------------------------------------------ S6 고랩 기준선
    def compute_senior_thresholds(self):
        """근무유형별 상대 고랩 기준선(constraints._senior_pool_threshold와 동일 정의)을
        미리 계산해둔다 — 배정 중 가드(_lv3_guard_ok)와 검증(check_soft)이 같은
        기준을 쓰도록 하기 위함."""
        pools = {
            "D": [s for s in self.staff if not s.is_partjang and s.can(Shift.D)],
            "E": [s for s in self.staff if not s.is_partjang and s.can(Shift.E)],
            "prn": [s for s in self.staff if not s.is_partjang and s.can(Shift.PRN)],
            "N": [s for s in self.staff
                  if not s.is_partjang and (s.is_nk or s.can(Shift.N))],
        }
        self.senior_threshold = {key: _senior_pool_threshold(pool)
                                 for key, pool in pools.items()}

    def _senior_min_level(self, shift: Shift) -> int:
        key = _SENIOR_SHIFT_KEY.get(shift)
        th = self.senior_threshold.get(key) if key else None
        return th if th is not None else 3

    # ------------------------------------------------------------ H6-4 목표
    def compute_night_targets(self):
        """야간 가능한 일반 간호사에게 이번 달 목표(기본 4일 또는 6일, params.night_quota_*
        로 조정 가능)를 배정한다.

        전월 누적 데이터(carryover.recent_night_score — 감쇠 이동평균)가 적은
        사람일수록 상한 목표를 받아 장기적으로 균등해지도록 한다(§전월 누적 기반)."""
        # 모두에게 공통으로 허용되는 블록 길이 상한(H2-3). 목표가 홀수면 2일만으로는
        # 정확히 못 채우므로 3일도 열린다.
        self._gen_max_block = 3 if (self.params.night_quota_low % 2
                                    or self.params.night_quota_high % 2) else 2
        eligible = [s for s in self.staff
                    if not (s.is_partjang or s.is_nk) and s.can(Shift.N)]
        # 후보로 **시도해볼** 길이 목록. 3N인 사람이 한 명이라도 있으면 3일도 시도한다
        # (그 사람에게만 허용되는지는 후보 안에서 사람별로 다시 거른다). 아무도 없으면
        # 예전과 똑같이 2일만 시도하므로 기존 근무표는 그대로다.
        any_three = any(s.night_block_pref >= 3 for s in eligible)
        self._night_block_lengths = ((2, 3) if (self._gen_max_block == 3 or any_three)
                                     else (2,))
        if not eligible:
            return
        ranked = sorted(
            eligible,
            key=lambda s: (self.sch.carryover[s.id].recent_night_score, s.id))
        # 상한(6) 목표를 몇 명에게 줄지는 **수요**로 정한다. 예전엔 무조건 반이었다 — 수요가 적은
        # 달에도 반이 6을 목표로 받아 채우지 못해(H6-4) 사람마다 야간이 2~6회로 벌어졌고, 수요가
        # 많은 달에는 반만 6이라 목표 초과 배정이 났다. 일반 간호사가 채울 밤 = 이번 달 야간
        # 최소인력 합 − 야간전담이 채우는 밤. 하한(4)×인원을 넘는 몫을 2씩 나눠 상한 목표 수로,
        # 지난달 적게 선 사람부터 받는다(누적 공평). 3N 선호자는 어차피 상한뿐이라 먼저 센다.
        demand = sum(self.min_for(d, "N") for d in range(self.sch.num_days))
        nk_cover = sum(1 for s in self.staff if s.is_nk and not s.is_partjang) * self.nk_target
        remaining = max(0, demand - nk_cover)
        lo, hi = self.params.night_quota_low, self.params.night_quota_high
        forced_hi = sum(1 for s in eligible if len(night_quota_options(s, self.params)) == 1)
        flexible = len(eligible) - forced_hi
        need_extra = remaining - lo * flexible - hi * forced_hi
        # 딱 맞추면 안 된다 — 휴가·원티드·간격(S1) 때문에 자기 목표를 다 못 채우는 사람이 꼭 있어,
        # 여유가 없으면 월말 밤이 비고 생성기가 간격 7일 완화(H2-9)로 2일 쉬고 다시 세운다(샘플
        # 명단 9월에서 실제로 났다). 채울 밤의 1할(최소 2일)을 여유로 얹는다 — 옛 '무조건 반'은
        # 여유가 과해 야간이 2~6회로 갈렸고, 여유 0은 간격이 깨진다.
        slack = max(2.0, 0.1 * remaining)
        step = max(1, hi - lo)
        six_count = min(flexible, max(0, -(-int(need_extra + slack) // step))) if need_extra + slack > 0 else 0
        # 고연차(Lv4+·야간리더)의 밤은 따로 센다 — H1-5가 **매일 밤** 그중 한 명을 요구하므로, 수요만
        # 보고 상한 인원을 줄이면 고연차 밤의 합이 달의 밤 수에 못 미쳐 H1-5가 는다(기준선 201개
        # 중 고연차가 드문 병동 60개에서 필수 위반이 +73 — 이 줄이 없을 때 실제로 그랬다). 야간전담
        # 고연차가 서는 밤은 빼고, 모자라는 몫은 고연차에게 상한을 먼저 준다(그 안에서는 지난달
        # 적게 선 사람부터). 수요로 정한 상한 인원 수가 그보다 적으면 고연차 쪽이 이긴다.
        def _senior(s):
            return s.level >= 4 or s.is_night_leader
        nk_senior_cover = sum(self.nk_target for s in self.staff
                              if s.is_nk and not s.is_partjang and _senior(s))
        senior_flex = [s for s in eligible if _senior(s) and len(night_quota_options(s, self.params)) > 1]
        senior_forced = sum(1 for s in eligible if _senior(s) and len(night_quota_options(s, self.params)) == 1)
        # 매일 밤 한 명 + 여유. 블록(2일)을 빈틈없이 잇는 건 불가능하고 휴가·원티드도 있어 여유 2일로는
        # 모자랐다(12개 최악 사례 206 vs 옛 규칙 164). 1.3배가 옛 '절반이 6'과 비슷한 고연차 밤을 준다.
        senior_need = max(0, int(self.sch.num_days * _SENIOR_NIGHT_SLACK) - nk_senior_cover)
        senior_extra = senior_need - lo * len(senior_flex) - hi * senior_forced
        senior_six = min(len(senior_flex), -(-senior_extra // step)) if senior_extra > 0 else 0
        # 수요가 하한(4×인원)에도 못 미치는 달엔 아무도 4를 못 채운다 — 그런 달에 고연차만 6을 주면
        # 목표가 큰 그 몇 명이 밤을 끌어모아(41명 병동에서 한 명이 6회, 나머지 1~2회) 근무일·OFF가
        # 갈린다. 상한을 줄 밤이 없으면 고연차도 안 준다.
        if six_count == 0:
            senior_six = 0
        given = 0
        senior_given = 0
        for i, s in enumerate(ranked):
            # 3N인 사람은 상한 하나뿐이다 — 3일 블록으로는 하한(기본 4)을 만들 수 없다.
            # constraints.night_quota_options와 같은 판단이라 그쪽을 그대로 부른다.
            opts = night_quota_options(s, self.params)
            if len(opts) == 1:
                self.sch.night_target[s.id] = opts[0]
                continue
            take = given < six_count or (_senior(s) and senior_given < senior_six)
            self.sch.night_target[s.id] = hi if take else lo
            if take:
                given += 1
                if _senior(s):
                    senior_given += 1

    # ------------------------------------------------------------ 입력 파싱
    @staticmethod
    def _parse_staff(raw: List[dict]) -> List[Staff]:
        staff = []
        for r in raw:
            staff.append(Staff(
                id=r["id"], role=r["role"], level=int(r.get("level", 1)),
                allowed_shifts=[parse_shift(x) for x in r.get("allowed_shifts", [])],
                flags=list(r.get("flags", [])),
            ))
        ids = [s.id for s in staff]
        if len(ids) != len(set(ids)):
            raise InputError("staff id 중복")
        return staff

    # ------------------------------------------------------------ 유틸
    def min_for(self, day: int, key: str) -> int:
        # 최소인력 표는 생성 중에 안 바뀐다. 요일별 덮어쓰기(weekday_by_dow)가 있으면
        # min_staff_for가 호출마다 dict를 새로 만드는데, 핫패스에서 수만 번 불린다 —
        # 날짜별로 한 번만 만들어 둔다. 값은 min_staff_for와 같다.
        by_day = self._min_by_day
        row = by_day.get(day)
        if row is None:
            row = by_day[day] = min_staff_for(self.days[day], self.params.min_staff)
        return row.get(key, 0)

    def _block_has_prn(self, sid: str, d: int, before: int, after: int) -> bool:
        """d를 넣었을 때 생기는 주간 블록 안에 prn 계열이 이미 들어 있는가.

        _day_block_cap(검사기)과 같은 질문이지만, 아직 d에 값을 넣기 전이라 그리드를
        그대로 읽을 수 없어서 앞뒤 길이로 구간을 잡아 본다."""
        row = self.sch.grid[sid]
        nd = self.sch.num_days
        for k in range(max(0, d - before), min(nd, d + after + 1)):
            if k != d and row[k] in PRN_LIKE_SHIFTS:
                return True
        return False

    def _cell_free(self, sid: str, d: int) -> bool:
        """배정 가능한 칸: 미배정이거나, 잠기지 않은 OFF."""
        if self.sch.is_locked(sid, d):
            return False
        v = self.sch.get(sid, d)
        return v is None or v == Shift.OFF

    def _is_rest_or_free(self, sid: str, d: int) -> bool:
        if d >= self.sch.num_days:
            return True
        v = self.sch.get(sid, d)
        return v is None or v in REST_SHIFTS

    def can_assign_day(self, s: Staff, d: int, shift: Shift) -> bool:
        """D/E/prn/8A(리더) 한 칸 배정 가능성 검사 (H1-3, H2-8, H3-1, H3-2)."""
        if s.is_partjang or s.is_nk:
            return False
        sch = self.sch
        sid = s.id
        # _cell_free 인라인(이 함수가 최다 호출 경로라 함수 호출 한 겹을 줄임 — 의미는 동일)
        if (sid, d) in sch.locked:
            return False
        v = sch.grid[sid][d]
        if v is not None and v != Shift.OFF:
            return False
        if shift == Shift.A8:
            # 엔진이 **스스로** 8A를 넣는 경우는 리더 운용 병동의 평일뿐이다. 규칙상
            # 주말 8A도 허용되지만(H1-2), 자동으로 주말까지 채우지는 않는다 —
            # 파트장이 원티드로 신청하거나 화면에서 직접 넣는 길은 열려 있다.
            if not (s.is_leader and self.params.leader_8a_as_prn
                    and self.days[d].auto_8a):
                return False
        elif shift not in s.allowed_shifts:
            return False
        # 연속근무: 앞뒤 이어진 근무와 합쳐 max_consecutive_work일 이하 (H3-1)
        base = self.month_start(sid)
        before = sch.work_run_ending(sid, d - 1) if d > base else \
            (sch.carryover[sid].consecutive_work_days
             if sch.carryover[sid].last_shift_type in WORK_SHIFTS else 0)
        after = sch.work_run_starting(sid, d + 1)
        total = before + 1 + after
        # 뒤 근무열이 월말 단독야간으로 끝나면 익월 1일 연장(H5-2) 예정 → +1
        nd = sch.num_days
        if d + 1 + after == nd and after > 0 \
                and sch.get(sid, nd - 1) in NIGHT_SHIFTS \
                and (nd < 2 or sch.get(sid, nd - 2) not in NIGHT_SHIFTS):
            total += 1
        if total > self.params.max_consecutive_work:
            return False
        # H6-1: 주간 연속블록 상한 (전용 카운트). prn 계열이 하루라도 끼면 5일까지다
        # — 검사기(_day_block_cap)와 같은 기준이어야 한다. 한쪽만 고치면 생성기가
        # 4일에서 막아 5일이 아예 안 만들어지거나(규칙을 풀어도 근무표가 안 바뀜),
        # 반대로 검사기가 못 잡아 5일이 그냥 통과한다.
        if shift in DAY_WORK_SHIFTS:
            day_before = sch.day_work_run_ending(sid, d - 1) if d > base else \
                (sch.carryover[sid].consecutive_work_days
                 if sch.carryover[sid].last_shift_type in DAY_WORK_SHIFTS else 0)
            day_after = sch.day_work_run_starting(sid, d + 1)
            cap = DAY_BLOCK_MAX
            if shift in PRN_LIKE_SHIFTS or self._block_has_prn(sid, d, day_before, day_after):
                cap = DAY_BLOCK_MAX_WITH_PRN
            if day_before + 1 + day_after > cap:
                return False
        # effective() 인라인(d-1/d-2가 이번 달 안이면 grid 직접 조회, 월경계만 이월 로직 사용)
        row = sch.grid[sid]
        if d >= 1:
            p1 = row[d - 1]
            if p1 is None:
                p1 = Shift.OFF
        else:
            p1 = sch.effective(sid, d - 1)
        if d >= 2:
            p2 = row[d - 2]
            if p2 is None:
                p2 = Shift.OFF
        else:
            p2 = sch.effective(sid, d - 2)
        # H2-8: N→주간, N-O→주간 금지
        if p1 in NIGHT_SHIFTS:
            return False
        if p2 in NIGHT_SHIFTS and p1 in REST_SHIFTS:
            return False
        # H3-2: E→D, E→prn
        if p1 == Shift.E and shift in (Shift.D, Shift.PRN, Shift.A8):
            return False
        # H6-3: EOD(E-O-D) 금지
        if p2 == Shift.E and p1 in REST_SHIFTS and shift == Shift.D:
            return False
        nxt = row[d + 1] if d + 1 < nd else None
        if shift == Shift.E and nxt in (Shift.D, Shift.PRN, Shift.A8):
            return False
        # H6-3: EOD(E-O-D) 금지 — 반대 방향(E를 놓았을 때 이틀 뒤에 이미 D가 있는 경우)
        if shift == Shift.E:
            nxt1 = Shift.OFF if nxt is None else nxt
            if d + 2 < nd:
                nxt2 = row[d + 2]
                if nxt2 is None:
                    nxt2 = Shift.OFF
            else:
                nxt2 = Shift.OFF
            if nxt1 in REST_SHIFTS and nxt2 == Shift.D:
                return False
        return True

    # ------------------------------------------------------------ Step 0
    def validate_input(self):
        p = self.params
        if not p.min_staff:
            raise InputError("params.min_staff 누락")
        for t in ("weekday", "saturday", "sunday_holiday"):
            if t not in p.min_staff:
                raise InputError(f"min_staff.{t} 누락")
        partjang = [s for s in self.staff if s.is_partjang]
        if len(partjang) > 1:
            raise InputError(
                f"파트장은 1명이어야 하는데 {len(partjang)}명입니다: "
                f"{', '.join(s.id for s in partjang)} — 인원 시트의 '직급' 칸을 확인하세요.")
        # 파트장 0명은 여기서 막지 않는다 — 파트장 개념 자체를 안 쓰는 최소 구성(테스트,
        # 일부 소규모 병동)도 유효한 입력이라서다. 실사용 흔적(엑셀 업로드로 만든 입력에
        # 파트장이 하나도 없는 경우 — 오타일 가능성이 높음)은 API 계층(pyodide-app/py/
        # bridge.py의 set_config)에서 경고로 별도 안내한다.
        nk_staff = [s for s in self.staff if s.is_nk]
        if len(nk_staff) != p.nk_count:
            raise InputError(
                f"nk_count={p.nk_count} 이지만 NK 전담 인원은 {len(nk_staff)}명")
        for s in nk_staff:
            if s.no_night:
                raise InputError(f"NK 전담 {s.id}에 야간불가 플래그")

        # 야간 슬롯 실현가능성: 총 야간수요 vs NK 공급 + 일반 야간역량
        # ⚠ 인원/설정 자체가 모순(위의 검사들)인 경우와 달리, 이건 "이 조건으로는
        # 이론상 100% 못 채운다"는 용량 부족일 뿐이다 — 여기서 생성을 막지 않고
        # 경고만 남긴 채 최대한 배정한다(최소인력 보존 우선, H1-1/H6-4로 잔여
        # 위반 표시). 실제 조정(인원 충원/상한 상향 등)은 리포트를 본 파트장이
        # 판단할 몫이다.
        total_night_slots = sum(self.min_for(d, "N")
                                for d in range(self.sch.num_days))
        nk_supply = len(nk_staff) * self.nk_target
        generals = [s for s in self.staff
                    if not (s.is_partjang or s.is_nk) and s.can(Shift.N)]
        capacity = sum(self.sch.night_target.get(s.id, p.max_nights)
                       for s in generals)
        if total_night_slots - nk_supply > capacity:
            self.sch.log(
                f"[경고] 이 조건으로는 야간 근무를 다 채울 수 없습니다 — 이번 달 야간 수요는 "
                f"{total_night_slots}칸인데, 야간전담 인원이 {nk_supply}칸을 채우고 나면 "
                f"나머지 일반 인원이 감당할 수 있는 야간은 최대 {capacity}칸뿐입니다. "
                "목표 상한을 넘겨서라도 최대한 배정하며(§3 H1-1 우선), 완전히 해소하려면 "
                "인원을 늘리거나 야간전담 인원수(NK)를 조정하거나 월최대야간 상한을 올려야 "
                "합니다 — 조정은 파트장 몫으로 남겨두고 우선 최선의 근무표를 만듭니다.")

        # 일별 총 최소인력 vs 가용 인원 (파트장 제외) — 마찬가지로 용량 부족은
        # 막지 않고 경고만 남긴다(그날은 구조적으로 최소인력을 못 채운다).
        head = len([s for s in self.staff if not s.is_partjang])
        for d in range(self.sch.num_days):
            need = sum(self.min_for(d, k) for k in ("D", "E", "N", "prn"))
            if need > head:
                self.sch.log(
                    f"[경고] 이 조건으로는 {d+1}일 최소인력을 다 채울 수 없습니다 — 필요한 "
                    f"합이 {need}명인데, 그날 배정 가능한 인원(파트장 제외)은 {head}명뿐입니다. "
                    "완전히 해소하려면 인원을 늘리거나 그날의 최소인력 기준을 낮춰야 합니다 — "
                    "조정은 파트장 몫으로 남겨두고 우선 최선의 근무표를 만듭니다.")

    # ------------------------------------------------------------ Step 0.5 (재생성)
    def apply_fixed(self):
        """리더 수정분 고정 배정. 이후 모든 스텝에서 이동 금지 (원티드보다 우선)."""
        for (sid, d), shift in sorted(self.fixed_cells.items()):
            if sid not in self.sch.by_id or not (0 <= d < self.sch.num_days):
                continue
            s = self.sch.by_id[sid]
            self.sch.set(sid, d, shift, lock=True)
            self.sch.wanted.add((sid, d))
            if shift == Shift.A8 and s.is_leader:
                self.sch.mark_leader_8a(sid, d)
            self.sch.log(f"[수정고정] {sid} {d+1}일 = {shift}")
            # ⚠ 예전에는 '휴'가 들어오면 그 달 나머지 날짜를 전부 '휴'로 채워 배정에서
            # 뺐다(휴직으로 해석). 지금은 채우지 않는다 — 파트장이 지정한 그 날만
            # 제외한다. 병원 OCS에서 '휴'는 하루짜리 단기부모휴가이고, 진짜 휴직은
            # 사·상·산전·육법·육연·R로 따로 있다. 하루 휴가를 휴직으로 읽으면 그 사람이
            # 한 달 내내 근무표에서 사라지는데, 오류도 안 나서 알아채기 어려웠다.
            # 여러 날 쉬는 경우는 파트장이 그 날들을 각각 표시한다.

    def complete_partial_night_blocks(self):
        """수정으로 생긴 단독 야간을 2~3일 블록으로 보완하고 뒤 휴식 2일 확보 (H2-4/H2-5)."""
        nd = self.sch.num_days
        for s in self.staff:
            d = 0
            while d < nd:
                if self.sch.get(s.id, d) not in NIGHT_SHIFTS:
                    d += 1
                    continue
                start = d
                while d + 1 < nd and self.sch.get(s.id, d + 1) in NIGHT_SHIFTS:
                    d += 1
                end = d
                length = end - start + 1
                carry_head = (start == self.month_start(s.id)
                              and self.sch.carryover[s.id].trailing_night_count > 0)
                night = Shift.NK if s.is_nk else Shift.N
                if length == 1 and end != nd - 1 and not carry_head:
                    if self._cell_free(s.id, end + 1):
                        self.sch.set(s.id, end + 1, night, lock=True)
                        end += 1
                        self.sch.log(f"[보완] {s.id} {end+1}일 {night} — 단독야간 블록화(H2-4)")
                    elif start > 0 and self._cell_free(s.id, start - 1) and \
                            self.sch.effective(s.id, start - 2) not in NIGHT_SHIFTS:
                        self.sch.set(s.id, start - 1, night, lock=True)
                        self.sch.log(f"[보완] {s.id} {start}일 {night} — 단독야간 블록화(H2-4)")
                if end - start + 1 >= 2 or carry_head:
                    for k in (1, 2):
                        dd = end + k
                        if dd < nd and self._cell_free(s.id, dd):
                            self.sch.set(s.id, dd, Shift.OFF, lock=True)
                d = end + 1

    # ------------------------------------------------------------ Step 1
    def lock_pre_join_days(self):
        """월중 전입자의 입사 전 날짜를 배정 대상에서 뺀다.

        그 기간은 우리 병동 소속이 아니므로 근무를 넣으면 안 되고, 최소인력 집계에도
        들어가면 안 된다. 코드는 '휴'(휴직)를 쓴다 — 이미 "그 기간은 이 병동 인력이
        아님"을 뜻하는 코드이고, OFF가 아니라서 순수오프(잔휴 차감)로도, 근무일수로도
        세어지지 않아 통계가 왜곡되지 않는다(반대 방향인 '휴직 발생일부터 월말까지
        제외'와 대칭)."""
        for sid, first_day in self.transfer_in_day.items():
            for d in range(first_day):
                if not self.sch.is_locked(sid, d):
                    self.sch.set(sid, d, Shift.LEAVE, lock=True)
            self.sch.log(f"[전입] {sid} {first_day + 1}일 입사 — 이전 {first_day}일 배정 제외")

    def working_holiday_count(self, sid: str) -> int:
        """그 사람의 이번 달 재직 구간에 속한 휴일수(토/일/공휴일).

        월중 전입자는 입사일부터만 센다 — 잔휴는 전 병동이 입사 전날까지 정산해
        넘겨준 숫자에서 이어받으므로, 우리 병동은 재직한 기간분만 적립해야 이중
        계산이 되지 않는다. 계속 근무자는 월 전체(기존과 동일)."""
        first = self.transfer_in_day.get(sid)
        if first is None:
            return holiday_count(self.days)
        return sum(1 for di in self.days[first:] if di.day_type != DAY_WEEKDAY)

    def month_start(self, sid: str) -> int:
        """그 사람의 '이번 달 첫날' 인덱스 — 이월정보를 적용하는 기준점.

        보통은 1일(0)이지만 월중 전입자는 입사일이다. 전입자의 이월정보는 전 병동의
        '입사 전날'까지를 역산한 값이라, 1일 기준으로 적용하면 입사 전(배정 제외된)
        날짜에 흡수돼 사라진다 — 전 병동에서 야간을 서고 온 사람에게 입사 첫날부터
        야간이 또 들어가는 식이 된다. 월경계를 다루는 자리는 0 대신 이 값을 쓴다."""
        return self.transfer_in_day.get(sid, 0)

    def staffing_pressure(self) -> dict:
        """이 입력이 얼마나 빠듯한지 — 압박률과 근거 숫자를 돌려준다(모듈 주석 참고).

        수요: 이번 달 최소인력을 전부 채우는 데 필요한 인원-일 (8A는 파트장 전용이라 제외).
        공급: 파트장을 뺀 인원이 실제로 근무에 낼 수 있는 인원-일. 월중 전입자는 입사 전
              날짜에 배정될 수 없으므로 그만큼 빼고(month_start), 누구나 H4-1로 월 최소
              휴무일(max(8, 휴일수-1))은 반드시 쉬므로 그것도 뺀다.
        """
        nd = self.sch.num_days
        demand = sum(self.min_for(d, k)
                     for d in range(nd) for k in ("D", "E", "N", "prn"))
        min_off_full = max(8, holiday_count(self.days) - 1)
        workers = [s for s in self.staff if not s.is_partjang]
        supply = 0
        for s in workers:
            avail = nd - self.month_start(s.id)      # 월중 전입자는 입사일부터
            if avail <= 0:
                continue
            # 월중 전입자의 최소 휴무일은 재직일수에 비례해 본다(H4-1은 월 단위 기준이라
            # 한 달을 다 다니지 않은 사람에게 그대로 적용하면 공급을 과소평가한다).
            min_off = min_off_full if avail >= nd else round(min_off_full * avail / nd)
            supply += max(0, avail - min_off)
        # 수요가 0이면(최소인력을 전부 0으로 둔 달) 공급이 얼마든 부족할 게 없다.
        # 이걸 안 걸러내면 '0인원-일이 필요한데 0인원-일뿐이라 위반이 반드시 남는다'는
        # 앞뒤 안 맞는 안내가 나간다 — 드문 입력이라 더더욱 아무도 못 잡는다.
        if demand == 0:
            ratio = 0.0
        elif supply:
            ratio = demand / supply
        else:
            ratio = float("inf")   # 쓸 사람이 아예 없는데 채울 건 있다 = 최악
        level = _pressure_level(ratio)
        return {
            "demand": demand,
            "supply": supply,
            "ratio": round(ratio, 3) if ratio != float("inf") else None,
            "level": level,
            "workers": len(workers),
            "num_days": nd,
            "min_off": min_off_full,
            "message": _pressure_message(level, demand, supply),
            "designated": self.designated_feasibility(min_off_full),
            "bounds": self.feasibility_bounds(),
        }

    def designated_feasibility(self, min_off_full: int) -> dict:
        """지정 인원(H1-6)을 산술적으로 채울 수 있는지 — 생성 전에 미리 본다.

        지정은 하드 규칙이라 못 채우면 위반이 남는데, **인원이 부족해서 못 채우는
        경우는 몇 번을 다시 돌려도 안 된다.** 지정 가능자가 2명인데 매일 2명이
        필요하면 그 둘이 한 달 내내 근무해야 하고, 그건 월 최소 휴무일(H4-1)과
        정면으로 부딪혀 산술적으로 불가능하다. 실제 운영 규모가 1~3명이라 충분히
        일어날 수 있는 일이라, 생성을 돌려 몇 십 초를 기다린 끝에 위반을 보는 대신
        시작 전에 알려준다.

        need(전체 필요 인원-일)와 capacity(지정 가능자들이 낼 수 있는 인원-일)를
        비교한다. capacity 계산은 staffing_pressure의 공급 계산과 같은 방식이다.
        """
        nd = self.sch.num_days
        need = sum(self.min_for(d, DESIGNATED_KEY) for d in range(nd))
        people = [s for s in self.staff if not s.is_partjang and s.is_designated]
        capacity = 0
        for s in people:
            avail = nd - self.month_start(s.id)
            if avail <= 0:
                continue
            min_off = min_off_full if avail >= nd else round(min_off_full * avail / nd)
            # 야간을 서는 사람은 그 뒤 이틀이 의무 휴식이고, 야간이 6회 이상이면
            # 수면오프가 하루 더 붙는다. 이 날들은 '쉬는 날'로는 안 세지만 근무를
            # 세울 수 없는 날이라, 안 빼면 낼 수 있는 인원-일이 실제보다 부풀려진다.
            # 지정 가능자 2명 병동이 "가능"으로 통과한 뒤 달마다 3~6일을 못 채웠던
            # 것이 이 부풀림 때문이었다.
            rest = 0
            if s.can(Shift.N) and not s.is_nk:
                nights = self.params.night_quota_high
                rest = 2 * max(1, nights // 2)      # 블록마다 이틀씩
                if nights >= 6:
                    rest += 1                        # 수면오프(H7-1)
            capacity += max(0, avail - min_off - rest)
        max_need_per_day = max((self.min_for(d, DESIGNATED_KEY) for d in range(nd)),
                               default=0)
        # 하루 평균으로 몇 명을 세울 수 있는가 — 총량이 맞아도 이 값이 필요 인원에
        # 바짝 붙어 있으면, 야간·휴식·오프가 겹치는 날에 반드시 빵꾸가 난다.
        per_day = capacity / nd if nd else 0.0
        message = ""
        if need:
            if len(people) < max_need_per_day:
                message = (f"지정 인원이 모자랍니다 — 하루에 최대 {max_need_per_day}명이 "
                           f"필요한데 가능근무에 '지정'을 적은 사람은 {len(people)}명뿐입니다. "
                           "명단의 가능근무 칸을 확인하거나 근무인력 표의 '지정' 값을 "
                           "낮춰주세요.")
            elif need > capacity:
                message = (f"지정 인원을 다 채울 수 없습니다 — 이번 달에 {need}인원-일이 "
                           f"필요한데 지정 가능자 {len(people)}명이 낼 수 있는 건 "
                           f"{capacity}인원-일뿐입니다(월 최소 휴무 {min_off_full}일과 "
                           "야간 뒤 휴식을 뺀 값). "
                           "지정 가능자를 늘리거나 근무인력 표의 '지정' 값을 낮춰야 합니다.")
            elif per_day < max_need_per_day + 0.5:
                # 총량은 되는데 여유가 없는 경우. 되돌려보내지 않고 경고만 한다 —
                # 실제로 대부분의 날은 채워지고, 며칠만 못 채운다. 다만 "가능"이라고
                # 말해놓고 하드 위반을 내미는 것이 제일 나쁘므로 미리 말한다.
                message = (f"지정 인원이 빠듯합니다 — 하루 평균 세울 수 있는 지정 가능자가 "
                           f"{per_day:.1f}명인데 필요한 건 {max_need_per_day}명입니다. "
                           "야간·야간 뒤 휴식·휴무가 겹치는 날은 못 채워 위반이 남을 수 "
                           "있습니다(그런 날은 화면에서 직접 바꿔주셔야 합니다). "
                           "지정 가능자를 한두 명 더 두시면 여유가 생깁니다.")
        return {
            "need": need, "capacity": capacity, "people": len(people),
            "max_per_day": max_need_per_day, "per_day": round(per_day, 2),
            "ok": not message,
            "message": message,
        }

    def feasibility_bounds(self) -> dict:
        """어떤 배정으로도 남을 수밖에 없는 필수 위반의 하한 — 생성 전에 센다.

        왜 필요한가. 못 찾은 것과 풀 수 없는 것은 다르다. 야간에 설 수 있는 숙련도 4 이상이
        한 명뿐인 병동은 31밤 중 23밤이 어떤 엔진으로도 빈다 — 그런 달에 "재시도"는 시간만
        쓰고, 파트장은 "왜 빨간 게 남지"만 본다. 하한이 있으면 ① 그 수에 닿는 순간 재시도를
        멈출 수 있고(generate_best) ② "이건 인원 문제다, 야간리더를 지정하거나 고연차를
        늘려야 풀린다"를 생성 전에 말할 수 있다.

        하한은 **절대 실제 최소보다 커서는 안 된다**(그러면 더 좋은 표를 두고 멈춘다). 그래서
        사람이 낼 수 있는 야간 수는 규칙상 최대(H2-6 상한 + H2-9 완화 최대 2, 야간전담은
        H2-2 고정값)로 넉넉히 잡고, 휴가·이월 휴식처럼 실제로는 더 줄이는 요인은 안 뺀다.
        느슨한 하한은 안전하고, 빠듯한 하한은 틀리면 위험하다.

        돌려주는 값:
          h15_floor       — H1-5(조마다 숙련도 4 이상) 위반의 하한(밤 + 낮)
          h15_night_floor — 그중 야간 몫과 근거(사람 수·낼 수 있는 밤 수)
          supply_short    — 자격자가 최소인력보다 적은 (날짜, 근무) — H1-1이 반드시 남는 자리
          message         — 파트장에게 보여줄 문장(없으면 빈 문자열)
        """
        nd = self.sch.num_days
        # 야간: 그 밤을 채울 수 있는 사람(숙련도 4 이상 또는 야간리더)이 낼 수 있는 밤의 합
        cap_total, people = 0, 0
        for s in self.staff:
            if s.is_partjang or not (s.level >= 4 or s.is_night_leader):
                continue
            if s.is_nk:
                cap = self.nk_target
            elif s.can(Shift.N):
                cap = self.params.max_nights + 2      # H2-9 완화 최대(relax 3 → +2)
            else:
                continue
            avail = nd - self.month_start(s.id)
            if avail <= 0:
                continue
            cap_total += min(cap, avail)
            people += 1
        # 야간 최소인력이 0인 밤은 아무도 안 서므로 H1-5 대상이 아니다
        night_days = sum(1 for d in range(nd) if self.min_for(d, "N") > 0)
        night_floor = max(0, night_days - cap_total)
        # 낮: D·E를 설 수 있는 숙련도 4 이상이 아예 없으면 그 근무가 필요한 날마다 남는다
        day_floor = {}
        for key, shift in (("D", Shift.D), ("E", Shift.E)):
            if any(s.level >= 4 and not s.is_partjang and not s.is_nk and s.can(shift)
                   for s in self.staff):
                continue
            day_floor[key] = sum(1 for d in range(nd) if self.min_for(d, key) > 0)
        # 자격자 수 < 최소인력 — 그 (날짜, 근무)는 어떤 배정으로도 H1-1이 남는다
        supply_short = []
        for d in range(nd):
            for key, shift in (("D", Shift.D), ("E", Shift.E), ("N", Shift.N), ("prn", Shift.PRN)):
                need = self.min_for(d, key)
                if need <= 0:
                    continue
                have = sum(1 for s in self.staff
                           if not s.is_partjang and self.month_start(s.id) <= d
                           and (s.can(shift) or (shift == Shift.N and s.is_nk)))
                if have < need:
                    supply_short.append({"day": d + 1, "key": key, "need": need, "have": have})
        # 종합 하한 — 사람은 하루에 한 조만 덮는다. 덮어야 할 (날, 조) 수에서 숙련도 4 이상·야간리더가
        # 낼 수 있는 사람·일 수(그 달의 재직일, 휴가·휴무를 안 빼 넉넉하게)를 뺀 값. 밤·낮 하한이 둘 다
        # 0인 고연차 희소 병동(Lv4+ 두 명이 D·E·N 세 조를 매일 덮을 수 없는 곳)을 잡는다 — 기준선
        # 201개에서 그런 달이 99개였고 "하한 0인데 실제 50건"이라 파트장이 고칠 수 있는 줄 알게 된다.
        # 느슨한 쪽으로만 틀린다(실제 최소보다 작거나 같다): 한 사람이 여러 조를 덮는 날은 없고,
        # 재직일 전부를 근무일로 쳐 준다.
        teams = sum(1 for d in range(nd) for key in ("D", "E", "N") if self.min_for(d, key) > 0)
        cover = sum(nd - self.month_start(s.id) for s in self.staff
                    if not s.is_partjang and (s.level >= 4 or s.is_night_leader)
                    and self.month_start(s.id) < nd)
        combined_floor = max(0, teams - cover)
        msgs = []
        if combined_floor > night_floor + sum(day_floor.values()):
            msgs.append(f"숙련도 4 이상·야간리더가 이번 달 낼 수 있는 근무일이 모두 {cover}일인데 D·E·N 조는 "
                        f"{teams}조·일이라, 최소 {combined_floor}조는 어떤 배정으로도 고연차 없이 남습니다(H1-5). "
                        "다시 생성해도 이 수 아래로는 내려가지 않습니다 — 고연차를 늘리거나 야간리더 표시를 "
                        "쓰는 수밖에 없습니다.")
        if night_floor:
            msgs.append(f"야간에 설 수 있는 숙련도 4 이상·야간리더가 {people}명이라 이번 달 "
                        f"{night_days}밤 중 최소 {night_floor}밤은 어떤 배정으로도 비게 됩니다"
                        "(H1-5). 가능근무 칸에 '야간리더'를 지정하거나 야간 가능한 고연차를 "
                        "늘려야 풀립니다 — 다시 생성해도 이 수 아래로는 내려가지 않습니다.")
        for key, n in day_floor.items():
            if n:
                msgs.append(f"{key} 근무를 설 수 있는 숙련도 4 이상이 없어 {key}가 필요한 {n}일은 "
                            f"어떤 배정으로도 H1-5가 남습니다.")
        if supply_short:
            head = ", ".join(f"{x['day']}일 {x['key']} {x['have']}명<{x['need']}명"
                             for x in supply_short[:4])
            more = f" 외 {len(supply_short) - 4}곳" if len(supply_short) > 4 else ""
            msgs.append(f"설 수 있는 사람 자체가 최소인력보다 적은 날이 있습니다 — {head}{more}. "
                        "가능근무 칸이나 근무인력 표를 확인해주세요.")
        return {
            "h15_floor": max(night_floor + sum(day_floor.values()), combined_floor),
            "h15_night_floor": {"floor": night_floor, "people": people, "capacity": cap_total,
                                "night_days": night_days},
            "h15_day_floor": day_floor,
            "h15_combined_floor": {"floor": combined_floor, "teams": teams, "capacity": cover},
            "supply_short": supply_short,
            "message": " ".join(msgs),
        }

    def apply_carryover(self):
        for s in self.staff:
            co = self.sch.carryover[s.id]
            base = self.month_start(s.id)
            # H5-1: 야간블록 후 이월 OFF
            for k in range(base, min(base + co.night_block_remaining_off, self.sch.num_days)):
                if self.sch.get(s.id, k) is None:
                    self.sch.set(s.id, k, Shift.OFF, lock=True)
                elif self.sch.get(s.id, k) not in REST_SHIFTS:
                    self.sch.log(f"[H5-1 충돌] {s.id} {k+1}일: 이월 OFF 자리에 "
                                 f"{self.sch.get(s.id, k)} 고정 배정 존재")
            # H5-2: 월말 단독(또는 미완) 야간블록 연결
            t = co.trailing_night_count
            if t <= 0:
                continue
            night = Shift.NK if s.is_nk else Shift.N
            target_len = 3 if s.is_nk else 2
            extend = max(0, min(target_len - t, 3 - t))
            d = base
            for _ in range(extend):
                if d < self.sch.num_days:
                    cur = self.sch.get(s.id, d)
                    if cur is None or cur in NIGHT_SHIFTS:
                        self.sch.set(s.id, d, night, lock=True)
                    else:
                        self.sch.log(f"[H5-2 충돌] {s.id} {d+1}일: 야간 연결 자리에 "
                                     f"{cur} 고정 배정 존재")
                    d += 1
            # 블록 종료 후 필수 OFF 2일 (H2-5)
            if t + extend >= 2 or extend > 0:
                for k in range(2):
                    if d + k < self.sch.num_days and \
                            self.sch.get(s.id, d + k) is None:
                        self.sch.set(s.id, d + k, Shift.OFF, lock=True)
            if extend:
                self.sch.log(f"[H5-2] {s.id}: 전월 야간 {t}일 → 이번달 {extend}일 연장 연결")

    # ------------------------------------------------------------ Step 2
    def _partjang_rest_requests(self) -> Dict[Tuple[str, int], Shift]:
        """파트장이 입력①에 적어 낸 휴가·휴무 신청 — (직원, 날짜) → 근무코드.

        파트장 행은 아래에서 평일 8A로 통째로 채워지는데, 그게 신청 반영(Step 4)보다
        먼저다. 그래서 파트장이 연차를 적어 내면 Step 4에서 "고정 배정과 충돌(8A)"로
        반려됐다 — 파트장도 연차·병가를 쓰는데 그걸 근무표에 넣을 길이 없었다는 뜻이다.
        여기서 미리 읽어 그 날만 신청한 값으로 채운다(Step 4는 칸이 이미 같은 값으로
        잠겨 있으면 '반영됨'으로 처리하므로 그대로 통과한다).

        휴가·교육 계열만 본다. 근무(D/E/N/NK/prn)는 파트장 자리가 아니라서 종전대로
        반려된다 — 최소인력·레벨 통계가 파트장을 빼고 세므로, 파트장에게 근무를 주면
        그날 사람이 하나 더 있는 것처럼 보이지만 어느 숫자에도 안 잡힌다.

        상근(8A/9A/10A)도 여기서는 건드리지 않는다. 평일은 어차피 아래에서 8A로 채우고,
        주말·공휴일 8A는 H1-2 위반이라 Step 4가 사유를 붙여 반려해야 한다 — 여기서 미리
        박아버리면 그 검사를 건너뛰게 된다."""
        import datetime as _dt
        allow = REST_SHIFTS | {Shift.EDU, Shift.TW}
        out: Dict[Tuple[str, int], Shift] = {}
        for req in self.requests:
            if req.type not in allow:
                continue
            s = self.sch.by_id.get(req.staff_id)
            if s is None or not s.is_partjang:
                continue
            try:
                dt = _dt.date.fromisoformat(req.date)
            except ValueError:
                continue  # 날짜 형식 오류는 Step 4가 사유를 붙여 반려한다
            if dt.year != self.year or dt.month != self.month:
                continue
            out[(s.id, dt.day - 1)] = req.type
        return out

    def assign_partjang(self):
        rest = self._partjang_rest_requests()
        for s in self.staff:
            if not s.is_partjang:
                continue
            for d, di in enumerate(self.days):
                if self.sch.get(s.id, d) is not None:
                    continue
                want = rest.get((s.id, d))
                # 자동으로 채우되 **잠그지 않는다**(파트장 요청). 예전엔 lock=True라
                # 엔진이 이 칸을 영영 못 건드렸는데, 주말 8A가 허용된 지금은 그 잠금이
                # "자동으로 넣은 기본값"을 "확정"처럼 굳혀버린다. 값 자체는 그대로
                # 넣으므로 파트장 행이 비지 않고 근무표 모양도 바뀌지 않는다.
                self.sch.set(s.id, d, want or
                             (Shift.A8 if di.auto_8a else Shift.OFF))

    # ------------------------------------------------------------ Step 3
    def assign_nk(self):
        nks = [s for s in self.staff if s.is_nk]
        for idx, s in enumerate(nks):
            done = self.sch.nights_in_month(s.id)  # Step1 연장분 포함
            remaining = self.nk_target - done
            # 시작 위치: 이월 OFF/연장블록 이후 + 전담자별 오프셋(서로 엇갈리게)
            d = 0
            while d < self.sch.num_days and self.sch.get(s.id, d) is not None:
                d += 1
            d += (idx * 3) % 5
            plan = _nk_block_plan(remaining, start_with_three=(idx % 2 == 0))
            pi = 0
            while remaining > 0 and d < self.sch.num_days:
                block = plan[pi] if pi < len(plan) else min(3, remaining)
                pi += 1
                block = min(block, remaining)
                placed = 0
                while placed < block and d < self.sch.num_days:
                    if self._cell_free(s.id, d):
                        self.sch.set(s.id, d, Shift.NK, lock=True)
                        placed += 1
                        d += 1
                    else:
                        d += 1
                        break
                remaining -= placed
                if placed >= 2:
                    rest = 2
                    # 남은 야간을 남은 일수에 고르게: 여유 있으면 3일 휴식(S10)
                    # (2일/3일 혼합 계획이므로 "3일 블록만" 가정한 division 추정 대신
                    #  실제 계획에 남은 블록 개수를 그대로 사용 — 과소추정 시 rest=3을
                    #  잘못 허용해 마지막 블록 배정할 날이 모자라는 문제 방지)
                    if pi < len(plan):
                        blocks_left = len(plan) - pi
                    else:
                        blocks_left = (remaining + 2) // 3
                    need_days = remaining + 2 * max(0, blocks_left - 1)
                    if remaining > 0 and (self.sch.num_days - d - rest - 1) > need_days:
                        rest = 3
                    for k in range(rest):
                        if d < self.sch.num_days and self._cell_free(s.id, d):
                            self.sch.set(s.id, d, Shift.OFF, lock=True)
                            d += 1
                        elif d < self.sch.num_days:
                            d += 1
            if remaining > 0:
                self.sch.log(f"[H2-2] NK {s.id}: 야간 {remaining}일 미충족 (달력 제약)")
            # 나머지는 전부 OFF (H2-2)
            for d2 in range(self.sch.num_days):
                if self.sch.get(s.id, d2) is None:
                    self.sch.set(s.id, d2, Shift.OFF, lock=True)

    # ------------------------------------------------------------ Step 4
    def _overlong_off_requests(self) -> set:
        """연속 15일 이상 휴무를 신청한 구간에서 **15일째부터**의 신청들(H4-3).

        검사기만 고치면 그런 달은 매번 빨간 위반이 남는다 — 엔진이 신청을 그대로
        받아주기 때문이다. 여기서 미리 잘라내고 반려 사유를 적어준다.

        ⚠ 사유가 보이는 곳은 **생성 결과의 "수용하지 못한 신청"**이다. 이 함수는
        apply_requests 안, 즉 생성 단계에서 돈다 — 업로드 단계가 아니다. 주석과
        설명서에 "업로드 결과에서 본다"고 적혀 있었는데 사실이 아니었다
        (v0.84 독립 QA, QA-08). 파트장은 파일을 올리고 아무 말이 없으면 받아들여진
        줄 알고 생성 버튼을 누르는데, 그 다음에야 반려를 본다.

        날짜 순으로 보면서 이어진 길이를 센다. 앞의 14일은 그대로 받고 그 뒤만
        반려하므로, 2주짜리 휴가는 통째로 날아가지 않고 14일까지 남는다."""
        import datetime as _dt
        by_person: Dict[str, Dict[int, Request]] = {}
        for req in self.requests:
            if req.type not in REST_SHIFTS:
                continue
            try:
                dt = _dt.date.fromisoformat(req.date)
            except (ValueError, TypeError):
                continue
            if dt.year != self.year or dt.month != self.month:
                continue
            by_person.setdefault(req.staff_id, {})[dt.day - 1] = req
        out = set()
        for days in by_person.values():
            run = 0
            for d in sorted(days):
                run = run + 1 if (d - 1) in days else 1
                if run > OFF_RUN_MAX:
                    out.add(id(days[d]))
        return out

    def _request_day(self, req) -> Optional[int]:
        """이 달 안의 신청이면 0-기준 일자, 아니면 None."""
        import datetime as _dt
        try:
            dt = _dt.date.fromisoformat(req.date)
        except (ValueError, TypeError):
            return None
        if dt.year != self.year or dt.month != self.month:
            return None
        return dt.day - 1

    def _monthly_request_counts(self) -> Dict[str, int]:
        """사람별 '이번 달에 원티드표에 적은 칸 수'. 휴무·근무를 **전부** 센다.

        파트장이 눈으로 세는 것과 같은 값이어야 한다 — 원티드표에서 그 사람 행에
        표시가 몇 개인가. 그래서 오프·연차도 포함한다(월 신청상한은 근무형만 세지만
        그것과는 다른 용도다)."""
        out: Dict[str, int] = {}
        for req in self.requests:
            if self._request_day(req) is None:
                continue
            out[req.staff_id] = out.get(req.staff_id, 0) + 1
        return out

    def _over_cap_requests(self) -> set:
        """월 신청상한(§5)을 넘긴 신청들 — **엑셀 행 순서로** 센다.

        상한 판정을 적용 순서에서 떼어낸다. 아래 _request_apply_order가 순서를
        바꾸므로, 같이 두면 '몇 번째 신청이 잘리는가'가 그날 누가 몰렸는지에 따라
        달라진다 — 같은 파일을 올렸는데 잘리는 칸이 바뀌면 파트장은 이유를 알 수 없다.
        상한은 '그 사람이 적은 순서대로 앞에서 N개'라는 뜻이므로 파일 순서로 센다."""
        seen: Dict[str, int] = {}
        out = set()
        for req in self.requests:
            if req.type not in WORK_SHIFTS:
                continue
            if self._request_day(req) is None:
                continue
            seen[req.staff_id] = seen.get(req.staff_id, 0) + 1
            if seen[req.staff_id] > self.params.max_requests_per_person:
                out.add(id(req))
        return out

    def _level_pool(self) -> Dict[int, int]:
        """숙련도별 인원 수(파트장 제외) — '그 숙련도가 병동에 흔한가'의 기준."""
        pool: Dict[int, int] = {}
        for s in self.staff:
            if s.is_partjang:
                continue
            pool[s.level] = pool.get(s.level, 0) + 1
        return pool

    def _order_group_by_level(self, group: List, rest: bool) -> List:
        """자리를 다투는 한 묶음 안의 순서 — 레벨 균형(S13 2순위).

        묶음은 '같은 날 같은 근무' 또는 '같은 날 휴무'다. 그 안에서는 신청 수가
        같으므로 숙련도만 본다. 방향이 반대라 둘을 나눠 적는다.

        - **휴무**: 같은 숙련도가 그날 아직 많이 남아 있는 사람부터 내보낸다.
          그 사람이 빠져도 그 숙련도가 남으니 조가 얇아지지 않는다.
        - **근무**: 그 조에 아직 적은 숙련도부터 채운다. 같으면 높은 숙련도를
          앞세운다 — Lv4 이상이 한 명은 들어가야 하기 때문이다(H1-5).
          여기서 '병동에 귀한 숙련도부터'로 하면 안 된다. 귀한 쪽에는 Lv4뿐 아니라
          **신입(Lv1)도 들어간다** — 실제로 그렇게 짰더니 여섯 자리 중 둘이 Lv1이 돼
          S11(신입끼리 같은 밤)에 걸렸다. 귀하다와 든든하다는 다른 축이다.

        고를 때마다 다시 세는 그리디다. 미리 한 번 정렬하면 "같은 숙련도 세 명이
        줄줄이 뽑히는" 일이 생긴다 — 첫 선택 뒤 상황이 바뀐 것을 반영해야 고르게 된다.
        """
        pool = self._level_pool()
        picked: Dict[int, int] = {}
        remaining = list(group)
        out = []
        while remaining:
            best, best_key = None, None
            for i, req in enumerate(remaining):
                s = self.sch.by_id.get(req.staff_id)
                lv = s.level if s is not None else 0
                if rest:
                    # 아직 일하는 같은 숙련도 수 — 많을수록 먼저(그래서 음수).
                    # 같으면 낮은 숙련도부터 내보낸다(높은 쪽을 그날 남긴다).
                    key = (-(pool.get(lv, 0) - picked.get(lv, 0)), lv, i)
                else:
                    # 그 조에 적은 숙련도부터, 같으면 높은 숙련도부터.
                    key = (picked.get(lv, 0), -lv, i)
                if best_key is None or key < best_key:
                    best, best_key = i, key
            req = remaining.pop(best)
            s = self.sch.by_id.get(req.staff_id)
            lv = s.level if s is not None else 0
            picked[lv] = picked.get(lv, 0) + 1
            out.append(req)
        return out

    def _request_apply_order(self) -> List:
        """원티드를 적용할 순서 — **엑셀 행 순서가 아니다**(S13).

        예전에는 self.requests를 파일에 적힌 순서 그대로 훑었다. 그러면 특정 날짜에
        신청이 몰렸을 때 **명단 위쪽에 있는 사람이 매달 이긴다.** 순번은 입사순이라
        같은 사람이 계속 유리하고, 한 사람이 열 칸을 적어 자리를 다 가져가도
        두 칸만 적은 사람이 밀린다 — 파트장이 손으로 조정하던 부분이다.

        1순위 **그 달 신청 수가 적은 사람부터.** 적게 적은 사람의 몇 안 되는 희망을
        먼저 본다. 많이 적은 사람이 손해를 보는 것이 아니라, 많이 적었으니 그중
        일부가 밀리는 것이다.
        2순위 **레벨 균형** — 위 _order_group_by_level.
        3순위 파일 순서(결정적이어야 같은 파일이 늘 같은 결과를 낸다).

        날짜가 빠른 묶음부터 본다. 야간 블록 가능성(H2-4)이 앞뒤 칸을 보고 판정하는데,
        날짜가 뒤섞여 들어오면 같은 사람의 5일·6일 신청 중 어느 쪽이 먼저 걸리는지가
        파일 순서에 따라 달라진다.
        """
        n_req = self._monthly_request_counts()
        # ⚠ get(sid, 0)이어야 한다. 이 달이 아닌 날짜·잘못된 날짜만 적은 사람은
        # n_req에 없어서, 키를 못 찾으면 그 신청이 **통째로 빠진다** — 반려 사유도
        # 안 붙고 accepted가 None인 채로 남아 화면에서 사라진다. 처음에 그렇게 짰고
        # 테스트 두 개가 바로 잡아냈다.
        order = []
        buckets = sorted({n_req.get(r.staff_id, 0) for r in self.requests})
        for bucket in buckets:
            groups: Dict[Tuple, List] = {}
            first: Dict[Tuple, int] = {}
            for i, req in enumerate(self.requests):
                if n_req.get(req.staff_id, 0) != bucket:
                    continue
                d = self._request_day(req)
                # 이 달이 아닌 신청은 묶을 자리가 없다 — 파일 순서로 뒤에 붙여
                # 본 루프가 사유를 적게 한다.
                key = ((d, "휴무" if req.type in REST_SHIFTS else req.type.value)
                       if d is not None else (10 ** 6, "기타"))
                groups.setdefault(key, []).append(req)
                first.setdefault(key, i)
            for key in sorted(groups, key=lambda k: (k[0], first[k])):
                g = groups[key]
                order.extend(g if len(g) == 1
                             else self._order_group_by_level(g, key[1] == "휴무"))
        return order

    def apply_requests(self):
        self._accepted_rest_reqs: Dict[Tuple[str, int], Request] = {}
        overlong_off = self._overlong_off_requests()
        over_cap = self._over_cap_requests()
        # 같은 날 같은 근무유형 채택 수 (자리 제한, §5) — 순서는 _request_apply_order
        taken: Dict[Tuple[int, Shift], int] = {}
        for req in self._request_apply_order():
            req.accepted = False
            s = self.sch.by_id.get(req.staff_id)
            if s is None:
                req.reject_reason = "존재하지 않는 직원"
                continue
            try:
                import datetime as _dt
                dt = _dt.date.fromisoformat(req.date)
            except ValueError:
                req.reject_reason = "날짜 형식 오류"
                continue
            if dt.year != self.year or dt.month != self.month:
                req.reject_reason = "해당 월이 아님"
                continue
            d = dt.day - 1
            t = req.type
            if id(req) in overlong_off:
                req.reject_reason = (
                    f"연속 휴무가 {OFF_RUN_MAX}일을 넘습니다(H4-3) — 앞의 "
                    f"{OFF_RUN_MAX}일은 반영했습니다. 더 쉬셔야 하면 원티드표에서 "
                    "구간을 나눠 신청해주세요.")
                continue
            # 월 신청 상한은 근무형 신청(D/E/N/8A/NK/prn)만 카운트한다 — 휴무/연차는
            # 병가·경조사 등 사유가 다양해 인원수 제한 취지와 안 맞으므로 제외(§5).
            # 어느 건이 상한을 넘었는지는 파일 순서로 미리 정해 둔다(_over_cap_requests).
            if id(req) in over_cap:
                req.reject_reason = f"월 신청 상한({self.params.max_requests_per_person}건) 초과"
                continue
            if self.sch.is_locked(s.id, d):
                if self.sch.get(s.id, d) == t:
                    # 리더가 신청과 동일한 근무로 이미 고정 배정해둔 경우 — 반영된 것으로 처리.
                    # _accepted_rest_reqs에는 넣지 않는다: 그 목록은 나중에 H1-1 미달 시
                    # _repair_via_revoke_request()가 회수할 수 있는 "일반 신청"용이고,
                    # 리더가 직접 고정한 칸은 그 어떤 경우에도 되돌려선 안 되기 때문.
                    if t in REST_SHIFTS:
                        self.sch.requested_off.add((s.id, d))
                    else:
                        taken[(d, t)] = taken.get((d, t), 0) + 1
                    self.sch.wanted.add((s.id, d))
                    req.accepted = True
                else:
                    req.reject_reason = (f"고정 배정과 충돌({self.sch.get(s.id, d)}) "
                                         "— 하드 제약/리더 수정 우선")
                continue
            if t in REST_SHIFTS:
                if not self._off_capacity_ok(d):
                    req.reject_reason = (
                        f"{d+1}일 휴무 신청이 자리보다 많아 밀렸습니다 — 이날 더 쉬면 "
                        f"최소인력을 못 채웁니다(H1-1). 그 달 신청이 적은 분부터, "
                        f"같으면 그날 같은 숙련도가 많이 남는 분부터 받았습니다(S13)")
                    self.sch.crowded_out.append((d, "휴무", s.id))
                    continue
            elif t == Shift.EDU:
                pass  # 교육(T)은 근무일수엔 포함되지만 최소인력 대상이 아니므로 인원 제한 없음
            else:
                if t in NIGHT_SHIFTS and s.no_night:
                    req.reject_reason = "임부/야간불가 야간금지(H2-7)"
                    continue
                if not s.can(t) and not (t == Shift.A8 and s.is_leader
                                         and self.params.leader_8a_as_prn):
                    req.reject_reason = f"허용 근무유형 아님(H1-3): {t}"
                    continue
                # 예전엔 여기서 "8A는 평일만(H1-2)"으로 반려했다. 주말·공휴일 8A가
                # 허용되면서 반려 사유가 사라졌다 — 규칙은 풀었는데 신청 창구만 막혀
                # 있으면 "되는데 안 받아주는" 상태가 된다.
                cap_key = "prn" if t in (Shift.PRN, Shift.A8) else t.value
                cap = self.min_for(d, "N" if t in NIGHT_SHIFTS else cap_key)
                if t in (Shift.PRN, Shift.A8):
                    cap += self.params.prn_cap_extra
                if taken.get((d, t), 0) >= cap:
                    req.reject_reason = (
                        f"{d+1}일 {t.value} 신청이 자리({cap}명)보다 많아 밀렸습니다 — "
                        f"그 달 신청이 적은 분부터, 같으면 그 조에 모자란 숙련도부터 "
                        f"받았습니다(S13)")
                    self.sch.crowded_out.append((d, t.value, s.id))
                    continue
                # H3-2(E 다음 날 D·prn 금지)를 신청 단계에서도 본다. 전날이 이미 정해진 칸
                # (전월 말 이월·먼저 채택된 신청·고정)이면 생성기가 나중에 바꿀 수 없어 위반이
                # 그대로 남는다 — 실제로 전월 말 E 뒤 1일 D 신청이 채택돼 8개 표가 빨강도
                # 없이 나갔다. 반대 방향(E를 받는데 다음 날이 이미 D·prn)도 같다.
                if t in (Shift.D, Shift.PRN, Shift.A8) and \
                        self.sch.effective(s.id, d - 1) == Shift.E and \
                        (d == 0 or self.sch.get(s.id, d - 1) is not None):
                    req.reject_reason = (f"{'전월 말' if d == 0 else f'{d}일'} 근무가 E라 "
                                         f"{d+1}일 {t.value}는 설 수 없습니다(H3-2: E 다음 날 "
                                         "D·prn 금지)")
                    continue
                if t == Shift.E and d + 1 < self.sch.num_days and \
                        self.sch.get(s.id, d + 1) in (Shift.D, Shift.PRN, Shift.A8):
                    req.reject_reason = (f"{d+2}일이 이미 {self.sch.get(s.id, d + 1).value}라 "
                                         f"{d+1}일 E는 설 수 없습니다(H3-2: E 다음 날 D·prn 금지)")
                    continue
                if t in NIGHT_SHIFTS:
                    # 단독야간 방지(H2-4): 앞뒤 어느 쪽으로든 블록 연장이 가능해야 수용
                    fwd = (d + 1 >= self.sch.num_days
                           or self._is_rest_or_free(s.id, d + 1)
                           or self.sch.get(s.id, d + 1) in NIGHT_SHIFTS)
                    bwd = (d > 0 and (self._cell_free(s.id, d - 1)
                                      or self.sch.get(s.id, d - 1) in NIGHT_SHIFTS))
                    if not (fwd or bwd):
                        req.reject_reason = "야간 블록 구성 불가(H2-4)"
                        continue
            # 채택
            self.sch.set(s.id, d, t, lock=True)
            self.sch.wanted.add((s.id, d))
            if t == Shift.A8 and s.is_leader:
                self.sch.mark_leader_8a(s.id, d)
            if t in REST_SHIFTS:
                self.sch.requested_off.add((s.id, d))
                self._accepted_rest_reqs[(s.id, d)] = req
            else:
                taken[(d, t)] = taken.get((d, t), 0) + 1
            req.accepted = True
            # ⚠ 예전에는 '휴'가 들어오면 그 달 나머지 날짜를 전부 '휴'로 채워 배정에서
            # 뺐다(휴직으로 해석). 지금은 채우지 않는다 — 파트장이 지정한 그 날만
            # 제외한다. 병원 OCS에서 '휴'는 하루짜리 단기부모휴가이고, 진짜 휴직은
            # 사·상·산전·육법·육연·R로 따로 있다. 하루 휴가를 휴직으로 읽으면 그 사람이
            # 한 달 내내 근무표에서 사라지는데, 오류도 안 나서 알아채기 어려웠다.
            # 여러 날 쉬는 경우는 파트장이 그 날들을 각각 표시한다.

    def _off_capacity_ok(self, d: int) -> bool:
        """d일에 휴무 1명 추가해도 최소인력 채울 수 있는지 (근사)."""
        generals = [s for s in self.staff if not (s.is_partjang or s.is_nk)]
        resting = sum(1 for s in generals
                      if self.sch.get(s.id, d) in REST_SHIFTS)
        nk_on = sum(1 for s in self.staff if s.is_nk
                    and self.sch.get(s.id, d) in NIGHT_SHIFTS)
        need = (self.min_for(d, "D") + self.min_for(d, "E")
                + self.min_for(d, "prn") + max(0, self.min_for(d, "N") - nk_on))
        return len(generals) - resting - 1 >= need

    # ------------------------------------------------------------ Step 5
    def assign_nights(self):
        """일반 간호사: 2일 블록만 배정하며, 개인별 월 목표(4일 또는 6일, H6-4) 내로
        제한한다. 목표를 지키면 못 채우는 경우(H1-1 최소인력 보존이 최우선) 목표를
        넘겨서라도 2일 블록으로 배정하고 위반을 기록한다."""
        nd = self.sch.num_days
        for d in range(nd):
            need = self.min_for(d, "N") - self.sch.count_shift(d, Shift.N)
            while need > 0:
                placed = False
                if d + 1 >= nd:
                    # 월말 단독야간 예외(H2-4) — 1일 블록만.
                    #
                    # ⚠ 말일에도 '목표를 넘겨서라도 채운다'가 있어야 한다. 예전엔 이 분기에만
                    # 그게 빠져 있어서, 그달 야간 목표를 다 채운 사람만 남으면 말일 야간이
                    # 그냥 비었다(H1-1). 말일이 아닌 날은 아래에서 초과 배정으로 메우는데
                    # 말일만 구멍으로 남은 것이다 — 파트장이 받은 11월 근무표의 30일 야간
                    # 4명 < 6명이 이것이다. H1-1은 필수, H6-4(목표 횟수)는 최선노력이라
                    # 말일도 다른 날과 같은 순서로 판단한다.
                    for over in (False, True):
                        for relax in (0, 1, 2, 3):
                            cand = self._pick_night_candidate(
                                d, relax, (1,), allow_over_target=over)
                            if cand is not None:
                                sid, length = cand
                                self._place_night_block(sid, d, length, relax)
                                if over:
                                    self.sch.log(
                                        f"[H6-4] {sid}: {d+1}일(말일) 야간 — 월 목표 초과 배정 "
                                        "(최소인력(H1-1) 우선)")
                                placed = True
                                break
                        if placed:
                            break
                else:
                    for relax in (0, 1, 2, 3):
                        cand = self._pick_night_candidate(
                            d, relax, self._night_block_lengths)
                        if cand is not None and relax == 0 and self._last_night_hard != (0, 0):
                            # 간격(S1)을 지키는 후보가 필수 쪽에 흠이 있으면 — 이 블록이
                            # 앞으로 그날 인원을 모자라게 만들거나(squeeze) 지정 인원을 덜
                            # 채우면 — 간격을 완화한 후보와 견줘 필수 쪽이 나은 사람을 쓴다.
                            # 하드(H1-1·H1-6)가 소프트(S1)보다 먼저다. 예전엔 0단계에 후보가
                            # 하나라도 있으면 그대로 써서, 간격을 7일로 바로잡고 달 경계까지
                            # 세자 20명 병동 prn 미달과 샘플 병동 12월 1일 E 미달이 생겼다.
                            #
                            # ⚠ 밤의 고연차(H1-5)는 여기서 보지 않는다. 넣어 봤더니 고연차가
                            # 빠진 밤마다 같은 고연차를 이틀 쉬고 다시 세워 간격 2일이 80건
                            # 안팎 생겼고(6개 병동 × 6개월), 필수 위반은 거의 줄지 않았다.
                            hard0 = self._last_night_hard
                            alt = self._pick_night_candidate(
                                d, 1, self._night_block_lengths)
                            if alt is not None and self._last_night_hard < hard0:
                                cand, relax = alt, 1
                        if cand is not None and relax == 0:
                            # 밤의 고연차(H1-5): 고른 사람이 고연차가 아니고 그 밤들에 고연차가
                            # 비면, 간격이 **조금만** 모자란(5~6일) 고연차를 대신 세운다 —
                            # 인원·지정이 나빠지지 않을 때만. 하한을 두는 이유: 하한 없이
                            # 했더니 고연차가 빈 밤마다 같은 고연차를 이틀 쉬고 다시 세워
                            # 간격 2일이 80건 안팎 생겼다. 예전 생성기는 6일 간격을 허용했고
                            # 그걸 7일로 바로잡자 60명 병동의 '고연차 없는 밤'이 4 → 12로
                            # 늘었는데(원티드 3종 × 6개월), 그 6일을 고연차에게만 되살린다.
                            sid0, len0 = cand
                            hard0 = self._last_night_hard
                            s0 = self.sch.by_id[sid0]
                            if not (s0.level >= 4 or s0.is_night_leader) \
                                    and self._night_days_without_senior(d, len0) > 0:
                                alt = self._pick_night_candidate(
                                    d, 1, self._night_block_lengths, senior_rescue=True)
                                if alt is not None and self._last_night_hard <= hard0:
                                    cand, relax = alt, 1
                        if cand is not None:
                            sid, length = cand
                            self._place_night_block(sid, d, length, relax)
                            placed = True
                            break
                    if not placed:
                        # 월 목표를 지키면 못 채움 — 최소인력(H1-1) 보존이 우선이므로
                        # 목표를 넘겨서라도 배정하고 위반으로 남긴다. 후보 블록 길이도
                        # self._night_block_lengths와 동일하게 둬서(목표가 홀수인 경우
                        # 3일 블록도 시도), 이 초과배정이 애매한 홀수 합으로 남지 않고
                        # 되도록 유효한 목표값 중 하나에 가깝게 떨어지도록 한다.
                        for relax in (0, 1, 2, 3):
                            cand = self._pick_night_candidate(
                                d, relax, self._night_block_lengths,
                                allow_over_target=True)
                            if cand is not None:
                                sid, length = cand
                                self._place_night_block(sid, d, length, relax)
                                self.sch.log(
                                    f"[H6-4] {sid}: {d+1}일 야간 — 월 목표 초과 배정 "
                                    "(블록 목표 소진, 최소인력(H1-1) 우선)")
                                placed = True
                                break
                if not placed:
                    self.sch.log(f"[H1-1] {d+1}일 야간 최소인력 미달 — 배정 가능 인원 없음")
                    break
                need -= 1

    def _pick_night_candidate(self, d: int, relax: int, lengths: Tuple[int, ...],
                              allow_over_target: bool = False,
                              senior_rescue: bool = False) -> Optional[Tuple[str, int]]:
        """senior_rescue=True면 '그 밤들에 고연차가 비었는데, 간격이 조금 모자라
        (NIGHT_GAP_RESCUE_MIN~NIGHT_GAP_MIN−1일) 0단계에서 빠진 고연차'만 본다."""
        # H1-5(하드): 그날 야간(N/NK) 배정 인원 중 레벨4+ 1명 이상.
        cur_levels = [s.level for s in self.staff
                     if not s.is_partjang and self.sch.grid[s.id][d] in NIGHT_SHIFTS]
        need_senior4 = not any(lv >= 4 for lv in cur_levels) and not any(
            x.is_night_leader for x in self.staff
            if not x.is_partjang and self.sch.grid[x.id][d] in NIGHT_SHIFTS)

        def _block_needs_senior(length: int) -> int:
            return self._night_days_without_senior(d, length)
        level_stats = self._shift_level_stats("N")
        # S11: 신입(Lv1)끼리 같은 밤에 몰리지 않게. 블록이 걸치는 날마다 이미 Lv1이
        # 야간에 있는지 여기서 한 번만 세어둔다 — 후보마다 다시 세면 핫패스(초당
        # 수만 번)가 느려진다. 야간전담(NK)은 야간이 상시 업무라 이 판정에서 뺀다.
        max_len = max(lengths) if lengths else 1
        lv1_ids = [x.id for x in self.staff
                   if x.level == 1 and not (x.is_partjang or x.is_nk)]
        lv1_nights = {i: {k for k in range(self.sch.num_days)
                          if self.sch.grid[i][k] in NIGHT_SHIFTS}
                      for i in lv1_ids}
        lv1_on_night = []      # 그 날 이미 야간인 Lv1 수
        lv1_who = []           # 그 날 이미 야간인 Lv1 이름들
        for k in range(max_len):
            day = d + k
            if day >= self.sch.num_days:
                lv1_on_night.append(0)
                lv1_who.append(())
                continue
            who = tuple(i for i in lv1_ids if day in lv1_nights[i])
            lv1_who.append(who)
            lv1_on_night.append(len(who))
        best = None
        best_score = None
        best_hard = None
        for length in lengths:
            for s in self.staff:
                if s.is_partjang or s.is_nk or s.no_night:
                    continue
                if Shift.N not in s.allowed_shifts:
                    continue
                # H2-3(하드): 이 사람에게 허용된 블록 길이를 넘으면 후보가 아니다.
                # 3N을 적은 사람만 3일이 열린다.
                if length > max(self._gen_max_block, s.night_block_pref):
                    continue
                if senior_rescue:
                    if not (s.level >= 4 or s.is_night_leader):
                        continue
                    r0 = self._night_rest_before(s.id, d)
                    if r0 is None or not (NIGHT_GAP_RESCUE_MIN <= r0 < NIGHT_GAP_MIN):
                        continue
                    if self._night_days_without_senior(d, length) == 0:
                        continue
                if not self._can_night_block(s, d, length, relax, allow_over_target):
                    continue
                # S8: 배정 시 뒤따르는 강제 OFF가 '신청 OFF'를 잡아먹으면 감점
                s8_pen = 0
                for k in range(length, length + 2):
                    if (s.id, d + k) in self.sch.requested_off:
                        s8_pen = 1
                # 휴식 잠금이 만들 인력 압박(look-ahead): 압박 없는 배정 우선
                squeeze = self._squeeze_after_block(s, d, length)
                # 직전 야간에서 며칠 쉬었나 — 이번 달에 야간이 없으면 전월 마지막 야간부터
                rest = self._night_rest_before(s.id, d)
                gap = rest + 1 if rest is not None else 99
                # 병동 전체 레벨 평균에 가까워지는 배정을 무작위 tiebreak 값에
                # 약하게 얹어 확률적으로만 선호 — H1-5(레벨4+ 1명 보장)나 야간
                # 배정 균형을 깨지 않는 선에서, 그리고 결정론적으로 두면 매번
                # 같은 사람이 뽑혀 형평성이 깨지는 부작용 없이(_LEVEL_NUDGE_WEIGHT
                # 참고) 근무별 레벨 구성이 한쪽으로 쏠리지 않도록 돕는다.
                level_gap = self._level_gap_given(level_stats, s.level, weight=length)
                # 그 블록이 걸치는 **날짜별** 조 평균도 같이 본다(위 level_gap은
                # 월 누적이라 이미 목표에 가까워서 날짜별 쏠림을 못 잡는다 —
                # 주간에서 확인된 것과 같은 이유다). 하루만 보면 블록 첫날에만
                # 맞추고 둘째·셋째 날은 방치되므로 걸치는 날의 평균을 쓴다.
                night_day_gap = self._night_block_level_gap(s.level, d, length)
                # S11: 이 사람이 Lv1인데 블록의 어느 날에 이미 Lv1이 야간이면 그 날 수만큼
                # 감점. 인력 실현가능성(squeeze)·신청 OFF 보호(s8_pen) 다음, 야간 형평성
                # 앞에 둔다 — 뒤로 밀면 형평성이 늘 이겨서 규칙이 거의 작동하지 않는다.
                # 대신 하드 제약이 아니라 점수라, 다른 후보가 없으면 그냥 배정된다.
                # 이미 있는 Lv1 '수'를 그대로 더한다(있다/없다가 아니라) — 2명째보다
                # 3명째를 훨씬 무겁게 막기 위해서다. 이 병동처럼 Lv1의 야간 총량이
                # 밤 수를 넘으면(8명×6회=48칸 > 31밤) 2명인 밤은 산술적으로 못 피하는데,
                # 그때 몰아서 3~4명을 만드는 것이 제일 나쁘기 때문이다.
                lv1_pen = (sum(lv1_on_night[k] for k in range(length))
                           if s.level == 1 else 0)
                # 2명인 밤을 못 피한다면, 최소한 '같은 두 사람'이 반복되지는 않게 한다.
                # 짝지어질 상대와 이미 몇 밤을 함께 섰는지를 더해, 처음 만나는 짝을
                # 먼저 고른다. lv1_pen 다음에 둬서 "2명이냐 3명이냐"가 먼저고,
                # 같은 인원수라면 덜 만난 조합을 고르는 순서가 된다.
                if s.level == 1 and lv1_pen:
                    mine = lv1_nights.get(s.id, frozenset())
                    pair_pen = sum(len(mine & lv1_nights[j])
                                   for k in range(length) for j in lv1_who[k]
                                   if j != s.id)
                else:
                    pair_pen = 0
                # S12: 그 사람이 적은 선호 길이(2N/3N)와 다르면 감점. 하드가 아니라
                # 점수라, 다른 방법이 없으면 선호와 다른 길이로도 배정된다 —
                # 그때는 check_soft가 S12로 남겨 파트장이 볼 수 있게 한다.
                pref_pen = 0 if length == s.night_block_pref else 1
                # H1-6: 블록이 걸치는 날 중 지정이 모자란 날 수 — 지정 가능자가
                # 그 밤들을 채우면 그만큼 부족이 줄어든다. 주간과 달리 블록이라
                # 여러 날을 한꺼번에 메울 수 있으므로 '몇 날을 메우나'로 센다.
                desig = -(sum(1 for k in range(length)
                              if d + k < self.sch.num_days
                              and self.designated_short(d + k) > 0)
                          if s.is_designated else 0)
                # 지정 가능자의 블록 뒤 휴식 2일에 다른 지정 가능자가 전부 쉬면(이미 OFF·휴가·휴식으로
                # 정해진 칸) 그 이틀은 지정 0명이 된다 — 지정 가능자가 둘뿐인 병동에서 H1-6이 남는
                # 자리의 대부분이 이것이었다(둘의 야간 휴식이 겹침). 블록 날만 보던 항에 휴식일을 보탠다.
                if s.is_designated:
                    desig += self._designated_rest_conflicts(s, d, length)
                # H1-5는 **자리는 그대로 두고 세기만 바꿨다.**
                #
                # 하드 규칙이니 위로 올려야 할 것 같아서 두 번 올려 봤는데 둘 다
                # 다른 하드를 깼다. 소프트 위(4번째)로 올리니 어떤 병동에서 그날
                # 지정 인원(H1-6)이 0이 됐고, 주간 쪽에서 같은 일을 했더니 7명
                # 병동의 최소인력 미달이 8일 → 9일로 늘었다. 이유는 같다 — 고연차를
                # 당겨 오면 그 사람이 **다른 날·다른 조에서 빠지고**, 후보가 얇은
                # 병동에서는 그 자리를 메울 사람이 없다. 하드끼리 부딪힐 때는
                # '그날 병동이 못 돌아가는 쪽'(H1-1·H1-6)이 먼저다.
                #
                # 대신 세는 방식을 고쳤다. 예전엔 `0 if (need_senior4 and Lv4+) else 1`로
                # 블록 **첫날만** 봤다 — 2~3일 블록의 둘째·셋째 날은 아무도 안 보는
                # 채로 남았다. 지금은 블록이 걸치는 날 중 구멍인 날 수를 세서, 여러
                # 날을 한꺼번에 메우는 후보를 먼저 고른다. 자리는 같지만 훨씬 자주
                # 맞는다(야간전담 Lv3 병동에서 야간 H1-5 14 → 10건).
                senior_fill = (-_block_needs_senior(length)
                               if (s.level >= 4 or s.is_night_leader) else 0)
                hard = (squeeze, desig)
                score = (squeeze, s8_pen, desig,
                         pref_pen, lv1_pen, pair_pen,
                         self.sch.nights_in_month(s.id),
                         -min(gap, 12), self.sch.workdays_in_month(s.id),
                         self.sch.carryover[s.id].recent_night_score,
                         senior_fill,
                         self.rng.random() + level_gap * _LEVEL_NUDGE_WEIGHT
                              + night_day_gap * _NIGHT_DAY_LEVEL_NUDGE_WEIGHT)
                if best_score is None or score < best_score:
                    best_score = score
                    best = (s.id, length)
                    best_hard = hard
        # 고른 후보의 필수 쪽 점수 — assign_nights가 간격(S1)을 깬 후보와 견주는 데 쓴다
        self._last_night_hard = best_hard if best is not None else None
        return best

    def _designated_rest_conflicts(self, s: Staff, d: int, length: int) -> int:
        """s(지정 가능자)가 d부터 length일 야간을 서면 쉬는 d+length·d+length+1 중, 다른 지정 가능자가
        한 명도 일할 수 없는(이미 OFF·휴가·휴식으로 정해진) 날 수 — 그날 지정이 모자라는 병동일 때만."""
        sch = self.sch
        others = [x for x in self.staff if x.is_designated and not x.is_partjang and x.id != s.id]
        n = 0
        for k in (d + length, d + length + 1):
            if k >= sch.num_days or self.min_for(k, DESIGNATED_KEY) <= 0:
                continue
            if all(sch.grid[x.id][k] is not None and sch.grid[x.id][k] not in COUNTED_WORK_SHIFTS for x in others):
                n += 1
        return n

    def _squeeze_after_block(self, s: Staff, d: int, length: int) -> int:
        """블록·휴식 기간의 각 날에 대해, 남은 가용 인원이 남은 최소인력 수요보다
        부족해질 날 수를 센다 (야간 배정의 주간 인력 look-ahead)."""
        sch = self.sch
        squeeze = 0
        for dd in range(d, min(d + length + 2, sch.num_days)):
            in_block = dd < d + length
            need = 0
            for key, sh in (("D", Shift.D), ("E", Shift.E), ("prn", Shift.PRN)):
                need += max(0, self.min_for(dd, key) - sch.count_shift(dd, sh))
            n_have = sch.count_shift(dd, Shift.N) + (1 if in_block else 0)
            need += max(0, self.min_for(dd, "N") - n_have)
            if need <= 0:
                continue            # 수요가 없으면 가용 인원이 몇이든 모자랄 수 없다
            avail = 0
            grid = sch.grid
            locked = sch.locked
            for t in self.staff:
                if t.is_partjang or t.is_nk or t.id == s.id:
                    continue
                v = grid[t.id][dd]
                if v is None or (v == Shift.OFF and (t.id, dd) not in locked):
                    avail += 1
            if avail < need:
                squeeze += 1
        return squeeze

    def _can_night_block(self, s: Staff, d: int, length: int, relax: int,
                         allow_over_target: bool = False) -> bool:
        sch = self.sch
        nd = sch.num_days
        # 월 경계를 넘는 블록은 불가 — _cell_free/sch.get()은 범위 밖 날짜를 None
        # (미배정)으로 취급해 "비어있음"으로 보이므로 여기서 따로 막아야 한다.
        # (2일 블록은 항상 d+1<nd일 때만 시도되어 원래 안전했지만, 3일 블록이
        # 추가되며 d+2가 월을 넘는 경우가 생겨 이 검사가 필요해졌다.)
        if d + length > nd:
            return False
        for i in range(length):
            if not self._cell_free(s.id, d + i):
                return False
        # 블록 뒤 2일 휴식 확보 가능해야 함 (H2-5): 이미 근무로 잠겨 있으면 불가
        for k in range(length, length + 2):
            if d + k < nd and not self._is_rest_or_free(s.id, d + k):
                return False
        # 월 야간 목표 (H6-4: 기본 4일 또는 6일만) — H1-1 보존을 위해 부득이할 때만 초과 허용
        if not allow_over_target:
            target = sch.night_target.get(s.id, self.params.max_nights)
            remaining = target - sch.nights_in_month(s.id) - length
            if remaining < 0:
                return False
            # 목표가 홀수라 3일 블록도 섞이는 경우, 나머지가 1일이면 그 뒤로는
            # 2/3일 블록으로 못 채우는 고립된 1일이 남는다 — 그런 배정은 애초에
            # 금지해 자연스럽게 3일 블록 쪽으로 유도한다. length==1(월말 단독야간
            # 예외, H2-4)은 애초에 이번 달 안에서 못 채우는 걸 전제한 상태라 대상 아님.
            if length >= 2 and remaining == 1:
                return False
        # 월 야간 상한 (H2-6 안전망, relax>=2부터 상향 H2-9)
        extra = max(0, relax - 1)
        if sch.nights_in_month(s.id) + length > self.params.max_nights + extra:
            return False
        # 연속근무 (H3-1)
        base = self.month_start(s.id)
        before = sch.work_run_ending(s.id, d - 1) if d > base else \
            (sch.carryover[s.id].consecutive_work_days
             if sch.carryover[s.id].last_shift_type in WORK_SHIFTS else 0)
        if before + length > self.params.max_consecutive_work:
            return False
        # 월말 단독야간은 익월에 최소 1일 연장(H5-2)되므로 그만큼 여유 필요 (H3-1)
        if length == 1 and d == nd - 1 and before + 2 > self.params.max_consecutive_work:
            return False
        # 직전이 야간이면 안 됨(블록은 통째로만 배정), 야간 후 휴식 2일 (H2-5/H2-8),
        # 그리고 S1(블록 사이 NIGHT_GAP_MIN일) — relax 0에서만 지킨다(H2-9 1순위 완화).
        rest = self._night_rest_before(s.id, d)
        if rest is None:
            co = sch.carryover[s.id]
            if co.trailing_night_count > 0 or co.night_block_remaining_off > 0:
                # 전월 마지막 야간 날짜를 모르는 옛 이월정보 — 월초(전입자는 입사일)
                # 이월 휴식 기준으로 근사한다
                rest = d - base
        if rest is not None:
            if rest < 2:
                return False
            if relax < 1 and rest < NIGHT_GAP_MIN:
                return False
        return True

    def _night_days_without_senior(self, d: int, length: int) -> int:
        """d일부터 length일 블록이 걸치는 날 중 Lv4+(또는 야간리더)가 아직 없는 날 수.

        첫날만 보면 2~3일 블록의 둘째·셋째 날은 아무도 안 본 채로 남는다 —
        야간은 블록으로 배정되므로 그 날들이 바로 구멍이 된다.
        야간전담(NK)도 그 밤에 서 있으면 Lv4+로 센다(검사기 H1-5와 같다)."""
        n = 0
        for k in range(length):
            day = d + k
            if day >= self.sch.num_days:
                break
            if not any((x.level >= 4 or x.is_night_leader)
                       for x in self.staff
                       if not x.is_partjang
                       and self.sch.grid[x.id][day] in NIGHT_SHIFTS):
                n += 1
        return n

    def _night_rest_before(self, sid: str, d: int) -> Optional[int]:
        """d일 앞에 야간이 아닌 날이 며칠 이어졌나 — 직전 야간까지. 이번 달에 야간이
        없으면 **전월 마지막 야간까지** 이어 센다(이월정보 days_since_last_night).

        예전엔 이번 달 안만 봐서, 이번 달 첫 블록은 전월 말 야간과 붙어 있어도 간격
        제한을 안 받았다(이월 휴식 2일만 지켰다). 모르면 None."""
        last = self.sch.last_night_day(sid, d)
        if last is not None:
            return d - last - 1
        tail = self.sch.carryover[sid].days_since_last_night
        if tail is None:
            return None
        return tail + (d - self.month_start(sid))

    def _place_night_block(self, sid: str, d: int, length: int, relax: int):
        sch = self.sch
        for i in range(length):
            sch.set(sid, d + i, Shift.N, lock=True)
        for k in range(length, length + 2):
            if d + k < sch.num_days and self.sch.get(sid, d + k) is None:
                sch.set(sid, d + k, Shift.OFF, lock=True)
        if relax >= 2:
            cap = self.params.max_nights + max(0, relax - 1)
            prev = sch.relaxed_night_cap.get(sid, self.params.max_nights)
            if cap > prev:
                sch.relaxed_night_cap[sid] = cap
                sch.log(f"[H2-9] {sid}: 월 야간상한 {cap}일로 완화")
        elif relax == 1:
            sch.log(f"[H2-9] {sid}: {d+1}일 야간 — S1(간격 7일) 완화 적용")
        if length == 1:
            sch.log(f"[H5-2] {sid}: 월말 단독야간({d+1}일) → 익월 연결 필요")

    # ------------------------------------------------------------ Step 6
    def fill_day_shifts(self):
        # 날짜 순서가 곧 우선순위다 — 먼저 채우는 날이 후보를 먼저 가져간다. 앞선 시도에서
        # 못 채운 날을 앞으로 당기는 '적응형 재시도'를 2026-10-22에 실험했다(기준선 201개):
        # 좋아진 표 47·나빠진 표 46·필수 위반 0 표 80→83으로 재배열에 가까웠고, 필수 위반이
        # 2~3건 느는 표도 있어 넣지 않았다(docs/report_v0.86/bench/baseline_rerun_adaptive_*.json).
        for d in range(self.sch.num_days):
            for key, shift in (("D", Shift.D), ("E", Shift.E), ("prn", Shift.PRN)):
                need = self.min_for(d, key) - self.sch.count_shift(d, shift)
                while need > 0:
                    cand = self._pick_day_candidate(d, shift)
                    if cand is None:
                        self.sch.log(f"[H1-1] {d+1}일 {key} 최소인력 미달 — 후보 없음")
                        break
                    self.sch.set(cand.id, d, shift)
                    need -= 1

    def _pick_day_candidate(self, d: int, shift: Shift,
                            protect_lower: Optional[int] = None) -> Optional[Staff]:
        # S6: 아직 고랩(상대 기준선) 없으면 우선 확보
        sch = self.sch
        min_lv = self._senior_min_level(shift)
        is_prn = shift == Shift.PRN
        cur_levels = []
        for s in self.staff:
            if s.is_partjang:
                continue
            v = sch.grid[s.id][d]
            if v == shift or (is_prn and v in PRN_LIKE_SHIFTS):
                cur_levels.append(s.level)
        need_lv3 = not any(lv >= min_lv for lv in cur_levels)
        # H1-5(하드): D/E/N 배정 인원 중 레벨4+ 1명 이상 — S6(상대기준)과 별개인
        # 절대기준. prn은 대상 아니라 shift==PRN이면 항상 False.
        need_senior4 = shift != Shift.PRN and not any(lv >= 4 for lv in cur_levels)
        weekend = self.days[d].day_type != DAY_WEEKDAY
        need_desig = self.designated_short(d) > 0
        level_key = _SENIOR_SHIFT_KEY.get(shift)
        level_stats = self._shift_level_stats(level_key) if level_key else None
        best, best_score = None, None
        can_assign_day = self.can_assign_day
        effective = sch.effective
        workdays_in_month = sch.workdays_in_month
        offs_in_month = sch.offs_in_month
        weekend_workdays_in_month = sch.weekend_workdays_in_month
        rand = self.rng.random
        for s in self.staff:
            if not can_assign_day(s, d, shift):
                continue
            sid = s.id
            odo = 1 if (effective(sid, d - 1) in REST_SHIFTS
                        and effective(sid, d + 1) in REST_SHIFTS) else 0
            wk_load = weekend_workdays_in_month(sid) if weekend else 0
            # H4-1 보호: 배정 시 OFF 하한이 깨질 사람은 후순위 (H4-1 > S6)
            lower_break = 0
            if protect_lower is not None and \
                    offs_in_month(sid) - 1 < protect_lower:
                lower_break = 1
            # H1-5는 최소인력(H1-1) 확보·기존 형평성 균형을 깨면서까지 강제하지
            # 않도록(그러면 특정 요일에 후보가 아예 고갈될 수 있음) 최하위
            # 우선순위(무작위 직전)로 둔다 — 그래도 동점일 때는 항상 이긴다.
            # 근무유형별 평균 숙련도가 병동 전체 평균에 가까워지는 후보를 무작위
            # tiebreak 값에 약하게 얹어 확률적으로만 선호 — 결정론적으로 두면
            # 매번 같은 후보가 뽑혀 형평성이 오히려 깨진다(_LEVEL_NUDGE_WEIGHT 참고).
            level_gap = (self._level_gap_given(level_stats, s.level)
                        if level_stats else 0.0)
            # 그날 조의 평균도 같이 본다(위 level_gap은 **월 누적** 평균이다).
            #
            # 예전엔 그날 조(cur_levels)를 '고랩이 한 명이라도 있나'라는 불리언으로만
            # 썼다. 그래서 Lv4+가 한 명 차는 순간 레벨은 아무 힘이 없어지고, 남은
            # 자리는 형평성과 난수로만 채워졌다 — 어느 날 고연차 5명이 몰려도 막는
            # 것이 없고, 그만큼 다른 날이 빈다. 실제 근무표에서 D조 평균 레벨이
            # 같은 달 안에서 2.00~4.14로 출렁였다(15일 3,3,4,4,5,5,5 vs 2일 1,1,2,2,2,2,3,3,3).
            #
            # 월 누적 평균은 이미 병동 평균에 가까워서 이걸 못 잡는다 — 평균이 맞아도
            # 날짜별로 몰렸다 비었다 할 수 있기 때문이다. 그래서 '오늘 이 조'를 따로 본다.
            # 조 구성(레벨 띠)이 병동 비율에 가까워지는 후보를 선호한다 — 평균(_day_level_gap)은
            # Lv5+Lv1과 Lv3+Lv3을 못 가르므로 구성 편차로 바꿨다(2026-10-22). 값은 '좋아지는 만큼'
            # 이라 빼 준다(작을수록 좋은 점수).
            day_gap = -mix_gain(cur_levels, s.level, self._band_share)
            # H1-6: 그날 지정 인원이 모자라면 지정 가능자를 먼저 뽑는다. 어차피 누군가는
            # 서야 할 자리이므로 인력을 더 쓰지 않는다 — 같은 자리를 누구로 채우느냐의
            # 문제다. H4-1(OFF 하한) 보호 다음, 고랩 확보(S6) 앞에 둔다: 지정은 하드고
            # S6은 소프트다.
            desig = 0 if (need_desig and s.is_designated) else 1
            # H1-5(그 조에 Lv4+ 1명)는 하드인데 이 항은 형평성보다도 **아래**에 있다.
            # 순서가 이상해 보여서 위로 올려 봤다 — 작은 병동이 깨졌다. 7명 병동에서
            # 최소인력 미달이 8일 → 9일로 늘고, 다른 병동에서는 지정 인원(H1-6)이
            # 0인 날이 생겼다. 고연차를 당겨 오느라 특정 날의 후보가 고갈되기 때문이다.
            # 그래서 **주간의 H1-5는 점수로 밀어붙이지 않고 사후 수리로 고친다**
            # (repair_level_coverage — 근무끼리 맞교환이라 인원 수가 안 변한다).
            # 야간은 블록이라 사후 수리가 안 먹어서 반대로 점수 쪽을 올렸다
            # (_pick_night_candidate의 senior_fill).
            # 주말·공휴일에는 주말 몫(wk_load)을 '하루짜리 조각 피하기'(odo)보다 먼저 본다. 전에는 odo가
            # 앞이라 금요일부터 이어 온 사람이 토·일을 그대로 가져갔다 — 주말 몫이 적은 사람은 그날
            # 새로 시작해야 해서 늘 뒤로 밀렸고, 한 달 뒤 주말 근무가 2~9회로 갈렸다(12월 재현).
            # 다만 1~2일째 블록을 이어 오는 사람은 그보다도 먼저다 — 여기서 끊으면 3일을 못 채운
            # 짧은 블록(H6-1)이 남고, 기준선 201개에서 그 조각이 필수 위반까지 늘렸다(주말 몫만 앞세운
            # 첫 시도: 블로킹 92→107). 3일을 채운 블록은 금요일에서 끝나도 되므로 주말 몫에 양보한다.
            # 평일은 전과 같다 — 거기까지 바꾸면 블록이 잘게 끊긴다.
            cont = ()
            if (weekend and self._weekend_first) or self._block_first:
                run = 0
                while run < 3 and effective(sid, d - 1 - run) in DAY_WORK_SHIFTS:
                    run += 1
                cont = (0 if 0 < run < 3 else 1,)
            if weekend and self._weekend_first:
                wk_part = (*cont, wk_load, odo)
            else:
                wk_part = (*cont, odo, wk_load)
            senior4 = 0 if (need_senior4 and s.level >= 4) else 1
            # 전략 S: 그 조의 Lv4+ 확보를 숙련도·주말·형평성보다 먼저 — 기본 순서에서는 맨 끝(사후 수리에
            # 맡김)이다. 위 주석대로 작은 병동에서 최소인력·지정을 깰 수 있어 기본으로는 안 쓰고, 시드 하나의
            # 전략으로만 쓴다(해로운 달에는 점수표에서 그 시드가 안 뽑힌다).
            score = (lower_break, desig,
                     senior4 if self._senior_first else 1,
                     0 if (need_lv3 and s.level >= min_lv) else 1,
                     *wk_part,
                     workdays_in_month(sid),
                     -offs_in_month(sid),
                     senior4,
                     rand() + level_gap * _LEVEL_NUDGE_WEIGHT
                          + day_gap * self._day_nudge_w)
            if best_score is None or score < best_score:
                best_score, best = score, s
        return best

    # ------------------------------------------------------------ 지정 인원(H1-6)
    def designated_short(self, d: int) -> int:
        """그날 지정 인원이 몇 명 모자란지 (0이면 충족 또는 지정을 안 쓰는 병동).

        배정 중에 후보 점수로 쓴다 — 아직 모자란 날에는 '지정' 가능자를 먼저 뽑아,
        어차피 누군가는 서야 할 자리를 지정 가능자로 채운다. 하드로 막지 않고 점수로
        두는 이유는, 막아버리면 지정 가능자가 다 소진된 날에 그 근무 자체를 못 채워
        최소인력(H1-1)까지 무너지기 때문이다. H1-6은 검증 단계에서 잡힌다."""
        need = self.min_for(d, DESIGNATED_KEY)
        if not need:
            return 0
        return max(0, need - self.sch.designated_count(d))

    def repair_designated(self):
        """H1-6 미달 수리 — 그날 근무 중인 비지정자 한 명을 지정 가능자와 맞바꾼다.

        배정 중에는 점수로만 선호한다(designated_short). 그런데 그날 최소인력이 이미
        비지정자로 다 채워졌으면 지정 가능자를 넣을 자리가 없다 — 한 명 더 넣는 것은
        H1-4(상한)가 막으므로, 남는 방법은 **자리를 바꾸는 것**뿐이다.

        실제로 지정 가능자 2명 병동을 여섯 달 돌렸더니 달마다 3~6일이 0명으로 남았다.
        사전 검사(designated_feasibility)는 '가능'이라고 했다 — 총량은 충분했기
        때문이다. 하드 규칙인데 파트장이 화면에서 한 칸씩 고치는 수밖에 없었다.

        인원 수는 그대로다(같은 근무를 다른 사람이 선다). 그래서 H1-1·H1-4는 흔들리지
        않고, 빠지는 사람은 근무가 하나 줄어 OFF가 하나 느는 쪽이라 H4-1(월 최소 휴무)도
        나빠지지 않는다."""
        for d in range(self.sch.num_days):
            guard = 0
            while self.designated_short(d) > 0 and guard < 4:
                guard += 1
                if not self._swap_in_designated(d):
                    break

    def _swap_in_designated(self, d: int) -> bool:
        """그날 쉬는 지정 가능자 한 명을, 근무 중인 비지정자 한 명과 맞바꾼다."""
        sch = self.sch
        for a in self.staff:
            if a.is_partjang or a.is_nk or not a.is_designated:
                continue
            if sch.get(a.id, d) in COUNTED_WORK_SHIFTS:
                continue                     # 이미 근무 중이면 이미 세어졌다
            if sch.is_locked(a.id, d):
                continue                     # 원티드·리더 고정은 건드리지 않는다
            for b in self.staff:
                if b.is_partjang or b.is_nk or b.is_designated or b.id == a.id:
                    continue
                y = sch.get(b.id, d)
                if y not in DAY_WORK_SHIFTS or sch.is_locked(b.id, d):
                    continue
                keep_a = sch.get(a.id, d)
                sch.grid[b.id][d] = Shift.OFF
                if self.can_assign_day(a, d, y):
                    sch.grid[a.id][d] = y
                    sch.log(f"[수리] {d+1}일: {b.id} {y} → {a.id}(지정)로 교체 (H1-6)")
                    return True
                sch.grid[b.id][d] = y        # 원복
                sch.grid[a.id][d] = keep_a
        return False

    # ------------------------------------------------------------ 레벨4+ 수리
    def level_short_shifts(self, d: int) -> List[Tuple[str, Shift]]:
        """그날 D/E/N 중 '배정 인원은 있는데 Lv4+가 하나도 없는' 근무 목록 (H1-5).

        ⚠ **야간은 야간리더도 충족으로 본다** — 검사기(check_h1_level_balance)와 화면
        (computeDailyLevelStats)이 그렇게 센다. 예전엔 여기만 Lv4만 보고 있었다.
        지금은 수리 루프가 야간을 건너뛰어서 결과가 안 바뀌었지만, 야간 수리를 다시
        켜는 순간 **이미 충족된 밤을 고치려고** 고연차를 끌어와 다른 필수를 깬다.
        검사기·화면·탐지기 셋이 같은 정의를 써야 한다(v0.85 Grok 검증, G-03/G-12).
        """
        out = []
        for key, shift in (("D", Shift.D), ("E", Shift.E), ("N", Shift.N)):
            on = [x for x in self.staff
                  if not x.is_partjang
                  and (self.sch.grid[x.id][d] in NIGHT_SHIFTS if shift == Shift.N
                       else self.sch.grid[x.id][d] == shift)]
            if not on:
                continue
            if any(x.level >= 4 for x in on):
                continue
            if shift == Shift.N and any(x.is_night_leader for x in on):
                continue
            out.append((key, shift))
        return out

    def _has_senior(self, d: int, shift: Shift, ignore: str = "") -> bool:
        for x in self.staff:
            if x.is_partjang or x.id == ignore or x.level < 4:
                continue
            v = self.sch.grid[x.id][d]
            if (v in NIGHT_SHIFTS) if shift == Shift.N else (v == shift):
                return True
        return False

    def repair_level_coverage(self, rounds: int = 2) -> int:
        """H1-5 수리 — 그 근무에 Lv4+가 없으면 고연차 한 명과 자리를 맞바꾼다.

        배정 중에는 점수로만 선호한다(need_senior4). 그런데 그 항은 **그날 그 조에
        아직 Lv4+가 없을 때만** 켜지는 최하위 동점 처리라, 고연차가 이미 다른 조에
        들어가 버린 뒤에는 되돌릴 방법이 없다. 탐욕적으로 앞에서부터 채우므로
        '지금 이 조에 꼭 필요한' 고연차를 앞 조가 먼저 가져가는 일이 생긴다.

        실측(40명 병동, 원티드 포함 12개월): E 14 · N 8 · D 6 = 28건. 병동에는
        D/E/N 가능한 Lv4+가 10명 있고 하루에 필요한 건 근무당 1명씩 3명뿐이라
        **용량 부족이 아니라 순서 문제**다 — 그래서 사후에 맞바꿔 고칠 수 있다.

        인원 수는 그대로다(같은 근무를 다른 사람이 선다). H1-1·H1-4는 흔들리지
        않는다. 고연차를 빼오는 쪽에 새 구멍이 생기지 않는지(_has_senior) 반드시
        확인한다 — 안 보면 구멍을 옮기기만 한다.

        야간은 칸 하나만 바꿀 수 없다(H2-4 단독 야간·H2-5 블록 후 휴식). 블록을
        통째로 옮긴다.
        """
        fixed = 0
        for _ in range(rounds):
            before = fixed
            for d in range(self.sch.num_days):
                for key, shift in self.level_short_shifts(d):
                    if shift == Shift.N:
                        continue          # 야간은 배정 시점에 잡는다(위 설명)
                    if self._swap_in_senior_day(d, shift):
                        fixed += 1
            if fixed == before:
                break
        return fixed

    def _swap_in_senior_day(self, d: int, shift: Shift) -> bool:
        """주간(D/E)에 Lv4+를 들여놓는다. **근무일 수를 늘리지 않는 쪽을 먼저 쓴다.**

        1단계 — 그날 다른 주간근무 중인 Lv4+와 자리를 맞바꾼다. 둘 다 근무 중이라
                누구의 근무일도 변하지 않는다(완전 중립).
        2단계 — 1단계가 안 되면 그날 쉬는 Lv4+를 넣고 비고연차를 뺀다. 이쪽은
                근무일이 한 칸 오간다. 그래서 **받는 쪽의 근무일이 더 적을 때만**
                한다 — 그러면 편차가 줄거나 그대로다.

        2단계를 조건 없이 먼저 쓰면 근무일 편차가 벌어진다. 실제로 그렇게 짰다가
        50명 병동 회귀 테스트가 깨졌다(편차 6일, 허용 4일) — 고연차만 계속 불려
        나오기 때문이다.
        """
        sch = self.sch
        wd = {x.id: sch.workdays_in_month(x.id) for x in self.staff}
        for stage in (1, 2):
            for a in self.staff:
                if a.is_partjang or a.is_nk or a.level < 4 or not a.can(shift):
                    continue
                if sch.is_locked(a.id, d):
                    continue              # 원티드·리더 고정은 건드리지 않는다
                cur_a = sch.get(a.id, d)
                if cur_a == shift:
                    continue              # 이미 그 조에 있으면 애초에 구멍이 아니다
                if stage == 1:
                    # 다른 주간근무에서 빼온다 — 그쪽에 Lv4+가 또 있어야 한다.
                    # 없으면 구멍을 옮기기만 한다. 야간에서는 안 빼온다(블록이 깨진다).
                    if cur_a not in (Shift.D, Shift.E):
                        continue
                    if not self._has_senior(d, cur_a, ignore=a.id):
                        continue
                else:
                    if cur_a is not None and cur_a not in REST_SHIFTS:
                        continue
                    if cur_a in LEAVE_SHIFTS:
                        continue          # 연차·병가 등은 쉬는 것이 아니라 쓰는 것이다
                for b in self.staff:
                    if b.is_partjang or b.is_nk or b.id == a.id or b.level >= 4:
                        continue
                    if sch.get(b.id, d) != shift or sch.is_locked(b.id, d):
                        continue
                    if stage == 2 and wd[a.id] >= wd[b.id]:
                        continue          # 편차를 벌리는 방향이면 하지 않는다
                    # H1-6을 깨뜨리면서까지 고치지 않는다. b가 지정 가능자이고
                    # a는 아니면, 이 교체로 그날 지정 인원이 한 명 준다 — 지정은
                    # 하드 규칙이라 H1-5 하나를 고치고 H1-6 하나를 만드는 셈이다.
                    # (지정 수리는 이 뒤에 돌지만, 자리가 이미 다 차 있으면 되돌리지
                    #  못한다 — 실제로 '22일 지정 인원 0명'이 그렇게 생겼다.)
                    if b.is_designated and not a.is_designated \
                            and self.min_for(d, DESIGNATED_KEY):
                        if self.sch.designated_count(d) <= self.min_for(d, DESIGNATED_KEY):
                            continue
                    keep_b = shift
                    sch.grid[b.id][d] = cur_a if cur_a is not None else Shift.OFF
                    sch.grid[a.id][d] = None
                    ok = self.can_assign_day(a, d, shift)
                    if ok and stage == 1:
                        ok = self.can_assign_day(b, d, cur_a)
                    if ok:
                        sch.grid[a.id][d] = shift
                        sch.log(f"[수리] {d+1}일: {b.id} {shift} → "
                                f"{a.id}(Lv{a.level})로 교체 (H1-5)")
                        return True
                    sch.grid[a.id][d] = cur_a      # 원복
                    sch.grid[b.id][d] = keep_b
        return False

    # 야간(H1-5)은 사후 수리를 하지 않는다 — 두 가지를 짜봤는데 둘 다 못 쓴다.
    #
    #   ① 쉬는 고연차를 그 밤에 넣고 비고연차를 뺀다
    #   ② 고연차가 다른 밤에 쓰고 있는 블록과 통째로 맞바꾼다(야간 횟수 보존)
    #
    # 40명 병동·야간전담 Lv2 조건에서 ①은 7번 불려 7번, ②는 38번 불려 38번 전부
    # 실패했다. 이유는 같다 — 야간은 블록(2~3일)에 뒤따르는 휴식 2일까지 묶여 있어서
    # 고연차가 **연속 4~5일을 통째로 비워야** 들어갈 수 있는데, 그 고연차는 바로 그
    # 날들에 D·E를 서고 있다. 그 사람의 주간까지 제3자에게 넘기는 3자 이동이라야
    # 풀리는데, 그러면 H1-1·H6-1·H3-1이 한꺼번에 흔들린다.
    #
    # 그래서 야간은 **배정 시점에** 잡는다 — _pick_night_candidate의 senior_fill이
    # 그 역할이고(소프트·형평성보다 위), 그걸 올린 것만으로 야간 H1-5가 NK Lv3 기준
    # 14 → 10건으로 줄었다. 사후 수리를 남겨두면 "돌고는 있으니 뭔가 하겠지"로
    # 읽히는데 실제로는 아무것도 안 한다 — 그게 더 나쁘다.

    # ------------------------------------------------------------ 최소인력 수리
    def count_deficits(self) -> int:
        n = 0
        for d in range(self.sch.num_days):
            for key, shift in (("D", Shift.D), ("E", Shift.E),
                               ("N", Shift.N), ("prn", Shift.PRN)):
                n += max(0, self.min_for(d, key)
                         - self.sch.count_shift(d, shift))
        return n

    def repair_min_staff(self):
        """H1-1 미달 칸을 이웃일 재배치로 수리 (E→prn 금지 등으로 후보가 없던 경우)."""
        lower = max(8, holiday_count(self.days) - 1)
        for d in range(self.sch.num_days):
            for key, shift in (("D", Shift.D), ("E", Shift.E), ("prn", Shift.PRN)):
                while self.sch.count_shift(d, shift) < self.min_for(d, key):
                    cand = self._pick_day_candidate(d, shift, protect_lower=lower)
                    if cand is not None:
                        self.sch.set(cand.id, d, shift)
                        continue
                    if self._repair_via_neighbor_transfer(d, shift, lower):
                        continue
                    if self._repair_via_same_day_switch(d, shift, lower):
                        continue
                    if self._window_rebuild(d):
                        continue
                    if self._window_rebuild(d, tries=20, span=5):
                        continue
                    if not self._repair_via_revoke_request(d, shift):
                        break

    def _repair_via_neighbor_transfer(self, d: int, shift: Shift,
                                      lower: int) -> bool:
        """이웃날 근무(E→x 금지·연속 5일 초과의 원인)를 제3자에게 이관해
        당일 부족 근무(H1-1)를 배정할 수 있게 만든다."""
        sch = self.sch
        # 1차: 수령자 OFF 하한을 지키는 이관만, 2차: 하한 무시(H1-1 > H4-1)
        for strict in (True, False):
            for a in self.staff:
                if a.is_partjang or a.is_nk or not a.can(shift):
                    continue
                if sch.get(a.id, d) != Shift.OFF or sch.is_locked(a.id, d):
                    continue
                for w in (d - 1, d + 1):
                    if not (0 <= w < sch.num_days):
                        continue
                    v = sch.get(a.id, w)
                    if v not in DAY_WORK_SHIFTS or sch.is_locked(a.id, w):
                        continue
                    if self._removal_creates_eod(a.id, w):
                        continue
                    sch.grid[a.id][w] = Shift.OFF
                    if not self.can_assign_day(a, d, shift):
                        sch.grid[a.id][w] = v
                        continue
                    receivers = sorted(
                        (r for r in self.staff if r.id != a.id),
                        key=lambda r: -sch.offs_in_month(r.id))
                    for r in receivers:
                        if strict and sch.offs_in_month(r.id) - 1 < lower:
                            continue
                        if self.can_assign_day(r, w, v) and \
                                self._lv3_guard_ok(a, r, w, v):
                            sch.set(r.id, w, v)
                            sch.set(a.id, d, shift)
                            sch.log(f"[수리] {w+1}일 {v}: {a.id}→{r.id} 이관 후 "
                                    f"{a.id} {d+1}일 {shift} 배정 (H1-1)")
                            return True
                    sch.grid[a.id][w] = v
        return False

    def _window_rebuild(self, d0: int, tries: int = 10, span: int = 3) -> bool:
        """부족일 주변 ±span일의 잠기지 않은 주간근무를 헐고 무작위 순서로 재충원.

        전역 미달 수가 줄어들 때만 채택 (destroy-and-repair).
        대형 병동에서 비용 폭주를 막기 위해 실행당 호출 횟수를 제한한다.
        """
        self._rebuild_calls = getattr(self, "_rebuild_calls", 0) + 1
        if self._rebuild_calls > 40:
            return False
        sch = self.sch
        lo, hi = max(0, d0 - span), min(sch.num_days - 1, d0 + span)
        snapshot = {s.id: sch.grid[s.id][lo:hi + 1] for s in self.staff}
        base = self.count_deficits()
        for _ in range(tries):
            for s in self.staff:
                if s.is_partjang or s.is_nk:
                    continue
                for dd in range(lo, hi + 1):
                    if sch.grid[s.id][dd] in DAY_WORK_SHIFTS \
                            and not sch.is_locked(s.id, dd):
                        sch.grid[s.id][dd] = Shift.OFF
            for dd in range(lo, hi + 1):
                for key, sh in (("D", Shift.D), ("E", Shift.E),
                                ("prn", Shift.PRN)):
                    need = self.min_for(dd, key) - sch.count_shift(dd, sh)
                    while need > 0:
                        cand = self._pick_day_candidate(dd, sh)
                        if cand is None:
                            break
                        sch.set(cand.id, dd, sh)
                        need -= 1
            if self.count_deficits() < base:
                sch.log(f"[수리] {d0+1}일 주변({lo+1}~{hi+1}일) 재구성으로 "
                        f"미달 {base}→{self.count_deficits()}건 (H1-1)")
                return True
            for s in self.staff:
                sch.grid[s.id][lo:hi + 1] = list(snapshot[s.id])
        return False

    def _revoke_order(self, reqs: dict, d: int, shift: Shift) -> List:
        """회수할 휴무 신청을 **S13의 반대 순서로** 고른다.

        예전엔 `sorted(reqs.items())`였다 — 키가 (이름, 날짜)라 사실상 **이름
        가나다순**이었다. 그러면 S13이 "적게 적은 분부터" 받아 준 휴무를, 하드가
        한 자리 모자랄 때 **이름이 앞이라는 이유로** 도로 뺏는다. 받는 쪽만 고치고
        뺏는 쪽을 그대로 두면 같은 사람이 또 진다 — 30개 병동-달에서 10번 돌던
        경로다(v0.86 자체 점검).

        1순위 **그 달 원티드를 많이 적은 사람부터** 회수한다(S13 1순위의 반대).
        2순위 그 근무에 **숙련도 4 이상이 없으면 Lv4+를 먼저** 부른다 — 어차피
        누군가를 다시 세워야 한다면 <code>H1-5</code>도 같이 메우는 쪽이 낫다.
        3순위 이름(같은 입력이 늘 같은 결과를 내도록).
        """
        n_req = getattr(self, "_n_req_cache", None)
        if n_req is None:
            n_req = self._n_req_cache = self._monthly_request_counts()
        need_senior = not self._has_senior(d, shift)
        out = []
        for (sid, dd), req in reqs.items():
            st = self.sch.by_id.get(sid)
            lv = st.level if st is not None else 0
            helps = 1 if (need_senior and lv >= 4) else 0
            out.append(((-n_req.get(sid, 0), -helps, sid, dd), ((sid, dd), req)))
        return [item for _, item in sorted(out, key=lambda x: x[0])]

    def _repair_via_revoke_request(self, d: int, shift: Shift) -> bool:
        """최후 수단: 원티드 OFF/연차를 반려(회수)하고 부족 근무를 배정.

        §3 우선순위 '하드(H1-1) > 원티드'에 따른 조치. 반려 사유를 기록한다.
        """
        sch = self.sch
        reqs = getattr(self, "_accepted_rest_reqs", {})
        for (sid, dd), req in self._revoke_order(reqs, d, shift):
            if dd != d:
                continue
            s = sch.by_id[sid]
            # 회수 시뮬레이션: 잠금 해제 후 배정 가능성 확인
            sch.locked.discard((sid, d))
            sch.requested_off.discard((sid, d))
            prev = sch.grid[sid][d]
            sch.grid[sid][d] = Shift.OFF
            lower = max(8, holiday_count(self.days) - 1)
            ok = False
            if self.can_assign_day(s, d, shift):
                sch.set(sid, d, shift)
                ok = True
            # 직접 배정이 막히면(연속근무 등) 이관·재구성까지 연쇄 시도
            elif self._repair_via_neighbor_transfer(d, shift, lower) or \
                    self._window_rebuild(d):
                ok = self.sch.count_shift(d, shift) >= self.min_for(
                    d, "prn" if shift == Shift.PRN else shift.value)
            if ok:
                req.accepted = False
                req.reject_reason = ("생성 중 최소인력(H1-1) 충족 불가 — "
                                     "하드 제약 우선(§3)으로 반려")
                del reqs[(sid, d)]
                sch.log(f"[수리] {d+1}일 {shift}: {sid}의 신청 {prev} 회수 "
                        f"(H1-1 > 원티드)")
                return True
            # 원복
            sch.grid[sid][d] = prev
            sch.locked.add((sid, d))
            sch.requested_off.add((sid, d))
        return False

    def _repair_via_same_day_switch(self, d: int, shift: Shift,
                                    lower: int) -> bool:
        """같은 날 다른 근무자(b)를 부족 근무로 돌리고, b가 비운 근무를
        제3자로 재충원한다. (예: E→prn 금지로 막힌 사람이 E는 설 수 있는 경우)"""
        sch = self.sch
        for b in self._staff_from(d):
            y = sch.get(b.id, d)
            if y not in DAY_WORK_SHIFTS or y == shift or sch.is_locked(b.id, d):
                continue
            sch.grid[b.id][d] = Shift.OFF
            if not self.can_assign_day(b, d, shift):
                sch.grid[b.id][d] = y
                continue
            sch.grid[b.id][d] = shift  # 가배정
            cand = self._pick_day_candidate(d, y, protect_lower=lower)
            if cand is not None:
                sch.set(cand.id, d, y)
                sch.log(f"[수리] {d+1}일: {b.id} {y}→{shift} 전환, "
                        f"{cand.id} {y} 충원 (H1-1)")
                return True
            if self._repair_via_neighbor_transfer(d, y, lower):
                sch.log(f"[수리] {d+1}일: {b.id} {y}→{shift} 전환 (H1-1)")
                return True
            sch.grid[b.id][d] = y  # 원복
        return False

    # ------------------------------------------------------------ 마무리(기본 OFF)
    def finalize_offs(self):
        for s in self.staff:
            for d in range(self.sch.num_days):
                if self.sch.get(s.id, d) is None:
                    self.sch.set(s.id, d, Shift.OFF)

    # ------------------------------------------------------------ Step 7 (G4)
    def fix_alternation(self) -> int:
        """S7 퐁당퐁당(ODO/OEO — 고립된 하루 근무) 완화. 한 번 고치면 다른 사람 자리가
        비어 새로 고칠 여지가 생길 수 있어, 호출부에서 변화 없을 때까지 반복 호출한다."""
        sch = self.sch
        nd = sch.num_days
        fixed = 0
        for s in self.staff:
            if s.is_partjang or s.is_nk:
                continue
            for d in range(nd):
                v = sch.get(s.id, d)
                if v not in DAY_WORK_SHIFTS:      # 야간·8A 제외 (가드⑤)
                    continue
                if sch.is_locked(s.id, d):        # 원티드 확정분 제외 (가드⑥)
                    continue
                if not (sch.effective(s.id, d - 1) in REST_SHIFTS
                        and sch.effective(s.id, d + 1) in REST_SHIFTS):
                    continue
                if self._try_transfer(s, d, v) or self._try_swap(s, d, v):
                    fixed += 1
        return fixed

    # ------------------------------------------------------------ Step 7b (H6-1)
    def _short_day_blocks(self) -> List[Tuple[Staff, int, int]]:
        """길이 1~2일짜리 D/E/prn 연속블록 목록 [(직원, start, end), ...].

        전월에서 이어지는 블록(정확한 시작을 모름)은 건드리지 않는다. 블록 바로
        다음날이 야간(N/NK)으로 이어지는 경우도 check_h6_day_block_length()와
        같은 이유로 건드리지 않는다 — 야간 시작 직전 준비 근무로 보고 예외로
        허용하는 블록이라, 억지로 늘리거나 다른 사람에게 넘기면 오히려 잘
        짜인 야간 전환 배치를 망가뜨릴 수 있다."""
        sch = self.sch
        nd = sch.num_days
        out: List[Tuple[Staff, int, int]] = []
        for s in self.staff:
            if s.is_partjang or s.is_nk:
                continue
            d = 0
            while d < nd:
                if sch.effective(s.id, d) not in DAY_WORK_SHIFTS:
                    d += 1
                    continue
                start = d
                while d + 1 < nd and sch.effective(s.id, d + 1) in DAY_WORK_SHIFTS:
                    d += 1
                end = d
                carried = (start == self.month_start(s.id)
                          and sch.carryover[s.id].last_shift_type in DAY_WORK_SHIFTS)
                length = end - start + 1
                next_is_night = end + 1 < nd and sch.effective(s.id, end + 1) in NIGHT_SHIFTS
                if length < 3 and not carried and not next_is_night:
                    out.append((s, start, end))
                d = end + 1
        return out

    def fix_short_day_blocks(self, max_passes: int = 5) -> int:
        """H6-1: 1~2일짜리 고립 주간근무 블록을 3일 이상으로 확장하거나(우선),
        확장이 불가하면 다른 사람에게 이관/맞교환한다(fix_alternation과 동일 기법).

        월경계 등에서 인접 블록이 이미 4일 꽉 차 확장·이관이 모두 막히는 경우가
        남을 수 있다 — 최종 리포트에 H6-1 잔여 위반으로 표시된다(§H1-1과 동일하게
        최선 노력 후 잔존을 허용하는 방식)."""
        sch = self.sch
        fixed_total = 0
        for _ in range(max_passes):
            blocks = self._short_day_blocks()
            if not blocks:
                break
            any_fixed = False
            for s, start, end in blocks:
                grown = False
                for dd, vv in ((end + 1, sch.get(s.id, end)),
                              (start - 1, sch.get(s.id, start))):
                    if not (0 <= dd < sch.num_days):
                        continue
                    if sch.is_locked(s.id, dd) or sch.get(s.id, dd) != Shift.OFF:
                        continue
                    # 최소인력은 상한이기도 하다 — 순수 추가(이관/맞교환과 달리
                    # 총원이 늘어남)라 확장 전에 그날 이미 목표 인원인지 확인.
                    key = "prn" if vv == Shift.PRN else vv.value
                    if sch.count_shift(dd, vv) >= self.min_for(dd, key):
                        continue
                    if self.can_assign_day(s, dd, vv):
                        sch.set(s.id, dd, vv)
                        sch.log(f"[H6-1] {s.id}: {dd+1}일 {vv} 추가 — "
                                f"단기블록({start+1}~{end+1}일) 확장")
                        grown = True
                        any_fixed = True
                        fixed_total += 1
                        break
                if grown:
                    continue
                for dd in range(start, end + 1):
                    if sch.is_locked(s.id, dd):
                        continue
                    vv = sch.get(s.id, dd)
                    if self._try_transfer(s, dd, vv) or self._try_swap(s, dd, vv):
                        any_fixed = True
                        fixed_total += 1
            if not any_fixed:
                break
        return fixed_total

    def _lv3_guard_ok(self, donor: Optional[Staff], receiver: Optional[Staff],
                      d: int, shift: Shift) -> bool:
        """가드③: 이동 후에도 해당 근무 고랩(상대 기준선) 유지. donor=None이면 순수 추가(제외 없음)."""
        # 답은 불리언 하나다: "이동 뒤 그 조에 min_lv 이상이 한 명이라도 남는가(조가
        # 비면 참)". 그래서 레벨 내림차순으로 보다가 그 조에 있는 첫 사람을 만나면 바로
        # 답이 정해진다 — 그 사람이 기준 미만이면 뒤 사람은 전부 더 낮다. 예전엔 매번
        # 전 직원을 훑어 레벨 목록을 만들었고(100명 병동에서 호출 14만 번), 그게 생성
        # 시간의 3할이었다. 결과는 같다(tests/test_level_stats_counters.py가 대조).
        min_lv = self._senior_min_level(shift)
        if receiver is not None and receiver.level >= min_lv:
            return True
        grid = self.sch.grid
        donor_id = donor.id if donor is not None else None
        for s in self._staff_by_level_desc:
            if s.id == donor_id or grid[s.id][d] != shift:
                continue
            return s.level >= min_lv
        return receiver is None

    def _staff_from(self, d: int) -> List[Staff]:
        """명단을 d일 기준으로 회전한 순서 — 선착순 루프용.

        이관·맞교환 같은 뒷단계는 '명단 순서대로 훑다 되는 첫 사람'을 쓴다. 명단이 레벨순이면 위쪽
        사람에게 변경이 몰려 표에 띠가 생긴다(같은 레벨끼리 같은 근무). 날짜마다 시작점을 돌리면
        같은 입력에 같은 결과(난수 없음)이면서 변경이 명단 전체로 퍼진다.

        2026-10-22에 '회전이면 한 날에 이웃한 두세 명이 연달아 뽑혀 두 줄짜리 띠가 되지 않나' 싶어
        날짜별 섞기로 바꿔 봤다 — 재 보니 명단순·회전·섞기 어느 것도 이웃 유사도·같은 레벨 유사도가
        우연 수준(0.09~0.11)으로 같았다(tools/adjacency_experiment.py). 화면에서 보이는 '이웃이 같은
        블록'은 한 달에 10건 안팎으로 우연이다. 그래서 회전으로 되돌렸다."""
        n = len(self.staff)
        if n == 0:
            return []
        k = d % n
        return self.staff[k:] + self.staff[:k]

    def _try_transfer(self, donor: Staff, d: int, shift: Shift) -> bool:
        """G4-a: 퐁당퐁당 근무를 인접 근무자가 있는 다른 사람에게 이관."""
        sch = self.sch
        grid = sch.grid
        locked = sch.locked
        # 휴일수는 달 안에서 안 변한다 — 예전엔 후보마다 달력을 다시 세었다.
        hol = self.holiday_count
        donor_wd = sch.workdays_in_month(donor.id)
        donor_over = sch.offs_in_month(donor.id) + 1 > hol + 2
        if donor_over:
            return False
        off_floor = max(8, hol - 1)
        for r in self._staff_from(d):
            if r.id == donor.id or r.is_partjang or r.is_nk:
                continue
            if grid[r.id][d] != Shift.OFF or (r.id, d) in locked:
                continue
            adjacent = (sch.effective(r.id, d - 1) in WORK_SHIFTS
                        or sch.effective(r.id, d + 1) in WORK_SHIFTS)
            if not adjacent:
                continue
            # 가드④: 근무일수 편차 악화 금지
            if sch.workdays_in_month(r.id) > donor_wd:
                continue
            # 가드: 수령자의 OFF 하한(H4-1) 붕괴·기증자의 OFF 상한(G6) 초과 금지
            if sch.offs_in_month(r.id) - 1 < off_floor:
                continue
            if not self._lv3_guard_ok(donor, r, d, shift):
                continue
            # 수령자 배정 가능성 (가드①② 포함: can_assign_day가 검사)
            sch.grid[donor.id][d] = Shift.OFF  # 임시 제거 후 검사
            ok = self.can_assign_day(r, d, shift)
            if ok:
                sch.set(r.id, d, shift)
                sch.log(f"[G4-a] {d+1}일 {shift}: {donor.id} → {r.id} 이관")
                return True
            sch.grid[donor.id][d] = shift  # 원복
        return False

    def _try_swap(self, donor: Staff, d: int, shift: Shift) -> bool:
        """G4-b: 인접일 근무자와 맞교환 (donor d일 근무 ↔ partner 인접일 근무)."""
        sch = self.sch
        grid = sch.grid
        locked = sch.locked
        for nd_ in (d - 1, d + 1):
            if not (0 <= nd_ < sch.num_days):
                continue
            # 기증자 쪽 조건은 상대와 무관하다 — 상대를 훑기 전에 한 번만 본다.
            if grid[donor.id][nd_] != Shift.OFF or (donor.id, nd_) in locked:
                continue
            for p in self._staff_from(d):
                if p.id == donor.id or p.is_partjang or p.is_nk:
                    continue
                prow = grid[p.id]
                pv = prow[nd_]
                if pv not in DAY_WORK_SHIFTS or (p.id, nd_) in locked:
                    continue
                if prow[d] != Shift.OFF or (p.id, d) in locked:
                    continue
                if not self._lv3_guard_ok(donor, p, d, shift):
                    continue
                if not self._lv3_guard_ok(p, donor, nd_, pv):
                    continue
                # 시험 적용
                sch.grid[donor.id][d] = Shift.OFF
                sch.grid[p.id][nd_] = Shift.OFF
                ok = (self.can_assign_day(p, d, shift)
                      and self.can_assign_day(donor, nd_, pv))
                if ok:
                    sch.set(p.id, d, shift)
                    sch.set(donor.id, nd_, pv)
                    sch.log(f"[G4-b] {donor.id}({d+1}일 {shift}) ↔ {p.id}({nd_+1}일 {pv}) 맞교환")
                    return True
                sch.grid[donor.id][d] = shift
                sch.grid[p.id][nd_] = pv
        return False

    # ------------------------------------------------------------ Step 7 보완: 전역 탐색
    # fix_alternation(위)은 인접일(±1)만 보고, 그 자리에서 "새 문제를 안 만드는지"를
    # 로컬로만 판단한다 — 실측해보니 검색 폭을 넓히거나 로컬 부작용을 막는 시도 둘 다
    # 오히려 잔여를 늘렸다(문서화된 실험 참고). 대신 여기서는 완전히 별도 단계로,
    # "그 달 전체 아무 날짜"를 상대로 이관/맞교환을 시도하되, 채택 기준을 "이 칸 주변에
    # 새 문제가 생기는지"가 아니라 "전체 고립근무일 수가 늘지 않는지"로 바꾼다 — 국소
    # 판단의 오류(멀리 있는 부작용을 놓치거나, 나중에 사슬로 풀릴 기회를 막는 것) 없이
    # 정확한 전역 기준으로 판단한다. 최선노력이며, 호출 횟수 상한으로 대형 병동 성능을 보호한다.

    def _is_isolated_workday(self, sid: str, d: int) -> bool:
        sch = self.sch
        if not (0 <= d < sch.num_days):
            return False
        if sch.effective(sid, d) not in DAY_WORK_SHIFTS:
            return False
        return (sch.effective(sid, d - 1) in REST_SHIFTS
                and sch.effective(sid, d + 1) in REST_SHIFTS)

    def _is_isolated_2block(self, sid: str, d: int) -> bool:
        """d,d+1 이틀 연속 근무가 앞뒤로 휴무에 둘러싸여 고립된 "2일짜리 블록"인지.

        d+2가 근무이면(3일 이상 블록) 여기 안 걸린다 — 정확히 2일짜리만 잡는다.
        """
        sch = self.sch
        nd = sch.num_days
        if not (0 <= d and d + 1 < nd):
            return False
        if sch.effective(sid, d) not in DAY_WORK_SHIFTS:
            return False
        if sch.effective(sid, d + 1) not in DAY_WORK_SHIFTS:
            return False
        return (sch.effective(sid, d - 1) in REST_SHIFTS
                and sch.effective(sid, d + 2) in REST_SHIFTS)

    def _local_isolation_score(self, cells) -> int:
        """cells(=[(직원id, 날짜), ...]) 주변만 놓고 센 고립근무(1일+2일블록) 개수.

        이관/맞교환은 딱 이 칸들의 근무값만 바꾸므로, 다른 어떤 칸의 고립 여부도
        바뀔 수 없다(1일 고립 판정은 자기 자신과 바로 옆 칸, 2일블록 고립 판정은
        최대 ±2칸까지만 본다) — 그래서 각 칸을 ±2 여유를 두고 넓혀서 확인하면
        이 부분합의 전/후 비교가 전체 보드를 다시 세는 것과 수학적으로 완전히
        같은 결과를 주면서, 대형 병동에서도 빠르다(전체 O(인원×일수) 대신 O(1))."""
        expanded = set()
        for sid, dd in cells:
            for delta in (-2, -1, 0, 1, 2):
                expanded.add((sid, dd + delta))
        score = 0
        for sid, dd in expanded:
            if self._is_isolated_workday(sid, dd):
                score += 1
            if self._is_isolated_2block(sid, dd):
                score += 1
        return score

    def global_fix_alternation(self, max_passes: int = 3, call_budget: int = 4000) -> int:
        """S7 잔여를 추가로 줄이는 전역 마무리 탐색 — fix_alternation이 끝난 뒤 호출."""
        sch = self.sch
        calls = 0
        fixed_total = 0
        for _ in range(max_passes):
            isolated = [(s, d) for s in self.staff if not (s.is_partjang or s.is_nk)
                       for d in range(sch.num_days)
                       if not sch.is_locked(s.id, d) and self._is_isolated_workday(s.id, d)]
            if not isolated:
                break
            any_fixed = False
            for s, d in isolated:
                if calls > call_budget:
                    return fixed_total
                if not self._is_isolated_workday(s.id, d):
                    continue  # 이번 패스 중 이미 다른 조치로 해소됨
                v = sch.get(s.id, d)
                calls += 1
                if self._try_global_transfer(s, d, v) or self._try_global_swap(s, d, v):
                    fixed_total += 1
                    any_fixed = True
            if not any_fixed:
                break
        return fixed_total

    def _try_global_transfer(self, donor: Staff, d: int, shift: Shift) -> bool:
        sch = self.sch
        hol = holiday_count(self.days)
        for r in self._staff_from(d):
            if r.id == donor.id or r.is_partjang or r.is_nk:
                continue
            if sch.get(r.id, d) != Shift.OFF or sch.is_locked(r.id, d):
                continue
            if sch.workdays_in_month(r.id) > sch.workdays_in_month(donor.id):
                continue
            if sch.offs_in_month(r.id) - 1 < max(8, hol - 1):
                continue
            if sch.offs_in_month(donor.id) + 1 > hol + 2:
                continue
            if not self._lv3_guard_ok(donor, r, d, shift):
                continue
            cells = [(donor.id, d - 1), (donor.id, d), (donor.id, d + 1),
                    (r.id, d - 1), (r.id, d), (r.id, d + 1)]
            before = self._local_isolation_score(cells)
            sch.grid[donor.id][d] = Shift.OFF
            ok = self.can_assign_day(r, d, shift)
            if ok:
                sch.set(r.id, d, shift)
                if self._local_isolation_score(cells) <= before:
                    sch.log(f"[G4-a 전역] {d+1}일 {shift}: {donor.id} → {r.id} 이관")
                    return True
                sch.grid[r.id][d] = Shift.OFF
            sch.grid[donor.id][d] = shift
        return False

    def _try_global_swap(self, donor: Staff, d: int, shift: Shift) -> bool:
        sch = self.sch
        for nd_ in range(sch.num_days):
            if nd_ == d:
                continue
            for p in self._staff_from(nd_):
                if p.id == donor.id or p.is_partjang or p.is_nk:
                    continue
                pv = sch.get(p.id, nd_)
                if pv not in DAY_WORK_SHIFTS or sch.is_locked(p.id, nd_):
                    continue
                if sch.get(p.id, d) != Shift.OFF or sch.is_locked(p.id, d):
                    continue
                if sch.get(donor.id, nd_) != Shift.OFF or sch.is_locked(donor.id, nd_):
                    continue
                cells = [(donor.id, d - 1), (donor.id, d), (donor.id, d + 1),
                        (p.id, d - 1), (p.id, d), (p.id, d + 1),
                        (donor.id, nd_ - 1), (donor.id, nd_), (donor.id, nd_ + 1),
                        (p.id, nd_ - 1), (p.id, nd_), (p.id, nd_ + 1)]
                before = self._local_isolation_score(cells)
                # Lv3 가드는 O(인원수)라 비용이 크다 — 대형 병동에서 이 이중루프
                # (일수×인원)와 곱해지면 전체가 너무 느려지므로, 훨씬 싼 하드 제약
                # 검사(can_assign_day)를 먼저 통과한 후보에게만 적용해 호출 수를 줄인다.
                sch.grid[donor.id][d] = Shift.OFF
                sch.grid[p.id][nd_] = Shift.OFF
                ok = (self.can_assign_day(p, d, shift)
                      and self.can_assign_day(donor, nd_, pv))
                if ok and self._lv3_guard_ok(donor, p, d, shift) \
                        and self._lv3_guard_ok(p, donor, nd_, pv):
                    sch.set(p.id, d, shift)
                    sch.set(donor.id, nd_, pv)
                    if self._local_isolation_score(cells) <= before:
                        sch.log(f"[G4-b 전역] {donor.id}({d+1}일 {shift}) ↔ "
                                f"{p.id}({nd_+1}일 {pv}) 맞교환")
                        return True
                    sch.grid[p.id][d] = Shift.OFF
                    sch.grid[donor.id][nd_] = Shift.OFF
                sch.grid[donor.id][d] = shift
                sch.grid[p.id][nd_] = pv
        return False

    def global_fix_2blocks(self, max_passes: int = 3, call_budget: int = 4000) -> int:
        """2일짜리 고립 근무블록(O-근무-근무-O)을 인접 휴무일을 근무로 늘려
        3일 이상 블록으로 확장해 고립을 해소한다 — global_fix_alternation 뒤에 호출.
        한 명 고치면 다른 사람 자리(OFF)가 새로 열려 반복하면 더 줄어들 수 있어
        fix_alternation과 같은 방식으로 수렴할 때까지 반복한다."""
        sch = self.sch
        calls = 0
        fixed_total = 0
        for _ in range(max_passes):
            blocks = [(s, d) for s in self.staff if not (s.is_partjang or s.is_nk)
                     for d in range(sch.num_days - 1)
                     if not sch.is_locked(s.id, d) and not sch.is_locked(s.id, d + 1)
                     and self._is_isolated_2block(s.id, d)]
            if not blocks:
                break
            any_fixed = False
            for s, d in blocks:
                if calls > call_budget:
                    return fixed_total
                if not self._is_isolated_2block(s.id, d):
                    continue  # 이번 패스 중 이미 다른 조치로 해소됨
                calls += 1
                if self._try_extend_2block(s, d):
                    fixed_total += 1
                    any_fixed = True
            if not any_fixed:
                break
        return fixed_total

    def _try_extend_2block(self, donor: Staff, d: int) -> bool:
        """d-1(앞) 또는 d+2(뒤) 휴무일 하나를 같은 사람 근무로 바꿔 블록을 늘린다."""
        sch = self.sch
        hol = holiday_count(self.days)
        for ext_d, shift in ((d - 1, sch.get(donor.id, d)),
                            (d + 2, sch.get(donor.id, d + 1))):
            if not (0 <= ext_d < sch.num_days):
                continue
            if sch.get(donor.id, ext_d) != Shift.OFF or sch.is_locked(donor.id, ext_d):
                continue
            if sch.offs_in_month(donor.id) - 1 < max(8, hol - 1):
                continue  # H4-1: 확장하면 본인 OFF 하한이 깨짐
            # 가드는 반드시 칸을 바꾸기 전에(현재 그리드 기준으로) 검사해야 한다 —
            # can_assign_day의 첫 체크(_cell_free)가 "지금 OFF인가"를 보기 때문에,
            # 먼저 값을 바꿔버리면 항상 실패로 나온다.
            if not self.can_assign_day(donor, ext_d, shift):
                continue
            if not self._lv3_guard_ok(None, donor, ext_d, shift):
                continue
            cells = [(donor.id, ext_d)]
            before = self._local_isolation_score(cells)
            sch.grid[donor.id][ext_d] = shift
            if self._local_isolation_score(cells) <= before:
                sch.log(f"[2블록 확장] {donor.id} {ext_d+1}일 OFF→{shift} "
                        f"(고립 2일블록 {d+1}~{d+2}일 해소)")
                return True
            sch.grid[donor.id][ext_d] = Shift.OFF
        return False

    # ------------------------------------------------------------ Step 8 (G6)
    def equalize_off(self):
        sch = self.sch
        hol = holiday_count(self.days)
        upper = hol + 2
        lower = max(8, hol - 1)
        # 1) OFF 부족자(H4-1) 해소 + 균등화: 근무 이관 (S3/S4)
        self._balance_transfers(lower)
        # 2) 그래도 초과인 사람: 추가 근무 배정 (PRN 우선 → D/E, G8)
        for s in self.staff:
            if s.is_partjang or s.is_nk:
                continue
            guard = 0
            while sch.offs_in_month(s.id) > upper and guard < 31:
                guard += 1
                if not self._add_one_workday(s):
                    break
        # 3) 잔여 미달자: 초과 인력 날에서 근무 제거 (최후 수단)
        for s in self.staff:
            if s.is_partjang or s.is_nk:
                continue
            guard = 0
            while sch.offs_in_month(s.id) < lower and guard < 31:
                guard += 1
                if not self._remove_one_workday(s):
                    break

    def _balance_transfers(self, lower: int):
        """OFF가 적은(과로) 사람의 주간근무를 OFF가 많은 사람에게 이관.

        총 근무 슬롯 수는 유지되므로 H1-1에 영향 없음.
        """
        sch = self.sch
        generals = [s for s in self.staff if not (s.is_partjang or s.is_nk)]
        for _ in range(400):
            offs = {s.id: sch.offs_in_month(s.id) for s in generals}
            donors = sorted(generals, key=lambda s: offs[s.id])
            moved = False
            for donor in donors:
                # 하한 미달이거나 편차가 2 초과인 경우만 이관 시도
                max_off = max(offs.values())
                need_fix = offs[donor.id] < lower or \
                    (max_off - offs[donor.id]) > 2
                if not need_fix:
                    continue
                receivers = sorted(
                    [r for r in generals if offs[r.id] > offs[donor.id] + 1],
                    key=lambda r: -offs[r.id])
                if not receivers:
                    continue
                # H4-1(하드) 미달 해소가 S6(소프트) Lv3 유지보다 우선
                allow_lv3_break = offs[donor.id] < lower
                if self._transfer_one_workday(donor, receivers, allow_lv3_break):
                    moved = True
                    break
            if not moved:
                break

    def _transfer_one_workday(self, donor: Staff, receivers: List[Staff],
                              allow_lv3_break: bool = False) -> bool:
        sch = self.sch
        # 주말 근무를 우선 이관 (S5: 주말 OFF 공평분배 개선)
        day_order = sorted(range(sch.num_days),
                           key=lambda d: self.days[d].day_type == DAY_WEEKDAY)
        for d in day_order:
            v = sch.get(donor.id, d)
            if v not in DAY_WORK_SHIFTS or sch.is_locked(donor.id, d):
                continue
            if self._removal_creates_eod(donor.id, d):
                continue
            for r in receivers:
                if sch.get(r.id, d) != Shift.OFF or sch.is_locked(r.id, d):
                    continue
                if not allow_lv3_break and not self._lv3_guard_ok(donor, r, d, v):
                    continue
                sch.grid[donor.id][d] = Shift.OFF
                if self.can_assign_day(r, d, v):
                    sch.set(r.id, d, v)
                    sch.log(f"[G6] {d+1}일 {v}: {donor.id} → {r.id} 이관(잔휴 균등화)")
                    return True
                sch.grid[donor.id][d] = v
        return False

    def _add_one_workday(self, s: Staff) -> bool:
        sch = self.sch
        # OFF 많은 날 중 배정 가능한 날 탐색 (퐁당퐁당 안 만드는 날 우선)
        # ⚠ 최소인력은 상한이기도 하다 — 그날 그 근무유형이 이미 최소인력만큼
        # 차 있으면(=목표 인원 도달) 더 채우지 않고 다른 날/근무를 찾는다.
        candidates = []
        for d in range(sch.num_days):
            if sch.get(s.id, d) != Shift.OFF or sch.is_locked(s.id, d):
                continue
            for shift in (Shift.PRN, Shift.D, Shift.E):
                key = "prn" if shift == Shift.PRN else shift.value
                if sch.count_shift(d, shift) >= self.min_for(d, key):
                    continue
                if not self.can_assign_day(s, d, shift):
                    continue
                odo = 1 if (sch.effective(s.id, d - 1) in REST_SHIFTS
                            and sch.effective(s.id, d + 1) in REST_SHIFTS) else 0
                pref = 0 if shift == Shift.PRN else 1  # G8: PRN 우선
                over = sch.count_shift(d, shift) - self.min_for(
                    d, "prn" if shift == Shift.PRN else shift.value)
                candidates.append((odo, pref, over, d, shift))
        if not candidates:
            return False
        candidates.sort()
        _, _, _, d, shift = candidates[0]
        sch.set(s.id, d, shift)
        sch.log(f"[G6] {s.id}: OFF 초과 → {d+1}일 {shift} 추가 배정")
        return True

    def _remove_one_workday(self, s: Staff) -> bool:
        sch = self.sch
        for d in range(sch.num_days):
            v = sch.get(s.id, d)
            if v not in DAY_WORK_SHIFTS or sch.is_locked(s.id, d):
                continue
            key = "prn" if v == Shift.PRN else v.value
            if sch.count_shift(d, v) - 1 < self.min_for(d, key):
                continue  # 최소인력 붕괴 금지 (H1-1)
            if not self._lv3_guard_ok(s, None, d, v):
                continue
            if self._removal_creates_eod(s.id, d):
                continue
            sch.grid[s.id][d] = Shift.OFF
            sch.log(f"[G6] {s.id}: OFF 부족 → {d+1}일 {v} 제거")
            return True
        return False

    def _removal_creates_eod(self, sid: str, d: int) -> bool:
        """이 칸을 비우면(OFF) E-O-D(EOD, H6-3) 패턴이 새로 생기는지."""
        sch = self.sch
        return (sch.effective(sid, d - 1) == Shift.E
                and sch.effective(sid, d + 1) == Shift.D)

    # ------------------------------------------------------------ Step 10c (S11)
    def _lv1_night_counts(self) -> List[int]:
        """날짜별 '야간을 서는 Lv1 일반 간호사' 수 (야간전담·파트장 제외)."""
        sch = self.sch
        lv1 = [s.id for s in self.staff
               if s.level == 1 and not (s.is_partjang or s.is_nk)]
        return [sum(1 for sid in lv1 if sch.grid[sid][d] in NIGHT_SHIFTS)
                for d in range(sch.num_days)]

    @staticmethod
    def _lv1_cluster_cost(counts: List[int]) -> int:
        """뭉침 비용 — 한 밤에 Lv1이 n명이면 (n-1)을 더한다.

        3명인 밤(비용 2)이 2명인 밤 둘(비용 1+1)보다 나쁘지 않게 같은 값이 되므로,
        아래 교환은 '총합이 같으면 최대치가 낮은 쪽'을 함께 본다."""
        return sum(max(0, c - 1) for c in counts)

    def reduce_lv1_night_clusters(self, max_swaps: int = 40) -> int:
        """S11 후처리 — Lv1이 3명 이상 몰린 밤을, Lv1의 야간블록을 통째로 비-Lv1에게
        넘겨서 푼다.

        이 병동처럼 Lv1의 야간 총량(8명×6회=48칸)이 밤 수(31)를 넘으면 2명인 밤은
        산술적으로 못 없앤다 — 없앨 수 있는 것은 '몰린 정도'뿐이라, 최대 인원이
        낮아지는 교환만 채택한다. 배정 단계(_pick_night_candidate)의 점수만으로는
        그 순간 후보가 Lv1뿐이면 그대로 뽑히므로 여기서 한 번 더 훑는다.

        하드 위반이 하나라도 늘면 되돌린다 — 뭉침을 줄이자고 안전 규칙을 깨지 않는다.
        """
        from .constraints import all_hard_checks

        sch = self.sch
        nd = sch.num_days
        base_hard = len(all_hard_checks(sch, self.days, self.params))
        swaps = 0
        for _ in range(max_swaps):
            counts = self._lv1_night_counts()
            worst = max(counts) if counts else 0
            if worst < 3:
                break
            day = counts.index(worst)
            moved = False
            for s in self.staff:
                if s.level != 1 or s.is_partjang or s.is_nk:
                    continue
                if sch.grid[s.id][day] not in NIGHT_SHIFTS:
                    continue
                # 그 사람의 야간블록 전체를 찾는다(연속된 N 구간)
                a = day
                while a > 0 and sch.grid[s.id][a - 1] in NIGHT_SHIFTS:
                    a -= 1
                b = day
                while b + 1 < nd and sch.grid[s.id][b + 1] in NIGHT_SHIFTS:
                    b += 1
                if any(sch.is_locked(s.id, k) for k in range(a, b + 1)):
                    continue
                for r in self.staff:
                    if r.level == 1 or r.is_partjang or r.is_nk or r.no_night:
                        continue
                    if Shift.N not in r.allowed_shifts:
                        continue
                    if any(sch.grid[r.id][k] is not Shift.OFF or sch.is_locked(r.id, k)
                           for k in range(a, b + 1)):
                        continue
                    before = [sch.grid[s.id][k] for k in range(a, b + 1)]
                    for k in range(a, b + 1):
                        sch.set(s.id, k, Shift.OFF)
                        sch.set(r.id, k, Shift.N)
                    new_counts = self._lv1_night_counts()
                    ok = (max(new_counts) < worst
                          and self._lv1_cluster_cost(new_counts)
                          <= self._lv1_cluster_cost(counts)
                          and len(all_hard_checks(sch, self.days, self.params)) <= base_hard)
                    if ok:
                        sch.log(f"[S11] {a+1}~{b+1}일 야간: {s.id}(Lv1) → {r.id}(Lv{r.level}) "
                                f"— {day+1}일 Lv1 {worst}명 몰림 해소")
                        swaps += 1
                        moved = True
                        break
                    for i, k in enumerate(range(a, b + 1)):
                        sch.set(r.id, k, Shift.OFF)
                        sch.set(s.id, k, before[i])
                if moved:
                    break
            if not moved:
                break
        return swaps

    # ------------------------------------------------------------ Step 5b (H7-1)
    # ------------------------------------------------------------ D/E 균등(마무리)
    def _de_dayers(self) -> List[Staff]:
        return [s for s in self.staff
                if not (s.is_partjang or s.is_nk)
                and Shift.D in s.allowed_shifts and Shift.E in s.allowed_shifts]

    def _shift_has_level(self, d: int, shift: Shift, min_level: int) -> bool:
        for x in self.staff:
            if not x.is_partjang and x.level >= min_level \
                    and self.sch.grid[x.id][d] == shift:
                return True
        return False

    def _try_swap_de_segment(self, a: Staff, b: Staff, x: int, y: int) -> bool:
        """x~y일 동안 a의 D와 b의 E를 맞바꾼다(a는 E, b는 D가 된다). 안 되면 원상복구.

        그날 D 인원·E 인원은 그대로고(한 명씩 서로 바뀔 뿐), 두 사람의 근무일·오프도
        그대로라 최소인력(H1-1·H1-4)·오프(H4-1)·연속근무(H3-1)·주간블록 길이(H6-1)·
        퐁당퐁당(S7)은 건드리지 않는다. 걸릴 수 있는 것은 근무 이음새다 — E 다음날 D
        (H3-2)·E-오프-D(H6-3). 그건 can_assign_day가 앞뒤를 다 보므로 한 칸씩 다시 놓으며
        그대로 맡긴다. 그날 조의 고연차(H1-5 Lv4+, S6 상대기준)는 따로 본다 — 둘 중
        누가 그 조의 유일한 고연차였으면 맞바꾸는 순간 구멍이 된다.
        """
        sch = self.sch
        days = range(x, y + 1)
        lv_need = {sh: self._senior_min_level(sh) for sh in (Shift.D, Shift.E)}
        before = {(d, sh, lv): self._shift_has_level(d, sh, lv)
                  for d in days for sh in (Shift.D, Shift.E)
                  for lv in {4, lv_need[sh]}}
        for d in days:
            sch.set(a.id, d, Shift.OFF)
            sch.set(b.id, d, Shift.OFF)
        ok = True
        for d in days:
            if not self.can_assign_day(a, d, Shift.E):
                ok = False
                break
            sch.set(a.id, d, Shift.E)
        if ok:
            for d in days:
                if not self.can_assign_day(b, d, Shift.D):
                    ok = False
                    break
                sch.set(b.id, d, Shift.D)
        if ok:
            ok = all(self._shift_has_level(d, sh, lv) or not had
                     for (d, sh, lv), had in before.items())
        if not ok:
            for d in days:
                sch.set(a.id, d, Shift.D)
                sch.set(b.id, d, Shift.E)
        return ok

    def balance_day_types(self, max_moves: int = 200, call_budget: int = 3000) -> int:
        """사람마다 D와 E를 고르게 — 같은 날 D인 사람과 E인 사람의 구간을 맞바꾼다.

        총 근무일수는 이미 고르게 나온다(S4). 갈리는 건 근무의 **종류**였다 — 샘플 40명
        병동 11월에 D가 1~14회, E가 1~17회로, 한 사람은 D만 서고 다른 사람은 E만 섰다.
        두 가지가 겹친 결과다. 주간 배정이 날마다 D를 먼저 채우면서 '그 사람이 D를 이미
        몇 번 섰나'를 안 봤고, 한 번 E로 들어가면 E 다음날 D 금지(H3-2) 때문에 오프 전까지
        D로 못 돌아와 E가 줄줄이 이어졌다.

        목표는 사람마다 'D÷(D+E)'를 병동 전체 비율에 맞추는 것이다(야간을 많이 서는 사람은
        주간 자체가 적으니 횟수가 아니라 비율로 본다). 비용 Σ(D − 비율×(D+E))²를 가장 많이
        줄이는 맞바꿈을 하나씩 적용하고, 더 줄일 수 없으면 멈춘다. 같은 입력이면 같은 순서로
        훑으므로 결과도 같다(난수를 쓰지 않는다).

        잠긴 칸(원티드 신청·이월·파트장 수정)은 건드리지 않는다.
        """
        sch = self.sch
        nd = sch.num_days
        people = self._de_dayers()
        if len(people) < 2:
            return 0
        grid = sch.grid
        calls = moves = 0
        for _ in range(max_moves):
            cnt = {s.id: (sum(1 for v in grid[s.id] if v == Shift.D),
                          sum(1 for v in grid[s.id] if v == Shift.E)) for s in people}
            tot_d = sum(c[0] for c in cnt.values())
            tot = sum(c[0] + c[1] for c in cnt.values())
            if not tot:
                return moves
            r = tot_d / tot
            surplus = {sid: dc - r * (dc + ec) for sid, (dc, ec) in cnt.items()}
            heavy_d = sorted((s for s in people if surplus[s.id] > 0.5),
                             key=lambda s: (-surplus[s.id], s.id))[:8]
            heavy_e = sorted((s for s in people if surplus[s.id] < -0.5),
                             key=lambda s: (surplus[s.id], s.id))[:8]
            done = False
            for a in heavy_d:
                for b in heavy_e:
                    gain_cap = surplus[a.id] - surplus[b.id]   # 맞바꾼 날수 k < 이 값이면 이득
                    if gain_cap <= 1:
                        continue
                    ra, rb = grid[a.id], grid[b.id]
                    d = 0
                    while d < nd and not done:
                        if not (ra[d] == Shift.D and rb[d] == Shift.E
                                and not sch.is_locked(a.id, d)
                                and not sch.is_locked(b.id, d)):
                            d += 1
                            continue
                        e = d
                        while (e + 1 < nd and ra[e + 1] == Shift.D and rb[e + 1] == Shift.E
                               and not sch.is_locked(a.id, e + 1)
                               and not sch.is_locked(b.id, e + 1)):
                            e += 1
                        # 겹친 구간 안에서 짧은 것부터 — 이음새(H3-2·H6-3)는 구간의
                        # 양끝에서만 걸리므로 끝을 바꿔 가며 본다.
                        for k in range(1, min(e - d + 1, 4) + 1):
                            if k >= gain_cap:
                                break
                            for x in range(d, e - k + 2):
                                calls += 1
                                if calls > call_budget:
                                    return moves
                                if self._try_swap_de_segment(a, b, x, x + k - 1):
                                    moves += 1
                                    done = True
                                    break
                            if done:
                                break
                        d = e + 1
                    if done:
                        break
                if done:
                    break
            if not done:
                break
        if moves:
            sch.log(f"[D/E 균등] 같은 날 D↔E 구간 맞바꿈 {moves}회")
        return moves

    def assign_sleep_offs(self) -> int:
        """야간을 많이 선 사람(H7-1 기준 이상)에게 수면오프(S/) 1개를 준다.

        **S/는 오프를 대체하는 것이 아니라 하루를 더 주는 것이다.** 이 사람의 월 OFF
        개수는 S/가 없는 사람과 똑같고, S/ 하루가 근무일에서 나온다.

        실제 병동 근무표(B관7, 2026년 8개월)로 확인한 근거: 이 병원의 잔휴는
        `전월잔휴 + 휴일수 − OFF개수`로 떨어지는데, S/를 가진 58명(6월 제외 49명)
        전원이 **S/를 OFF로 세지 않은** 이 식과 정확히 맞았다. S/가 오프를 대체한
        것이라면 그 사람만 OFF가 하나 적어 잔휴가 하루씩 어긋났어야 한다.

        놓는 자리는 **마지막 야간블록 바로 다음날** — 실제 근무표가 예외 없이
        `N N S/ /` 꼴이다. 그 자리는 야간 뒤 의무휴식(H2-5)으로 이미 OFF가 잠겨
        있으므로 그것을 S/로 덮는다. 그러면 OFF가 하나 줄지만, 이 함수가
        equalize_off(Step 8)보다 **먼저** 돌기 때문에 거기서 OFF 하한까지 다시
        채워진다 — 그 과정에서 근무 하루가 빠지고, 그것이 곧 '더 주는 하루'다.

        순서가 중요하다. 예전엔 이 함수가 맨 마지막이라 이미 확정된 오프를 S/로
        바꿀 수밖에 없었고, 그러면 **OFF가 하나 줄어든 채로 끝나** 잔휴가 하루
        늘어났다 — 병원 정산과 반대 방향이다. fill_day_shifts(Step 6) 앞으로
        옮겨야 그날이 애초에 근무로 채워지지 않고, 그 자리를 다른 사람이 메워
        최소인력(H1-1)도 깨지지 않는다.
        """
        from .constraints import SLEEP_OFF_NIGHT_THRESHOLD

        sch = self.sch
        nd = sch.num_days
        placed = 0
        for s in self.staff:
            if s.is_partjang or s.is_nk:
                continue
            if sch.nights_in_month(s.id) < SLEEP_OFF_NIGHT_THRESHOLD:
                continue
            if any(v is Shift.SLEEP_OFF for v in sch.grid[s.id]):
                continue  # 원티드로 이미 신청한 사람
            last_night = max((d for d in range(nd)
                              if sch.grid[s.id][d] in NIGHT_SHIFTS), default=-1)
            if last_night < 0:
                continue
            # **아직 아무것도 안 정해진 칸에만 놓는다.** 야간 뒤 의무휴식(H2-5)으로
            # 잠긴 OFF를 덮으면 그 사람의 OFF가 하나 줄어드는데, equalize_off는 OFF를
            # 정확한 목표가 아니라 [하한, 상한] 범위로만 맞추므로 하한에 여유가 있는
            # 사람은 줄어든 채로 끝난다(실측: OFF −0.55일). 그러면 S/가 '더 주는 하루'가
            # 아니라 '오프를 절반쯤 빼앗은 하루'가 된다. 빈 칸에만 놓으면 OFF 개수는
            # 손대지 않고 근무 하루만 줄어 — 병원 잔휴 정산과 같아진다.
            #
            # 야간블록과 그 휴식 바로 다음날부터 찾는다. 실제 근무표에서 S/가 야간
            # 근처에 붙어 있는 모양을 최대한 따르되, 자리 자체는 규칙이 아니다
            # (파트장이 그 달 안에서 쓰는 값).
            order = list(range(last_night + 1, nd)) + list(range(0, last_night + 1))
            for d in order:
                if sch.grid[s.id][d] is not None:
                    continue
                if (s.id, d) in sch.wanted:
                    continue
                sch.set(s.id, d, Shift.SLEEP_OFF, lock=True)
                sch.log(f"[H7-1] {s.id}: {d+1}일 수면오프(S/) "
                        f"(야간 {sch.nights_in_month(s.id)}회 — 오프와 별도로 하루 추가)")
                placed += 1
                break
        return placed

    # ------------------------------------------------------------ Step 9 (G7)
    def split_long_offs(self):
        """H4-2: 원치 않는 연속 오프(REST_SHIFTS) 5일 이상(4일까지는 허용)을
        분할한다. 본인이 신청/승인받은 구간(전부 wanted)은 원하는 장기휴가라
        건드리지 않는다."""
        sch = self.sch
        nd = sch.num_days
        for s in self.staff:
            if s.is_partjang or s.is_nk:
                continue
            d = 0
            while d < nd:
                if sch.get(s.id, d) not in REST_SHIFTS:
                    d += 1
                    continue
                start = d
                while d < nd and sch.get(s.id, d) in REST_SHIFTS:
                    d += 1
                end = d - 1
                if end - start + 1 >= 5:
                    wanted_all = all((s.id, dd) in sch.wanted for dd in range(start, end + 1))
                    if not wanted_all:
                        self._break_off_run(s, start, end)

    def _break_off_run(self, s: Staff, start: int, end: int) -> bool:
        """연속 OFF 중간일로 다른 날 근무 1개를 이동 (총 OFF 개수 유지)."""
        sch = self.sch
        mid = (start + end) // 2
        targets = sorted(range(start + 1, end),
                         key=lambda x: abs(x - mid))
        for m in targets:
            if sch.get(s.id, m) != Shift.OFF or sch.is_locked(s.id, m):
                continue
            for w in range(sch.num_days):
                if w == m:
                    continue
                v = sch.get(s.id, w)
                if v not in DAY_WORK_SHIFTS or sch.is_locked(s.id, w):
                    continue
                key = "prn" if v == Shift.PRN else v.value
                if sch.count_shift(w, v) - 1 < self.min_for(w, key):
                    continue
                if not self._lv3_guard_ok(s, None, w, v):
                    continue
                if self._removal_creates_eod(s.id, w):
                    continue
                # 이동할 날(m)이 이미 그 근무유형 최소인력만큼 차 있으면(=상한
                # 도달) 옮기지 않는다 — 최소인력은 상한이기도 하다.
                if sch.count_shift(m, v) >= self.min_for(m, key):
                    continue
                sch.grid[s.id][w] = Shift.OFF
                if self.can_assign_day(s, m, v):
                    sch.set(s.id, m, v)
                    sch.log(f"[G7] {s.id}: 장기 OFF 분할 — {w+1}일 {v}를 {m+1}일로 이동")
                    return True
                sch.grid[s.id][w] = v
        sch.log(f"[G7] {s.id}: {start+1}~{end+1}일 연속 OFF 분할 실패")
        return False

    # ------------------------------------------------------------ carryover 출력
    def build_next_carryover(self) -> Dict[str, dict]:
        out = {}
        nd = self.sch.num_days
        for s in self.staff:
            grid = self.sch.grid[s.id]
            last = grid[nd - 1] or Shift.OFF
            run = self.sch.work_run_ending(s.id, nd - 1) \
                if last in WORK_SHIFTS else 0
            trailing = 0
            d = nd - 1
            while d >= 0 and grid[d] in NIGHT_SHIFTS:
                trailing += 1
                d -= 1
            remaining_off = 0
            if trailing >= 2:
                remaining_off = 2
            elif trailing == 0:
                # 야간블록 종료 후 OFF가 1일만 확보된 채 월이 끝난 경우
                if nd >= 2 and grid[nd - 1] in REST_SHIFTS \
                        and grid[nd - 2] in NIGHT_SHIFTS:
                    blk = 1
                    dd = nd - 3
                    while dd >= 0 and grid[dd] in NIGHT_SHIFTS:
                        blk += 1
                        dd -= 1
                    if blk >= 2:
                        remaining_off = 1
            old_score = self.sch.carryover[s.id].recent_night_score
            this_month_nights = self.sch.nights_in_month(s.id)
            # 잔휴(정상 오프 누적잔액) = 전월 잔휴 + (이번달 휴일수 - 이번달 순수오프일수).
            # 순수오프는 문자 그대로 OFF(원티드="X"/일반="/")로 찍힌 칸만 세고, 연차/공가/
            # 조사/S//군 등 다른 휴가유형은 반영하지 않는다(실측 검증된 병원 공식).
            old_off_balance = self.sch.carryover[s.id].off_balance
            this_month_offs = self.sch.offs_in_month(s.id)
            since = _days_since_last_night(grid, nd)
            if since is None:
                # 이번 달 야간이 없으면 전월 값에 이번 달 날수를 더해 이어 간다
                prev = self.sch.carryover[s.id].days_since_last_night
                since = None if prev is None else prev + nd
            out[s.id] = {
                "last_shift_type": str(last),
                "consecutive_work_days": run,
                "night_block_remaining_off": remaining_off,
                "night_block_in_progress": trailing == 1,
                "trailing_night_count": trailing,
                # 최근 몇 달 야간 누적을 감쇠 이동평균으로 근사(대략 최근 3개월 비중)
                # — 야간을 적게 받은 사람이 다음 몇 달간 우선권을 갖도록 함(S2 장기화).
                "recent_night_score": round(old_score * (2 / 3) + this_month_nights, 2),
                # 휴일수는 그 사람이 실제로 재직한 구간만 센다(월중 전입자는 입사일부터) —
                # 전 병동이 입사 전날까지 정산해 넘긴 잔휴에 한 달 치를 통째로 더하면
                # 그 사람만 휴가가 부풀려진다.
                "off_balance": round(old_off_balance + self.working_holiday_count(s.id)
                                     - this_month_offs, 2),
                "days_since_last_night": since,
            }
        return out

    # ------------------------------------------------------------ 실행
    def run(self) -> MonthSchedule:
        self._rebuild_calls = 0
        self.compute_senior_thresholds()  # S6 근무유형별 상대 고랩 기준선
        self.compute_night_targets()  # H6-4 개인별 월 목표(4/6일) 산정
        self.validate_input()      # Step 0
        self.lock_pre_join_days()  # Step 0.4: 월중 전입자의 입사 전 날짜 제외
        self.apply_fixed()         # Step 0.5: 리더 수정분 고정 (재생성 모드)
        self.complete_partial_night_blocks()
        self.apply_carryover()     # Step 1
        self.assign_partjang()     # Step 2
        self.assign_nk()           # Step 3
        self.apply_requests()      # Step 4
        self.complete_partial_night_blocks()  # 신청된 단독 야간 블록 보완 (H2-4)
        self.sch.protected = set(self.sch.locked)  # 여기까지가 사람이 정한 칸 — 균등화가 지키는 경계
        self.assign_nights()       # Step 5
        # H7-1은 여기서 놓는다 — 야간이 확정돼 누가 대상인지 알 수 있고, 아직 주간을
        # 채우기 전이라 그 하루가 애초에 근무로 잡히지 않는다(그 자리는 다른 사람이
        # 메워 H1-1도 유지된다). 맨 끝에서 하면 이미 확정된 오프를 바꿀 수밖에 없어
        # OFF가 하나 줄고, 잔휴가 병원 정산과 반대로 하루 늘어난다.
        self.assign_sleep_offs()   # Step 5b
        self.fill_day_shifts()     # Step 6
        self.finalize_offs()
        self.repair_min_staff()    # H1-1 미달 수리
        for _ in range(5):         # Step 7 — 한 명 고치면 다른 사람 자리가 열려 반복하면 더 줄어듦
            if self.fix_alternation() == 0:
                break
        for _ in range(5):         # Step 7b — 1~2일 단기블록을 3~4일로 확장(H6-1)
            if self.fix_short_day_blocks() == 0:
                break
        self.equalize_off()        # Step 8
        self.split_long_offs()     # Step 9
        # 수리 ↔ 균등화 반복: 균등화가 만든 빈 자리를 수리가 활용 (Step 10 사전)
        for _ in range(4):
            self.equalize_off()
            self.repair_min_staff()
            if self.count_deficits() == 0:
                break
        self.equalize_off()        # 수리로 생긴 편중 재조정 (일별 인원수 보존)
        for _ in range(5):         # 최종 퐁당퐁당 완화 (G4 재실행, 수렴까지 반복)
            if self.fix_alternation() == 0:
                break
        for _ in range(5):         # 최종 단기블록 확장(H6-1) 재실행
            if self.fix_short_day_blocks() == 0:
                break
        self.global_fix_alternation()  # 인접일 검색으로 못 줄인 잔여를 전역 탐색으로 마무리
        self.global_fix_2blocks()      # 2일짜리 고립 블록도 확장해서 마무리
        self.global_fix_alternation()  # 2블록 확장 과정에서 새 1일 고립이 생겼을 수 있어 재정리
        self.reduce_lv1_night_clusters()  # S11 Lv1이 몰린 밤 풀기
        # H1-5(그 근무에 Lv4+ 1명) 수리 — 블록 정리·균등화가 끝난 뒤라야 한다.
        # 먼저 하면 뒤의 정리가 고연차를 도로 다른 조로 옮겨 구멍이 되살아난다.
        self.repair_level_coverage()
        # 위 수리가 못 고친 구멍 — 쉬는 고연차를 근무일 수 그대로 창 맞교환으로 들여놓는다(equalize.py).
        # 고연차가 적은 병동에서 위 2단계가 '근무일이 더 적을 때만'에 막혀 거의 못 고치던 자리다.
        from .equalize import repair_senior_coverage
        rep = repair_senior_coverage(self.sch, self.days, self.params)
        if rep["day"] or rep["night"]:
            self.sch.log(f"[H1-5 수리] 창 맞교환으로 주간 {rep['day']}건·야간 {rep['night']}건 메움(검사 {rep['checked']}회)")
        # 지정 인원 수리는 맨 끝이다 — 앞의 균등화·블록 정리가 지정 가능자의 근무를
        # 다시 OFF로 돌려놓을 수 있어서, 그보다 먼저 고치면 도로 무너진다.
        self.repair_designated()
        # D/E를 사람마다 고르게 — **맨 마지막이어야 한다.** 같은 날 두 사람의 D와 E를
        # 맞바꿀 뿐이라 칸의 근무/휴무 모양·그날 인원·지정 인원이 그대로고, 이음새(H3-2·
        # H6-3)와 그 조의 고연차(H1-5)는 맞바꾸기 전에 막는다. 그래서 어떤 하드 규칙도
        # 늘릴 수 없다. 앞에 두면 그렇지 않았다 — 뒤의 H1-5·지정 수리가 바뀐 판 위에서
        # 다르게 움직여 60·80명 병동에서 최선노력 위반이 6개월에 30여 건 늘었다.
        self.balance_day_types()
        return self.sch


# 월경계 등에서 로컬 수리만으로는 구조적으로 0건을 보장하기 어려운 최선노력 하드
# 규칙 — 이 규칙들만 남으면 재시도를 멈춘다(계속 시도해도 거의 안 줄어들어 시간만 소모).
# H1-4(최소인력 상한): 생성 로직은 최대한 상한을 지키지만, 전월에서 이어지는
# 야간블록 완성(H5-2)처럼 그 자체가 하드 규칙인 강제 배정은 상한보다 우선이라
# 드물게 초과가 남을 수 있다.
# H7-1(수면오프): 오프를 S/로 바꾸는 것뿐이라 대개 그냥 되지만, 그 사람의 오프가
# 월 하한(H4-1)에 딱 걸쳐 있거나 남은 오프가 전부 확정칸·본인 신청분이면 넣을 자리가
# 없다. 재시도해도 같은 이유로 다시 막히므로 최선노력으로 둔다.
# H1-5(그 근무에 Lv4+ 1명)는 **여기 없다** — 필수(빨강)다.
#
# 예전엔 최선노력이었다. 근거는 "병동에 레벨4+가 적으면 매일 D·E·N 세 곳을 동시에
# 못 채운다"였는데, 재 보니 사실이 아니었다. 40명 병동에 D/E/N 가능한 Lv4+가
# 10명이고 하루에 필요한 건 근무당 1명씩 3명뿐이다 — 10명이 각자 20일쯤 일하니
# 하루 6.7명분이 있는 셈이라 **용량이 아니라 순서 문제**였다. 실제로 점수에서
# H1-5를 소프트(S6)와 형평성보다 위로 올리고 주간에 사후 수리를 붙였더니
# 6개월 14건 → 4건이 됐다.
#
# 밤에 숙련도 4 이상이 한 명도 없는 것은 노랗게 넘길 일이 아니라는 파트장 판단이다.
# 남으면 확정·다운로드 때 한 번 더 묻고, 파트장이 그 칸을 직접 채운다.
#
# ⚠ 야간전담(NK)이 저연차인 병동은 아직 달마다 2~3건 남는다(아래 야간 수리 설명).
# 그 병동에서는 이 규칙이 "매달 열어서 확인할 목록"으로 뜬다 — 의도된 것이다.
_BEST_EFFORT_RULES = {"H6-1", "H6-4", "H4-1", "H1-4", "H4-2", "H7-1"}


def fairness_components(gen: "Generator", sch: MonthSchedule) -> dict:
    """공평성 점수와 그 구성 — 정의는 fairness.py 한 곳(점수표·보고서·생성기가 같은 정의)."""
    from .fairness import components
    return components(gen, sch)


def attempt_stats(gen: "Generator", sch: MonthSchedule) -> dict:
    """한 시도의 결과를 시도끼리 견줄 숫자로 — generate_best와 병렬 생성(브라우저가 시드를
    나눠 돌리는 길)이 **같은 숫자로 같은 판정**을 내리기 위한 한 벌.

    blocking: H1-5를 뺀 필수 위반 · h15: H1-5 · hard: 전체 하드(최선노력 포함) · strict: 필수 ·
    fairness 및 그 구성(weekend·night·de·wanted): fairness_components 참고."""
    from .constraints import all_hard_checks
    violations = all_hard_checks(sch, gen.days, gen.params)
    n_hard = len(violations)
    n_strict = sum(1 for v in violations if v.rule not in _BEST_EFFORT_RULES)
    n_blocking = sum(1 for v in violations
                     if v.rule not in _BEST_EFFORT_RULES and v.rule != "H1-5")
    st = {"seed": gen.seed, "strategy": strategy_label(gen.seed), "hard": n_hard, "strict": n_strict,
          "blocking": n_blocking, "h15": n_strict - n_blocking}
    st.update(fairness_components(gen, sch))
    return st


def attempt_key(stat: dict) -> Tuple:
    """시도끼리의 우열 — 앞 단계가 다르면 뒤는 보지 않는다. 작을수록 좋다.

    1 운영 필수 위반(H1-5 제외) 2 숙련도(H1-5) 3 공평성 점수(fairness.py: 2×횟수 + 주말 + 조 구성 +
    단독 고연차 + 원티드 미반영) 4 전체 하드(최선노력 포함) 5 앞 시드.
    예전엔 '필수 0이면 그 자리에서 멈춤'이었는데, 시드 셋을 다 돌려 공평성까지 보는 것으로 바꿨다
    (2026-10-22, 사용자 결정). 2026-10-30에 공평성을 전체 하드(노랑)보다 앞으로 올렸다(사용자 결정):
    기준선 201개 가상 비교에서 공평성 합 −3%(3회)·−4%(9회), 노랑 위반 합 +2%·+4% — 노랑은 화면에 남아
    파트장이 보고 넘기는 것이고, 공평성은 안 보이는 채로 한 달을 가기 때문이다. 필수(빨강)는 그대로 앞."""
    return (stat["blocking"], stat["h15"], round(stat.get("fairness", 0.0), 2), stat["hard"], stat["seed"])


def choose_attempt(stats: List[dict], h15_floor: int = 0) -> int:
    """시도 결과 목록에서 가장 좋은 시드. 멈춤 조건 없이 전부 비교한다 — attempt_key 참고.
    h15_floor는 안내용으로만 남아 있다(하한에 닿은 시도도 다른 시도와 공평성까지 견준다)."""
    return min(stats, key=attempt_key)["seed"]


def finish_candidate(gen: "Generator", sch: MonthSchedule) -> MonthSchedule:
    """고르지 않았던 시도를 화면에 올릴 때 — 고른 표와 같은 마무리(주말 균등화)를 한 번만 얹는다."""
    if getattr(sch, "equalize_report", None) is None:
        _apply_post_equalize(gen, sch)
    return sch


def generate_best(config: dict,
                  fixed_cells: Optional[Dict[Tuple[str, int], Shift]] = None,
                  attempts: int = 3,
                  time_budget: float = 30.0,
                  seeds: Optional[List[int]] = None) -> Tuple["Generator", MonthSchedule]:
    """하드 위반이 남으면 탐색 순서를 바꿔 재시도하고 최선의 결과를 반환 (Step 10).

    _BEST_EFFORT_RULES를 제외한 하드 규칙이 전부 0건이면 그 시점에서 반환한다
    (아래 설명 참고).

    **멈추는 기준은 '시도 횟수'다. time_budget은 안전판일 뿐이다.**

    예전엔 반대였다(attempts=24, time_budget=10초). 그러면 "10초 동안 되는 만큼"이
    되는데, 시도 1회에 걸리는 시간은 기기 성능과 그때그때 CPU 부하에 좌우된다 —
    같은 입력인데 **빠른 PC에서는 3회를 돌아 위반 0이 나오고, 폰에서는 2회에서
    잘려 위반이 남았다.** 실제로 크로미움과 네이티브에서 같은 입력이 서로 다른
    근무표를 냈다(그리드 해시 불일치로 확인). 사용자 입장에선 "같은 걸 눌렀는데
    결과가 다른" 앱이 된다.

    횟수 기준으로 바꾸면 기기가 달라도 시도 횟수가 같으므로 **같은 입력은 항상
    같은 근무표**가 나온다. 느린 기기는 시간이 더 걸릴 뿐이다.

    ⚠ attempts=3인 이유 — 실측이다. 40·50·60·70명 로스터를 각각 3개월 연속으로
    이어 돌려(출력②를 다음 달 입력②로 넣어 실제 이월정보를 만든 12케이스):

        · 필수 위반 0 달성: 11/12건
        · 달성에 필요한 시도: 최소 1회 / 최대 3회 / 평균 1.3회 (11건 전부 3회 이내)
        · 나머지 1건은 12회를 돌려도, 60회를 돌려도 필수 위반 1건이 그대로였다
          (구조적으로 불가능한 입력 — 더 굴려도 답이 안 나온다)

    즉 **되는 것은 3회 안에 되고, 안 되는 것은 몇십 회를 해도 안 된다.** 4회 이상은
    "안 되는 입력을 붙들고 기다리는 시간"만 늘린다.

    ⚠ time_budget=30초는 상한이 아니라 **병리적 입력용 안전판**이다. 체크가 "시도와
    시도 사이"에서만 이뤄지므로, 시도 1회가 30초보다 오래 걸리면 그 시도가 끝날
    때까지는 못 끊는다. 실제 소요시간은 30초 이하가 아니라 "시도 1회 소요시간의
    배수"에 가깝다.

    ⚠ 안전판이 실제로 무는 경우가 있다 — 위 12케이스 중 70명·시도1회 11.3초짜리
    달은 3회에 35.9초(네이티브)가 걸려서, 브라우저(약 2배 느림)에서는 2회째에
    30초를 넘겨 잘린다. 그 달만은 기기에 따라 결과가 갈릴 수 있다. 이 값을 올리면
    (약 75초) 그 케이스도 일관되지만, 대신 폰에서 그만큼 기다리게 된다 — 의도적인
    맞바꿈이니 바꾸려면 위 실측을 다시 재보고 판단할 것.
    """
    import time as _time

    t0 = _time.time()
    results = []   # (gen, sch, stat)
    timed_out = False
    h15_floor = None   # 첫 시도의 Generator로 한 번만 센다(입력만 보므로 시드와 무관)
    # seeds를 주면 그 시드만 돈다 — 병렬 생성이 고른 시드 하나를 다시 돌려 상태를 만들 때,
    # 또는 코어가 적은 기기가 시드 하나만 돌릴 때.
    order = list(seeds) if seeds is not None else list(range(attempts))
    for n, i in enumerate(order):
        t_att = _time.perf_counter()
        gen = Generator(config, fixed_cells=fixed_cells, seed=i)
        if h15_floor is None:
            h15_floor = gen.feasibility_bounds()["h15_floor"]
        sch = gen.run()
        # 숫자와 판정은 attempt_stats/attempt_key/choose_attempt 한 벌을 쓴다 — 병렬 생성
        # (브라우저가 시드를 나눠 돌리고 choose_attempt로 고르는 길)과 같은 표가 나오려면
        # 여기서 따로 세면 안 된다. 멈춤 조건은 없다: 시드를 전부 돌려 운영 필수 → 숙련도 →
        # 공평성 → 전체 하드 순으로 견준다(예전엔 필수 0이면 그 자리에서 멈췄다).
        st = attempt_stats(gen, sch)
        st["sec"] = round(_time.perf_counter() - t_att, 3)   # 시도 하나의 시간 — 점수표·속도 보고서용
        results.append((gen, sch, st))
        if n + 1 < len(order) and _time.time() - t0 > time_budget:
            timed_out = True
            break
    stats = [st for _, _, st in results]
    win = choose_attempt(stats, h15_floor)
    gen, sch, st = next(r for r in results if r[2]["seed"] == win)
    sch.timed_out = timed_out
    sch.attempt_stats = st
    sch.attempt_table = [dict(x, chosen=(x["seed"] == win)) for x in stats]
    # 고르지 않은 시도도 버리지 않는다 — 화면 점수표에서 그 시드를 누르면 그 표로 바꿔 볼 수
    # 있게(사용자 요청 2026-10-22). 균등화는 고른 표에만 미리 얹고, 나머지는 바꿔 볼 때 얹는다.
    sch.candidates = {x["seed"]: (g, s) for g, s, x in results}
    if len(stats) > 1:
        sch.log(f"[재시도] 시드 {len(stats)}개 중 시드 {win} 선택 — 운영 필수 {st['blocking']}·숙련도 "
                f"{st['h15']}·공평성 {st['fairness']}·전체 {st['hard']}")
    if st["strict"]:
        sch.log(f"[재시도] {len(stats)}회 시도 후에도 하드 위반 {st['hard']}건 잔존"
                f"(그중 필수 위반 {st['strict']}건) — 최선 결과 반환"
                + (f" (시간 예산 {time_budget:.0f}초 소진으로 {len(order)}개 중 {len(stats)}개만 평가)"
                   if timed_out else "")
                + (f" · 이 중 H1-5 {st['h15']}건은 입력상 하한 {h15_floor}건에 "
                   f"{'닿아 더 줄일 수 없음' if st['blocking'] == 0 and st['h15'] <= h15_floor else '아직 못 미침'}"
                   if h15_floor else ""))
    elif timed_out:
        sch.log(f"[재시도] 시간 예산 {time_budget:.0f}초 소진으로 {len(order)}개 중 {len(stats)}개만 평가")
    # 고른 표에 마지막 손질 — 같은 조건 집단 안의 주말 편중을 맞교환으로 줄인다(규칙·횟수·인원
    # 보존, 위반 비증가). 시도 비교는 균등화 **전** 숫자로 했다(병렬 생성과 같은 숫자여야 한다).
    t_eq = _time.perf_counter()
    _apply_post_equalize(gen, sch)
    sch.equalize_report["sec"] = round(_time.perf_counter() - t_eq, 3)
    return gen, sch


def _apply_post_equalize(gen: "Generator", sch: MonthSchedule) -> None:
    """고른 표의 마무리 — 야간 블록을 목표에 맞게 옮기고(횟수 균등), 그다음 주말 몫을 맞바꾼다(배치
    균등). 야간이 먼저다: 야간이 옮겨지면 그 사람의 주간·주말이 같이 바뀌므로 주말은 그 뒤에 본다."""
    from .equalize import equalize_nights, equalize_weekends
    rep_n = equalize_nights(sch, gen.days, gen.params)
    if rep_n["accepted"]:
        sch.log(f"[균등] 야간 블록 이동 {rep_n['accepted']}건(검사 {rep_n['checked']}회) — "
                f"집단 내 야간 편차 {rep_n['before_sq']} → {rep_n['after_sq']}")
    rep = equalize_weekends(sch, gen.days, gen.params)
    rep["nights"] = rep_n
    sch.equalize_report = rep
    if rep["accepted"]:
        sch.log(f"[균등] 주말 맞교환 {rep['accepted']}건 적용(검사 {rep['checked']}회) — "
                f"집단 내 주말 편차 {rep['before']['sq']} → {rep['after']['sq']}")


# ---------------------------------------------------------------- 인력 압박 사전 진단
#
# 왜 필요한가 — generate_best는 최대 3회 시도해 최선을 고르는데, 인원이 빠듯하면 시도
# 1회 자체가 길어진다(실측: 여유로운 40명 0.5초인데 빠듯한 36명은 13초). 그러면 3회를
# 다 돌아도 위반이 남고, 그 사이 사용자는 한참을 기다린다.
# 게다가 브라우저(Pyodide)는 네이티브보다 느리다 — 실측 2.0~2.3배다(크로미움 헤드리스에서
# 같은 입력으로 잰 값: 여유로운 40명 네이티브 0.53초/브라우저 1.2초, 빠듯한 36명 네이티브
# 12.8초/브라우저 25.7초). 즉 빠듯한 달은 데스크톱 브라우저에서도 26초가 걸리고, 폰은 CPU가
# 더 느려 여기서 몇 배가 더 붙는다. 그동안 화면은 "생성 중..." 한 줄뿐이라 사용자는 앱이
# 죽은 줄 알고 새로고침한다 — 그러면 처음부터 다시다.
#
# 그래서 생성을 시작하기 전에 "이 입력이 얼마나 빠듯한지"를 미리 재서 화면에 알려준다.
#
# ⚠ 여기서 '빠듯하다'고 판정돼도 시도 횟수를 더 주지는 않는다 — 더 굴려봐야 안 되기
# 때문이다. 실측(36명·압박률 0.96)에서 시도를 1→2회로 늘리면 필수위반이 5→4건으로 한 건
# 줄고, 4회·8회로 더 늘려도 4건 그대로였다. 압박률이 더 높은 쪽(18명·1.98)은 16회를
# 돌려도 67→67로 완전히 평평했다. 이 구간에 위반이 남는 건 운이 나빠서가 아니라 인원이
# 모자라서라, 주사위를 더 굴려도 답이 안 나온다. 그래서 '알려주되 더 기다리게 하지는
# 않는다'로 정했다. (반대로 인원이 넉넉한 달은 3회 안에 대부분 해결된다 — generate_best
# 주석의 12케이스 실측 참고.)
#
# 지표(압박률) = 이번 달 최소인력을 채우는 데 필요한 인원-일 / 실제로 쓸 수 있는 인원-일.
# 실측으로 보정했다(sample_input.xlsx 42명 기준, 인원만 줄여가며 측정):
#
#     압박률 0.86 →  0.5초, 필수위반  0건   ← 여유
#     압박률 0.96 → 13.0초, 필수위반  5건   ← 가장 느림('될 듯 말 듯'한 구간)
#     압박률 1.09 →  9.9초, 필수위반 28건
#     압박률 1.98 →  2.1초, 필수위반 67건   ← 가망이 없으면 오히려 빨리 포기한다
#
# 비용이 가장 큰 구간이 0.95~1.10이라는 게 중요하다. 이건 인원이 몇 명 빠진 병동 —
# 즉 현실에서 제일 흔한 상황이다. 반대로 압박률이 1을 크게 넘으면 수리 로직이 일찍
# 포기해서 오히려 빨리 끝난다.
PRESSURE_TIGHT = 0.90   # 이 이상이면 '빠듯' — 최소인력을 다 채우기 어렵고 생성이 느려진다
PRESSURE_SHORT = 1.00   # 이 이상이면 산술적으로 불가능 — 최소인력을 채울 방법이 없다


def staffing_pressure(config: dict) -> dict:
    """생성을 시작하기 전에 이 입력이 얼마나 빠듯한지 재본다.

    Generator를 만들기만 하고 run()은 하지 않는다(생성 자체는 하지 않으므로 가볍다).
    최소인력 조회는 반드시 Generator.min_for를 그대로 쓴다 — 요일별 최소인력 같은
    분기를 여기서 다시 구현하면 두 벌이 되고, 그게 이 프로젝트가 반복해서 밟은 함정이다.
    """
    return Generator(config).staffing_pressure()


def _pressure_level(ratio: float) -> str:
    if ratio >= PRESSURE_SHORT:
        return "short"
    if ratio >= PRESSURE_TIGHT:
        return "tight"
    return "ok"


def _pressure_message(level: str, demand: int, supply: int) -> str:
    """생성 전에 화면에 띄울 안내 문구.

    **문구를 여기(엔진)에 두는 이유**: 판단(압박률)은 엔진이 하는데 문구를 화면
    (pyodide-app/app.js)에 따로 적으면 언젠가 한쪽만 고쳐져 판단과 안내가 갈린다.
    예전에 화면이 두 벌(옛 Flask판·브라우저판)이던 시절 실제로 반복해서 밟은 함정이라
    출처를 하나로 둔다.

    '1~2분'은 지어낸 값이 아니라 실측이다(36명·압박률 0.96에서 네이티브 12초,
    브라우저/폰은 몇 배 느리다). 다만 기기 편차가 크므로 단정하지 않고 범위로 적는다.
    """
    if level == "ok":
        return ""
    slow = "생성도 평소보다 오래 걸립니다(기기에 따라 10~40초)."
    if level == "short":
        return (f"인원이 부족합니다 — 이번 달 최소인력을 다 채우려면 {demand}인원-일이 "
                f"필요한데 쓸 수 있는 건 {supply}인원-일뿐입니다. 산술적으로 다 채울 수 "
                f"없어 위반이 반드시 남습니다 — 인원을 늘리거나 근무인력 기준을 낮춰야 "
                f"완전히 해소됩니다. {slow}")
    # 빠듯(tight): 숫자만 보면 공급이 수요보다 크다. 그런데도 위반이 남는 이유를 같이
    # 적지 않으면 "707 필요한데 735 있다면서 왜 빠듯하냐"는 모순으로 읽힌다 — 여유분을
    # 그대로 쓸 수 없게 만드는 건 야간 블록(2~3일 + 뒤 OFF 2일)과 연속근무 상한이다.
    margin = supply - demand
    pct = round(margin / supply * 100) if supply else 0
    return (f"인원이 빠듯합니다 — 이번 달 최소인력을 채우는 데 {demand}인원-일이 필요하고 "
            f"쓸 수 있는 건 {supply}인원-일이라, 여유가 {margin}인원-일({pct}%)뿐입니다. "
            f"야간은 2~3일씩 묶어 서고 그 뒤 이틀을 쉬어야 하는 등 배치 제약이 있어서 "
            f"이 정도 여유로는 최소인력을 다 채우지 못한 위반이 남을 수 있습니다. {slow}")


# ---------------------------------------------------------------- 지난달 그리드 → 이월값 역산
def _days_since_last_night(row, num_days: int) -> Optional[int]:
    """마지막 야간 뒤로 말일까지 야간이 아닌 날 수(말일이 야간이면 0). 야간이 없으면 None."""
    for d in range(num_days - 1, -1, -1):
        if row[d] in NIGHT_SHIFTS:
            return num_days - 1 - d
    return None


def carryover_from_grid(grid: Dict[str, List[str]], num_days: int,
                        lenient: bool = False) -> Dict[str, dict]:
    """지난달 확정 근무표(그리드, 문자열 근무코드)만으로 이번 달 전월이월값을 역산.

    Generator.build_next_carryover()와 동일한 계산이나, 그 달의 전월이월 정보 없이
    그리드 자체의 말일 상태만으로 계산한다(월 전체가 근무로 채워진 극단적인 경우
    연속근무일수가 실제보다 짧게 나올 수 있음 — 흔치 않은 근사).

    lenient=True면 빈 칸이나 모르는 코드를 예외 대신 OFF(근무 안 한 날)로 본다 —
    연간근무표는 파트장이 손으로 행을 더하거나 고칠 수 있는 파일이라, 칸 하나 때문에
    서버 오류로 떨어지면 안 된다(업로드 단계에서 이미 모르는 표기를 걸러 알려준다).
    업로드된 병원 OCS 파일처럼 코드가 이미 검증된 경로는 기본값(엄격)을 그대로 쓴다.
    """
    def _to_shift(v) -> Shift:
        if not lenient:
            return parse_shift(v)
        s = "" if v is None else str(v).strip()
        if not s:
            return Shift.OFF
        try:
            return parse_shift(s)
        except ValueError:
            return Shift.OFF

    out: Dict[str, dict] = {}
    for sid, raw_row in grid.items():
        row = [_to_shift(v) for v in raw_row]
        nd = num_days
        last = row[nd - 1] if nd else Shift.OFF
        run = 0
        d = nd - 1
        while d >= 0 and row[d] in WORK_SHIFTS:
            run += 1
            d -= 1
        trailing = 0
        d = nd - 1
        while d >= 0 and row[d] in NIGHT_SHIFTS:
            trailing += 1
            d -= 1
        remaining_off = 0
        if trailing >= 2:
            remaining_off = 2
        elif trailing == 0:
            if nd >= 2 and row[nd - 1] in REST_SHIFTS and row[nd - 2] in NIGHT_SHIFTS:
                blk = 1
                dd = nd - 3
                while dd >= 0 and row[dd] in NIGHT_SHIFTS:
                    blk += 1
                    dd -= 1
                if blk >= 2:
                    remaining_off = 1
        this_month_nights = sum(1 for v in row if v in NIGHT_SHIFTS)
        out[sid] = {
            "last_shift_type": str(last),
            "consecutive_work_days": run,
            "night_block_remaining_off": remaining_off,
            "night_block_in_progress": trailing == 1,
            "trailing_night_count": trailing,
            # 그리드 한 장만으로는 그 이전 달의 recent_night_score를 알 수 없으므로
            # 이번 달 실적만으로 새로 시작한다(그래도 0으로 두는 것보다는 근사가 낫다).
            "recent_night_score": float(this_month_nights),
            # 이 그리드 안에 야간이 없으면 None — 그 앞 달은 모르니 경계를 세지 않는다
            "days_since_last_night": _days_since_last_night(row, nd),
        }
    return out


# ---------------------------------------------------------------- 전입·전출 대조
def _is_night_peer(s: dict) -> bool:
    """야간 형평성 비교군인지 — 파트장·야간전담·야간불가는 목표 산정 대상이 아니라 제외."""
    if str(s.get("role", "")).strip() == "파트장":
        return False
    flags = list(s.get("flags") or [])
    if "night_only" in flags or "pregnant" in flags or "no_night" in flags:
        return False
    return "N" in [str(x).strip() for x in (s.get("allowed_shifts") or [])]


def reconcile_roster(staff: List[dict], prev_stats: Dict[str, dict],
                     transferred: Optional[set] = None) -> dict:
    """이번 달 명단(입력①)과 지난달 실적(입력②)을 대조해 전입·전출을 가려낸다.

    입력①은 '미래'(이번 달 근무표를 만들 명단), 입력②는 '과거'(지난달까지의 실적)다.
    따라서 명단의 기준은 항상 입력①이고, 둘의 차집합이 곧 인사이동이다.
      · 전입(incoming) = 입력①에만 있음 — 이월정보가 없는 사람
      · 전출(outgoing) = 입력②에만 있음 — 이번 달부터 배정 대상이 아닌 사람

    newcomer_night_score: 전입자에게 줄 recent_night_score 초기값. 0으로 두면
    "야간을 한 번도 안 선 사람"으로 취급돼 첫 달부터 야간 상한을 받아버리므로
    (compute_night_targets가 이 점수 오름차순으로 상한을 준다), 계속 근무 중인
    야간 비교군의 중앙값을 대신 쓴다 — 전 병동 이력을 모르는 상태에서 한쪽으로
    치우치지 않는 가장 중립적인 추정값이다.
    """
    prev_names = set(prev_stats or {})
    cur_names = [str(s.get("id", "")).strip() for s in staff]
    incoming = [n for n in cur_names if n and n not in prev_names]
    outgoing = sorted(prev_names - set(cur_names))

    # 비교군은 '계속 근무해온 사람'이어야 한다 — 이번 달 전입자는 (연간근무표에 행이
    # 있어 prev_names에 들어가더라도) 우리 병동 실적이 없으므로 중앙값을 끌어내린다.
    moved_in = set(transferred or ())
    peer_scores = []
    for s in staff:
        sid = str(s.get("id", "")).strip()
        # 조회도 '다듬은 이름'으로 해야 한다 — 판정만 strip하고 조회는 원문으로 하면,
        # 이름 앞뒤에 공백이 섞인 사람이 조용히 0점으로 잡혀 중앙값을 끌어내린다.
        if sid in prev_names and sid not in moved_in and _is_night_peer(s):
            peer_scores.append(
                float((prev_stats.get(sid) or {}).get("recent_night_score", 0.0)))
    peer_scores.sort()
    if peer_scores:
        mid = len(peer_scores) // 2
        median = (peer_scores[mid] if len(peer_scores) % 2
                  else (peer_scores[mid - 1] + peer_scores[mid]) / 2)
    else:
        median = 0.0
    return {"incoming": incoming, "outgoing": outgoing,
            "newcomer_night_score": round(median, 2)}


def night_score_from_grid_history(annual_dates: List[str], codes: List[str],
                                  year: int, month: int,
                                  before: Optional[str] = None) -> Optional[float]:
    """붙여넣은 근무기록(1~3개월치)에서 recent_night_score를 실제 공식대로 접어 계산한다.

    전입자가 전 병동 기록을 가져온 경우에 쓴다. build_next_carryover()가 매달 쓰는
    감쇠 이동평균과 같은 식(`이전점수 * 2/3 + 그 달 야간수`)을 기록이 있는 달마다
    순서대로 적용하므로, 계속 근무해온 사람과 같은 척도의 값이 나온다 — 1개월치면
    거친 근사, 3개월치면 사실상 수렴한 값이다.

    before('YYYY-MM-DD')를 주면 그 날짜 '전날까지'만 센다 — 월중 전입자는 입사일이
    경계이므로 이번 달 입사 전 구간(예: 2/1~2/14)도 실적에 포함해야 한다. 안 주면
    이번 달(year, month) 1일이 경계다(월초 전입·계속 근무자).

    부분 달(입사 전까지만 있는 달)도 한 달로 쳐서 접는다 — 감쇠 공식이 달 단위라
    그보다 잘게 나눌 수 없다. 형평성 참고값이므로 과소평가보다 이 편이 안전하다.
    """
    if not annual_dates or not codes:
        return None
    boundary = before or f"{year:04d}-{month:02d}-01"
    by_month: Dict[str, int] = {}
    has_record = False                   # 칸에 실제로 뭔가 적혀 있었는가
    for i, ds in enumerate(annual_dates):
        if i >= len(codes):
            break
        if ds >= boundary:
            continue                     # 아직 실적이 아닌 구간
        ym = ds[:7]                      # "YYYY-MM"
        by_month.setdefault(ym, 0)
        code = (codes[i] or "").strip()
        if code:
            has_record = True
        if code in ("N", "NK"):
            by_month[ym] += 1
    # '기록이 있고 야간이 0회'(0.0을 돌려줘야 함 — 야간 우선권을 주는 게 맞다)와
    # '기록 자체가 전부 빈칸'(알 수 없으니 None)을 구분한다. 전자에 중립값을 씌우면
    # 야간을 적게 선 사람의 우선권을 빼앗고, 후자를 0으로 두면 첫 달 야간을 몰아준다.
    if not by_month or not has_record:
        return None
    score = 0.0
    for ym in sorted(by_month):
        score = score * (2 / 3) + by_month[ym]
    return round(score, 2)


def carryover_from_history_before(annual_dates: List[str], codes: List[str],
                                  before: str) -> Optional[dict]:
    """붙여넣은 근무기록에서 'before(입사일) 전날' 기준 이월정보를 역산한다.

    월중 전입자용. 기본 경로(carryover_from_staff_table)는 '전월 1일~말일'을 잘라
    쓰는데, 2/15 입사자는 2/14까지 전 병동에서 근무했으므로 그 기준이 맞지 않는다
    (전월 말일로 계산하면 입사 직전의 야간블록을 통째로 놓쳐 야간 후 휴식이 안 지켜진다).

    연속근무일수·야간블록 판정에 필요한 만큼만 뒤에서 잘라 쓴다(넉넉히 62일).
    """
    if not annual_dates or not codes or not before:
        return None
    window = [c for ds, c in zip(annual_dates, codes) if ds < before]
    if not window:
        return None
    window = window[-62:]
    got = carryover_from_grid({"_": window}, len(window), lenient=True)
    return got.get("_")


# ---------------------------------------------------------------- 연간근무표 → 이월값 역산
def carryover_from_staff_table(annual_dates: List[str], annual_grid: Dict[str, List[str]],
                               year: int, month: int) -> Dict[str, dict]:
    """'연간근무표'의 연간 그리드에서 직전 달 구간만 잘라 carryover_from_grid로 역산.

    annual_dates에 직전 달 1일~말일이 빠짐없이 이어져 있는 경우에만 계산하고,
    아직 그만큼 안 쌓였거나 중간에 구멍이 있으면 빈 dict를 돌려준다(호출 쪽에서
    이월 없이 진행하거나 다른 값으로 채우면 됨).
    """
    import calendar as _cal
    import datetime as _dt
    py, pm = (year - 1, 12) if month == 1 else (year, month - 1)
    ndays = _cal.monthrange(py, pm)[1]
    prev_dates = [_dt.date(py, pm, d).isoformat() for d in range(1, ndays + 1)]
    try:
        idxs = [annual_dates.index(d) for d in prev_dates]
    except ValueError:
        return {}
    if idxs != list(range(idxs[0], idxs[0] + ndays)):
        return {}
    start = idxs[0]
    sliced = {sid: row[start:start + ndays] for sid, row in annual_grid.items()
             if len(row) >= start + ndays}
    return carryover_from_grid(sliced, ndays, lenient=True)

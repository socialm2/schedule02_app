# -*- coding: utf-8 -*-
"""근무표 생성 알고리즘 (설계서 §4 Step 0~9)."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from .calendar_utils import (
    DayInfo, DAY_WEEKDAY, build_calendar, holiday_count, min_staff_for,
)
from .constraints import (DAY_BLOCK_MAX, DAY_BLOCK_MAX_WITH_PRN, OFF_RUN_MAX,
                          _senior_pool_threshold, night_quota_options)
from .models import (
    Carryover, COUNTED_WORK_SHIFTS, MonthSchedule, Request, Shift, Staff,
    DAY_WORK_SHIFTS, DESIGNATED_KEY, NIGHT_SHIFTS, PRN_LIKE_SHIFTS, REST_SHIFTS,
    WORK_SHIFTS, parse_shift,
)

# S6 고랩 판정용 근무유형 키 (constraints.check_soft의 S6와 동일 매핑)
_SENIOR_SHIFT_KEY = {
    Shift.D: "D", Shift.E: "E", Shift.PRN: "prn", Shift.A8: "prn",
    Shift.N: "N", Shift.NK: "N",
}

# 근무유형별 레벨평균 소프트 튜닝의 가중치 — 무작위 tiebreak(0~1 균등분포)에 이
# 비율만큼만 격차를 얹어서, "항상 목표에 가장 가까운 후보"로 결정론적으로
# 쏠리지 않고 확률적으로만 살짝 선호하게 한다. 결정론적 tiebreak으로 두면
# 매일 같은 사람이 반복 선택돼 그 사람의 다른 근무일 가용성이 소진되면서
# 오히려 최소인력(H1-1) 위반이 늘어나는 부작용이 회귀 테스트로 확인됐다.
_LEVEL_NUDGE_WEIGHT = 0.15
#: 그날 조 평균을 맞추는 쪽의 가중치(_day_level_gap). 월 누적(_LEVEL_NUDGE_WEIGHT)보다
#: 세게 준다 — 월 누적은 이미 맞아 있는 경우가 많아 사실상 난수와 구분이 안 되는데,
#: 날짜별 쏠림은 바로 그 상태에서 생기기 때문이다. 다만 하드 규칙과 형평성(S2~S5)을
#: 침해하면 안 되므로 여전히 **최하위 동점 처리**에 얹는다(난수 0~1 위의 보정값).
#:
#: 값은 실측으로 골랐다. 샘플 병동(40명)에 실제 비율의 원티드를 섞어 10개월(2026-09~
#: 2027-06, 신청 920건)을 돌리고 0 / 0.3 / 0.6 / 1.0 / 1.5 / 2.0 / 3.0을 비교했다:
#:
#:                     0(끔)    1.0     1.5~3.0
#:   D조 레벨 폭        1.70    1.45    1.50~1.60
#:   D조 표준편차       0.429   0.354   0.356~0.375
#:   D에 고랩 없는 날   1.70    0.80    1.00~1.30
#:   하드 위반          52.0    50.8    49.8~50.0
#:   원티드 반영        902     910     905~908   (/920)
#:   근무일·OFF 편차   5.3·6.4  5.4·6.5  오차 범위
#:
#: 1.0에서 가장 좋고 그 위로는 더 나아지지 않는다(오히려 조금 나빠진다). 형평성
#: (근무일·OFF 편차)과 원티드 반영이 안 나빠지는 것을 같이 확인했다 — 레벨만 보고
#: 당기면 그 둘이 밀리는데, 최하위 동점 처리라 그렇지 않았다.
#:
#: ⚠ **주간 후보에만 넣었다.** 야간은 2~3일 블록으로 묶여 배정돼서 같은 보정을 넣으면
#: 블록 전체가 끌려간다 — 실측에서도 야간 지표는 전혀 안 움직였다(N폭 1.88 그대로).
#: 야간 쏠림은 따로 볼 문제다(파트장 요청 범위 밖).
_DAY_LEVEL_NUDGE_WEIGHT = 1.0


@dataclass
class Params:
    nk_count: int = 0
    min_staff: Dict[str, Dict[str, int]] = field(default_factory=dict)
    leader_8a_as_prn: bool = False
    max_nights: int = 6            # H2-6 (입력키: off_max_per_month)
    holidays: List[str] = field(default_factory=list)
    substitute_holidays: List[str] = field(default_factory=list)
    advanced_track_staff: List[str] = field(default_factory=list)
    max_requests_per_person: int = 20  # §5 (입력엑셀에서는 안 받고 고정값만 씀)
    prn_cap_extra: int = 2             # 확정 #7: 하루 prn 최대 = 최소+2
    # B팀(신입) 이름만 — 스케줄링에는 전혀 관여하지 않고 출력 시 이름만 표시(§team_b)
    team_b_names: List[str] = field(default_factory=list)
    # H6-4 월 야간목표 하한/상한(일반 간호사, 야간전담 제외) — 기본 4/6일(2일블록만).
    # 상한을 홀수로 올리면(예: 7) 2일 블록만으로는 못 채우므로 3일 블록도 자동 허용된다
    # (assign_nights/_can_night_block 참고) — off_max_per_month(H2-6 상한)도 함께 올려야
    # 실제로 그 인원까지 배정될 수 있다.
    night_quota_low: int = 4
    night_quota_high: int = 6
    # H3-1 안전 규칙 — 연속근무 허용 일수 상한(이 값을 넘는 연속근무는 절대 배정하지
    # 않는다). 기본 5일(기존 동작과 동일). 병동별로 4일까지만 허용하고 싶으면 병동인력표(옛 입력①)
    # "설정" 시트의 "연속근무제한" 칸을 4로 바꾸면 된다 — 낮출수록 배치 자유도가
    # 줄어 §H6-1(주간 3~4일 블록) 등 최선노력 규칙이 더 자주 못 지켜질 수 있다.
    max_consecutive_work: int = 5

    @classmethod
    def from_dict(cls, d: dict) -> "Params":
        return cls(
            nk_count=int(d.get("nk_count", 0)),
            min_staff=d.get("min_staff", {}),
            leader_8a_as_prn=bool(d.get("leader_8a_as_prn", False)),
            max_nights=int(d.get("off_max_per_month",
                                 d.get("max_nights_per_month", 6))),
            holidays=d.get("holidays", []),
            substitute_holidays=d.get("substitute_holidays", []),
            advanced_track_staff=d.get("advanced_track_staff", []),
            max_requests_per_person=int(d.get("max_requests_per_person", 20)),
            prn_cap_extra=int(d.get("prn_cap_extra", 2)),
            team_b_names=d.get("team_b_names", []),
            night_quota_low=int(d.get("night_quota_low", 4)),
            night_quota_high=int(d.get("night_quota_high", 6)),
            max_consecutive_work=int(d.get("max_consecutive_work", 5)),
        )


class InputError(Exception):
    pass


def _nk_block_plan(total: int, start_with_three: bool = True) -> List[int]:
    """NK 월 목표 야간일수를 2일/3일 블록으로 최대한 비슷한 비율로 나눈다(S10 최선 근사).

    2*a + 3*b = total 을 만족하는 조합 중 |a-b|(2일/3일 블록 개수차)가 최소인 것을 고른다.
    (예: 15 → 2일 3개+3일 3개 정확히 1:1, 14 → 2일 4개+3일 2개가 최선의 근사)

    start_with_three: NK 인원이 여럿일 때 서로 다른 값을 줘서 근무/휴식 위상을
    엇갈리게 한다 — 위상이 같으면 여러 NK가 동시에 OFF인 날이 생겨 그날 일반
    간호사가 야간을 더 메워야 해 다른 근무 최소인력이 부족해지기 쉽다.
    """
    best = None
    for b in range(0, total // 3 + 1):
        rem = total - 3 * b
        if rem < 0 or rem % 2 != 0:
            continue
        a = rem // 2
        diff = abs(a - b)
        if best is None or diff < best[0]:
            best = (diff, a, b)
    if best is None:
        return [total] if total > 0 else []
    _, a, b = best
    plan: List[int] = []
    while a > 0 or b > 0:
        if start_with_three:
            if b > 0:
                plan.append(3)
                b -= 1
            if a > 0:
                plan.append(2)
                a -= 1
        else:
            if a > 0:
                plan.append(2)
                a -= 1
            if b > 0:
                plan.append(3)
                b -= 1
    return plan


class Generator:
    def __init__(self, config: dict,
                 fixed_cells: Optional[Dict[Tuple[str, int], Shift]] = None,
                 seed: int = 0):
        self.cfg = config
        self.fixed_cells = fixed_cells or {}
        self.seed = seed
        self.year = int(config["year"])
        self.month = int(config["month"])
        self.params = Params.from_dict(config.get("params", {}))
        self.staff = self._parse_staff(config["staff"])
        orig_order = {s.id: i for i, s in enumerate(self.staff)}  # 셔플 전 원본 순서
        import random
        self.rng = random.Random(seed)
        if seed:
            # 재시도 시 후보 순서·동순위 결정을 바꿔 다른 해를 찾는다 (Step 10 재시도)
            self.rng.shuffle(self.staff)
        carry = {sid: Carryover.from_dict(v)
                 for sid, v in (config.get("prev_month_carryover") or {}).items()
                 if sid in {s.id for s in self.staff}}
        self.sch = MonthSchedule(self.year, self.month, self.staff, carry,
                                 team_b=self.params.team_b_names)
        # 출력용 순서 고정 — self.staff는 seed>0일 때 섞여 있으므로, 출력 정렬은
        # 리스트 순서 대신 이 매핑을 참조해야 원본 입력 순서를 그대로 유지한다.
        self.sch.orig_staff_order = orig_order
        self.days: List[DayInfo] = build_calendar(
            self.year, self.month, self.params.holidays,
            self.params.substitute_holidays)
        self.sch.set_weekend_days(
            {i for i, di in enumerate(self.days) if di.day_type != DAY_WEEKDAY})
        self.requests: List[Request] = [
            Request(staff_id=r["staff_id"], date=r["date"],
                    type=parse_shift(r["type"]),
                    priority=int(r.get("priority", 1)))
            for r in (config.get("requests") or [])
        ]
        # 월중 전입자의 이번 달 첫 근무일(0-based). 입사 전 날짜는 우리 병동 소속이
        # 아니므로 배정에서 빼고, 잔휴도 재직 구간(입사일~말일)의 휴일수만 적립한다.
        # {staff_id: day_index} — 월초(1일자) 전입이나 계속 근무자는 여기 없다.
        self.transfer_in_day: Dict[str, int] = {}
        for sid, ds in (config.get("transfer_in_dates") or {}).items():
            if sid not in {s.id for s in self.staff}:
                continue
            try:
                y, m, d = (int(x) for x in str(ds)[:10].split("-"))
            except (TypeError, ValueError):
                continue
            if (y, m) == (self.year, self.month) and 1 < d <= self.sch.num_days:
                self.transfer_in_day[sid] = d - 1
        # 제약검사(constraints)는 Generator를 모르고 sch만 받으므로, month_start()와
        # 같은 기준점을 sch에도 실어 보낸다 — 안 그러면 월중 전입자의 이월 연결이
        # 검사 쪽에서만 끊겨, 생성기는 정상으로 보는 배치를 검사기가 위반으로 찍는다.
        self.sch.month_start_day = dict(self.transfer_in_day)
        self.nk_target = 14 if self.month == 2 else 15
        self.senior_threshold: Dict[str, Optional[int]] = {}
        # 근무유형(D/E/N/prn)별 평균 숙련도가 서로 골고루 맞춰지도록(요청사항) —
        # 병동 전체 평균(파트장 제외)을 목표로 두고, 배정 중 누적 평균-목표 격차가
        # 가장 작아지는 후보를 동점 상황에서 우선한다(최하위 우선순위 — 다른 배정
        # 기준을 침해하지 않음, H1-5와 같은 설계). 결과는 화면/출력 하단의
        # 레벨평균 표시(프론트엔드에서 그리드로부터 직접 계산)로 확인할 수 있다.
        self._staff_by_id = {s.id: s for s in self.staff}
        generals_for_avg = [s for s in self.staff if not s.is_partjang]
        self._shift_level_target = (
            sum(s.level for s in generals_for_avg) / len(generals_for_avg)
            if generals_for_avg else 0.0)

    def _shift_level_stats(self, key: str) -> Tuple[float, int]:
        """key 근무유형에 현재(그 시점 그리드 기준) 배정된 인원(파트장 제외)의
        레벨 합·인원수를 매번 그리드에서 직접 다시 센다. 수리(repair)가 셀을
        지우고 다시 채우는 경우가 흔해, 증분 누적 방식은 지운 만큼 빼주지 않으면
        실제 그리드와 어긋나는 값으로 계속 쌓인다 — 그 드리프트가 특정 후보를
        비정상적으로 계속 선호하게 만들어 최소인력(H1-1) 위반을 늘리는 부작용을
        낳는 것으로 확인됐다(회귀 테스트로 발견). 그리드 스캔은 후보 하나당이
        아니라 _pick_day_candidate/_pick_night_candidate 호출당 한 번만 하므로
        비용도 감당할 만하다."""
        total, cnt = 0.0, 0
        for s in self.staff:
            if s.is_partjang:
                continue
            for v in self.sch.grid[s.id]:
                if _SENIOR_SHIFT_KEY.get(v) == key:
                    total += s.level
                    cnt += 1
        return total, cnt

    def _day_level_gap(self, cur_levels: List[int], level: int) -> float:
        """이 사람을 그날 그 조에 넣으면 조 평균이 병동 평균에서 얼마나 멀어지는가.

        작을수록 좋다. 조가 비어 있으면(첫 배정) 0을 돌려준다 — 첫 사람은 비교할
        대상이 없고, 여기서 레벨을 고르기 시작하면 H1-5(Lv4+ 확보)와 싸운다."""
        if not cur_levels:
            return 0.0
        new_avg = (sum(cur_levels) + level) / (len(cur_levels) + 1)
        return abs(new_avg - self._shift_level_target)

    def _level_gap_given(self, stats: Tuple[float, int], level: int,
                         weight: int = 1) -> float:
        """stats(=_shift_level_stats 결과)에 이 레벨을 weight만큼 더하면 병동
        전체 평균과의 격차가 얼마나 되는지 — 작을수록(0에 가까울수록) 그
        근무유형의 평균을 목표에 가깝게 만드는 배정이라는 뜻."""
        total, cnt = stats
        new_cnt = cnt + weight
        if new_cnt == 0:
            return 0.0
        new_avg = (total + level * weight) / new_cnt
        return abs(new_avg - self._shift_level_target)

    # ------------------------------------------------------------ S6 고랩 기준선
    def compute_senior_thresholds(self):
        """근무유형별 상대 고랩 기준선(constraints._senior_pool_threshold와 동일 정의)을
        미리 계산해둔다 — 배정 중 가드(_lv3_guard_ok)와 검증(check_soft)이 같은
        기준을 쓰도록 하기 위함."""
        pools = {
            "D": [s for s in self.staff if not s.is_partjang and s.can(Shift.D)],
            "E": [s for s in self.staff if not s.is_partjang and s.can(Shift.E)],
            "prn": [s for s in self.staff if not s.is_partjang and s.can(Shift.PRN)],
            "N": [s for s in self.staff
                  if not s.is_partjang and (s.is_nk or s.can(Shift.N))],
        }
        self.senior_threshold = {key: _senior_pool_threshold(pool)
                                 for key, pool in pools.items()}

    def _senior_min_level(self, shift: Shift) -> int:
        key = _SENIOR_SHIFT_KEY.get(shift)
        th = self.senior_threshold.get(key) if key else None
        return th if th is not None else 3

    # ------------------------------------------------------------ H6-4 목표
    def compute_night_targets(self):
        """야간 가능한 일반 간호사에게 이번 달 목표(기본 4일 또는 6일, params.night_quota_*
        로 조정 가능)를 배정한다.

        전월 누적 데이터(carryover.recent_night_score — 감쇠 이동평균)가 적은
        사람일수록 상한 목표를 받아 장기적으로 균등해지도록 한다(§전월 누적 기반)."""
        # 모두에게 공통으로 허용되는 블록 길이 상한(H2-3). 목표가 홀수면 2일만으로는
        # 정확히 못 채우므로 3일도 열린다.
        self._gen_max_block = 3 if (self.params.night_quota_low % 2
                                    or self.params.night_quota_high % 2) else 2
        eligible = [s for s in self.staff
                    if not (s.is_partjang or s.is_nk) and s.can(Shift.N)]
        # 후보로 **시도해볼** 길이 목록. 3N인 사람이 한 명이라도 있으면 3일도 시도한다
        # (그 사람에게만 허용되는지는 후보 안에서 사람별로 다시 거른다). 아무도 없으면
        # 예전과 똑같이 2일만 시도하므로 기존 근무표는 그대로다.
        any_three = any(s.night_block_pref >= 3 for s in eligible)
        self._night_block_lengths = ((2, 3) if (self._gen_max_block == 3 or any_three)
                                     else (2,))
        if not eligible:
            return
        ranked = sorted(
            eligible,
            key=lambda s: (self.sch.carryover[s.id].recent_night_score, s.id))
        six_count = (len(ranked) + 1) // 2  # 홀수면 상한 그룹이 1명 더 많게(적게 한 쪽 우선)
        for i, s in enumerate(ranked):
            # 3N인 사람은 상한 하나뿐이다 — 3일 블록으로는 하한(기본 4)을 만들 수 없다.
            # constraints.night_quota_options와 같은 판단이라 그쪽을 그대로 부른다.
            opts = night_quota_options(s, self.params)
            if len(opts) == 1:
                self.sch.night_target[s.id] = opts[0]
                continue
            self.sch.night_target[s.id] = (
                self.params.night_quota_high if i < six_count
                else self.params.night_quota_low)

    # ------------------------------------------------------------ 입력 파싱
    @staticmethod
    def _parse_staff(raw: List[dict]) -> List[Staff]:
        staff = []
        for r in raw:
            staff.append(Staff(
                id=r["id"], role=r["role"], level=int(r.get("level", 1)),
                allowed_shifts=[parse_shift(x) for x in r.get("allowed_shifts", [])],
                flags=list(r.get("flags", [])),
            ))
        ids = [s.id for s in staff]
        if len(ids) != len(set(ids)):
            raise InputError("staff id 중복")
        return staff

    # ------------------------------------------------------------ 유틸
    def min_for(self, day: int, key: str) -> int:
        return min_staff_for(self.days[day], self.params.min_staff).get(key, 0)

    def _block_has_prn(self, sid: str, d: int, before: int, after: int) -> bool:
        """d를 넣었을 때 생기는 주간 블록 안에 prn 계열이 이미 들어 있는가.

        _day_block_cap(검사기)과 같은 질문이지만, 아직 d에 값을 넣기 전이라 그리드를
        그대로 읽을 수 없어서 앞뒤 길이로 구간을 잡아 본다."""
        row = self.sch.grid[sid]
        nd = self.sch.num_days
        for k in range(max(0, d - before), min(nd, d + after + 1)):
            if k != d and row[k] in PRN_LIKE_SHIFTS:
                return True
        return False

    def _cell_free(self, sid: str, d: int) -> bool:
        """배정 가능한 칸: 미배정이거나, 잠기지 않은 OFF."""
        if self.sch.is_locked(sid, d):
            return False
        v = self.sch.get(sid, d)
        return v is None or v == Shift.OFF

    def _is_rest_or_free(self, sid: str, d: int) -> bool:
        if d >= self.sch.num_days:
            return True
        v = self.sch.get(sid, d)
        return v is None or v in REST_SHIFTS

    def can_assign_day(self, s: Staff, d: int, shift: Shift) -> bool:
        """D/E/prn/8A(리더) 한 칸 배정 가능성 검사 (H1-3, H2-8, H3-1, H3-2)."""
        if s.is_partjang or s.is_nk:
            return False
        sch = self.sch
        sid = s.id
        # _cell_free 인라인(이 함수가 최다 호출 경로라 함수 호출 한 겹을 줄임 — 의미는 동일)
        if (sid, d) in sch.locked:
            return False
        v = sch.grid[sid][d]
        if v is not None and v != Shift.OFF:
            return False
        if shift == Shift.A8:
            # 엔진이 **스스로** 8A를 넣는 경우는 리더 운용 병동의 평일뿐이다. 규칙상
            # 주말 8A도 허용되지만(H1-2), 자동으로 주말까지 채우지는 않는다 —
            # 파트장이 원티드로 신청하거나 화면에서 직접 넣는 길은 열려 있다.
            if not (s.is_leader and self.params.leader_8a_as_prn
                    and self.days[d].auto_8a):
                return False
        elif shift not in s.allowed_shifts:
            return False
        # 연속근무: 앞뒤 이어진 근무와 합쳐 max_consecutive_work일 이하 (H3-1)
        base = self.month_start(sid)
        before = sch.work_run_ending(sid, d - 1) if d > base else \
            (sch.carryover[sid].consecutive_work_days
             if sch.carryover[sid].last_shift_type in WORK_SHIFTS else 0)
        after = sch.work_run_starting(sid, d + 1)
        total = before + 1 + after
        # 뒤 근무열이 월말 단독야간으로 끝나면 익월 1일 연장(H5-2) 예정 → +1
        nd = sch.num_days
        if d + 1 + after == nd and after > 0 \
                and sch.get(sid, nd - 1) in NIGHT_SHIFTS \
                and (nd < 2 or sch.get(sid, nd - 2) not in NIGHT_SHIFTS):
            total += 1
        if total > self.params.max_consecutive_work:
            return False
        # H6-1: 주간 연속블록 상한 (전용 카운트). prn 계열이 하루라도 끼면 5일까지다
        # — 검사기(_day_block_cap)와 같은 기준이어야 한다. 한쪽만 고치면 생성기가
        # 4일에서 막아 5일이 아예 안 만들어지거나(규칙을 풀어도 근무표가 안 바뀜),
        # 반대로 검사기가 못 잡아 5일이 그냥 통과한다.
        if shift in DAY_WORK_SHIFTS:
            day_before = sch.day_work_run_ending(sid, d - 1) if d > base else \
                (sch.carryover[sid].consecutive_work_days
                 if sch.carryover[sid].last_shift_type in DAY_WORK_SHIFTS else 0)
            day_after = sch.day_work_run_starting(sid, d + 1)
            cap = DAY_BLOCK_MAX
            if shift in PRN_LIKE_SHIFTS or self._block_has_prn(sid, d, day_before, day_after):
                cap = DAY_BLOCK_MAX_WITH_PRN
            if day_before + 1 + day_after > cap:
                return False
        # effective() 인라인(d-1/d-2가 이번 달 안이면 grid 직접 조회, 월경계만 이월 로직 사용)
        row = sch.grid[sid]
        if d >= 1:
            p1 = row[d - 1]
            if p1 is None:
                p1 = Shift.OFF
        else:
            p1 = sch.effective(sid, d - 1)
        if d >= 2:
            p2 = row[d - 2]
            if p2 is None:
                p2 = Shift.OFF
        else:
            p2 = sch.effective(sid, d - 2)
        # H2-8: N→주간, N-O→주간 금지
        if p1 in NIGHT_SHIFTS:
            return False
        if p2 in NIGHT_SHIFTS and p1 in REST_SHIFTS:
            return False
        # H3-2: E→D, E→prn
        if p1 == Shift.E and shift in (Shift.D, Shift.PRN, Shift.A8):
            return False
        # H6-3: EOD(E-O-D) 금지
        if p2 == Shift.E and p1 in REST_SHIFTS and shift == Shift.D:
            return False
        nxt = row[d + 1] if d + 1 < nd else None
        if shift == Shift.E and nxt in (Shift.D, Shift.PRN, Shift.A8):
            return False
        # H6-3: EOD(E-O-D) 금지 — 반대 방향(E를 놓았을 때 이틀 뒤에 이미 D가 있는 경우)
        if shift == Shift.E:
            nxt1 = Shift.OFF if nxt is None else nxt
            if d + 2 < nd:
                nxt2 = row[d + 2]
                if nxt2 is None:
                    nxt2 = Shift.OFF
            else:
                nxt2 = Shift.OFF
            if nxt1 in REST_SHIFTS and nxt2 == Shift.D:
                return False
        return True

    # ------------------------------------------------------------ Step 0
    def validate_input(self):
        p = self.params
        if not p.min_staff:
            raise InputError("params.min_staff 누락")
        for t in ("weekday", "saturday", "sunday_holiday"):
            if t not in p.min_staff:
                raise InputError(f"min_staff.{t} 누락")
        partjang = [s for s in self.staff if s.is_partjang]
        if len(partjang) > 1:
            raise InputError(
                f"파트장은 1명이어야 하는데 {len(partjang)}명입니다: "
                f"{', '.join(s.id for s in partjang)} — 인원 시트의 '직급' 칸을 확인하세요.")
        # 파트장 0명은 여기서 막지 않는다 — 파트장 개념 자체를 안 쓰는 최소 구성(테스트,
        # 일부 소규모 병동)도 유효한 입력이라서다. 실사용 흔적(엑셀 업로드로 만든 입력에
        # 파트장이 하나도 없는 경우 — 오타일 가능성이 높음)은 API 계층(webapp/app.py,
        # bridge.py의 set_config)에서 경고로 별도 안내한다.
        nk_staff = [s for s in self.staff if s.is_nk]
        if len(nk_staff) != p.nk_count:
            raise InputError(
                f"nk_count={p.nk_count} 이지만 NK 전담 인원은 {len(nk_staff)}명")
        for s in nk_staff:
            if s.no_night:
                raise InputError(f"NK 전담 {s.id}에 야간불가 플래그")

        # 야간 슬롯 실현가능성: 총 야간수요 vs NK 공급 + 일반 야간역량
        # ⚠ 인원/설정 자체가 모순(위의 검사들)인 경우와 달리, 이건 "이 조건으로는
        # 이론상 100% 못 채운다"는 용량 부족일 뿐이다 — 여기서 생성을 막지 않고
        # 경고만 남긴 채 최대한 배정한다(최소인력 보존 우선, H1-1/H6-4로 잔여
        # 위반 표시). 실제 조정(인원 충원/상한 상향 등)은 리포트를 본 파트장이
        # 판단할 몫이다.
        total_night_slots = sum(self.min_for(d, "N")
                                for d in range(self.sch.num_days))
        nk_supply = len(nk_staff) * self.nk_target
        generals = [s for s in self.staff
                    if not (s.is_partjang or s.is_nk) and s.can(Shift.N)]
        capacity = sum(self.sch.night_target.get(s.id, p.max_nights)
                       for s in generals)
        if total_night_slots - nk_supply > capacity:
            self.sch.log(
                f"[경고] 이 조건으로는 야간 근무를 다 채울 수 없습니다 — 이번 달 야간 수요는 "
                f"{total_night_slots}칸인데, 야간전담 인원이 {nk_supply}칸을 채우고 나면 "
                f"나머지 일반 인원이 감당할 수 있는 야간은 최대 {capacity}칸뿐입니다. "
                "목표 상한을 넘겨서라도 최대한 배정하며(§3 H1-1 우선), 완전히 해소하려면 "
                "인원을 늘리거나 야간전담 인원수(NK)를 조정하거나 월최대야간 상한을 올려야 "
                "합니다 — 조정은 파트장 몫으로 남겨두고 우선 최선의 근무표를 만듭니다.")

        # 일별 총 최소인력 vs 가용 인원 (파트장 제외) — 마찬가지로 용량 부족은
        # 막지 않고 경고만 남긴다(그날은 구조적으로 최소인력을 못 채운다).
        head = len([s for s in self.staff if not s.is_partjang])
        for d in range(self.sch.num_days):
            need = sum(self.min_for(d, k) for k in ("D", "E", "N", "prn"))
            if need > head:
                self.sch.log(
                    f"[경고] 이 조건으로는 {d+1}일 최소인력을 다 채울 수 없습니다 — 필요한 "
                    f"합이 {need}명인데, 그날 배정 가능한 인원(파트장 제외)은 {head}명뿐입니다. "
                    "완전히 해소하려면 인원을 늘리거나 그날의 최소인력 기준을 낮춰야 합니다 — "
                    "조정은 파트장 몫으로 남겨두고 우선 최선의 근무표를 만듭니다.")

    # ------------------------------------------------------------ Step 0.5 (재생성)
    def apply_fixed(self):
        """리더 수정분 고정 배정. 이후 모든 스텝에서 이동 금지 (원티드보다 우선)."""
        for (sid, d), shift in sorted(self.fixed_cells.items()):
            if sid not in self.sch.by_id or not (0 <= d < self.sch.num_days):
                continue
            s = self.sch.by_id[sid]
            self.sch.set(sid, d, shift, lock=True)
            self.sch.wanted.add((sid, d))
            if shift == Shift.A8 and s.is_leader:
                self.sch.mark_leader_8a(sid, d)
            self.sch.log(f"[수정고정] {sid} {d+1}일 = {shift}")
            # ⚠ 예전에는 '휴'가 들어오면 그 달 나머지 날짜를 전부 '휴'로 채워 배정에서
            # 뺐다(휴직으로 해석). 지금은 채우지 않는다 — 파트장이 지정한 그 날만
            # 제외한다. 병원 OCS에서 '휴'는 하루짜리 단기부모휴가이고, 진짜 휴직은
            # 사·상·산전·육법·육연·R로 따로 있다. 하루 휴가를 휴직으로 읽으면 그 사람이
            # 한 달 내내 근무표에서 사라지는데, 오류도 안 나서 알아채기 어려웠다.
            # 여러 날 쉬는 경우는 파트장이 그 날들을 각각 표시한다.

    def complete_partial_night_blocks(self):
        """수정으로 생긴 단독 야간을 2~3일 블록으로 보완하고 뒤 휴식 2일 확보 (H2-4/H2-5)."""
        nd = self.sch.num_days
        for s in self.staff:
            d = 0
            while d < nd:
                if self.sch.get(s.id, d) not in NIGHT_SHIFTS:
                    d += 1
                    continue
                start = d
                while d + 1 < nd and self.sch.get(s.id, d + 1) in NIGHT_SHIFTS:
                    d += 1
                end = d
                length = end - start + 1
                carry_head = (start == self.month_start(s.id)
                              and self.sch.carryover[s.id].trailing_night_count > 0)
                night = Shift.NK if s.is_nk else Shift.N
                if length == 1 and end != nd - 1 and not carry_head:
                    if self._cell_free(s.id, end + 1):
                        self.sch.set(s.id, end + 1, night, lock=True)
                        end += 1
                        self.sch.log(f"[보완] {s.id} {end+1}일 {night} — 단독야간 블록화(H2-4)")
                    elif start > 0 and self._cell_free(s.id, start - 1) and \
                            self.sch.effective(s.id, start - 2) not in NIGHT_SHIFTS:
                        self.sch.set(s.id, start - 1, night, lock=True)
                        self.sch.log(f"[보완] {s.id} {start}일 {night} — 단독야간 블록화(H2-4)")
                if end - start + 1 >= 2 or carry_head:
                    for k in (1, 2):
                        dd = end + k
                        if dd < nd and self._cell_free(s.id, dd):
                            self.sch.set(s.id, dd, Shift.OFF, lock=True)
                d = end + 1

    # ------------------------------------------------------------ Step 1
    def lock_pre_join_days(self):
        """월중 전입자의 입사 전 날짜를 배정 대상에서 뺀다.

        그 기간은 우리 병동 소속이 아니므로 근무를 넣으면 안 되고, 최소인력 집계에도
        들어가면 안 된다. 코드는 '휴'(휴직)를 쓴다 — 이미 "그 기간은 이 병동 인력이
        아님"을 뜻하는 코드이고, OFF가 아니라서 순수오프(잔휴 차감)로도, 근무일수로도
        세어지지 않아 통계가 왜곡되지 않는다(반대 방향인 '휴직 발생일부터 월말까지
        제외'와 대칭)."""
        for sid, first_day in self.transfer_in_day.items():
            for d in range(first_day):
                if not self.sch.is_locked(sid, d):
                    self.sch.set(sid, d, Shift.LEAVE, lock=True)
            self.sch.log(f"[전입] {sid} {first_day + 1}일 입사 — 이전 {first_day}일 배정 제외")

    def working_holiday_count(self, sid: str) -> int:
        """그 사람의 이번 달 재직 구간에 속한 휴일수(토/일/공휴일).

        월중 전입자는 입사일부터만 센다 — 잔휴는 전 병동이 입사 전날까지 정산해
        넘겨준 숫자에서 이어받으므로, 우리 병동은 재직한 기간분만 적립해야 이중
        계산이 되지 않는다. 계속 근무자는 월 전체(기존과 동일)."""
        first = self.transfer_in_day.get(sid)
        if first is None:
            return holiday_count(self.days)
        return sum(1 for di in self.days[first:] if di.day_type != DAY_WEEKDAY)

    def month_start(self, sid: str) -> int:
        """그 사람의 '이번 달 첫날' 인덱스 — 이월정보를 적용하는 기준점.

        보통은 1일(0)이지만 월중 전입자는 입사일이다. 전입자의 이월정보는 전 병동의
        '입사 전날'까지를 역산한 값이라, 1일 기준으로 적용하면 입사 전(배정 제외된)
        날짜에 흡수돼 사라진다 — 전 병동에서 야간을 서고 온 사람에게 입사 첫날부터
        야간이 또 들어가는 식이 된다. 월경계를 다루는 자리는 0 대신 이 값을 쓴다."""
        return self.transfer_in_day.get(sid, 0)

    def staffing_pressure(self) -> dict:
        """이 입력이 얼마나 빠듯한지 — 압박률과 근거 숫자를 돌려준다(모듈 주석 참고).

        수요: 이번 달 최소인력을 전부 채우는 데 필요한 인원-일 (8A는 파트장 전용이라 제외).
        공급: 파트장을 뺀 인원이 실제로 근무에 낼 수 있는 인원-일. 월중 전입자는 입사 전
              날짜에 배정될 수 없으므로 그만큼 빼고(month_start), 누구나 H4-1로 월 최소
              휴무일(max(8, 휴일수-1))은 반드시 쉬므로 그것도 뺀다.
        """
        nd = self.sch.num_days
        demand = sum(self.min_for(d, k)
                     for d in range(nd) for k in ("D", "E", "N", "prn"))
        min_off_full = max(8, holiday_count(self.days) - 1)
        workers = [s for s in self.staff if not s.is_partjang]
        supply = 0
        for s in workers:
            avail = nd - self.month_start(s.id)      # 월중 전입자는 입사일부터
            if avail <= 0:
                continue
            # 월중 전입자의 최소 휴무일은 재직일수에 비례해 본다(H4-1은 월 단위 기준이라
            # 한 달을 다 다니지 않은 사람에게 그대로 적용하면 공급을 과소평가한다).
            min_off = min_off_full if avail >= nd else round(min_off_full * avail / nd)
            supply += max(0, avail - min_off)
        # 수요가 0이면(최소인력을 전부 0으로 둔 달) 공급이 얼마든 부족할 게 없다.
        # 이걸 안 걸러내면 '0인원-일이 필요한데 0인원-일뿐이라 위반이 반드시 남는다'는
        # 앞뒤 안 맞는 안내가 나간다 — 드문 입력이라 더더욱 아무도 못 잡는다.
        if demand == 0:
            ratio = 0.0
        elif supply:
            ratio = demand / supply
        else:
            ratio = float("inf")   # 쓸 사람이 아예 없는데 채울 건 있다 = 최악
        level = _pressure_level(ratio)
        return {
            "demand": demand,
            "supply": supply,
            "ratio": round(ratio, 3) if ratio != float("inf") else None,
            "level": level,
            "workers": len(workers),
            "num_days": nd,
            "min_off": min_off_full,
            "message": _pressure_message(level, demand, supply),
            "designated": self.designated_feasibility(min_off_full),
        }

    def designated_feasibility(self, min_off_full: int) -> dict:
        """지정 인원(H1-6)을 산술적으로 채울 수 있는지 — 생성 전에 미리 본다.

        지정은 하드 규칙이라 못 채우면 위반이 남는데, **인원이 부족해서 못 채우는
        경우는 몇 번을 다시 돌려도 안 된다.** 지정 가능자가 2명인데 매일 2명이
        필요하면 그 둘이 한 달 내내 근무해야 하고, 그건 월 최소 휴무일(H4-1)과
        정면으로 부딪혀 산술적으로 불가능하다. 실제 운영 규모가 1~3명이라 충분히
        일어날 수 있는 일이라, 생성을 돌려 몇 십 초를 기다린 끝에 위반을 보는 대신
        시작 전에 알려준다.

        need(전체 필요 인원-일)와 capacity(지정 가능자들이 낼 수 있는 인원-일)를
        비교한다. capacity 계산은 staffing_pressure의 공급 계산과 같은 방식이다.
        """
        nd = self.sch.num_days
        need = sum(self.min_for(d, DESIGNATED_KEY) for d in range(nd))
        people = [s for s in self.staff if not s.is_partjang and s.is_designated]
        capacity = 0
        for s in people:
            avail = nd - self.month_start(s.id)
            if avail <= 0:
                continue
            min_off = min_off_full if avail >= nd else round(min_off_full * avail / nd)
            # 야간을 서는 사람은 그 뒤 이틀이 의무 휴식이고, 야간이 6회 이상이면
            # 수면오프가 하루 더 붙는다. 이 날들은 '쉬는 날'로는 안 세지만 근무를
            # 세울 수 없는 날이라, 안 빼면 낼 수 있는 인원-일이 실제보다 부풀려진다.
            # 지정 가능자 2명 병동이 "가능"으로 통과한 뒤 달마다 3~6일을 못 채웠던
            # 것이 이 부풀림 때문이었다.
            rest = 0
            if s.can(Shift.N) and not s.is_nk:
                nights = self.params.night_quota_high
                rest = 2 * max(1, nights // 2)      # 블록마다 이틀씩
                if nights >= 6:
                    rest += 1                        # 수면오프(H7-1)
            capacity += max(0, avail - min_off - rest)
        max_need_per_day = max((self.min_for(d, DESIGNATED_KEY) for d in range(nd)),
                               default=0)
        # 하루 평균으로 몇 명을 세울 수 있는가 — 총량이 맞아도 이 값이 필요 인원에
        # 바짝 붙어 있으면, 야간·휴식·오프가 겹치는 날에 반드시 빵꾸가 난다.
        per_day = capacity / nd if nd else 0.0
        message = ""
        if need:
            if len(people) < max_need_per_day:
                message = (f"지정 인원이 모자랍니다 — 하루에 최대 {max_need_per_day}명이 "
                           f"필요한데 가능근무에 '지정'을 적은 사람은 {len(people)}명뿐입니다. "
                           "명단의 가능근무 칸을 확인하거나 근무인력 표의 '지정' 값을 "
                           "낮춰주세요.")
            elif need > capacity:
                message = (f"지정 인원을 다 채울 수 없습니다 — 이번 달에 {need}인원-일이 "
                           f"필요한데 지정 가능자 {len(people)}명이 낼 수 있는 건 "
                           f"{capacity}인원-일뿐입니다(월 최소 휴무 {min_off_full}일과 "
                           "야간 뒤 휴식을 뺀 값). "
                           "지정 가능자를 늘리거나 근무인력 표의 '지정' 값을 낮춰야 합니다.")
            elif per_day < max_need_per_day + 0.5:
                # 총량은 되는데 여유가 없는 경우. 되돌려보내지 않고 경고만 한다 —
                # 실제로 대부분의 날은 채워지고, 며칠만 못 채운다. 다만 "가능"이라고
                # 말해놓고 하드 위반을 내미는 것이 제일 나쁘므로 미리 말한다.
                message = (f"지정 인원이 빠듯합니다 — 하루 평균 세울 수 있는 지정 가능자가 "
                           f"{per_day:.1f}명인데 필요한 건 {max_need_per_day}명입니다. "
                           "야간·야간 뒤 휴식·휴무가 겹치는 날은 못 채워 위반이 남을 수 "
                           "있습니다(그런 날은 화면에서 직접 바꿔주셔야 합니다). "
                           "지정 가능자를 한두 명 더 두시면 여유가 생깁니다.")
        return {
            "need": need, "capacity": capacity, "people": len(people),
            "max_per_day": max_need_per_day, "per_day": round(per_day, 2),
            "ok": not message,
            "message": message,
        }

    def apply_carryover(self):
        for s in self.staff:
            co = self.sch.carryover[s.id]
            base = self.month_start(s.id)
            # H5-1: 야간블록 후 이월 OFF
            for k in range(base, min(base + co.night_block_remaining_off, self.sch.num_days)):
                if self.sch.get(s.id, k) is None:
                    self.sch.set(s.id, k, Shift.OFF, lock=True)
                elif self.sch.get(s.id, k) not in REST_SHIFTS:
                    self.sch.log(f"[H5-1 충돌] {s.id} {k+1}일: 이월 OFF 자리에 "
                                 f"{self.sch.get(s.id, k)} 고정 배정 존재")
            # H5-2: 월말 단독(또는 미완) 야간블록 연결
            t = co.trailing_night_count
            if t <= 0:
                continue
            night = Shift.NK if s.is_nk else Shift.N
            target_len = 3 if s.is_nk else 2
            extend = max(0, min(target_len - t, 3 - t))
            d = base
            for _ in range(extend):
                if d < self.sch.num_days:
                    cur = self.sch.get(s.id, d)
                    if cur is None or cur in NIGHT_SHIFTS:
                        self.sch.set(s.id, d, night, lock=True)
                    else:
                        self.sch.log(f"[H5-2 충돌] {s.id} {d+1}일: 야간 연결 자리에 "
                                     f"{cur} 고정 배정 존재")
                    d += 1
            # 블록 종료 후 필수 OFF 2일 (H2-5)
            if t + extend >= 2 or extend > 0:
                for k in range(2):
                    if d + k < self.sch.num_days and \
                            self.sch.get(s.id, d + k) is None:
                        self.sch.set(s.id, d + k, Shift.OFF, lock=True)
            if extend:
                self.sch.log(f"[H5-2] {s.id}: 전월 야간 {t}일 → 이번달 {extend}일 연장 연결")

    # ------------------------------------------------------------ Step 2
    def _partjang_rest_requests(self) -> Dict[Tuple[str, int], Shift]:
        """파트장이 입력①에 적어 낸 휴가·휴무 신청 — (직원, 날짜) → 근무코드.

        파트장 행은 아래에서 평일 8A로 통째로 채워지는데, 그게 신청 반영(Step 4)보다
        먼저다. 그래서 파트장이 연차를 적어 내면 Step 4에서 "고정 배정과 충돌(8A)"로
        반려됐다 — 파트장도 연차·병가를 쓰는데 그걸 근무표에 넣을 길이 없었다는 뜻이다.
        여기서 미리 읽어 그 날만 신청한 값으로 채운다(Step 4는 칸이 이미 같은 값으로
        잠겨 있으면 '반영됨'으로 처리하므로 그대로 통과한다).

        휴가·교육 계열만 본다. 근무(D/E/N/NK/prn)는 파트장 자리가 아니라서 종전대로
        반려된다 — 최소인력·레벨 통계가 파트장을 빼고 세므로, 파트장에게 근무를 주면
        그날 사람이 하나 더 있는 것처럼 보이지만 어느 숫자에도 안 잡힌다.

        상근(8A/9A/10A)도 여기서는 건드리지 않는다. 평일은 어차피 아래에서 8A로 채우고,
        주말·공휴일 8A는 H1-2 위반이라 Step 4가 사유를 붙여 반려해야 한다 — 여기서 미리
        박아버리면 그 검사를 건너뛰게 된다."""
        import datetime as _dt
        allow = REST_SHIFTS | {Shift.EDU, Shift.TW}
        out: Dict[Tuple[str, int], Shift] = {}
        for req in self.requests:
            if req.type not in allow:
                continue
            s = self.sch.by_id.get(req.staff_id)
            if s is None or not s.is_partjang:
                continue
            try:
                dt = _dt.date.fromisoformat(req.date)
            except ValueError:
                continue  # 날짜 형식 오류는 Step 4가 사유를 붙여 반려한다
            if dt.year != self.year or dt.month != self.month:
                continue
            out[(s.id, dt.day - 1)] = req.type
        return out

    def assign_partjang(self):
        rest = self._partjang_rest_requests()
        for s in self.staff:
            if not s.is_partjang:
                continue
            for d, di in enumerate(self.days):
                if self.sch.get(s.id, d) is not None:
                    continue
                want = rest.get((s.id, d))
                # 자동으로 채우되 **잠그지 않는다**(파트장 요청). 예전엔 lock=True라
                # 엔진이 이 칸을 영영 못 건드렸는데, 주말 8A가 허용된 지금은 그 잠금이
                # "자동으로 넣은 기본값"을 "확정"처럼 굳혀버린다. 값 자체는 그대로
                # 넣으므로 파트장 행이 비지 않고 근무표 모양도 바뀌지 않는다.
                self.sch.set(s.id, d, want or
                             (Shift.A8 if di.auto_8a else Shift.OFF))

    # ------------------------------------------------------------ Step 3
    def assign_nk(self):
        nks = [s for s in self.staff if s.is_nk]
        for idx, s in enumerate(nks):
            done = self.sch.nights_in_month(s.id)  # Step1 연장분 포함
            remaining = self.nk_target - done
            # 시작 위치: 이월 OFF/연장블록 이후 + 전담자별 오프셋(서로 엇갈리게)
            d = 0
            while d < self.sch.num_days and self.sch.get(s.id, d) is not None:
                d += 1
            d += (idx * 3) % 5
            plan = _nk_block_plan(remaining, start_with_three=(idx % 2 == 0))
            pi = 0
            while remaining > 0 and d < self.sch.num_days:
                block = plan[pi] if pi < len(plan) else min(3, remaining)
                pi += 1
                block = min(block, remaining)
                placed = 0
                while placed < block and d < self.sch.num_days:
                    if self._cell_free(s.id, d):
                        self.sch.set(s.id, d, Shift.NK, lock=True)
                        placed += 1
                        d += 1
                    else:
                        d += 1
                        break
                remaining -= placed
                if placed >= 2:
                    rest = 2
                    # 남은 야간을 남은 일수에 고르게: 여유 있으면 3일 휴식(S10)
                    # (2일/3일 혼합 계획이므로 "3일 블록만" 가정한 division 추정 대신
                    #  실제 계획에 남은 블록 개수를 그대로 사용 — 과소추정 시 rest=3을
                    #  잘못 허용해 마지막 블록 배정할 날이 모자라는 문제 방지)
                    if pi < len(plan):
                        blocks_left = len(plan) - pi
                    else:
                        blocks_left = (remaining + 2) // 3
                    need_days = remaining + 2 * max(0, blocks_left - 1)
                    if remaining > 0 and (self.sch.num_days - d - rest - 1) > need_days:
                        rest = 3
                    for k in range(rest):
                        if d < self.sch.num_days and self._cell_free(s.id, d):
                            self.sch.set(s.id, d, Shift.OFF, lock=True)
                            d += 1
                        elif d < self.sch.num_days:
                            d += 1
            if remaining > 0:
                self.sch.log(f"[H2-2] NK {s.id}: 야간 {remaining}일 미충족 (달력 제약)")
            # 나머지는 전부 OFF (H2-2)
            for d2 in range(self.sch.num_days):
                if self.sch.get(s.id, d2) is None:
                    self.sch.set(s.id, d2, Shift.OFF, lock=True)

    # ------------------------------------------------------------ Step 4
    def _overlong_off_requests(self) -> set:
        """연속 15일 이상 휴무를 신청한 구간에서 **15일째부터**의 신청들(H4-3).

        검사기만 고치면 그런 달은 매번 빨간 위반이 남는다 — 엔진이 신청을 그대로
        받아주기 때문이다. 여기서 미리 잘라내고 반려 사유를 적어주면, 파트장은
        "왜 안 받아줬는지"를 업로드 결과에서 바로 본다.

        날짜 순으로 보면서 이어진 길이를 센다. 앞의 14일은 그대로 받고 그 뒤만
        반려하므로, 2주짜리 휴가는 통째로 날아가지 않고 14일까지 남는다."""
        import datetime as _dt
        by_person: Dict[str, Dict[int, Request]] = {}
        for req in self.requests:
            if req.type not in REST_SHIFTS:
                continue
            try:
                dt = _dt.date.fromisoformat(req.date)
            except (ValueError, TypeError):
                continue
            if dt.year != self.year or dt.month != self.month:
                continue
            by_person.setdefault(req.staff_id, {})[dt.day - 1] = req
        out = set()
        for days in by_person.values():
            run = 0
            for d in sorted(days):
                run = run + 1 if (d - 1) in days else 1
                if run > OFF_RUN_MAX:
                    out.add(id(days[d]))
        return out

    def apply_requests(self):
        self._accepted_rest_reqs: Dict[Tuple[str, int], Request] = {}
        per_person: Dict[str, int] = {}
        overlong_off = self._overlong_off_requests()
        # 같은 날 같은 근무유형 채택 수 (선착순 제한, §5)
        taken: Dict[Tuple[int, Shift], int] = {}
        for req in self.requests:
            req.accepted = False
            s = self.sch.by_id.get(req.staff_id)
            if s is None:
                req.reject_reason = "존재하지 않는 직원"
                continue
            try:
                import datetime as _dt
                dt = _dt.date.fromisoformat(req.date)
            except ValueError:
                req.reject_reason = "날짜 형식 오류"
                continue
            if dt.year != self.year or dt.month != self.month:
                req.reject_reason = "해당 월이 아님"
                continue
            d = dt.day - 1
            t = req.type
            if id(req) in overlong_off:
                req.reject_reason = (
                    f"연속 휴무가 {OFF_RUN_MAX}일을 넘습니다(H4-3) — 앞의 "
                    f"{OFF_RUN_MAX}일은 반영했습니다. 더 쉬셔야 하면 원티드표에서 "
                    "구간을 나눠 신청해주세요.")
                continue
            # 월 신청 상한은 근무형 신청(D/E/N/8A/NK/prn)만 카운트한다 — 휴무/연차는
            # 병가·경조사 등 사유가 다양해 인원수 제한 취지와 안 맞으므로 제외(§5).
            if t in WORK_SHIFTS:
                per_person[s.id] = per_person.get(s.id, 0) + 1
                if per_person[s.id] > self.params.max_requests_per_person:
                    req.reject_reason = f"월 신청 상한({self.params.max_requests_per_person}건) 초과"
                    continue
            if self.sch.is_locked(s.id, d):
                if self.sch.get(s.id, d) == t:
                    # 리더가 신청과 동일한 근무로 이미 고정 배정해둔 경우 — 반영된 것으로 처리.
                    # _accepted_rest_reqs에는 넣지 않는다: 그 목록은 나중에 H1-1 미달 시
                    # _repair_via_revoke_request()가 회수할 수 있는 "일반 신청"용이고,
                    # 리더가 직접 고정한 칸은 그 어떤 경우에도 되돌려선 안 되기 때문.
                    if t in REST_SHIFTS:
                        self.sch.requested_off.add((s.id, d))
                    else:
                        taken[(d, t)] = taken.get((d, t), 0) + 1
                    self.sch.wanted.add((s.id, d))
                    req.accepted = True
                else:
                    req.reject_reason = (f"고정 배정과 충돌({self.sch.get(s.id, d)}) "
                                         "— 하드 제약/리더 수정 우선")
                continue
            if t in REST_SHIFTS:
                if not self._off_capacity_ok(d):
                    req.reject_reason = "해당일 최소인력 부족으로 휴무 불가(H1-1)"
                    continue
            elif t == Shift.EDU:
                pass  # 교육(T)은 근무일수엔 포함되지만 최소인력 대상이 아니므로 인원 제한 없음
            else:
                if t in NIGHT_SHIFTS and s.no_night:
                    req.reject_reason = "임부/야간불가 야간금지(H2-7)"
                    continue
                if not s.can(t) and not (t == Shift.A8 and s.is_leader
                                         and self.params.leader_8a_as_prn):
                    req.reject_reason = f"허용 근무유형 아님(H1-3): {t}"
                    continue
                # 예전엔 여기서 "8A는 평일만(H1-2)"으로 반려했다. 주말·공휴일 8A가
                # 허용되면서 반려 사유가 사라졌다 — 규칙은 풀었는데 신청 창구만 막혀
                # 있으면 "되는데 안 받아주는" 상태가 된다.
                cap_key = "prn" if t in (Shift.PRN, Shift.A8) else t.value
                cap = self.min_for(d, "N" if t in NIGHT_SHIFTS else cap_key)
                if t in (Shift.PRN, Shift.A8):
                    cap += self.params.prn_cap_extra
                if taken.get((d, t), 0) >= cap:
                    req.reject_reason = "동일 일자·근무 신청 몰림 — 선착순 마감(§5)"
                    continue
                if t in NIGHT_SHIFTS:
                    # 단독야간 방지(H2-4): 앞뒤 어느 쪽으로든 블록 연장이 가능해야 수용
                    fwd = (d + 1 >= self.sch.num_days
                           or self._is_rest_or_free(s.id, d + 1)
                           or self.sch.get(s.id, d + 1) in NIGHT_SHIFTS)
                    bwd = (d > 0 and (self._cell_free(s.id, d - 1)
                                      or self.sch.get(s.id, d - 1) in NIGHT_SHIFTS))
                    if not (fwd or bwd):
                        req.reject_reason = "야간 블록 구성 불가(H2-4)"
                        continue
            # 채택
            self.sch.set(s.id, d, t, lock=True)
            self.sch.wanted.add((s.id, d))
            if t == Shift.A8 and s.is_leader:
                self.sch.mark_leader_8a(s.id, d)
            if t in REST_SHIFTS:
                self.sch.requested_off.add((s.id, d))
                self._accepted_rest_reqs[(s.id, d)] = req
            else:
                taken[(d, t)] = taken.get((d, t), 0) + 1
            req.accepted = True
            # ⚠ 예전에는 '휴'가 들어오면 그 달 나머지 날짜를 전부 '휴'로 채워 배정에서
            # 뺐다(휴직으로 해석). 지금은 채우지 않는다 — 파트장이 지정한 그 날만
            # 제외한다. 병원 OCS에서 '휴'는 하루짜리 단기부모휴가이고, 진짜 휴직은
            # 사·상·산전·육법·육연·R로 따로 있다. 하루 휴가를 휴직으로 읽으면 그 사람이
            # 한 달 내내 근무표에서 사라지는데, 오류도 안 나서 알아채기 어려웠다.
            # 여러 날 쉬는 경우는 파트장이 그 날들을 각각 표시한다.

    def _off_capacity_ok(self, d: int) -> bool:
        """d일에 휴무 1명 추가해도 최소인력 채울 수 있는지 (근사)."""
        generals = [s for s in self.staff if not (s.is_partjang or s.is_nk)]
        resting = sum(1 for s in generals
                      if self.sch.get(s.id, d) in REST_SHIFTS)
        nk_on = sum(1 for s in self.staff if s.is_nk
                    and self.sch.get(s.id, d) in NIGHT_SHIFTS)
        need = (self.min_for(d, "D") + self.min_for(d, "E")
                + self.min_for(d, "prn") + max(0, self.min_for(d, "N") - nk_on))
        return len(generals) - resting - 1 >= need

    # ------------------------------------------------------------ Step 5
    def assign_nights(self):
        """일반 간호사: 2일 블록만 배정하며, 개인별 월 목표(4일 또는 6일, H6-4) 내로
        제한한다. 목표를 지키면 못 채우는 경우(H1-1 최소인력 보존이 최우선) 목표를
        넘겨서라도 2일 블록으로 배정하고 위반을 기록한다."""
        nd = self.sch.num_days
        for d in range(nd):
            need = self.min_for(d, "N") - self.sch.count_shift(d, Shift.N)
            while need > 0:
                placed = False
                if d + 1 >= nd:
                    # 월말 단독야간 예외(H2-4) — 목표 개념 없이 1일 블록만
                    for relax in (0, 1, 2, 3):
                        cand = self._pick_night_candidate(d, relax, (1,))
                        if cand is not None:
                            sid, length = cand
                            self._place_night_block(sid, d, length, relax)
                            placed = True
                            break
                else:
                    for relax in (0, 1, 2, 3):
                        cand = self._pick_night_candidate(
                            d, relax, self._night_block_lengths)
                        if cand is not None:
                            sid, length = cand
                            self._place_night_block(sid, d, length, relax)
                            placed = True
                            break
                    if not placed:
                        # 월 목표를 지키면 못 채움 — 최소인력(H1-1) 보존이 우선이므로
                        # 목표를 넘겨서라도 배정하고 위반으로 남긴다. 후보 블록 길이도
                        # self._night_block_lengths와 동일하게 둬서(목표가 홀수인 경우
                        # 3일 블록도 시도), 이 초과배정이 애매한 홀수 합으로 남지 않고
                        # 되도록 유효한 목표값 중 하나에 가깝게 떨어지도록 한다.
                        for relax in (0, 1, 2, 3):
                            cand = self._pick_night_candidate(
                                d, relax, self._night_block_lengths,
                                allow_over_target=True)
                            if cand is not None:
                                sid, length = cand
                                self._place_night_block(sid, d, length, relax)
                                self.sch.log(
                                    f"[H6-4] {sid}: {d+1}일 야간 — 월 목표 초과 배정 "
                                    "(블록 목표 소진, 최소인력(H1-1) 우선)")
                                placed = True
                                break
                if not placed:
                    self.sch.log(f"[H1-1] {d+1}일 야간 최소인력 미달 — 배정 가능 인원 없음")
                    break
                need -= 1

    def _pick_night_candidate(self, d: int, relax: int, lengths: Tuple[int, ...],
                              allow_over_target: bool = False) -> Optional[Tuple[str, int]]:
        # H1-5(하드): 그날 야간(N/NK) 배정 인원 중 레벨4+ 1명 이상.
        cur_levels = [s.level for s in self.staff
                     if not s.is_partjang and self.sch.grid[s.id][d] in NIGHT_SHIFTS]
        need_senior4 = not any(lv >= 4 for lv in cur_levels)
        level_stats = self._shift_level_stats("N")
        # S11: 신입(Lv1)끼리 같은 밤에 몰리지 않게. 블록이 걸치는 날마다 이미 Lv1이
        # 야간에 있는지 여기서 한 번만 세어둔다 — 후보마다 다시 세면 핫패스(초당
        # 수만 번)가 느려진다. 야간전담(NK)은 야간이 상시 업무라 이 판정에서 뺀다.
        max_len = max(lengths) if lengths else 1
        lv1_ids = [x.id for x in self.staff
                   if x.level == 1 and not (x.is_partjang or x.is_nk)]
        lv1_nights = {i: {k for k in range(self.sch.num_days)
                          if self.sch.grid[i][k] in NIGHT_SHIFTS}
                      for i in lv1_ids}
        lv1_on_night = []      # 그 날 이미 야간인 Lv1 수
        lv1_who = []           # 그 날 이미 야간인 Lv1 이름들
        for k in range(max_len):
            day = d + k
            if day >= self.sch.num_days:
                lv1_on_night.append(0)
                lv1_who.append(())
                continue
            who = tuple(i for i in lv1_ids if day in lv1_nights[i])
            lv1_who.append(who)
            lv1_on_night.append(len(who))
        best = None
        best_score = None
        for length in lengths:
            for s in self.staff:
                if s.is_partjang or s.is_nk or s.no_night:
                    continue
                if Shift.N not in s.allowed_shifts:
                    continue
                # H2-3(하드): 이 사람에게 허용된 블록 길이를 넘으면 후보가 아니다.
                # 3N을 적은 사람만 3일이 열린다.
                if length > max(self._gen_max_block, s.night_block_pref):
                    continue
                if not self._can_night_block(s, d, length, relax, allow_over_target):
                    continue
                # S8: 배정 시 뒤따르는 강제 OFF가 '신청 OFF'를 잡아먹으면 감점
                s8_pen = 0
                for k in range(length, length + 2):
                    if (s.id, d + k) in self.sch.requested_off:
                        s8_pen = 1
                # 휴식 잠금이 만들 인력 압박(look-ahead): 압박 없는 배정 우선
                squeeze = self._squeeze_after_block(s, d, length)
                last = self.sch.last_night_day(s.id, d)
                gap = d - last if last is not None else 99
                # 병동 전체 레벨 평균에 가까워지는 배정을 무작위 tiebreak 값에
                # 약하게 얹어 확률적으로만 선호 — H1-5(레벨4+ 1명 보장)나 야간
                # 배정 균형을 깨지 않는 선에서, 그리고 결정론적으로 두면 매번
                # 같은 사람이 뽑혀 형평성이 깨지는 부작용 없이(_LEVEL_NUDGE_WEIGHT
                # 참고) 근무별 레벨 구성이 한쪽으로 쏠리지 않도록 돕는다.
                level_gap = self._level_gap_given(level_stats, s.level, weight=length)
                # S11: 이 사람이 Lv1인데 블록의 어느 날에 이미 Lv1이 야간이면 그 날 수만큼
                # 감점. 인력 실현가능성(squeeze)·신청 OFF 보호(s8_pen) 다음, 야간 형평성
                # 앞에 둔다 — 뒤로 밀면 형평성이 늘 이겨서 규칙이 거의 작동하지 않는다.
                # 대신 하드 제약이 아니라 점수라, 다른 후보가 없으면 그냥 배정된다.
                # 이미 있는 Lv1 '수'를 그대로 더한다(있다/없다가 아니라) — 2명째보다
                # 3명째를 훨씬 무겁게 막기 위해서다. 이 병동처럼 Lv1의 야간 총량이
                # 밤 수를 넘으면(8명×6회=48칸 > 31밤) 2명인 밤은 산술적으로 못 피하는데,
                # 그때 몰아서 3~4명을 만드는 것이 제일 나쁘기 때문이다.
                lv1_pen = (sum(lv1_on_night[k] for k in range(length))
                           if s.level == 1 else 0)
                # 2명인 밤을 못 피한다면, 최소한 '같은 두 사람'이 반복되지는 않게 한다.
                # 짝지어질 상대와 이미 몇 밤을 함께 섰는지를 더해, 처음 만나는 짝을
                # 먼저 고른다. lv1_pen 다음에 둬서 "2명이냐 3명이냐"가 먼저고,
                # 같은 인원수라면 덜 만난 조합을 고르는 순서가 된다.
                if s.level == 1 and lv1_pen:
                    mine = lv1_nights.get(s.id, frozenset())
                    pair_pen = sum(len(mine & lv1_nights[j])
                                   for k in range(length) for j in lv1_who[k]
                                   if j != s.id)
                else:
                    pair_pen = 0
                # S12: 그 사람이 적은 선호 길이(2N/3N)와 다르면 감점. 하드가 아니라
                # 점수라, 다른 방법이 없으면 선호와 다른 길이로도 배정된다 —
                # 그때는 check_soft가 S12로 남겨 파트장이 볼 수 있게 한다.
                pref_pen = 0 if length == s.night_block_pref else 1
                # H1-6: 블록이 걸치는 날 중 지정이 모자란 날 수 — 지정 가능자가
                # 그 밤들을 채우면 그만큼 부족이 줄어든다. 주간과 달리 블록이라
                # 여러 날을 한꺼번에 메울 수 있으므로 '몇 날을 메우나'로 센다.
                desig = -(sum(1 for k in range(length)
                              if d + k < self.sch.num_days
                              and self.designated_short(d + k) > 0)
                          if s.is_designated else 0)
                score = (squeeze, s8_pen, desig, pref_pen, lv1_pen, pair_pen,
                         self.sch.nights_in_month(s.id),
                         -min(gap, 12), self.sch.workdays_in_month(s.id),
                         self.sch.carryover[s.id].recent_night_score,
                         0 if (need_senior4 and s.level >= 4) else 1,
                         self.rng.random() + level_gap * _LEVEL_NUDGE_WEIGHT)
                if best_score is None or score < best_score:
                    best_score = score
                    best = (s.id, length)
        return best

    def _squeeze_after_block(self, s: Staff, d: int, length: int) -> int:
        """블록·휴식 기간의 각 날에 대해, 남은 가용 인원이 남은 최소인력 수요보다
        부족해질 날 수를 센다 (야간 배정의 주간 인력 look-ahead)."""
        sch = self.sch
        squeeze = 0
        for dd in range(d, min(d + length + 2, sch.num_days)):
            in_block = dd < d + length
            need = 0
            for key, sh in (("D", Shift.D), ("E", Shift.E), ("prn", Shift.PRN)):
                need += max(0, self.min_for(dd, key) - sch.count_shift(dd, sh))
            n_have = sch.count_shift(dd, Shift.N) + (1 if in_block else 0)
            need += max(0, self.min_for(dd, "N") - n_have)
            avail = 0
            for t in self.staff:
                if t.is_partjang or t.is_nk or t.id == s.id:
                    continue
                v = sch.get(t.id, dd)
                if v is None or (v == Shift.OFF and not sch.is_locked(t.id, dd)):
                    avail += 1
            if avail < need:
                squeeze += 1
        return squeeze

    def _can_night_block(self, s: Staff, d: int, length: int, relax: int,
                         allow_over_target: bool = False) -> bool:
        sch = self.sch
        nd = sch.num_days
        # 월 경계를 넘는 블록은 불가 — _cell_free/sch.get()은 범위 밖 날짜를 None
        # (미배정)으로 취급해 "비어있음"으로 보이므로 여기서 따로 막아야 한다.
        # (2일 블록은 항상 d+1<nd일 때만 시도되어 원래 안전했지만, 3일 블록이
        # 추가되며 d+2가 월을 넘는 경우가 생겨 이 검사가 필요해졌다.)
        if d + length > nd:
            return False
        for i in range(length):
            if not self._cell_free(s.id, d + i):
                return False
        # 블록 뒤 2일 휴식 확보 가능해야 함 (H2-5): 이미 근무로 잠겨 있으면 불가
        for k in range(length, length + 2):
            if d + k < nd and not self._is_rest_or_free(s.id, d + k):
                return False
        # 월 야간 목표 (H6-4: 기본 4일 또는 6일만) — H1-1 보존을 위해 부득이할 때만 초과 허용
        if not allow_over_target:
            target = sch.night_target.get(s.id, self.params.max_nights)
            remaining = target - sch.nights_in_month(s.id) - length
            if remaining < 0:
                return False
            # 목표가 홀수라 3일 블록도 섞이는 경우, 나머지가 1일이면 그 뒤로는
            # 2/3일 블록으로 못 채우는 고립된 1일이 남는다 — 그런 배정은 애초에
            # 금지해 자연스럽게 3일 블록 쪽으로 유도한다. length==1(월말 단독야간
            # 예외, H2-4)은 애초에 이번 달 안에서 못 채우는 걸 전제한 상태라 대상 아님.
            if length >= 2 and remaining == 1:
                return False
        # 월 야간 상한 (H2-6 안전망, relax>=2부터 상향 H2-9)
        extra = max(0, relax - 1)
        if sch.nights_in_month(s.id) + length > self.params.max_nights + extra:
            return False
        # 연속근무 (H3-1)
        base = self.month_start(s.id)
        before = sch.work_run_ending(s.id, d - 1) if d > base else \
            (sch.carryover[s.id].consecutive_work_days
             if sch.carryover[s.id].last_shift_type in WORK_SHIFTS else 0)
        if before + length > self.params.max_consecutive_work:
            return False
        # 월말 단독야간은 익월에 최소 1일 연장(H5-2)되므로 그만큼 여유 필요 (H3-1)
        if length == 1 and d == nd - 1 and before + 2 > self.params.max_consecutive_work:
            return False
        # 직전이 야간이면 안 됨(블록은 통째로만 배정), 야간 후 휴식 2일 (H2-5/H2-8)
        last = sch.last_night_day(s.id, d)
        if last is None:
            co = sch.carryover[s.id]
            if co.trailing_night_count > 0 or co.night_block_remaining_off > 0:
                # 월초(전입자는 입사일) 이월 휴식 중 → 간격을 그 기준으로 계산
                gap = d - base + 1
                if gap < 3:
                    return False
                if relax < 1 and gap < 7:
                    return False
        else:
            gap = d - last
            if gap < 3:  # 최소 2일 휴식 + 1
                return False
            if relax < 1 and gap < 7:  # S1 하한 (H2-9 1순위 완화)
                return False
        return True

    def _place_night_block(self, sid: str, d: int, length: int, relax: int):
        sch = self.sch
        for i in range(length):
            sch.set(sid, d + i, Shift.N, lock=True)
        for k in range(length, length + 2):
            if d + k < sch.num_days and self.sch.get(sid, d + k) is None:
                sch.set(sid, d + k, Shift.OFF, lock=True)
        if relax >= 2:
            cap = self.params.max_nights + max(0, relax - 1)
            prev = sch.relaxed_night_cap.get(sid, self.params.max_nights)
            if cap > prev:
                sch.relaxed_night_cap[sid] = cap
                sch.log(f"[H2-9] {sid}: 월 야간상한 {cap}일로 완화")
        elif relax == 1:
            sch.log(f"[H2-9] {sid}: {d+1}일 야간 — S1(간격 7일) 완화 적용")
        if length == 1:
            sch.log(f"[H5-2] {sid}: 월말 단독야간({d+1}일) → 익월 연결 필요")

    # ------------------------------------------------------------ Step 6
    def fill_day_shifts(self):
        for d in range(self.sch.num_days):
            for key, shift in (("D", Shift.D), ("E", Shift.E), ("prn", Shift.PRN)):
                need = self.min_for(d, key) - self.sch.count_shift(d, shift)
                while need > 0:
                    cand = self._pick_day_candidate(d, shift)
                    if cand is None:
                        self.sch.log(f"[H1-1] {d+1}일 {key} 최소인력 미달 — 후보 없음")
                        break
                    self.sch.set(cand.id, d, shift)
                    need -= 1

    def _pick_day_candidate(self, d: int, shift: Shift,
                            protect_lower: Optional[int] = None) -> Optional[Staff]:
        # S6: 아직 고랩(상대 기준선) 없으면 우선 확보
        sch = self.sch
        min_lv = self._senior_min_level(shift)
        is_prn = shift == Shift.PRN
        cur_levels = []
        for s in self.staff:
            if s.is_partjang:
                continue
            v = sch.grid[s.id][d]
            if v == shift or (is_prn and v in PRN_LIKE_SHIFTS):
                cur_levels.append(s.level)
        need_lv3 = not any(lv >= min_lv for lv in cur_levels)
        # H1-5(하드): D/E/N 배정 인원 중 레벨4+ 1명 이상 — S6(상대기준)과 별개인
        # 절대기준. prn은 대상 아니라 shift==PRN이면 항상 False.
        need_senior4 = shift != Shift.PRN and not any(lv >= 4 for lv in cur_levels)
        weekend = self.days[d].day_type != DAY_WEEKDAY
        need_desig = self.designated_short(d) > 0
        level_key = _SENIOR_SHIFT_KEY.get(shift)
        level_stats = self._shift_level_stats(level_key) if level_key else None
        best, best_score = None, None
        can_assign_day = self.can_assign_day
        effective = sch.effective
        workdays_in_month = sch.workdays_in_month
        offs_in_month = sch.offs_in_month
        weekend_workdays_in_month = sch.weekend_workdays_in_month
        rand = self.rng.random
        for s in self.staff:
            if not can_assign_day(s, d, shift):
                continue
            sid = s.id
            odo = 1 if (effective(sid, d - 1) in REST_SHIFTS
                        and effective(sid, d + 1) in REST_SHIFTS) else 0
            wk_load = weekend_workdays_in_month(sid) if weekend else 0
            # H4-1 보호: 배정 시 OFF 하한이 깨질 사람은 후순위 (H4-1 > S6)
            lower_break = 0
            if protect_lower is not None and \
                    offs_in_month(sid) - 1 < protect_lower:
                lower_break = 1
            # H1-5는 최소인력(H1-1) 확보·기존 형평성 균형을 깨면서까지 강제하지
            # 않도록(그러면 특정 요일에 후보가 아예 고갈될 수 있음) 최하위
            # 우선순위(무작위 직전)로 둔다 — 그래도 동점일 때는 항상 이긴다.
            # 근무유형별 평균 숙련도가 병동 전체 평균에 가까워지는 후보를 무작위
            # tiebreak 값에 약하게 얹어 확률적으로만 선호 — 결정론적으로 두면
            # 매번 같은 후보가 뽑혀 형평성이 오히려 깨진다(_LEVEL_NUDGE_WEIGHT 참고).
            level_gap = (self._level_gap_given(level_stats, s.level)
                        if level_stats else 0.0)
            # 그날 조의 평균도 같이 본다(위 level_gap은 **월 누적** 평균이다).
            #
            # 예전엔 그날 조(cur_levels)를 '고랩이 한 명이라도 있나'라는 불리언으로만
            # 썼다. 그래서 Lv4+가 한 명 차는 순간 레벨은 아무 힘이 없어지고, 남은
            # 자리는 형평성과 난수로만 채워졌다 — 어느 날 고연차 5명이 몰려도 막는
            # 것이 없고, 그만큼 다른 날이 빈다. 실제 근무표에서 D조 평균 레벨이
            # 같은 달 안에서 2.00~4.14로 출렁였다(15일 3,3,4,4,5,5,5 vs 2일 1,1,2,2,2,2,3,3,3).
            #
            # 월 누적 평균은 이미 병동 평균에 가까워서 이걸 못 잡는다 — 평균이 맞아도
            # 날짜별로 몰렸다 비었다 할 수 있기 때문이다. 그래서 '오늘 이 조'를 따로 본다.
            day_gap = self._day_level_gap(cur_levels, s.level)
            # H1-6: 그날 지정 인원이 모자라면 지정 가능자를 먼저 뽑는다. 어차피 누군가는
            # 서야 할 자리이므로 인력을 더 쓰지 않는다 — 같은 자리를 누구로 채우느냐의
            # 문제다. H4-1(OFF 하한) 보호 다음, 고랩 확보(S6) 앞에 둔다: 지정은 하드고
            # S6은 소프트다.
            desig = 0 if (need_desig and s.is_designated) else 1
            score = (lower_break, desig,
                     0 if (need_lv3 and s.level >= min_lv) else 1,
                     odo, wk_load,
                     workdays_in_month(sid),
                     -offs_in_month(sid),
                     0 if (need_senior4 and s.level >= 4) else 1,
                     rand() + level_gap * _LEVEL_NUDGE_WEIGHT
                          + day_gap * _DAY_LEVEL_NUDGE_WEIGHT)
            if best_score is None or score < best_score:
                best_score, best = score, s
        return best

    # ------------------------------------------------------------ 지정 인원(H1-6)
    def designated_short(self, d: int) -> int:
        """그날 지정 인원이 몇 명 모자란지 (0이면 충족 또는 지정을 안 쓰는 병동).

        배정 중에 후보 점수로 쓴다 — 아직 모자란 날에는 '지정' 가능자를 먼저 뽑아,
        어차피 누군가는 서야 할 자리를 지정 가능자로 채운다. 하드로 막지 않고 점수로
        두는 이유는, 막아버리면 지정 가능자가 다 소진된 날에 그 근무 자체를 못 채워
        최소인력(H1-1)까지 무너지기 때문이다. H1-6은 검증 단계에서 잡힌다."""
        need = self.min_for(d, DESIGNATED_KEY)
        if not need:
            return 0
        return max(0, need - self.sch.designated_count(d))

    def repair_designated(self):
        """H1-6 미달 수리 — 그날 근무 중인 비지정자 한 명을 지정 가능자와 맞바꾼다.

        배정 중에는 점수로만 선호한다(designated_short). 그런데 그날 최소인력이 이미
        비지정자로 다 채워졌으면 지정 가능자를 넣을 자리가 없다 — 한 명 더 넣는 것은
        H1-4(상한)가 막으므로, 남는 방법은 **자리를 바꾸는 것**뿐이다.

        실제로 지정 가능자 2명 병동을 여섯 달 돌렸더니 달마다 3~6일이 0명으로 남았다.
        사전 검사(designated_feasibility)는 '가능'이라고 했다 — 총량은 충분했기
        때문이다. 하드 규칙인데 파트장이 화면에서 한 칸씩 고치는 수밖에 없었다.

        인원 수는 그대로다(같은 근무를 다른 사람이 선다). 그래서 H1-1·H1-4는 흔들리지
        않고, 빠지는 사람은 근무가 하나 줄어 OFF가 하나 느는 쪽이라 H4-1(월 최소 휴무)도
        나빠지지 않는다."""
        for d in range(self.sch.num_days):
            guard = 0
            while self.designated_short(d) > 0 and guard < 4:
                guard += 1
                if not self._swap_in_designated(d):
                    break

    def _swap_in_designated(self, d: int) -> bool:
        """그날 쉬는 지정 가능자 한 명을, 근무 중인 비지정자 한 명과 맞바꾼다."""
        sch = self.sch
        for a in self.staff:
            if a.is_partjang or a.is_nk or not a.is_designated:
                continue
            if sch.get(a.id, d) in COUNTED_WORK_SHIFTS:
                continue                     # 이미 근무 중이면 이미 세어졌다
            if sch.is_locked(a.id, d):
                continue                     # 원티드·리더 고정은 건드리지 않는다
            for b in self.staff:
                if b.is_partjang or b.is_nk or b.is_designated or b.id == a.id:
                    continue
                y = sch.get(b.id, d)
                if y not in DAY_WORK_SHIFTS or sch.is_locked(b.id, d):
                    continue
                keep_a = sch.get(a.id, d)
                sch.grid[b.id][d] = Shift.OFF
                if self.can_assign_day(a, d, y):
                    sch.grid[a.id][d] = y
                    sch.log(f"[수리] {d+1}일: {b.id} {y} → {a.id}(지정)로 교체 (H1-6)")
                    return True
                sch.grid[b.id][d] = y        # 원복
                sch.grid[a.id][d] = keep_a
        return False

    # ------------------------------------------------------------ 최소인력 수리
    def count_deficits(self) -> int:
        n = 0
        for d in range(self.sch.num_days):
            for key, shift in (("D", Shift.D), ("E", Shift.E),
                               ("N", Shift.N), ("prn", Shift.PRN)):
                n += max(0, self.min_for(d, key)
                         - self.sch.count_shift(d, shift))
        return n

    def repair_min_staff(self):
        """H1-1 미달 칸을 이웃일 재배치로 수리 (E→prn 금지 등으로 후보가 없던 경우)."""
        lower = max(8, holiday_count(self.days) - 1)
        for d in range(self.sch.num_days):
            for key, shift in (("D", Shift.D), ("E", Shift.E), ("prn", Shift.PRN)):
                while self.sch.count_shift(d, shift) < self.min_for(d, key):
                    cand = self._pick_day_candidate(d, shift, protect_lower=lower)
                    if cand is not None:
                        self.sch.set(cand.id, d, shift)
                        continue
                    if self._repair_via_neighbor_transfer(d, shift, lower):
                        continue
                    if self._repair_via_same_day_switch(d, shift, lower):
                        continue
                    if self._window_rebuild(d):
                        continue
                    if self._window_rebuild(d, tries=20, span=5):
                        continue
                    if not self._repair_via_revoke_request(d, shift):
                        break

    def _repair_via_neighbor_transfer(self, d: int, shift: Shift,
                                      lower: int) -> bool:
        """이웃날 근무(E→x 금지·연속 5일 초과의 원인)를 제3자에게 이관해
        당일 부족 근무(H1-1)를 배정할 수 있게 만든다."""
        sch = self.sch
        # 1차: 수령자 OFF 하한을 지키는 이관만, 2차: 하한 무시(H1-1 > H4-1)
        for strict in (True, False):
            for a in self.staff:
                if a.is_partjang or a.is_nk or not a.can(shift):
                    continue
                if sch.get(a.id, d) != Shift.OFF or sch.is_locked(a.id, d):
                    continue
                for w in (d - 1, d + 1):
                    if not (0 <= w < sch.num_days):
                        continue
                    v = sch.get(a.id, w)
                    if v not in DAY_WORK_SHIFTS or sch.is_locked(a.id, w):
                        continue
                    if self._removal_creates_eod(a.id, w):
                        continue
                    sch.grid[a.id][w] = Shift.OFF
                    if not self.can_assign_day(a, d, shift):
                        sch.grid[a.id][w] = v
                        continue
                    receivers = sorted(
                        (r for r in self.staff if r.id != a.id),
                        key=lambda r: -sch.offs_in_month(r.id))
                    for r in receivers:
                        if strict and sch.offs_in_month(r.id) - 1 < lower:
                            continue
                        if self.can_assign_day(r, w, v) and \
                                self._lv3_guard_ok(a, r, w, v):
                            sch.set(r.id, w, v)
                            sch.set(a.id, d, shift)
                            sch.log(f"[수리] {w+1}일 {v}: {a.id}→{r.id} 이관 후 "
                                    f"{a.id} {d+1}일 {shift} 배정 (H1-1)")
                            return True
                    sch.grid[a.id][w] = v
        return False

    def _window_rebuild(self, d0: int, tries: int = 10, span: int = 3) -> bool:
        """부족일 주변 ±span일의 잠기지 않은 주간근무를 헐고 무작위 순서로 재충원.

        전역 미달 수가 줄어들 때만 채택 (destroy-and-repair).
        대형 병동에서 비용 폭주를 막기 위해 실행당 호출 횟수를 제한한다.
        """
        self._rebuild_calls = getattr(self, "_rebuild_calls", 0) + 1
        if self._rebuild_calls > 40:
            return False
        sch = self.sch
        lo, hi = max(0, d0 - span), min(sch.num_days - 1, d0 + span)
        snapshot = {s.id: sch.grid[s.id][lo:hi + 1] for s in self.staff}
        base = self.count_deficits()
        for _ in range(tries):
            for s in self.staff:
                if s.is_partjang or s.is_nk:
                    continue
                for dd in range(lo, hi + 1):
                    if sch.grid[s.id][dd] in DAY_WORK_SHIFTS \
                            and not sch.is_locked(s.id, dd):
                        sch.grid[s.id][dd] = Shift.OFF
            for dd in range(lo, hi + 1):
                for key, sh in (("D", Shift.D), ("E", Shift.E),
                                ("prn", Shift.PRN)):
                    need = self.min_for(dd, key) - sch.count_shift(dd, sh)
                    while need > 0:
                        cand = self._pick_day_candidate(dd, sh)
                        if cand is None:
                            break
                        sch.set(cand.id, dd, sh)
                        need -= 1
            if self.count_deficits() < base:
                sch.log(f"[수리] {d0+1}일 주변({lo+1}~{hi+1}일) 재구성으로 "
                        f"미달 {base}→{self.count_deficits()}건 (H1-1)")
                return True
            for s in self.staff:
                sch.grid[s.id][lo:hi + 1] = list(snapshot[s.id])
        return False

    def _repair_via_revoke_request(self, d: int, shift: Shift) -> bool:
        """최후 수단: 원티드 OFF/연차를 반려(회수)하고 부족 근무를 배정.

        §3 우선순위 '하드(H1-1) > 원티드'에 따른 조치. 반려 사유를 기록한다.
        """
        sch = self.sch
        reqs = getattr(self, "_accepted_rest_reqs", {})
        for (sid, dd), req in sorted(reqs.items()):
            if dd != d:
                continue
            s = sch.by_id[sid]
            # 회수 시뮬레이션: 잠금 해제 후 배정 가능성 확인
            sch.locked.discard((sid, d))
            sch.requested_off.discard((sid, d))
            prev = sch.grid[sid][d]
            sch.grid[sid][d] = Shift.OFF
            lower = max(8, holiday_count(self.days) - 1)
            ok = False
            if self.can_assign_day(s, d, shift):
                sch.set(sid, d, shift)
                ok = True
            # 직접 배정이 막히면(연속근무 등) 이관·재구성까지 연쇄 시도
            elif self._repair_via_neighbor_transfer(d, shift, lower) or \
                    self._window_rebuild(d):
                ok = self.sch.count_shift(d, shift) >= self.min_for(
                    d, "prn" if shift == Shift.PRN else shift.value)
            if ok:
                req.accepted = False
                req.reject_reason = ("생성 중 최소인력(H1-1) 충족 불가 — "
                                     "하드 제약 우선(§3)으로 반려")
                del reqs[(sid, d)]
                sch.log(f"[수리] {d+1}일 {shift}: {sid}의 신청 {prev} 회수 "
                        f"(H1-1 > 원티드)")
                return True
            # 원복
            sch.grid[sid][d] = prev
            sch.locked.add((sid, d))
            sch.requested_off.add((sid, d))
        return False

    def _repair_via_same_day_switch(self, d: int, shift: Shift,
                                    lower: int) -> bool:
        """같은 날 다른 근무자(b)를 부족 근무로 돌리고, b가 비운 근무를
        제3자로 재충원한다. (예: E→prn 금지로 막힌 사람이 E는 설 수 있는 경우)"""
        sch = self.sch
        for b in self.staff:
            y = sch.get(b.id, d)
            if y not in DAY_WORK_SHIFTS or y == shift or sch.is_locked(b.id, d):
                continue
            sch.grid[b.id][d] = Shift.OFF
            if not self.can_assign_day(b, d, shift):
                sch.grid[b.id][d] = y
                continue
            sch.grid[b.id][d] = shift  # 가배정
            cand = self._pick_day_candidate(d, y, protect_lower=lower)
            if cand is not None:
                sch.set(cand.id, d, y)
                sch.log(f"[수리] {d+1}일: {b.id} {y}→{shift} 전환, "
                        f"{cand.id} {y} 충원 (H1-1)")
                return True
            if self._repair_via_neighbor_transfer(d, y, lower):
                sch.log(f"[수리] {d+1}일: {b.id} {y}→{shift} 전환 (H1-1)")
                return True
            sch.grid[b.id][d] = y  # 원복
        return False

    # ------------------------------------------------------------ 마무리(기본 OFF)
    def finalize_offs(self):
        for s in self.staff:
            for d in range(self.sch.num_days):
                if self.sch.get(s.id, d) is None:
                    self.sch.set(s.id, d, Shift.OFF)

    # ------------------------------------------------------------ Step 7 (G4)
    def fix_alternation(self) -> int:
        """S7 퐁당퐁당(ODO/OEO — 고립된 하루 근무) 완화. 한 번 고치면 다른 사람 자리가
        비어 새로 고칠 여지가 생길 수 있어, 호출부에서 변화 없을 때까지 반복 호출한다."""
        sch = self.sch
        nd = sch.num_days
        fixed = 0
        for s in self.staff:
            if s.is_partjang or s.is_nk:
                continue
            for d in range(nd):
                v = sch.get(s.id, d)
                if v not in DAY_WORK_SHIFTS:      # 야간·8A 제외 (가드⑤)
                    continue
                if sch.is_locked(s.id, d):        # 원티드 확정분 제외 (가드⑥)
                    continue
                if not (sch.effective(s.id, d - 1) in REST_SHIFTS
                        and sch.effective(s.id, d + 1) in REST_SHIFTS):
                    continue
                if self._try_transfer(s, d, v) or self._try_swap(s, d, v):
                    fixed += 1
        return fixed

    # ------------------------------------------------------------ Step 7b (H6-1)
    def _short_day_blocks(self) -> List[Tuple[Staff, int, int]]:
        """길이 1~2일짜리 D/E/prn 연속블록 목록 [(직원, start, end), ...].

        전월에서 이어지는 블록(정확한 시작을 모름)은 건드리지 않는다. 블록 바로
        다음날이 야간(N/NK)으로 이어지는 경우도 check_h6_day_block_length()와
        같은 이유로 건드리지 않는다 — 야간 시작 직전 준비 근무로 보고 예외로
        허용하는 블록이라, 억지로 늘리거나 다른 사람에게 넘기면 오히려 잘
        짜인 야간 전환 배치를 망가뜨릴 수 있다."""
        sch = self.sch
        nd = sch.num_days
        out: List[Tuple[Staff, int, int]] = []
        for s in self.staff:
            if s.is_partjang or s.is_nk:
                continue
            d = 0
            while d < nd:
                if sch.effective(s.id, d) not in DAY_WORK_SHIFTS:
                    d += 1
                    continue
                start = d
                while d + 1 < nd and sch.effective(s.id, d + 1) in DAY_WORK_SHIFTS:
                    d += 1
                end = d
                carried = (start == self.month_start(s.id)
                          and sch.carryover[s.id].last_shift_type in DAY_WORK_SHIFTS)
                length = end - start + 1
                next_is_night = end + 1 < nd and sch.effective(s.id, end + 1) in NIGHT_SHIFTS
                if length < 3 and not carried and not next_is_night:
                    out.append((s, start, end))
                d = end + 1
        return out

    def fix_short_day_blocks(self, max_passes: int = 5) -> int:
        """H6-1: 1~2일짜리 고립 주간근무 블록을 3일 이상으로 확장하거나(우선),
        확장이 불가하면 다른 사람에게 이관/맞교환한다(fix_alternation과 동일 기법).

        월경계 등에서 인접 블록이 이미 4일 꽉 차 확장·이관이 모두 막히는 경우가
        남을 수 있다 — 최종 리포트에 H6-1 잔여 위반으로 표시된다(§H1-1과 동일하게
        최선 노력 후 잔존을 허용하는 방식)."""
        sch = self.sch
        fixed_total = 0
        for _ in range(max_passes):
            blocks = self._short_day_blocks()
            if not blocks:
                break
            any_fixed = False
            for s, start, end in blocks:
                grown = False
                for dd, vv in ((end + 1, sch.get(s.id, end)),
                              (start - 1, sch.get(s.id, start))):
                    if not (0 <= dd < sch.num_days):
                        continue
                    if sch.is_locked(s.id, dd) or sch.get(s.id, dd) != Shift.OFF:
                        continue
                    # 최소인력은 상한이기도 하다 — 순수 추가(이관/맞교환과 달리
                    # 총원이 늘어남)라 확장 전에 그날 이미 목표 인원인지 확인.
                    key = "prn" if vv == Shift.PRN else vv.value
                    if sch.count_shift(dd, vv) >= self.min_for(dd, key):
                        continue
                    if self.can_assign_day(s, dd, vv):
                        sch.set(s.id, dd, vv)
                        sch.log(f"[H6-1] {s.id}: {dd+1}일 {vv} 추가 — "
                                f"단기블록({start+1}~{end+1}일) 확장")
                        grown = True
                        any_fixed = True
                        fixed_total += 1
                        break
                if grown:
                    continue
                for dd in range(start, end + 1):
                    if sch.is_locked(s.id, dd):
                        continue
                    vv = sch.get(s.id, dd)
                    if self._try_transfer(s, dd, vv) or self._try_swap(s, dd, vv):
                        any_fixed = True
                        fixed_total += 1
            if not any_fixed:
                break
        return fixed_total

    def _lv3_guard_ok(self, donor: Optional[Staff], receiver: Optional[Staff],
                      d: int, shift: Shift) -> bool:
        """가드③: 이동 후에도 해당 근무 고랩(상대 기준선) 유지. donor=None이면 순수 추가(제외 없음)."""
        levels = []
        for s in self.staff:
            if s.is_partjang or (donor is not None and s.id == donor.id):
                continue
            if self.sch.get(s.id, d) == shift:
                levels.append(s.level)
        if receiver is not None:
            levels.append(receiver.level)
        min_lv = self._senior_min_level(shift)
        return (not levels) or any(lv >= min_lv for lv in levels)

    def _try_transfer(self, donor: Staff, d: int, shift: Shift) -> bool:
        """G4-a: 퐁당퐁당 근무를 인접 근무자가 있는 다른 사람에게 이관."""
        sch = self.sch
        for r in self.staff:
            if r.id == donor.id or r.is_partjang or r.is_nk:
                continue
            if sch.get(r.id, d) != Shift.OFF or sch.is_locked(r.id, d):
                continue
            adjacent = (sch.effective(r.id, d - 1) in WORK_SHIFTS
                        or sch.effective(r.id, d + 1) in WORK_SHIFTS)
            if not adjacent:
                continue
            # 가드④: 근무일수 편차 악화 금지
            if sch.workdays_in_month(r.id) > sch.workdays_in_month(donor.id):
                continue
            # 가드: 수령자의 OFF 하한(H4-1) 붕괴·기증자의 OFF 상한(G6) 초과 금지
            hol = holiday_count(self.days)
            if sch.offs_in_month(r.id) - 1 < max(8, hol - 1):
                continue
            if sch.offs_in_month(donor.id) + 1 > hol + 2:
                continue
            if not self._lv3_guard_ok(donor, r, d, shift):
                continue
            # 수령자 배정 가능성 (가드①② 포함: can_assign_day가 검사)
            sch.grid[donor.id][d] = Shift.OFF  # 임시 제거 후 검사
            ok = self.can_assign_day(r, d, shift)
            if ok:
                sch.set(r.id, d, shift)
                sch.log(f"[G4-a] {d+1}일 {shift}: {donor.id} → {r.id} 이관")
                return True
            sch.grid[donor.id][d] = shift  # 원복
        return False

    def _try_swap(self, donor: Staff, d: int, shift: Shift) -> bool:
        """G4-b: 인접일 근무자와 맞교환 (donor d일 근무 ↔ partner 인접일 근무)."""
        sch = self.sch
        for nd_ in (d - 1, d + 1):
            if not (0 <= nd_ < sch.num_days):
                continue
            for p in self.staff:
                if p.id == donor.id or p.is_partjang or p.is_nk:
                    continue
                pv = sch.get(p.id, nd_)
                if pv not in DAY_WORK_SHIFTS or sch.is_locked(p.id, nd_):
                    continue
                if sch.get(p.id, d) != Shift.OFF or sch.is_locked(p.id, d):
                    continue
                if sch.get(donor.id, nd_) != Shift.OFF or sch.is_locked(donor.id, nd_):
                    continue
                if not self._lv3_guard_ok(donor, p, d, shift):
                    continue
                if not self._lv3_guard_ok(p, donor, nd_, pv):
                    continue
                # 시험 적용
                sch.grid[donor.id][d] = Shift.OFF
                sch.grid[p.id][nd_] = Shift.OFF
                ok = (self.can_assign_day(p, d, shift)
                      and self.can_assign_day(donor, nd_, pv))
                if ok:
                    sch.set(p.id, d, shift)
                    sch.set(donor.id, nd_, pv)
                    sch.log(f"[G4-b] {donor.id}({d+1}일 {shift}) ↔ {p.id}({nd_+1}일 {pv}) 맞교환")
                    return True
                sch.grid[donor.id][d] = shift
                sch.grid[p.id][nd_] = pv
        return False

    # ------------------------------------------------------------ Step 7 보완: 전역 탐색
    # fix_alternation(위)은 인접일(±1)만 보고, 그 자리에서 "새 문제를 안 만드는지"를
    # 로컬로만 판단한다 — 실측해보니 검색 폭을 넓히거나 로컬 부작용을 막는 시도 둘 다
    # 오히려 잔여를 늘렸다(문서화된 실험 참고). 대신 여기서는 완전히 별도 단계로,
    # "그 달 전체 아무 날짜"를 상대로 이관/맞교환을 시도하되, 채택 기준을 "이 칸 주변에
    # 새 문제가 생기는지"가 아니라 "전체 고립근무일 수가 늘지 않는지"로 바꾼다 — 국소
    # 판단의 오류(멀리 있는 부작용을 놓치거나, 나중에 사슬로 풀릴 기회를 막는 것) 없이
    # 정확한 전역 기준으로 판단한다. 최선노력이며, 호출 횟수 상한으로 대형 병동 성능을 보호한다.

    def _is_isolated_workday(self, sid: str, d: int) -> bool:
        sch = self.sch
        if not (0 <= d < sch.num_days):
            return False
        if sch.effective(sid, d) not in DAY_WORK_SHIFTS:
            return False
        return (sch.effective(sid, d - 1) in REST_SHIFTS
                and sch.effective(sid, d + 1) in REST_SHIFTS)

    def _is_isolated_2block(self, sid: str, d: int) -> bool:
        """d,d+1 이틀 연속 근무가 앞뒤로 휴무에 둘러싸여 고립된 "2일짜리 블록"인지.

        d+2가 근무이면(3일 이상 블록) 여기 안 걸린다 — 정확히 2일짜리만 잡는다.
        """
        sch = self.sch
        nd = sch.num_days
        if not (0 <= d and d + 1 < nd):
            return False
        if sch.effective(sid, d) not in DAY_WORK_SHIFTS:
            return False
        if sch.effective(sid, d + 1) not in DAY_WORK_SHIFTS:
            return False
        return (sch.effective(sid, d - 1) in REST_SHIFTS
                and sch.effective(sid, d + 2) in REST_SHIFTS)

    def _local_isolation_score(self, cells) -> int:
        """cells(=[(직원id, 날짜), ...]) 주변만 놓고 센 고립근무(1일+2일블록) 개수.

        이관/맞교환은 딱 이 칸들의 근무값만 바꾸므로, 다른 어떤 칸의 고립 여부도
        바뀔 수 없다(1일 고립 판정은 자기 자신과 바로 옆 칸, 2일블록 고립 판정은
        최대 ±2칸까지만 본다) — 그래서 각 칸을 ±2 여유를 두고 넓혀서 확인하면
        이 부분합의 전/후 비교가 전체 보드를 다시 세는 것과 수학적으로 완전히
        같은 결과를 주면서, 대형 병동에서도 빠르다(전체 O(인원×일수) 대신 O(1))."""
        expanded = set()
        for sid, dd in cells:
            for delta in (-2, -1, 0, 1, 2):
                expanded.add((sid, dd + delta))
        score = 0
        for sid, dd in expanded:
            if self._is_isolated_workday(sid, dd):
                score += 1
            if self._is_isolated_2block(sid, dd):
                score += 1
        return score

    def global_fix_alternation(self, max_passes: int = 3, call_budget: int = 4000) -> int:
        """S7 잔여를 추가로 줄이는 전역 마무리 탐색 — fix_alternation이 끝난 뒤 호출."""
        sch = self.sch
        calls = 0
        fixed_total = 0
        for _ in range(max_passes):
            isolated = [(s, d) for s in self.staff if not (s.is_partjang or s.is_nk)
                       for d in range(sch.num_days)
                       if not sch.is_locked(s.id, d) and self._is_isolated_workday(s.id, d)]
            if not isolated:
                break
            any_fixed = False
            for s, d in isolated:
                if calls > call_budget:
                    return fixed_total
                if not self._is_isolated_workday(s.id, d):
                    continue  # 이번 패스 중 이미 다른 조치로 해소됨
                v = sch.get(s.id, d)
                calls += 1
                if self._try_global_transfer(s, d, v) or self._try_global_swap(s, d, v):
                    fixed_total += 1
                    any_fixed = True
            if not any_fixed:
                break
        return fixed_total

    def _try_global_transfer(self, donor: Staff, d: int, shift: Shift) -> bool:
        sch = self.sch
        hol = holiday_count(self.days)
        for r in self.staff:
            if r.id == donor.id or r.is_partjang or r.is_nk:
                continue
            if sch.get(r.id, d) != Shift.OFF or sch.is_locked(r.id, d):
                continue
            if sch.workdays_in_month(r.id) > sch.workdays_in_month(donor.id):
                continue
            if sch.offs_in_month(r.id) - 1 < max(8, hol - 1):
                continue
            if sch.offs_in_month(donor.id) + 1 > hol + 2:
                continue
            if not self._lv3_guard_ok(donor, r, d, shift):
                continue
            cells = [(donor.id, d - 1), (donor.id, d), (donor.id, d + 1),
                    (r.id, d - 1), (r.id, d), (r.id, d + 1)]
            before = self._local_isolation_score(cells)
            sch.grid[donor.id][d] = Shift.OFF
            ok = self.can_assign_day(r, d, shift)
            if ok:
                sch.set(r.id, d, shift)
                if self._local_isolation_score(cells) <= before:
                    sch.log(f"[G4-a 전역] {d+1}일 {shift}: {donor.id} → {r.id} 이관")
                    return True
                sch.grid[r.id][d] = Shift.OFF
            sch.grid[donor.id][d] = shift
        return False

    def _try_global_swap(self, donor: Staff, d: int, shift: Shift) -> bool:
        sch = self.sch
        for nd_ in range(sch.num_days):
            if nd_ == d:
                continue
            for p in self.staff:
                if p.id == donor.id or p.is_partjang or p.is_nk:
                    continue
                pv = sch.get(p.id, nd_)
                if pv not in DAY_WORK_SHIFTS or sch.is_locked(p.id, nd_):
                    continue
                if sch.get(p.id, d) != Shift.OFF or sch.is_locked(p.id, d):
                    continue
                if sch.get(donor.id, nd_) != Shift.OFF or sch.is_locked(donor.id, nd_):
                    continue
                cells = [(donor.id, d - 1), (donor.id, d), (donor.id, d + 1),
                        (p.id, d - 1), (p.id, d), (p.id, d + 1),
                        (donor.id, nd_ - 1), (donor.id, nd_), (donor.id, nd_ + 1),
                        (p.id, nd_ - 1), (p.id, nd_), (p.id, nd_ + 1)]
                before = self._local_isolation_score(cells)
                # Lv3 가드는 O(인원수)라 비용이 크다 — 대형 병동에서 이 이중루프
                # (일수×인원)와 곱해지면 전체가 너무 느려지므로, 훨씬 싼 하드 제약
                # 검사(can_assign_day)를 먼저 통과한 후보에게만 적용해 호출 수를 줄인다.
                sch.grid[donor.id][d] = Shift.OFF
                sch.grid[p.id][nd_] = Shift.OFF
                ok = (self.can_assign_day(p, d, shift)
                      and self.can_assign_day(donor, nd_, pv))
                if ok and self._lv3_guard_ok(donor, p, d, shift) \
                        and self._lv3_guard_ok(p, donor, nd_, pv):
                    sch.set(p.id, d, shift)
                    sch.set(donor.id, nd_, pv)
                    if self._local_isolation_score(cells) <= before:
                        sch.log(f"[G4-b 전역] {donor.id}({d+1}일 {shift}) ↔ "
                                f"{p.id}({nd_+1}일 {pv}) 맞교환")
                        return True
                    sch.grid[p.id][d] = Shift.OFF
                    sch.grid[donor.id][nd_] = Shift.OFF
                sch.grid[donor.id][d] = shift
                sch.grid[p.id][nd_] = pv
        return False

    def global_fix_2blocks(self, max_passes: int = 3, call_budget: int = 4000) -> int:
        """2일짜리 고립 근무블록(O-근무-근무-O)을 인접 휴무일을 근무로 늘려
        3일 이상 블록으로 확장해 고립을 해소한다 — global_fix_alternation 뒤에 호출.
        한 명 고치면 다른 사람 자리(OFF)가 새로 열려 반복하면 더 줄어들 수 있어
        fix_alternation과 같은 방식으로 수렴할 때까지 반복한다."""
        sch = self.sch
        calls = 0
        fixed_total = 0
        for _ in range(max_passes):
            blocks = [(s, d) for s in self.staff if not (s.is_partjang or s.is_nk)
                     for d in range(sch.num_days - 1)
                     if not sch.is_locked(s.id, d) and not sch.is_locked(s.id, d + 1)
                     and self._is_isolated_2block(s.id, d)]
            if not blocks:
                break
            any_fixed = False
            for s, d in blocks:
                if calls > call_budget:
                    return fixed_total
                if not self._is_isolated_2block(s.id, d):
                    continue  # 이번 패스 중 이미 다른 조치로 해소됨
                calls += 1
                if self._try_extend_2block(s, d):
                    fixed_total += 1
                    any_fixed = True
            if not any_fixed:
                break
        return fixed_total

    def _try_extend_2block(self, donor: Staff, d: int) -> bool:
        """d-1(앞) 또는 d+2(뒤) 휴무일 하나를 같은 사람 근무로 바꿔 블록을 늘린다."""
        sch = self.sch
        hol = holiday_count(self.days)
        for ext_d, shift in ((d - 1, sch.get(donor.id, d)),
                            (d + 2, sch.get(donor.id, d + 1))):
            if not (0 <= ext_d < sch.num_days):
                continue
            if sch.get(donor.id, ext_d) != Shift.OFF or sch.is_locked(donor.id, ext_d):
                continue
            if sch.offs_in_month(donor.id) - 1 < max(8, hol - 1):
                continue  # H4-1: 확장하면 본인 OFF 하한이 깨짐
            # 가드는 반드시 칸을 바꾸기 전에(현재 그리드 기준으로) 검사해야 한다 —
            # can_assign_day의 첫 체크(_cell_free)가 "지금 OFF인가"를 보기 때문에,
            # 먼저 값을 바꿔버리면 항상 실패로 나온다.
            if not self.can_assign_day(donor, ext_d, shift):
                continue
            if not self._lv3_guard_ok(None, donor, ext_d, shift):
                continue
            cells = [(donor.id, ext_d)]
            before = self._local_isolation_score(cells)
            sch.grid[donor.id][ext_d] = shift
            if self._local_isolation_score(cells) <= before:
                sch.log(f"[2블록 확장] {donor.id} {ext_d+1}일 OFF→{shift} "
                        f"(고립 2일블록 {d+1}~{d+2}일 해소)")
                return True
            sch.grid[donor.id][ext_d] = Shift.OFF
        return False

    # ------------------------------------------------------------ Step 8 (G6)
    def equalize_off(self):
        sch = self.sch
        hol = holiday_count(self.days)
        upper = hol + 2
        lower = max(8, hol - 1)
        # 1) OFF 부족자(H4-1) 해소 + 균등화: 근무 이관 (S3/S4)
        self._balance_transfers(lower)
        # 2) 그래도 초과인 사람: 추가 근무 배정 (PRN 우선 → D/E, G8)
        for s in self.staff:
            if s.is_partjang or s.is_nk:
                continue
            guard = 0
            while sch.offs_in_month(s.id) > upper and guard < 31:
                guard += 1
                if not self._add_one_workday(s):
                    break
        # 3) 잔여 미달자: 초과 인력 날에서 근무 제거 (최후 수단)
        for s in self.staff:
            if s.is_partjang or s.is_nk:
                continue
            guard = 0
            while sch.offs_in_month(s.id) < lower and guard < 31:
                guard += 1
                if not self._remove_one_workday(s):
                    break

    def _balance_transfers(self, lower: int):
        """OFF가 적은(과로) 사람의 주간근무를 OFF가 많은 사람에게 이관.

        총 근무 슬롯 수는 유지되므로 H1-1에 영향 없음.
        """
        sch = self.sch
        generals = [s for s in self.staff if not (s.is_partjang or s.is_nk)]
        for _ in range(400):
            offs = {s.id: sch.offs_in_month(s.id) for s in generals}
            donors = sorted(generals, key=lambda s: offs[s.id])
            moved = False
            for donor in donors:
                # 하한 미달이거나 편차가 2 초과인 경우만 이관 시도
                max_off = max(offs.values())
                need_fix = offs[donor.id] < lower or \
                    (max_off - offs[donor.id]) > 2
                if not need_fix:
                    continue
                receivers = sorted(
                    [r for r in generals if offs[r.id] > offs[donor.id] + 1],
                    key=lambda r: -offs[r.id])
                if not receivers:
                    continue
                # H4-1(하드) 미달 해소가 S6(소프트) Lv3 유지보다 우선
                allow_lv3_break = offs[donor.id] < lower
                if self._transfer_one_workday(donor, receivers, allow_lv3_break):
                    moved = True
                    break
            if not moved:
                break

    def _transfer_one_workday(self, donor: Staff, receivers: List[Staff],
                              allow_lv3_break: bool = False) -> bool:
        sch = self.sch
        # 주말 근무를 우선 이관 (S5: 주말 OFF 공평분배 개선)
        day_order = sorted(range(sch.num_days),
                           key=lambda d: self.days[d].day_type == DAY_WEEKDAY)
        for d in day_order:
            v = sch.get(donor.id, d)
            if v not in DAY_WORK_SHIFTS or sch.is_locked(donor.id, d):
                continue
            if self._removal_creates_eod(donor.id, d):
                continue
            for r in receivers:
                if sch.get(r.id, d) != Shift.OFF or sch.is_locked(r.id, d):
                    continue
                if not allow_lv3_break and not self._lv3_guard_ok(donor, r, d, v):
                    continue
                sch.grid[donor.id][d] = Shift.OFF
                if self.can_assign_day(r, d, v):
                    sch.set(r.id, d, v)
                    sch.log(f"[G6] {d+1}일 {v}: {donor.id} → {r.id} 이관(잔휴 균등화)")
                    return True
                sch.grid[donor.id][d] = v
        return False

    def _add_one_workday(self, s: Staff) -> bool:
        sch = self.sch
        # OFF 많은 날 중 배정 가능한 날 탐색 (퐁당퐁당 안 만드는 날 우선)
        # ⚠ 최소인력은 상한이기도 하다 — 그날 그 근무유형이 이미 최소인력만큼
        # 차 있으면(=목표 인원 도달) 더 채우지 않고 다른 날/근무를 찾는다.
        candidates = []
        for d in range(sch.num_days):
            if sch.get(s.id, d) != Shift.OFF or sch.is_locked(s.id, d):
                continue
            for shift in (Shift.PRN, Shift.D, Shift.E):
                key = "prn" if shift == Shift.PRN else shift.value
                if sch.count_shift(d, shift) >= self.min_for(d, key):
                    continue
                if not self.can_assign_day(s, d, shift):
                    continue
                odo = 1 if (sch.effective(s.id, d - 1) in REST_SHIFTS
                            and sch.effective(s.id, d + 1) in REST_SHIFTS) else 0
                pref = 0 if shift == Shift.PRN else 1  # G8: PRN 우선
                over = sch.count_shift(d, shift) - self.min_for(
                    d, "prn" if shift == Shift.PRN else shift.value)
                candidates.append((odo, pref, over, d, shift))
        if not candidates:
            return False
        candidates.sort()
        _, _, _, d, shift = candidates[0]
        sch.set(s.id, d, shift)
        sch.log(f"[G6] {s.id}: OFF 초과 → {d+1}일 {shift} 추가 배정")
        return True

    def _remove_one_workday(self, s: Staff) -> bool:
        sch = self.sch
        for d in range(sch.num_days):
            v = sch.get(s.id, d)
            if v not in DAY_WORK_SHIFTS or sch.is_locked(s.id, d):
                continue
            key = "prn" if v == Shift.PRN else v.value
            if sch.count_shift(d, v) - 1 < self.min_for(d, key):
                continue  # 최소인력 붕괴 금지 (H1-1)
            if not self._lv3_guard_ok(s, None, d, v):
                continue
            if self._removal_creates_eod(s.id, d):
                continue
            sch.grid[s.id][d] = Shift.OFF
            sch.log(f"[G6] {s.id}: OFF 부족 → {d+1}일 {v} 제거")
            return True
        return False

    def _removal_creates_eod(self, sid: str, d: int) -> bool:
        """이 칸을 비우면(OFF) E-O-D(EOD, H6-3) 패턴이 새로 생기는지."""
        sch = self.sch
        return (sch.effective(sid, d - 1) == Shift.E
                and sch.effective(sid, d + 1) == Shift.D)

    # ------------------------------------------------------------ Step 10c (S11)
    def _lv1_night_counts(self) -> List[int]:
        """날짜별 '야간을 서는 Lv1 일반 간호사' 수 (야간전담·파트장 제외)."""
        sch = self.sch
        lv1 = [s.id for s in self.staff
               if s.level == 1 and not (s.is_partjang or s.is_nk)]
        return [sum(1 for sid in lv1 if sch.grid[sid][d] in NIGHT_SHIFTS)
                for d in range(sch.num_days)]

    @staticmethod
    def _lv1_cluster_cost(counts: List[int]) -> int:
        """뭉침 비용 — 한 밤에 Lv1이 n명이면 (n-1)을 더한다.

        3명인 밤(비용 2)이 2명인 밤 둘(비용 1+1)보다 나쁘지 않게 같은 값이 되므로,
        아래 교환은 '총합이 같으면 최대치가 낮은 쪽'을 함께 본다."""
        return sum(max(0, c - 1) for c in counts)

    def reduce_lv1_night_clusters(self, max_swaps: int = 40) -> int:
        """S11 후처리 — Lv1이 3명 이상 몰린 밤을, Lv1의 야간블록을 통째로 비-Lv1에게
        넘겨서 푼다.

        이 병동처럼 Lv1의 야간 총량(8명×6회=48칸)이 밤 수(31)를 넘으면 2명인 밤은
        산술적으로 못 없앤다 — 없앨 수 있는 것은 '몰린 정도'뿐이라, 최대 인원이
        낮아지는 교환만 채택한다. 배정 단계(_pick_night_candidate)의 점수만으로는
        그 순간 후보가 Lv1뿐이면 그대로 뽑히므로 여기서 한 번 더 훑는다.

        하드 위반이 하나라도 늘면 되돌린다 — 뭉침을 줄이자고 안전 규칙을 깨지 않는다.
        """
        from .constraints import all_hard_checks

        sch = self.sch
        nd = sch.num_days
        base_hard = len(all_hard_checks(sch, self.days, self.params))
        swaps = 0
        for _ in range(max_swaps):
            counts = self._lv1_night_counts()
            worst = max(counts) if counts else 0
            if worst < 3:
                break
            day = counts.index(worst)
            moved = False
            for s in self.staff:
                if s.level != 1 or s.is_partjang or s.is_nk:
                    continue
                if sch.grid[s.id][day] not in NIGHT_SHIFTS:
                    continue
                # 그 사람의 야간블록 전체를 찾는다(연속된 N 구간)
                a = day
                while a > 0 and sch.grid[s.id][a - 1] in NIGHT_SHIFTS:
                    a -= 1
                b = day
                while b + 1 < nd and sch.grid[s.id][b + 1] in NIGHT_SHIFTS:
                    b += 1
                if any(sch.is_locked(s.id, k) for k in range(a, b + 1)):
                    continue
                for r in self.staff:
                    if r.level == 1 or r.is_partjang or r.is_nk or r.no_night:
                        continue
                    if Shift.N not in r.allowed_shifts:
                        continue
                    if any(sch.grid[r.id][k] is not Shift.OFF or sch.is_locked(r.id, k)
                           for k in range(a, b + 1)):
                        continue
                    before = [sch.grid[s.id][k] for k in range(a, b + 1)]
                    for k in range(a, b + 1):
                        sch.set(s.id, k, Shift.OFF)
                        sch.set(r.id, k, Shift.N)
                    new_counts = self._lv1_night_counts()
                    ok = (max(new_counts) < worst
                          and self._lv1_cluster_cost(new_counts)
                          <= self._lv1_cluster_cost(counts)
                          and len(all_hard_checks(sch, self.days, self.params)) <= base_hard)
                    if ok:
                        sch.log(f"[S11] {a+1}~{b+1}일 야간: {s.id}(Lv1) → {r.id}(Lv{r.level}) "
                                f"— {day+1}일 Lv1 {worst}명 몰림 해소")
                        swaps += 1
                        moved = True
                        break
                    for i, k in enumerate(range(a, b + 1)):
                        sch.set(r.id, k, Shift.OFF)
                        sch.set(s.id, k, before[i])
                if moved:
                    break
            if not moved:
                break
        return swaps

    # ------------------------------------------------------------ Step 5b (H7-1)
    def assign_sleep_offs(self) -> int:
        """야간을 많이 선 사람(H7-1 기준 이상)에게 수면오프(S/) 1개를 준다.

        **S/는 오프를 대체하는 것이 아니라 하루를 더 주는 것이다.** 이 사람의 월 OFF
        개수는 S/가 없는 사람과 똑같고, S/ 하루가 근무일에서 나온다.

        실제 병동 근무표(B관7, 2026년 8개월)로 확인한 근거: 이 병원의 잔휴는
        `전월잔휴 + 휴일수 − OFF개수`로 떨어지는데, S/를 가진 58명(6월 제외 49명)
        전원이 **S/를 OFF로 세지 않은** 이 식과 정확히 맞았다. S/가 오프를 대체한
        것이라면 그 사람만 OFF가 하나 적어 잔휴가 하루씩 어긋났어야 한다.

        놓는 자리는 **마지막 야간블록 바로 다음날** — 실제 근무표가 예외 없이
        `N N S/ /` 꼴이다. 그 자리는 야간 뒤 의무휴식(H2-5)으로 이미 OFF가 잠겨
        있으므로 그것을 S/로 덮는다. 그러면 OFF가 하나 줄지만, 이 함수가
        equalize_off(Step 8)보다 **먼저** 돌기 때문에 거기서 OFF 하한까지 다시
        채워진다 — 그 과정에서 근무 하루가 빠지고, 그것이 곧 '더 주는 하루'다.

        순서가 중요하다. 예전엔 이 함수가 맨 마지막이라 이미 확정된 오프를 S/로
        바꿀 수밖에 없었고, 그러면 **OFF가 하나 줄어든 채로 끝나** 잔휴가 하루
        늘어났다 — 병원 정산과 반대 방향이다. fill_day_shifts(Step 6) 앞으로
        옮겨야 그날이 애초에 근무로 채워지지 않고, 그 자리를 다른 사람이 메워
        최소인력(H1-1)도 깨지지 않는다.
        """
        from .constraints import SLEEP_OFF_NIGHT_THRESHOLD

        sch = self.sch
        nd = sch.num_days
        placed = 0
        for s in self.staff:
            if s.is_partjang or s.is_nk:
                continue
            if sch.nights_in_month(s.id) < SLEEP_OFF_NIGHT_THRESHOLD:
                continue
            if any(v is Shift.SLEEP_OFF for v in sch.grid[s.id]):
                continue  # 원티드로 이미 신청한 사람
            last_night = max((d for d in range(nd)
                              if sch.grid[s.id][d] in NIGHT_SHIFTS), default=-1)
            if last_night < 0:
                continue
            # **아직 아무것도 안 정해진 칸에만 놓는다.** 야간 뒤 의무휴식(H2-5)으로
            # 잠긴 OFF를 덮으면 그 사람의 OFF가 하나 줄어드는데, equalize_off는 OFF를
            # 정확한 목표가 아니라 [하한, 상한] 범위로만 맞추므로 하한에 여유가 있는
            # 사람은 줄어든 채로 끝난다(실측: OFF −0.55일). 그러면 S/가 '더 주는 하루'가
            # 아니라 '오프를 절반쯤 빼앗은 하루'가 된다. 빈 칸에만 놓으면 OFF 개수는
            # 손대지 않고 근무 하루만 줄어 — 병원 잔휴 정산과 같아진다.
            #
            # 야간블록과 그 휴식 바로 다음날부터 찾는다. 실제 근무표에서 S/가 야간
            # 근처에 붙어 있는 모양을 최대한 따르되, 자리 자체는 규칙이 아니다
            # (파트장이 그 달 안에서 쓰는 값).
            order = list(range(last_night + 1, nd)) + list(range(0, last_night + 1))
            for d in order:
                if sch.grid[s.id][d] is not None:
                    continue
                if (s.id, d) in sch.wanted:
                    continue
                sch.set(s.id, d, Shift.SLEEP_OFF, lock=True)
                sch.log(f"[H7-1] {s.id}: {d+1}일 수면오프(S/) "
                        f"(야간 {sch.nights_in_month(s.id)}회 — 오프와 별도로 하루 추가)")
                placed += 1
                break
        return placed

    # ------------------------------------------------------------ Step 9 (G7)
    def split_long_offs(self):
        """H4-2: 원치 않는 연속 오프(REST_SHIFTS) 5일 이상(4일까지는 허용)을
        분할한다. 본인이 신청/승인받은 구간(전부 wanted)은 원하는 장기휴가라
        건드리지 않는다."""
        sch = self.sch
        nd = sch.num_days
        for s in self.staff:
            if s.is_partjang or s.is_nk:
                continue
            d = 0
            while d < nd:
                if sch.get(s.id, d) not in REST_SHIFTS:
                    d += 1
                    continue
                start = d
                while d < nd and sch.get(s.id, d) in REST_SHIFTS:
                    d += 1
                end = d - 1
                if end - start + 1 >= 5:
                    wanted_all = all((s.id, dd) in sch.wanted for dd in range(start, end + 1))
                    if not wanted_all:
                        self._break_off_run(s, start, end)

    def _break_off_run(self, s: Staff, start: int, end: int) -> bool:
        """연속 OFF 중간일로 다른 날 근무 1개를 이동 (총 OFF 개수 유지)."""
        sch = self.sch
        mid = (start + end) // 2
        targets = sorted(range(start + 1, end),
                         key=lambda x: abs(x - mid))
        for m in targets:
            if sch.get(s.id, m) != Shift.OFF or sch.is_locked(s.id, m):
                continue
            for w in range(sch.num_days):
                if w == m:
                    continue
                v = sch.get(s.id, w)
                if v not in DAY_WORK_SHIFTS or sch.is_locked(s.id, w):
                    continue
                key = "prn" if v == Shift.PRN else v.value
                if sch.count_shift(w, v) - 1 < self.min_for(w, key):
                    continue
                if not self._lv3_guard_ok(s, None, w, v):
                    continue
                if self._removal_creates_eod(s.id, w):
                    continue
                # 이동할 날(m)이 이미 그 근무유형 최소인력만큼 차 있으면(=상한
                # 도달) 옮기지 않는다 — 최소인력은 상한이기도 하다.
                if sch.count_shift(m, v) >= self.min_for(m, key):
                    continue
                sch.grid[s.id][w] = Shift.OFF
                if self.can_assign_day(s, m, v):
                    sch.set(s.id, m, v)
                    sch.log(f"[G7] {s.id}: 장기 OFF 분할 — {w+1}일 {v}를 {m+1}일로 이동")
                    return True
                sch.grid[s.id][w] = v
        sch.log(f"[G7] {s.id}: {start+1}~{end+1}일 연속 OFF 분할 실패")
        return False

    # ------------------------------------------------------------ carryover 출력
    def build_next_carryover(self) -> Dict[str, dict]:
        out = {}
        nd = self.sch.num_days
        for s in self.staff:
            grid = self.sch.grid[s.id]
            last = grid[nd - 1] or Shift.OFF
            run = self.sch.work_run_ending(s.id, nd - 1) \
                if last in WORK_SHIFTS else 0
            trailing = 0
            d = nd - 1
            while d >= 0 and grid[d] in NIGHT_SHIFTS:
                trailing += 1
                d -= 1
            remaining_off = 0
            if trailing >= 2:
                remaining_off = 2
            elif trailing == 0:
                # 야간블록 종료 후 OFF가 1일만 확보된 채 월이 끝난 경우
                if nd >= 2 and grid[nd - 1] in REST_SHIFTS \
                        and grid[nd - 2] in NIGHT_SHIFTS:
                    blk = 1
                    dd = nd - 3
                    while dd >= 0 and grid[dd] in NIGHT_SHIFTS:
                        blk += 1
                        dd -= 1
                    if blk >= 2:
                        remaining_off = 1
            old_score = self.sch.carryover[s.id].recent_night_score
            this_month_nights = self.sch.nights_in_month(s.id)
            # 잔휴(정상 오프 누적잔액) = 전월 잔휴 + (이번달 휴일수 - 이번달 순수오프일수).
            # 순수오프는 문자 그대로 OFF(원티드="X"/일반="/")로 찍힌 칸만 세고, 연차/공가/
            # 조사/S//군 등 다른 휴가유형은 반영하지 않는다(실측 검증된 병원 공식).
            old_off_balance = self.sch.carryover[s.id].off_balance
            this_month_offs = self.sch.offs_in_month(s.id)
            out[s.id] = {
                "last_shift_type": str(last),
                "consecutive_work_days": run,
                "night_block_remaining_off": remaining_off,
                "night_block_in_progress": trailing == 1,
                "trailing_night_count": trailing,
                # 최근 몇 달 야간 누적을 감쇠 이동평균으로 근사(대략 최근 3개월 비중)
                # — 야간을 적게 받은 사람이 다음 몇 달간 우선권을 갖도록 함(S2 장기화).
                "recent_night_score": round(old_score * (2 / 3) + this_month_nights, 2),
                # 휴일수는 그 사람이 실제로 재직한 구간만 센다(월중 전입자는 입사일부터) —
                # 전 병동이 입사 전날까지 정산해 넘긴 잔휴에 한 달 치를 통째로 더하면
                # 그 사람만 휴가가 부풀려진다.
                "off_balance": round(old_off_balance + self.working_holiday_count(s.id)
                                     - this_month_offs, 2),
            }
        return out

    # ------------------------------------------------------------ 실행
    def run(self) -> MonthSchedule:
        self._rebuild_calls = 0
        self.compute_senior_thresholds()  # S6 근무유형별 상대 고랩 기준선
        self.compute_night_targets()  # H6-4 개인별 월 목표(4/6일) 산정
        self.validate_input()      # Step 0
        self.lock_pre_join_days()  # Step 0.4: 월중 전입자의 입사 전 날짜 제외
        self.apply_fixed()         # Step 0.5: 리더 수정분 고정 (재생성 모드)
        self.complete_partial_night_blocks()
        self.apply_carryover()     # Step 1
        self.assign_partjang()     # Step 2
        self.assign_nk()           # Step 3
        self.apply_requests()      # Step 4
        self.complete_partial_night_blocks()  # 신청된 단독 야간 블록 보완 (H2-4)
        self.assign_nights()       # Step 5
        # H7-1은 여기서 놓는다 — 야간이 확정돼 누가 대상인지 알 수 있고, 아직 주간을
        # 채우기 전이라 그 하루가 애초에 근무로 잡히지 않는다(그 자리는 다른 사람이
        # 메워 H1-1도 유지된다). 맨 끝에서 하면 이미 확정된 오프를 바꿀 수밖에 없어
        # OFF가 하나 줄고, 잔휴가 병원 정산과 반대로 하루 늘어난다.
        self.assign_sleep_offs()   # Step 5b
        self.fill_day_shifts()     # Step 6
        self.finalize_offs()
        self.repair_min_staff()    # H1-1 미달 수리
        for _ in range(5):         # Step 7 — 한 명 고치면 다른 사람 자리가 열려 반복하면 더 줄어듦
            if self.fix_alternation() == 0:
                break
        for _ in range(5):         # Step 7b — 1~2일 단기블록을 3~4일로 확장(H6-1)
            if self.fix_short_day_blocks() == 0:
                break
        self.equalize_off()        # Step 8
        self.split_long_offs()     # Step 9
        # 수리 ↔ 균등화 반복: 균등화가 만든 빈 자리를 수리가 활용 (Step 10 사전)
        for _ in range(4):
            self.equalize_off()
            self.repair_min_staff()
            if self.count_deficits() == 0:
                break
        self.equalize_off()        # 수리로 생긴 편중 재조정 (일별 인원수 보존)
        for _ in range(5):         # 최종 퐁당퐁당 완화 (G4 재실행, 수렴까지 반복)
            if self.fix_alternation() == 0:
                break
        for _ in range(5):         # 최종 단기블록 확장(H6-1) 재실행
            if self.fix_short_day_blocks() == 0:
                break
        self.global_fix_alternation()  # 인접일 검색으로 못 줄인 잔여를 전역 탐색으로 마무리
        self.global_fix_2blocks()      # 2일짜리 고립 블록도 확장해서 마무리
        self.global_fix_alternation()  # 2블록 확장 과정에서 새 1일 고립이 생겼을 수 있어 재정리
        self.reduce_lv1_night_clusters()  # S11 Lv1이 몰린 밤 풀기
        # 지정 인원 수리는 맨 끝이다 — 앞의 균등화·블록 정리가 지정 가능자의 근무를
        # 다시 OFF로 돌려놓을 수 있어서, 그보다 먼저 고치면 도로 무너진다.
        self.repair_designated()
        return self.sch


# 월경계 등에서 로컬 수리만으로는 구조적으로 0건을 보장하기 어려운 최선노력 하드
# 규칙 — 이 규칙들만 남으면 재시도를 멈춘다(계속 시도해도 거의 안 줄어들어 시간만 소모).
# H1-4(최소인력 상한): 생성 로직은 최대한 상한을 지키지만, 전월에서 이어지는
# 야간블록 완성(H5-2)처럼 그 자체가 하드 규칙인 강제 배정은 상한보다 우선이라
# 드물게 초과가 남을 수 있다.
# H1-5(레벨균등): 배정 시 레벨4+ 후보를 최우선으로 고르지만, 병동 자체에 레벨4+
# 인원이 적으면(한 사람이 하루에 D/E/N 중 한 곳에만 있을 수 있으므로) 매일 세
# 시간대를 동시에 못 채우는 구조적 한계가 있다.
# H7-1(수면오프): 오프를 S/로 바꾸는 것뿐이라 대개 그냥 되지만, 그 사람의 오프가
# 월 하한(H4-1)에 딱 걸쳐 있거나 남은 오프가 전부 확정칸·본인 신청분이면 넣을 자리가
# 없다. 재시도해도 같은 이유로 다시 막히므로 최선노력으로 둔다.
_BEST_EFFORT_RULES = {"H6-1", "H6-4", "H4-1", "H1-4", "H1-5", "H4-2", "H7-1"}


def generate_best(config: dict,
                  fixed_cells: Optional[Dict[Tuple[str, int], Shift]] = None,
                  attempts: int = 3,
                  time_budget: float = 30.0) -> Tuple["Generator", MonthSchedule]:
    """하드 위반이 남으면 탐색 순서를 바꿔 재시도하고 최선의 결과를 반환 (Step 10).

    _BEST_EFFORT_RULES를 제외한 하드 규칙이 전부 0건이면 그 시점에서 반환한다
    (아래 설명 참고).

    **멈추는 기준은 '시도 횟수'다. time_budget은 안전판일 뿐이다.**

    예전엔 반대였다(attempts=24, time_budget=10초). 그러면 "10초 동안 되는 만큼"이
    되는데, 시도 1회에 걸리는 시간은 기기 성능과 그때그때 CPU 부하에 좌우된다 —
    같은 입력인데 **빠른 PC에서는 3회를 돌아 위반 0이 나오고, 폰에서는 2회에서
    잘려 위반이 남았다.** 실제로 크로미움과 네이티브에서 같은 입력이 서로 다른
    근무표를 냈다(그리드 해시 불일치로 확인). 사용자 입장에선 "같은 걸 눌렀는데
    결과가 다른" 앱이 된다.

    횟수 기준으로 바꾸면 기기가 달라도 시도 횟수가 같으므로 **같은 입력은 항상
    같은 근무표**가 나온다. 느린 기기는 시간이 더 걸릴 뿐이다.

    ⚠ attempts=3인 이유 — 실측이다. 40·50·60·70명 로스터를 각각 3개월 연속으로
    이어 돌려(출력②를 다음 달 입력②로 넣어 실제 이월정보를 만든 12케이스):

        · 필수 위반 0 달성: 11/12건
        · 달성에 필요한 시도: 최소 1회 / 최대 3회 / 평균 1.3회 (11건 전부 3회 이내)
        · 나머지 1건은 12회를 돌려도, 60회를 돌려도 필수 위반 1건이 그대로였다
          (구조적으로 불가능한 입력 — 더 굴려도 답이 안 나온다)

    즉 **되는 것은 3회 안에 되고, 안 되는 것은 몇십 회를 해도 안 된다.** 4회 이상은
    "안 되는 입력을 붙들고 기다리는 시간"만 늘린다.

    ⚠ time_budget=30초는 상한이 아니라 **병리적 입력용 안전판**이다. 체크가 "시도와
    시도 사이"에서만 이뤄지므로, 시도 1회가 30초보다 오래 걸리면 그 시도가 끝날
    때까지는 못 끊는다. 실제 소요시간은 30초 이하가 아니라 "시도 1회 소요시간의
    배수"에 가깝다.

    ⚠ 안전판이 실제로 무는 경우가 있다 — 위 12케이스 중 70명·시도1회 11.3초짜리
    달은 3회에 35.9초(네이티브)가 걸려서, 브라우저(약 2배 느림)에서는 2회째에
    30초를 넘겨 잘린다. 그 달만은 기기에 따라 결과가 갈릴 수 있다. 이 값을 올리면
    (약 75초) 그 케이스도 일관되지만, 대신 폰에서 그만큼 기다리게 된다 — 의도적인
    맞바꿈이니 바꾸려면 위 실측을 다시 재보고 판단할 것.
    """
    import time as _time
    from .constraints import all_hard_checks
    t0 = _time.time()
    best = None  # (gen, sch, n_hard, n_strict)
    tried = 0
    timed_out = False
    for i in range(attempts):
        tried = i + 1
        gen = Generator(config, fixed_cells=fixed_cells, seed=i)
        sch = gen.run()
        violations = all_hard_checks(sch, gen.days, gen.params)
        n_hard = len(violations)
        n_strict = sum(1 for v in violations if v.rule not in _BEST_EFFORT_RULES)
        if n_hard == 0:
            if i:
                sch.log(f"[재시도] {i+1}번째 시도에서 하드 위반 0건 달성")
            return gen, sch
        if best is None or (n_strict, n_hard) < (best[3], best[2]):
            best = (gen, sch, n_hard, n_strict)
        if n_strict == 0:
            sch.log(f"[재시도] {i+1}번째 시도에서 필수 하드 위반 0건 — "
                    f"최선노력 규칙(H6-1/H6-4) 잔여 {n_hard}건만 남아 반환")
            return gen, sch
        if _time.time() - t0 > time_budget:
            timed_out = True
            break
    gen, sch, n_hard, n_strict = best
    sch.timed_out = timed_out
    sch.log(f"[재시도] {tried}회 시도 후에도 하드 위반 {n_hard}건 잔존"
            f"(그중 필수 위반 {n_strict}건) — 최선 결과 반환"
            + (f" (시간 예산 {time_budget:.0f}초 소진)" if timed_out else ""))
    return gen, sch


# ---------------------------------------------------------------- 인력 압박 사전 진단
#
# 왜 필요한가 — generate_best는 최대 3회 시도해 최선을 고르는데, 인원이 빠듯하면 시도
# 1회 자체가 길어진다(실측: 여유로운 40명 0.5초인데 빠듯한 36명은 13초). 그러면 3회를
# 다 돌아도 위반이 남고, 그 사이 사용자는 한참을 기다린다.
# 게다가 브라우저(Pyodide)는 네이티브보다 느리다 — 실측 2.0~2.3배다(크로미움 헤드리스에서
# 같은 입력으로 잰 값: 여유로운 40명 네이티브 0.53초/브라우저 1.2초, 빠듯한 36명 네이티브
# 12.8초/브라우저 25.7초). 즉 빠듯한 달은 데스크톱 브라우저에서도 26초가 걸리고, 폰은 CPU가
# 더 느려 여기서 몇 배가 더 붙는다. 그동안 화면은 "생성 중..." 한 줄뿐이라 사용자는 앱이
# 죽은 줄 알고 새로고침한다 — 그러면 처음부터 다시다.
#
# 그래서 생성을 시작하기 전에 "이 입력이 얼마나 빠듯한지"를 미리 재서 화면에 알려준다.
#
# ⚠ 여기서 '빠듯하다'고 판정돼도 시도 횟수를 더 주지는 않는다 — 더 굴려봐야 안 되기
# 때문이다. 실측(36명·압박률 0.96)에서 시도를 1→2회로 늘리면 필수위반이 5→4건으로 한 건
# 줄고, 4회·8회로 더 늘려도 4건 그대로였다. 압박률이 더 높은 쪽(18명·1.98)은 16회를
# 돌려도 67→67로 완전히 평평했다. 이 구간에 위반이 남는 건 운이 나빠서가 아니라 인원이
# 모자라서라, 주사위를 더 굴려도 답이 안 나온다. 그래서 '알려주되 더 기다리게 하지는
# 않는다'로 정했다. (반대로 인원이 넉넉한 달은 3회 안에 대부분 해결된다 — generate_best
# 주석의 12케이스 실측 참고.)
#
# 지표(압박률) = 이번 달 최소인력을 채우는 데 필요한 인원-일 / 실제로 쓸 수 있는 인원-일.
# 실측으로 보정했다(sample_input.xlsx 42명 기준, 인원만 줄여가며 측정):
#
#     압박률 0.86 →  0.5초, 필수위반  0건   ← 여유
#     압박률 0.96 → 13.0초, 필수위반  5건   ← 가장 느림('될 듯 말 듯'한 구간)
#     압박률 1.09 →  9.9초, 필수위반 28건
#     압박률 1.98 →  2.1초, 필수위반 67건   ← 가망이 없으면 오히려 빨리 포기한다
#
# 비용이 가장 큰 구간이 0.95~1.10이라는 게 중요하다. 이건 인원이 몇 명 빠진 병동 —
# 즉 현실에서 제일 흔한 상황이다. 반대로 압박률이 1을 크게 넘으면 수리 로직이 일찍
# 포기해서 오히려 빨리 끝난다.
PRESSURE_TIGHT = 0.90   # 이 이상이면 '빠듯' — 최소인력을 다 채우기 어렵고 생성이 느려진다
PRESSURE_SHORT = 1.00   # 이 이상이면 산술적으로 불가능 — 최소인력을 채울 방법이 없다


def staffing_pressure(config: dict) -> dict:
    """생성을 시작하기 전에 이 입력이 얼마나 빠듯한지 재본다.

    Generator를 만들기만 하고 run()은 하지 않는다(생성 자체는 하지 않으므로 가볍다).
    최소인력 조회는 반드시 Generator.min_for를 그대로 쓴다 — 요일별 최소인력 같은
    분기를 여기서 다시 구현하면 두 벌이 되고, 그게 이 프로젝트가 반복해서 밟은 함정이다.
    """
    return Generator(config).staffing_pressure()


def _pressure_level(ratio: float) -> str:
    if ratio >= PRESSURE_SHORT:
        return "short"
    if ratio >= PRESSURE_TIGHT:
        return "tight"
    return "ok"


def _pressure_message(level: str, demand: int, supply: int) -> str:
    """생성 전에 화면에 띄울 안내 문구.

    **문구를 여기(엔진)에 두는 이유**: 화면이 두 벌(webapp/static/app.js와
    pyodide-app/app.js)이라 양쪽에 따로 적으면 언젠가 한쪽만 고쳐져 같은 상황에서
    다른 안내가 나간다. 이 프로젝트가 반복해서 밟은 함정이라 출처를 하나로 둔다.

    '1~2분'은 지어낸 값이 아니라 실측이다(36명·압박률 0.96에서 네이티브 12초,
    브라우저/폰은 몇 배 느리다). 다만 기기 편차가 크므로 단정하지 않고 범위로 적는다.
    """
    if level == "ok":
        return ""
    slow = "생성도 평소보다 오래 걸립니다(기기에 따라 10~40초)."
    if level == "short":
        return (f"인원이 부족합니다 — 이번 달 최소인력을 다 채우려면 {demand}인원-일이 "
                f"필요한데 쓸 수 있는 건 {supply}인원-일뿐입니다. 산술적으로 다 채울 수 "
                f"없어 위반이 반드시 남습니다 — 인원을 늘리거나 근무인력 기준을 낮춰야 "
                f"완전히 해소됩니다. {slow}")
    # 빠듯(tight): 숫자만 보면 공급이 수요보다 크다. 그런데도 위반이 남는 이유를 같이
    # 적지 않으면 "707 필요한데 735 있다면서 왜 빠듯하냐"는 모순으로 읽힌다 — 여유분을
    # 그대로 쓸 수 없게 만드는 건 야간 블록(2~3일 + 뒤 OFF 2일)과 연속근무 상한이다.
    margin = supply - demand
    pct = round(margin / supply * 100) if supply else 0
    return (f"인원이 빠듯합니다 — 이번 달 최소인력을 채우는 데 {demand}인원-일이 필요하고 "
            f"쓸 수 있는 건 {supply}인원-일이라, 여유가 {margin}인원-일({pct}%)뿐입니다. "
            f"야간은 2~3일씩 묶어 서고 그 뒤 이틀을 쉬어야 하는 등 배치 제약이 있어서 "
            f"이 정도 여유로는 최소인력을 다 채우지 못한 위반이 남을 수 있습니다. {slow}")


# ---------------------------------------------------------------- 지난달 그리드 → 이월값 역산
def carryover_from_grid(grid: Dict[str, List[str]], num_days: int,
                        lenient: bool = False) -> Dict[str, dict]:
    """지난달 확정 근무표(그리드, 문자열 근무코드)만으로 이번 달 전월이월값을 역산.

    Generator.build_next_carryover()와 동일한 계산이나, 그 달의 전월이월 정보 없이
    그리드 자체의 말일 상태만으로 계산한다(월 전체가 근무로 채워진 극단적인 경우
    연속근무일수가 실제보다 짧게 나올 수 있음 — 흔치 않은 근사).

    lenient=True면 빈 칸이나 모르는 코드를 예외 대신 OFF(근무 안 한 날)로 본다 —
    연간근무표는 파트장이 손으로 행을 더하거나 고칠 수 있는 파일이라, 칸 하나 때문에
    서버 오류로 떨어지면 안 된다(업로드 단계에서 이미 모르는 표기를 걸러 알려준다).
    업로드된 병원 OCS 파일처럼 코드가 이미 검증된 경로는 기본값(엄격)을 그대로 쓴다.
    """
    def _to_shift(v) -> Shift:
        if not lenient:
            return parse_shift(v)
        s = "" if v is None else str(v).strip()
        if not s:
            return Shift.OFF
        try:
            return parse_shift(s)
        except ValueError:
            return Shift.OFF

    out: Dict[str, dict] = {}
    for sid, raw_row in grid.items():
        row = [_to_shift(v) for v in raw_row]
        nd = num_days
        last = row[nd - 1] if nd else Shift.OFF
        run = 0
        d = nd - 1
        while d >= 0 and row[d] in WORK_SHIFTS:
            run += 1
            d -= 1
        trailing = 0
        d = nd - 1
        while d >= 0 and row[d] in NIGHT_SHIFTS:
            trailing += 1
            d -= 1
        remaining_off = 0
        if trailing >= 2:
            remaining_off = 2
        elif trailing == 0:
            if nd >= 2 and row[nd - 1] in REST_SHIFTS and row[nd - 2] in NIGHT_SHIFTS:
                blk = 1
                dd = nd - 3
                while dd >= 0 and row[dd] in NIGHT_SHIFTS:
                    blk += 1
                    dd -= 1
                if blk >= 2:
                    remaining_off = 1
        this_month_nights = sum(1 for v in row if v in NIGHT_SHIFTS)
        out[sid] = {
            "last_shift_type": str(last),
            "consecutive_work_days": run,
            "night_block_remaining_off": remaining_off,
            "night_block_in_progress": trailing == 1,
            "trailing_night_count": trailing,
            # 그리드 한 장만으로는 그 이전 달의 recent_night_score를 알 수 없으므로
            # 이번 달 실적만으로 새로 시작한다(그래도 0으로 두는 것보다는 근사가 낫다).
            "recent_night_score": float(this_month_nights),
        }
    return out


# ---------------------------------------------------------------- 전입·전출 대조
def _is_night_peer(s: dict) -> bool:
    """야간 형평성 비교군인지 — 파트장·야간전담·야간불가는 목표 산정 대상이 아니라 제외."""
    if str(s.get("role", "")).strip() == "파트장":
        return False
    flags = list(s.get("flags") or [])
    if "night_only" in flags or "pregnant" in flags or "no_night" in flags:
        return False
    return "N" in [str(x).strip() for x in (s.get("allowed_shifts") or [])]


def reconcile_roster(staff: List[dict], prev_stats: Dict[str, dict],
                     transferred: Optional[set] = None) -> dict:
    """이번 달 명단(입력①)과 지난달 실적(입력②)을 대조해 전입·전출을 가려낸다.

    입력①은 '미래'(이번 달 근무표를 만들 명단), 입력②는 '과거'(지난달까지의 실적)다.
    따라서 명단의 기준은 항상 입력①이고, 둘의 차집합이 곧 인사이동이다.
      · 전입(incoming) = 입력①에만 있음 — 이월정보가 없는 사람
      · 전출(outgoing) = 입력②에만 있음 — 이번 달부터 배정 대상이 아닌 사람

    newcomer_night_score: 전입자에게 줄 recent_night_score 초기값. 0으로 두면
    "야간을 한 번도 안 선 사람"으로 취급돼 첫 달부터 야간 상한을 받아버리므로
    (compute_night_targets가 이 점수 오름차순으로 상한을 준다), 계속 근무 중인
    야간 비교군의 중앙값을 대신 쓴다 — 전 병동 이력을 모르는 상태에서 한쪽으로
    치우치지 않는 가장 중립적인 추정값이다.
    """
    prev_names = set(prev_stats or {})
    cur_names = [str(s.get("id", "")).strip() for s in staff]
    incoming = [n for n in cur_names if n and n not in prev_names]
    outgoing = sorted(prev_names - set(cur_names))

    # 비교군은 '계속 근무해온 사람'이어야 한다 — 이번 달 전입자는 (연간근무표에 행이
    # 있어 prev_names에 들어가더라도) 우리 병동 실적이 없으므로 중앙값을 끌어내린다.
    moved_in = set(transferred or ())
    peer_scores = []
    for s in staff:
        sid = str(s.get("id", "")).strip()
        # 조회도 '다듬은 이름'으로 해야 한다 — 판정만 strip하고 조회는 원문으로 하면,
        # 이름 앞뒤에 공백이 섞인 사람이 조용히 0점으로 잡혀 중앙값을 끌어내린다.
        if sid in prev_names and sid not in moved_in and _is_night_peer(s):
            peer_scores.append(
                float((prev_stats.get(sid) or {}).get("recent_night_score", 0.0)))
    peer_scores.sort()
    if peer_scores:
        mid = len(peer_scores) // 2
        median = (peer_scores[mid] if len(peer_scores) % 2
                  else (peer_scores[mid - 1] + peer_scores[mid]) / 2)
    else:
        median = 0.0
    return {"incoming": incoming, "outgoing": outgoing,
            "newcomer_night_score": round(median, 2)}


def night_score_from_grid_history(annual_dates: List[str], codes: List[str],
                                  year: int, month: int,
                                  before: Optional[str] = None) -> Optional[float]:
    """붙여넣은 근무기록(1~3개월치)에서 recent_night_score를 실제 공식대로 접어 계산한다.

    전입자가 전 병동 기록을 가져온 경우에 쓴다. build_next_carryover()가 매달 쓰는
    감쇠 이동평균과 같은 식(`이전점수 * 2/3 + 그 달 야간수`)을 기록이 있는 달마다
    순서대로 적용하므로, 계속 근무해온 사람과 같은 척도의 값이 나온다 — 1개월치면
    거친 근사, 3개월치면 사실상 수렴한 값이다.

    before('YYYY-MM-DD')를 주면 그 날짜 '전날까지'만 센다 — 월중 전입자는 입사일이
    경계이므로 이번 달 입사 전 구간(예: 2/1~2/14)도 실적에 포함해야 한다. 안 주면
    이번 달(year, month) 1일이 경계다(월초 전입·계속 근무자).

    부분 달(입사 전까지만 있는 달)도 한 달로 쳐서 접는다 — 감쇠 공식이 달 단위라
    그보다 잘게 나눌 수 없다. 형평성 참고값이므로 과소평가보다 이 편이 안전하다.
    """
    if not annual_dates or not codes:
        return None
    boundary = before or f"{year:04d}-{month:02d}-01"
    by_month: Dict[str, int] = {}
    has_record = False                   # 칸에 실제로 뭔가 적혀 있었는가
    for i, ds in enumerate(annual_dates):
        if i >= len(codes):
            break
        if ds >= boundary:
            continue                     # 아직 실적이 아닌 구간
        ym = ds[:7]                      # "YYYY-MM"
        by_month.setdefault(ym, 0)
        code = (codes[i] or "").strip()
        if code:
            has_record = True
        if code in ("N", "NK"):
            by_month[ym] += 1
    # '기록이 있고 야간이 0회'(0.0을 돌려줘야 함 — 야간 우선권을 주는 게 맞다)와
    # '기록 자체가 전부 빈칸'(알 수 없으니 None)을 구분한다. 전자에 중립값을 씌우면
    # 야간을 적게 선 사람의 우선권을 빼앗고, 후자를 0으로 두면 첫 달 야간을 몰아준다.
    if not by_month or not has_record:
        return None
    score = 0.0
    for ym in sorted(by_month):
        score = score * (2 / 3) + by_month[ym]
    return round(score, 2)


def carryover_from_history_before(annual_dates: List[str], codes: List[str],
                                  before: str) -> Optional[dict]:
    """붙여넣은 근무기록에서 'before(입사일) 전날' 기준 이월정보를 역산한다.

    월중 전입자용. 기본 경로(carryover_from_staff_table)는 '전월 1일~말일'을 잘라
    쓰는데, 2/15 입사자는 2/14까지 전 병동에서 근무했으므로 그 기준이 맞지 않는다
    (전월 말일로 계산하면 입사 직전의 야간블록을 통째로 놓쳐 야간 후 휴식이 안 지켜진다).

    연속근무일수·야간블록 판정에 필요한 만큼만 뒤에서 잘라 쓴다(넉넉히 62일).
    """
    if not annual_dates or not codes or not before:
        return None
    window = [c for ds, c in zip(annual_dates, codes) if ds < before]
    if not window:
        return None
    window = window[-62:]
    got = carryover_from_grid({"_": window}, len(window), lenient=True)
    return got.get("_")


# ---------------------------------------------------------------- 연간근무표 → 이월값 역산
def carryover_from_staff_table(annual_dates: List[str], annual_grid: Dict[str, List[str]],
                               year: int, month: int) -> Dict[str, dict]:
    """'연간근무표'의 연간 그리드에서 직전 달 구간만 잘라 carryover_from_grid로 역산.

    annual_dates에 직전 달 1일~말일이 빠짐없이 이어져 있는 경우에만 계산하고,
    아직 그만큼 안 쌓였거나 중간에 구멍이 있으면 빈 dict를 돌려준다(호출 쪽에서
    이월 없이 진행하거나 다른 값으로 채우면 됨).
    """
    import calendar as _cal
    import datetime as _dt
    py, pm = (year - 1, 12) if month == 1 else (year, month - 1)
    ndays = _cal.monthrange(py, pm)[1]
    prev_dates = [_dt.date(py, pm, d).isoformat() for d in range(1, ndays + 1)]
    try:
        idxs = [annual_dates.index(d) for d in prev_dates]
    except ValueError:
        return {}
    if idxs != list(range(idxs[0], idxs[0] + ndays)):
        return {}
    start = idxs[0]
    sliced = {sid: row[start:start + ndays] for sid, row in annual_grid.items()
             if len(row) >= start + ndays}
    return carryover_from_grid(sliced, ndays, lenient=True)

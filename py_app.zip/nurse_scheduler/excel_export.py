# -*- coding: utf-8 -*-
"""엑셀 출력 (설계서 §7, G10~G12)."""
from __future__ import annotations

import calendar
from typing import List, Optional

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from .calendar_utils import DayInfo, DAY_WEEKDAY, DAY_SATURDAY, holiday_count
from .models import MonthSchedule, Shift, NIGHT_SHIFTS, WORK_SHIFTS

SHIFT_FILLS = {
    Shift.A8: "D9D9D9",
    Shift.A9: "BFBFBF",
    Shift.A10: "A6A6A6",
    Shift.D: "BDD7EE",
    Shift.E: "F8CBAD",
    Shift.N: "1F3864",
    Shift.NK: "7030A0",
    Shift.PRN: "C6E0B4",
    Shift.AL: "FFE699",
    Shift.EDU: "B4C7E7",
    Shift.BEREAVE: "808080",
    Shift.CELEBRATE: "F4B6C2",
    Shift.AL_1H: "FFF2CC",
    Shift.AL_2H: "FFF2CC",
    Shift.AL_3H: "FFF2CC",
    Shift.AL_HALF: "FFF2CC",
    Shift.OFFICIAL: "D0CECE",
    Shift.SICK: "F8C9C4",
    Shift.LEAVE: "BFBFBF",
    Shift.PROMO_EDU: "DDEBF7",
    Shift.SLEEP_OFF: "9DC3E6",
    Shift.TW: "A9D18E",
    Shift.MIL: "C9C9C9",
}
WHITE_FONT_SHIFTS = {Shift.N, Shift.NK, Shift.BEREAVE}
WEEKEND_FILL = PatternFill("solid", fgColor="FCE4EC")
SUB_FILL = PatternFill("solid", fgColor="FFD966")
THIN = Border(*[Side(style="thin", color="BFBFBF")] * 4)
CENTER = Alignment(horizontal="center", vertical="center")

# 화면 그리드의 원티드(골드 테두리)·위반(빨강/노랑 테두리) 표시를 다운로드 파일에도
# 그대로 반영하기 위한 테두리 색 — 화면 CSS의 강조색과 맞춤(§style.css td.wanted 등).
WANTED_BORDER = Border(*[Side(style="medium", color="996900")] * 4)
HARD_VIOLATION_BORDER = Border(*[Side(style="medium", color="B5472E")] * 4)
SOFT_VIOLATION_BORDER = Border(*[Side(style="medium", color="9A6B12")] * 4)


def _violation_cell_flags(violations):
    """[{day, staff_id, best_effort, ...}, ...] → {(staff_id, day): "hard"|"soft"}.

    한 칸에 하드(필수)와 최선노력 위반이 둘 다 걸려 있으면 더 급한 쪽(hard)을 우선한다.
    day/staff_id가 없는 항목(날짜 전체 최소인력 미달 등, 특정 칸을 못 짚는 위반)은
    칸 단위로 표시할 수 없으니 건너뛴다."""
    flags = {}
    for v in violations or []:
        sid, day = v.get("staff_id"), v.get("day")
        if not sid or day is None:
            continue
        key = (sid, day)
        kind = "soft" if v.get("best_effort") else "hard"
        if kind == "hard" or key not in flags:
            flags[key] = kind
    return flags


def _count_eq(rng: str, code: str) -> str:
    """원티드 접미사(*)를 무시하고 code와 정확히 일치하는 칸 수를 세는 수식 조각.

    COUNTIF의 "*" 와일드카드는 접두사가 겹치는 코드(N vs NK 등)를 이중 계산하므로
    대신 SUBSTITUTE로 접미사를 지운 뒤 정확히 비교한다."""
    return f'SUMPRODUCT(--(SUBSTITUTE({rng},"*","")="{code}"))'


def export_excel(sch: MonthSchedule, days: List[DayInfo], path: str):
    """근무표 출력 (병원 표준 양식 호환).

    열 구성: 이름 | Lv | 잔휴(전월) | 잔휴(이번달) | 1일...말일 |
             D | E | N | ® | ⓡ | 금월 | T연 | R연 | 부서
    ®/ⓡ/T연/R연/부서는 우리 엔진이 추적하지 않는 병원 HR 항목이라 빈칸으로 둔다
    (표준 서식과의 열 자리는 맞추되 값은 지어내지 않음). 금월 = holiday_count()
    (이 달의 휴일수), 잔휴 = 전월 잔휴 + (금월 휴일수 - 이번달 순수오프일수).
    파트장 행 다음에 'A' 팀 구분 행을 넣어 병원 양식의 팀 구획 표기를 반영한다
    (Team B는 우리 엔진이 관리하는 개념이 아니라 생략)."""
    wb = Workbook()
    ws = wb.active
    ws.title = f"{sch.year}-{sch.month:02d}"
    off_bal_col1, off_bal_col2 = 3, 4  # 잔휴(전월)/잔휴(이번달)
    first_day_col = 5  # E열부터 1일
    last_day_col = first_day_col + sch.num_days - 1
    hol = holiday_count(days)
    sum_cols = ["D", "E", "N", "®", "ⓡ", "금월", "T연", "R연", "부서"]
    _write_schedule_sheet(ws, sch, days, hol, first_day_col, last_day_col,
                          off_bal_col1, off_bal_col2, sum_cols)
    wb.save(path)


def _write_schedule_sheet(ws, sch: MonthSchedule, days: List[DayInfo], hol: int,
                          first_day_col: int, last_day_col: int,
                          off_bal_col1: int, off_bal_col2: int, sum_cols: List[str]):
    nd = sch.num_days
    ws.cell(1, 1, f"{sch.year}년 {sch.month}월 근무표").font = Font(bold=True, size=14)
    ws.cell(2, 1, "이름").font = Font(bold=True)
    ws.cell(2, 2, "Lv").font = Font(bold=True)
    ws.cell(2, off_bal_col1, "잔휴").font = Font(bold=True)
    ws.cell(3, off_bal_col1, "전월").font = Font(bold=True, size=9)
    ws.cell(2, off_bal_col2, "잔휴").font = Font(bold=True)
    ws.cell(3, off_bal_col2, "이후").font = Font(bold=True, size=9)
    for c in (off_bal_col1, off_bal_col2):
        ws.cell(2, c).alignment = CENTER
        ws.cell(3, c).alignment = CENTER
        ws.column_dimensions[get_column_letter(c)].width = 6
    for d in range(nd):
        c = first_day_col + d
        di = days[d]
        cell = ws.cell(2, c, d + 1)
        dow = ws.cell(3, c, di.dow_name)
        for x in (cell, dow):
            x.alignment = CENTER
            x.font = Font(bold=True)
            if di.is_substitute:
                x.fill = SUB_FILL
            elif di.day_type != DAY_WEEKDAY:
                x.fill = WEEKEND_FILL
        ws.column_dimensions[get_column_letter(c)].width = 4.5
    for i, name in enumerate(sum_cols):
        c = last_day_col + 1 + i
        ws.cell(2, c, name).font = Font(bold=True)
        ws.cell(2, c).alignment = CENTER
        ws.column_dimensions[get_column_letter(c)].width = 6

    _oo = sch.orig_staff_order
    ordered = sorted(sch.staff, key=lambda s: (not s.is_partjang, _oo.get(s.id, 10**9)))
    partjang_rows = [s for s in ordered if s.is_partjang]
    others = [s for s in ordered if not s.is_partjang]

    def write_staff_row(row, s):
        ws.cell(row, 1, s.id)
        ws.cell(row, 2, s.level).alignment = CENTER
        off_before = sch.carryover[s.id].off_balance
        ws.cell(row, off_bal_col1, round(off_before, 2)).alignment = CENTER
        for d in range(nd):
            v = sch.grid[s.id][d]
            if v == Shift.OFF:
                text = "X" if (s.id, d) in sch.wanted else "/"
            else:
                text = str(v) if v else ""
                if v and (s.id, d) in sch.wanted:
                    text += "*"
            c = ws.cell(row, first_day_col + d, text)
            c.alignment = CENTER
            c.border = THIN
            if v in SHIFT_FILLS:
                c.fill = PatternFill("solid", fgColor=SHIFT_FILLS[v])
                if v in WHITE_FONT_SHIFTS:
                    c.font = Font(color="FFFFFF")
        a = get_column_letter(first_day_col)
        b = get_column_letter(last_day_col)
        rng = f"{a}{row}:{b}{row}"
        off_after = round(off_before + hol - sch.offs_in_month(s.id), 2)
        ws.cell(row, off_bal_col2, off_after).alignment = CENTER
        ws.cell(row, last_day_col + 1, f'={_count_eq(rng, "D")}').alignment = CENTER
        ws.cell(row, last_day_col + 2, f'={_count_eq(rng, "E")}').alignment = CENTER
        ws.cell(row, last_day_col + 3,
                f'={_count_eq(rng, "N")}+{_count_eq(rng, "NK")}').alignment = CENTER
        ws.cell(row, last_day_col + 6, hol).alignment = CENTER  # 금월

    row = 4
    for s in partjang_rows:
        write_staff_row(row, s)
        row += 1
    # 'A' 팀 구분 행 (병원 양식 호환용 — Team B는 우리 엔진이 관리하지 않아 생략)
    ws.cell(row, 1, "A").font = Font(bold=True, color="808080")
    row += 1
    nurse_top = row
    for s in others:
        write_staff_row(row, s)
        row += 1
    nurse_bot = row - 1

    labels = [("D", ["D"]),
              ("E", ["E"]),
              ("N", ["N", "NK"]),
              ("prn", ["prn", "8A", "9A", "10A"])]
    sum_start = row + 1
    for i, (name, codes) in enumerate(labels):
        rr = sum_start + i
        ws.cell(rr, 1, f"{name} 계").font = Font(bold=True)
        for d in range(nd):
            col = get_column_letter(first_day_col + d)
            rng = f"{col}{nurse_top}:{col}{nurse_bot}"
            formula = "=" + "+".join(_count_eq(rng, code) for code in codes)
            cell = ws.cell(rr, first_day_col + d, formula)
            cell.alignment = CENTER
            cell.border = THIN

    rr = sum_start + len(labels)
    ws.cell(rr, 1, "Lv 평균").font = Font(bold=True)
    for d in range(nd):
        levels = [s.level for s in sch.staff
                  if not s.is_partjang and sch.grid[s.id][d] in WORK_SHIFTS]
        val = round(sum(levels) / len(levels), 2) if levels else ""
        cell = ws.cell(rr, first_day_col + d, val)
        cell.alignment = CENTER
        cell.border = THIN

    # B팀(신입) — 이름만 표시, 나머지 칸은 전부 빈칸(파트장이 직접 배정)
    if sch.team_b_names:
        rr += 2
        ws.cell(rr, 1, "B").font = Font(bold=True, color="808080")
        for name in sch.team_b_names:
            rr += 1
            ws.cell(rr, 1, name)

    ws.freeze_panes = ws.cell(4, first_day_col)
    ws.column_dimensions["A"].width = 12
    ws.column_dimensions["B"].width = 4


# ---------------------------------------------------------------- OCS 원본 형식 출력

# 근무유형별 레벨 통계 — 화면(app.js computeLevelStats)과 같은 기준: 파트장 제외,
# N은 NK 포함, prn은 8A 포함(9A/10A는 별도 근무라 집계에서 뺀다 — 화면과 동일).
_LEVEL_STAT_SHIFT_KEY = {Shift.D: "D", Shift.E: "E", Shift.N: "N", Shift.NK: "N",
                        Shift.PRN: "prn", Shift.A8: "prn"}


def _level_stats(sch: MonthSchedule) -> dict:
    """{"D": (평균 또는 None, Lv4-5 인원수, Lv1-3 인원수), "E": ..., "N": ..., "prn": ...}."""
    levels = {"D": [], "E": [], "N": [], "prn": []}
    for s in sch.staff:
        if s.is_partjang:
            continue
        for v in sch.grid[s.id]:
            key = _LEVEL_STAT_SHIFT_KEY.get(v)
            if key:
                levels[key].append(s.level)

    def stat(vals):
        avg = round(sum(vals) / len(vals), 2) if vals else None
        return avg, sum(1 for lv in vals if lv >= 4), sum(1 for lv in vals if lv <= 3)

    return {k: stat(v) for k, v in levels.items()}


def _write_daily_level_foot_rows(ws, row: int, sch: MonthSchedule,
                                 first_day_col: int, last_day_col: int, name_col: int = 2) -> int:
    """날짜별(그리드 열과 1:1 정렬) 레벨평균·Lv4-5·Lv1-3 3줄 — 화면 결과 그리드 맨 아래의
    같은 행과 동일 기준(파트장 제외, 그 날 D/E/N/prn 근무 배정자만)으로 맞췄다."""
    nd = last_day_col - first_day_col + 1
    generals = [s for s in sch.staff if not s.is_partjang]
    day_stats = []
    for d in range(nd):
        levels = [s.level for s in generals if _LEVEL_STAT_SHIFT_KEY.get(sch.grid[s.id][d])]
        avg = round(sum(levels) / len(levels), 1) if levels else None
        day_stats.append((avg, sum(1 for lv in levels if lv >= 4), sum(1 for lv in levels if lv <= 3)))

    def write_row(row, label, value_fn):
        ws.cell(row, name_col, label).font = Font(bold=True)
        for d, stat in enumerate(day_stats):
            v = value_fn(stat)
            c = ws.cell(row, first_day_col + d, v if v is not None else "–")
            c.alignment = CENTER
        return row + 1

    row = write_row(row, "레벨평균", lambda st: st[0])
    row = write_row(row, "Lv4-5", lambda st: st[1])
    row = write_row(row, "Lv1-3", lambda st: st[2])
    return row


def _write_level_stats_block(ws, row: int, sch: MonthSchedule, col: int = 2) -> int:
    """근무별(D/E/N/prn) 레벨 평균·Lv4-5·Lv1-3 인원수를 row부터 4줄짜리 표로 쓰고,
    다 쓴 다음 줄 번호를 반환한다. 화면 결과 화면 하단의 같은 통계와 맞춘 것."""
    stats = _level_stats(sch)
    ws.cell(row, col, "근무별 레벨 통계 (파트장 제외)").font = Font(bold=True, size=10, color="5A6763")
    row += 1
    for i, name in enumerate(["근무", "평균", "Lv4-5", "Lv1-3"]):
        c = ws.cell(row, col + i, name)
        c.font = Font(bold=True, size=9)
        c.alignment = CENTER
    row += 1
    for name, key in (("D", "D"), ("E", "E"), ("N", "N"), ("prn/8A", "prn")):
        avg, hi, lo = stats[key]
        ws.cell(row, col, name)
        ws.cell(row, col + 1, avg if avg is not None else "–").alignment = CENTER
        ws.cell(row, col + 2, hi).alignment = CENTER
        ws.cell(row, col + 3, lo).alignment = CENTER
        row += 1
    return row


def _cell_shift_text(sch: MonthSchedule, sid: str, d: int):
    """OFF는 X(원티드)/－ (일반) 표시로 바꾸고, 그 외는 원티드 접미사(*)를 붙인다.
    반환: (표시 텍스트, 실제 Shift 값 — 색칠용)."""
    v = sch.grid[sid][d]
    if v == Shift.OFF:
        text = "X" if (sid, d) in sch.wanted else "/"
    else:
        text = str(v) if v else ""
        if v and (sid, d) in sch.wanted:
            text += "*"
    return text, v


def export_excel_ocs(sch: MonthSchedule, days: List[DayInfo], path: str,
                     violations: Optional[list] = None):
    """근무표 출력 — 병원 OCS가 실제로 내보내는 원본과 같은 모양(간호스케줄).

    열 구성: 순번 | 성명 | (빈칸, 원본의 익명화 코드는 재현 불가) | 잔휴(전월) |
             잔휴(이후) | 1일...말일 | D | E | N | ® | ⓡ | 금월 | T연 | R연 | 부서 | Lv
    T연/R연/부서/®/ⓡ는 우리 엔진이 추적하지 않는 HR 데이터라 빈칸. Lv는 원본에
    없는 우리 쪽 추가 정보라 맨 뒤에 붙인다. 원본처럼 하단 합계행은 없다(원본
    파일 자체가 그렇게 끝남) — 요약이 필요하면 기본 export_excel()을 쓴다.
    load_prev_month_schedule_xlsx()의 병원 OCS 폴백 파서로 그대로 재업로드 가능.

    violations(app 계층의 report["hard"] 그대로, best_effort 플래그 포함)를 주면
    화면 그리드와 같은 표시를 셀 테두리로 재현한다 — 원티드 칸은 골드, 위반 칸은
    빨강(필수)/노랑(최선노력) 테두리. 셀 배경색(근무유형)은 그대로 유지한 채
    테두리만 덧씌우는 방식이라 화면의 "색은 유지, 표시만 추가"와 같은 원리다."""
    wb = Workbook()
    ws = wb.active
    ws.title = f"{sch.year}-{sch.month:02d}"
    nd = sch.num_days
    off_bal_col1, off_bal_col2 = 4, 5
    first_day_col = 6
    last_day_col = first_day_col + nd - 1
    lv_col = last_day_col + 10  # D,E,N,®,ⓡ,금월,T연,R연,부서(9) 다음
    hol = holiday_count(days)

    ws.cell(1, 2, "간호스케줄").font = Font(bold=True, size=14)
    ws.cell(2, 2, f"조회 : {sch.year}년{sch.month:02d}월").font = Font(bold=True)
    ws.cell(3, off_bal_col1, "전월").font = Font(bold=True, size=9)
    ws.cell(4, 2, "성  명").font = Font(bold=True)
    ws.cell(4, off_bal_col1, "잔휴").font = Font(bold=True, size=9)
    ws.cell(4, off_bal_col2, "잔휴").font = Font(bold=True, size=9)
    for c in (off_bal_col1, off_bal_col2):
        ws.cell(3, c).alignment = CENTER
        ws.cell(4, c).alignment = CENTER
        ws.column_dimensions[get_column_letter(c)].width = 6
    for d in range(nd):
        c = first_day_col + d
        di = days[d]
        cell = ws.cell(3, c, d + 1)
        dow = ws.cell(4, c, di.dow_name)
        for x in (cell, dow):
            x.alignment = CENTER
            x.font = Font(bold=True)
            if di.is_substitute:
                x.fill = SUB_FILL
            elif di.day_type != DAY_WEEKDAY:
                x.fill = WEEKEND_FILL
        ws.column_dimensions[get_column_letter(c)].width = 4.5
    for i, name in enumerate(["D", "E", "N", "®", "ⓡ", "금월", "T연", "R연", "부서"]):
        c = last_day_col + 1 + i
        ws.cell(3, c, name).font = Font(bold=True)
        ws.cell(3, c).alignment = CENTER
        ws.column_dimensions[get_column_letter(c)].width = 6
    ws.cell(3, lv_col, "Lv").font = Font(bold=True)
    ws.cell(3, lv_col).alignment = CENTER
    ws.column_dimensions[get_column_letter(lv_col)].width = 5

    cell_flags = _violation_cell_flags(violations)

    def write_row(row, s, seq):
        if seq is not None:
            ws.cell(row, 1, seq).alignment = CENTER
        ws.cell(row, 2, s.id)
        off_before = sch.carryover[s.id].off_balance
        ws.cell(row, off_bal_col1, round(off_before, 2)).alignment = CENTER
        for d in range(nd):
            text, v = _cell_shift_text(sch, s.id, d)
            c = ws.cell(row, first_day_col + d, text)
            c.alignment = CENTER
            c.border = THIN
            if v in SHIFT_FILLS:
                c.fill = PatternFill("solid", fgColor=SHIFT_FILLS[v])
                if v in WHITE_FONT_SHIFTS:
                    c.font = Font(color="FFFFFF")
            # 위반(빨강/노랑)이 원티드(골드)보다 우선 — 화면과 같은 우선순위.
            flag = cell_flags.get((s.id, d))
            if flag == "hard":
                c.border = HARD_VIOLATION_BORDER
            elif flag == "soft":
                c.border = SOFT_VIOLATION_BORDER
            elif (s.id, d) in sch.wanted:
                c.border = WANTED_BORDER
        a, b = get_column_letter(first_day_col), get_column_letter(last_day_col)
        rng = f"{a}{row}:{b}{row}"
        off_after = round(off_before + hol - sch.offs_in_month(s.id), 2)
        ws.cell(row, off_bal_col2, off_after).alignment = CENTER
        ws.cell(row, last_day_col + 1, f'={_count_eq(rng, "D")}').alignment = CENTER
        ws.cell(row, last_day_col + 2, f'={_count_eq(rng, "E")}').alignment = CENTER
        ws.cell(row, last_day_col + 3,
                f'={_count_eq(rng, "N")}+{_count_eq(rng, "NK")}').alignment = CENTER
        ws.cell(row, last_day_col + 6, hol).alignment = CENTER  # 금월
        ws.cell(row, lv_col, s.level).alignment = CENTER

    _oo = sch.orig_staff_order
    ordered = sorted(sch.staff, key=lambda s: (not s.is_partjang, _oo.get(s.id, 10**9)))
    partjang_rows = [s for s in ordered if s.is_partjang]
    others = [s for s in ordered if not s.is_partjang]

    row = 5
    for s in partjang_rows:
        write_row(row, s, None)  # 파트장은 원본에서도 순번이 없음
        row += 1
    ws.cell(row, 2, "A").font = Font(bold=True, color="808080")
    row += 1
    seq = 0
    for s in others:
        seq += 1
        write_row(row, s, seq)
        row += 1
    if sch.team_b_names:
        ws.cell(row, 2, "B").font = Font(bold=True, color="808080")
        row += 1
        for name in sch.team_b_names:
            seq += 1
            ws.cell(row, 1, seq).alignment = CENTER
            ws.cell(row, 2, name)
            row += 1

    # 빈 줄 하나를 반드시 두고 시작한다 — 병원 OCS 재업로드 파서(_try_parse_hospital_ocs_shape)가
    # 성명 칸(2열)이 빈 줄에서 멈추고 그 아래를 인원 데이터로 안 읽기 때문에, 붙여서 쓰면
    # "레벨평균" 같은 라벨이 사람 이름으로, 그 옆 숫자가 근무코드로 잘못 읽혀 재업로드가 깨진다.
    row = _write_daily_level_foot_rows(ws, row + 1, sch, first_day_col, last_day_col)
    _write_level_stats_block(ws, row + 1, sch)

    ws.freeze_panes = ws.cell(5, first_day_col)
    ws.column_dimensions["A"].width = 6
    ws.column_dimensions["B"].width = 14
    ws.column_dimensions["C"].width = 8
    wb.save(path)


# ---------------------------------------------------------------- 연간근무표 (다월 자동 연동용, 구 명칭 "인원표")

STAT_FILL = PatternFill("solid", fgColor="E2EFDA")
NK_ROW_FILL = PatternFill("solid", fgColor="F2E9F7")
GROUP_FONT = Font(bold=True, size=11, color="808080")
BOLD = Font(bold=True)


def export_staff_table_xlsx(staff, stats: dict, annual_dates: list,
                             annual_grid: dict, path: str,
                             last_reflected: str = "",
                             team_b_names: Optional[list] = None):
    """'연간근무표' 내보내기 — 로스터 + 누적통계(형평성 참고용) + 연간 근무 그리드(1/1~, 참고용).

    staff: List[Staff] (현재 인원 명단, 이 순서/구성대로 출력)
    stats: {staff_id: {"night","workday","off","weekend_night",
                        "blocks_2","blocks_3","months","recent_night_score"}}
    annual_dates: [datetime.date, ...] — 1/1부터 이어진 연간 그리드 날짜(오름차순)
    annual_grid: {staff_id: [code, ...]} — annual_dates와 나란히
    team_b_names: B팀(신입) 이름만 — 스케줄링에 관여하지 않으므로 순번·이름만 채우고
        나머지 칸(통계·연간 그리드)은 전부 빈칸으로 둔다(출력① export_excel_ocs와 같은 취지).
    """
    from .excel_input import STAFF_TABLE_STATIC_COLS, STAFF_TABLE_STAT_KEYS, STAFF_TABLE_STAT_LABELS
    from .calendar_utils import WEEKDAY_NAMES

    wb = Workbook()
    ws = wb.active
    ws.title = "연간근무표"

    n_static = len(STAFF_TABLE_STATIC_COLS)
    n_stat = len(STAFF_TABLE_STAT_KEYS)
    first_day_col = 1 + n_static + n_stat  # 1-based

    title = "연간근무표"
    if last_reflected:
        title += f" — {last_reflected}까지 반영"
    ws.cell(1, 1, title).font = Font(bold=True, size=13)

    ws.cell(2, 1, "[ 인원 정보 ]").font = GROUP_FONT
    ws.cell(2, 1 + n_static, "[ 누적 통계 (형평성 참고용) ]").font = GROUP_FONT
    if annual_dates:
        ws.cell(2, first_day_col, "[ 연간 근무표 (참고용, 1/1 리셋) ]").font = GROUP_FONT

    header_row = 3
    for i, name in enumerate(STAFF_TABLE_STATIC_COLS):
        c = ws.cell(header_row, 1 + i, name)
        c.font = BOLD
        c.alignment = CENTER
    for i, name in enumerate(STAFF_TABLE_STAT_LABELS):
        c = ws.cell(header_row, 1 + n_static + i, name)
        c.font = BOLD
        c.alignment = CENTER
        c.fill = STAT_FILL

    dow_row = header_row + 1
    for i, d in enumerate(annual_dates):
        c = first_day_col + i
        cell = ws.cell(header_row, c, d)
        cell.number_format = "m/d"
        cell.font = Font(bold=True, size=9)
        cell.alignment = CENTER
        dow = ws.cell(dow_row, c, WEEKDAY_NAMES[d.weekday()])
        dow.font = Font(bold=True, size=9)
        dow.alignment = CENTER
        if d.weekday() >= 5:
            cell.fill = WEEKEND_FILL
            dow.fill = WEEKEND_FILL
        ws.column_dimensions[get_column_letter(c)].width = 4.2

    row0 = dow_row + 1
    for r, s in enumerate(staff):
        row = row0 + r
        is_nk = "night_only" in (s.flags or [])
        note = []
        if is_nk:
            note.append("야간전담")
        if "pregnant" in (s.flags or []):
            note.append("임부(야간 금지)")
        elif "no_night" in (s.flags or []):
            note.append("야간금지")
        static_vals = [r + 1, s.id, s.role, f"Lv{s.level}",
                       ",".join(s.allowed_shifts), ", ".join(note)]
        for i, v in enumerate(static_vals):
            c = ws.cell(row, 1 + i, v)
            c.alignment = CENTER
            if is_nk:
                c.fill = NK_ROW_FILL

        st = stats.get(s.id, {})
        for i, key in enumerate(STAFF_TABLE_STAT_KEYS):
            v = st.get(key, 0)
            c = ws.cell(row, 1 + n_static + i, v)
            c.alignment = CENTER
            c.fill = NK_ROW_FILL if is_nk else STAT_FILL

        codes = annual_grid.get(s.id, [])
        for i in range(len(annual_dates)):
            code = codes[i] if i < len(codes) else ""
            c = ws.cell(row, first_day_col + i, code)
            c.alignment = CENTER
            c.font = Font(size=9)
            if code in SHIFT_FILLS:
                c.fill = PatternFill("solid", fgColor=SHIFT_FILLS[code])
                if code in WHITE_FONT_SHIFTS:
                    c.font = Font(size=9, color="FFFFFF")

    # B팀(신입) — 이름만 표시, 나머지 칸은 전부 빈칸(파트장이 직접 배정) — 출력①과 같은 취지.
    if team_b_names:
        row = row0 + len(staff)
        ws.cell(row, 1, "B").font = GROUP_FONT
        row += 1
        for name in team_b_names:
            ws.cell(row, 2, name).alignment = CENTER
            row += 1

    ws.column_dimensions["A"].width = 6
    ws.column_dimensions["B"].width = 12
    ws.column_dimensions["C"].width = 9
    ws.column_dimensions["D"].width = 8
    ws.column_dimensions["E"].width = 18
    ws.column_dimensions["F"].width = 22
    if annual_dates:
        ws.freeze_panes = ws.cell(row0, first_day_col)
    wb.save(path)


_WANTED_GUIDE_LINES = [
    "입력② 원티드표 — 양식 안내", "",
    "입력③과 같은 그리드 모양에, 칸마다 신청 표시만 적어서 올리는 파일입니다. "
    "직원별로 원하는 근무/휴무를 미리 표기해두면 근무표 생성 시 최대한 반영됩니다.",
    "",
    "⚠ 이름 옆 직급·숙련도·가능근무·비고 칸이 이제 이 파일의 인원 정보 역할도 겸합니다 — "
    "현재 화면에 반영된 값으로 미리 채워져 있으니 필요한 부분만 고쳐서 올리면, 그 인원 정보가 "
    "화면에 그대로 반영됩니다(직급·숙련도가 비어 있는 사람이 하나라도 있으면 전체가 반려되니, "
    "이 4칸을 아예 안 쓸 게 아니라면 모든 행을 채워주세요).",
    "",
    "⚠ 인원 명단 아래 이름 칸에 'B' 한 글자만 있는 구분 행과 그 아래 이름들은 B팀(신입)입니다 — "
    "근무 배정에는 전혀 관여하지 않고 출력 근무표에 이름만 표시됩니다. 필요 없으면 그 행들을 "
    "지우고 올리세요.",
    "",
    "⚠ 중요 — '원티드표' 시트의 A1 셀에 적힌 'YYYY년 M월'을 보고 코드가 이 파일이 몇 년 "
    "몇 월 신청분인지 자동으로 인식합니다. A1의 월 이름을 실제 신청 대상 월과 다르게 "
    "고치면(예: 파일을 복사해서 재사용하다가 안 고침) 엉뚱한 달로 인식되니, 월을 바꿀 때는 "
    "A1도 꼭 같이 맞춰주세요 — 파일명이 아니라 A1 셀 내용을 봅니다.",
    "",
    "표기 코드 (뒤에 별표 * 가 있어도 없어도 인식됩니다)",
    "· 근무 희망: D / E / N / 8A / 9A / NK / prn / T(교육) / TW(반근무+반교육)",
    "· 휴가유형별 희망: 연·연차(연차) / 연1·연2·연3(시간제 연차) / 연4(반차) / 조(조사) / "
    "경(경조사) / 공(공가) / 병(병가) / 휴(휴직) / 승(승급교육) / 군(군공가) / S/(수면오프)",
    "· 단순 OFF 희망: X",
    "· 그 외 인식 못 하는 표시(포상휴가 등 특수 코드)는 업로드 후 '인식 못 한 표시' 목록으로 알려드립니다.",
    "· 빈 칸은 신청 없음으로 건너뜁니다.",
    "",
    "각 코드가 배정에서 어떻게 처리되는지",
    "· 병(병가): 연속근무일수 계산에서 제외됩니다(연속근무 5일 제한에 안 걸림)",
    "· 휴(휴직): 신청일부터 그 달 나머지 기간 전부 휴직으로 자동 처리됩니다",
    "· 공/승(공가/승급교육): 휴무(OFF)와 동일하게 취급되지만 연차는 차감되지 않습니다",
    "· 연1/연2/연3/연4(시간제/반차 연차): 몇 시간이든 하루치 연차 희망으로 집계됩니다",
    "· 군(군공가)/S/(수면오프): 휴무(OFF)와 동일하게 취급되지만 잔휴에는 반영되지 않습니다",
    "· TW(반근무+반교육): 근무일수엔 포함되지만 최소인력 계산에는 제외됩니다(교육 T와 동일)",
    "· 9A(09시 시작): 8A와 동격으로 취급됩니다(시작 시각만 다름)",
    "",
    "가장 쉬운 사용법",
    "이번 달 근무표를 아무 값이나 넣어 한 번 생성해서 빈 그리드 모양(입력③과 같은 모양)을 "
    "받은 뒤, 그 위에 표시만 채워서 다시 올려도 됩니다.",
]


_WANTED_TEMPLATE_TEAM_B_EXAMPLE = ["41", "42"]


def generate_wanted_template_xlsx(year: int, month: int, staff: List[dict], path: str,
                                  team_b_names: Optional[List[str]] = None):
    """입력② 원티드표 양식 — 선택한 연/월의 실제 일수에 맞춰 날짜 열을 만들고,
    현재 화면에 입력돼 있는 인원 목록 그대로 빈 행을 깔아준다(표시만 채워서 재업로드).

    이름 옆(B~E열)에 직급·숙련도·가능근무·비고를 현재 값으로 미리 채워 넣는다 — 이 파일이
    이제 원티드 신청뿐 아니라 인원 정보의 소스 역할도 겸하기 때문(load_wanted_grid_xlsx가
    다시 읽어 인원 표를 갱신한다). staff는 {"id","role","level","allowed_shifts","flags"} 형태
    (cfg["staff"]와 동일 스키마) — id만 있고 나머지가 없으면(과거 방식과의 호환) 그 4칸은
    빈 채로 둔다.

    일반 인원 아래에 'B' 구분 행 + team_b_names를 이름만 채워 넣는다 — 현재 반영된 B팀이
    있으면 그대로, 없으면(빈 상태) 입력①과 같은 예시("41","42")를 보여준다. 이 자리에 그대로
    두고 업로드하면 load_wanted_grid_xlsx가 B팀으로 인식하고, 필요 없으면 그 행들만 지우고
    올리면 된다.

    '안내' 시트(표기 규칙 설명)는 달과 무관하게 고정, '원티드표' 시트만 연/월별로 다시 만든다.
    코드가 어느 시트가 원티드표인지는 시트 이름이 아니라 A1 셀의 'YYYY년 M월' 문구로
    찾으므로(_find_grid_sheet), 시트 이름 자체는 참고용이다 — 다만 A1 문구는 반드시 맞아야
    한다."""
    from openpyxl.comments import Comment
    from openpyxl.styles import Font as _Font, PatternFill as _PatternFill

    num_days = calendar.monthrange(year, month)[1]
    first_day_col = 6  # A=이름 B=직급 C=숙련도 D=가능근무 E=비고 F~=날짜

    wb = Workbook()
    guide = wb.active
    guide.title = "안내"
    for i, line in enumerate(_WANTED_GUIDE_LINES, start=1):
        guide.cell(i, 1, line)
    guide.column_dimensions["A"].width = 100

    ws = wb.create_sheet("원티드표")
    title_cell = ws.cell(1, 1, f"{year}년 {month}월 원티드표")
    title_cell.comment = Comment(
        "이 칸의 'YYYY년 M월'을 보고 코드가 몇 월 신청분인지 자동으로 인식합니다 — "
        "파일명이 아니라 이 셀 내용을 봅니다. 다른 달에 재사용하려면 이 칸도 꼭 같이 고치세요.",
        "SMC Fair Shift",
    )
    head = _Font(bold=True)
    fill = _PatternFill("solid", fgColor="DDEBE7")
    headers = ["이름", "직급", "숙련도", "가능근무", "비고"]
    for c, label in enumerate(headers, start=1):
        cell = ws.cell(2, c, label)
        cell.font = head
        cell.fill = fill
    for d in range(num_days):
        cell = ws.cell(2, first_day_col + d, d + 1)
        cell.font = head
        cell.fill = fill
    ws.cell(3, 1, "※ 이름 옆 직급·숙련도·가능근무·비고는 필요하면 고치고, 날짜 칸엔 표시만 "
                  "채워서 업로드하세요. 표기 규칙은 '안내' 시트 참고.")
    for i, s in enumerate(staff):
        row = 4 + i
        ws.cell(row, 1, s.get("id") if isinstance(s, dict) else s)
        if not isinstance(s, dict):
            continue
        role = s.get("role")
        level = s.get("level")
        allowed = s.get("allowed_shifts") or []
        flags = s.get("flags") or []
        if role:
            ws.cell(row, 2, role)
        if level:
            ws.cell(row, 3, f"Lv{level}")
        if allowed:
            ws.cell(row, 4, ",".join(allowed))
        notes = []
        if "night_only" in flags:
            notes.append("야간전담")
        if "pregnant" in flags:
            notes.append("임부(야간 금지)")
        elif "no_night" in flags:
            notes.append("야간금지")
        if notes:
            ws.cell(row, 5, ", ".join(notes))

    names_b = team_b_names if team_b_names else _WANTED_TEMPLATE_TEAM_B_EXAMPLE
    b_row = 4 + len(staff)
    ws.cell(b_row, 1, "B").font = head
    for i, name in enumerate(names_b):
        ws.cell(b_row + 1 + i, 1, name)

    for col, w in (("A", 12), ("B", 9), ("C", 8), ("D", 16), ("E", 22)):
        ws.column_dimensions[col].width = w

    wb.save(path)

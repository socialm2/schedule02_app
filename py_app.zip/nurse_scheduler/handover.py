# -*- coding: utf-8 -*-
"""병동 간 인계 카드(E-1) — 전출자의 기록을 파일로 다음 병동에 넘긴다.

지금까지 전입자의 전 병동 기록은 파트장이 다른 병동의 연간근무표를 열어 그 사람 행을
우리 입력②에 손으로 붙여 넣어야 했다. 실제로는 생략되고, 그러면 "기록 없음"으로
재직자 중앙값에서 시작한다. 전출하는 쪽 병동이 출력②를 만들 때 전출자마다 카드 시트를
함께 내보내고, 받는 병동은 그 파일을 '인계 카드' 칸에 올리면 입력②에 기록이 없어도
입사 전날 기준 이월 역산(구성 A-a)과 야간 점수 접기(A-b)가 실제 기록으로 돌아간다.

카드 시트 양식(E1-f): 첫 칸 A1에 표식 "인계카드". 위쪽은 항목·값 두 열(발신 병동, 전출월,
근무자, 마지막 기록일, 카드 다이제스트, 잔휴, 최근야간점수, 이월 항목들), 그 아래 월별 야간
횟수, 그 아래 날짜·근무 두 열의 기록. 전출자가 여럿이면 사람마다 시트 하나.

다이제스트는 출력② 파일 전체가 아니라 **카드 내용**(근무자·발신 병동·기록 행·이월 항목)의
SHA-256 앞 12자다 — 파일 전체 해시는 같은 파일 안에 적을 수 없고, 내용 해시는 받는 쪽이
다시 계산해 손으로 고친 카드를 알아볼 수 있다.
"""
from __future__ import annotations

import hashlib
import json
import re
from typing import Dict, List, Optional, Tuple

from .excel_input import ExcelInputError

CARD_MARK = "인계카드"
SHEET_PREFIX = "인계카드_"
RECORD_SHEET = "인계기록"

CARRY_FIELDS = [
    ("last_shift_type", "마지막 근무유형"),
    ("consecutive_work_days", "연속근무일수"),
    ("night_block_remaining_off", "야간블록 잔여 휴식일"),
    ("night_block_in_progress", "야간블록 진행 여부"),
    ("trailing_night_count", "말일 연속야간일수"),
    ("days_since_last_night", "최근 야간 뒤 경과일"),
]
HEAD_FIELDS = [
    ("ward", "발신 병동"),
    ("left_at", "전출월"),
    ("id", "근무자"),
    ("last_record_date", "마지막 기록일"),
    ("digest", "카드 다이제스트"),
    ("off_balance", "잔휴"),
    ("recent_night_score", "최근야간점수"),
]
LABEL_TO_KEY = {label: key for key, label in HEAD_FIELDS + CARRY_FIELDS}


def card_digest(card: dict) -> str:
    """카드 내용의 SHA-256 앞 12자. 다이제스트 칸 자체는 넣지 않는다."""
    body = {
        "id": card.get("id", ""), "ward": card.get("ward", ""), "left_at": card.get("left_at", ""),
        "dates": list(card.get("dates") or []), "codes": [str(c or "") for c in (card.get("codes") or [])],
        "carry": {k: str(card.get("carryover", {}).get(k, "")) for k, _ in CARRY_FIELDS},
        "off_balance": str(card.get("off_balance", "")),
        "recent_night_score": str(card.get("recent_night_score", "")),
    }
    raw = json.dumps(body, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:12]


def monthly_nights(dates: List[str], codes: List[str]) -> Dict[str, int]:
    out: Dict[str, int] = {}
    for ds, c in zip(dates, codes):
        ym = ds[:7]
        out.setdefault(ym, 0)
        if str(c or "").strip() in ("N", "NK"):
            out[ym] += 1
    return out


def build_card(sid: str, ward: str, left_at: str, dates: List[str], codes: List[str],
               stats: Optional[dict], carryover: Optional[dict], min_days: int = 62) -> Optional[dict]:
    """전출자 한 명의 카드. 기록이 전혀 없으면 None — 빈 카드는 받는 쪽을 속인다.

    dates·codes: 연간 그리드의 그 사람 행(전출월 전까지). 최근 62일 이상이면 가능한 한 전체를
    싣는다(점수 접기는 달 단위라 많을수록 정확하다)."""
    pairs = [(d, str(c or "").strip()) for d, c in zip(dates, codes) if d[:7] < left_at]
    if not any(c for _, c in pairs):
        return None
    last = max(d for d, c in pairs if c)
    card = {
        "id": sid, "ward": ward or "", "left_at": left_at, "last_record_date": last,
        "dates": [d for d, _ in pairs], "codes": [c for _, c in pairs],
        "off_balance": round(float((stats or {}).get("off_balance", 0.0) or 0.0), 2),
        "recent_night_score": round(float((stats or {}).get("recent_night_score", 0.0) or 0.0), 2),
        "carryover": {k: (carryover or {}).get(k, "") for k, _ in CARRY_FIELDS},
    }
    card["monthly_nights"] = monthly_nights(card["dates"], card["codes"])
    card["digest"] = card_digest(card)
    return card


def _sheet_title(sid: str) -> str:
    safe = re.sub(r'[\[\]:*?/\\]', "_", sid)
    return (SHEET_PREFIX + safe)[:31]


def write_cards(wb, cards: List[dict]) -> None:
    """openpyxl Workbook에 카드 시트를 더한다(출력②와 같은 통합 문서)."""
    from openpyxl.styles import Font
    for card in cards:
        ws = wb.create_sheet(_sheet_title(card["id"]))
        ws.cell(1, 1, CARD_MARK).font = Font(bold=True, size=13)
        ws.cell(1, 2, "전출자의 근무 기록 인계 카드 — 받는 병동은 이 파일을 '인계 카드' 칸에 올립니다. 손으로 고치지 마세요(다이제스트로 확인합니다)")
        r = 3
        for key, label in HEAD_FIELDS:
            ws.cell(r, 1, label); ws.cell(r, 2, card.get(key, "")); r += 1
        for key, label in CARRY_FIELDS:
            v = card["carryover"].get(key, "")
            ws.cell(r, 1, label); ws.cell(r, 2, "" if v is None else str(v)); r += 1
        r += 1
        ws.cell(r, 1, "월별 야간").font = Font(bold=True); r += 1
        for ym in sorted(card.get("monthly_nights") or {}):
            ws.cell(r, 1, ym); ws.cell(r, 2, card["monthly_nights"][ym]); r += 1
        r += 1
        ws.cell(r, 1, "날짜").font = Font(bold=True); ws.cell(r, 2, "근무").font = Font(bold=True); r += 1
        for d, c in zip(card["dates"], card["codes"]):
            ws.cell(r, 1, d); ws.cell(r, 2, c); r += 1
        ws.column_dimensions["A"].width = 22
        ws.column_dimensions["B"].width = 16


def write_applied_record(wb, applied: List[dict]) -> None:
    """E1-e: 이번 달에 인계 카드를 적용한 전입자 기록 — 다음 달부터는 입력②의 그 사람 행이
    기록이 되므로 카드는 다시 쓰지 않는다. 어느 카드를 썼는지만 남긴다."""
    if not applied:
        return
    from openpyxl.styles import Font
    ws = wb.create_sheet(RECORD_SHEET)
    ws.cell(1, 1, RECORD_SHEET).font = Font(bold=True, size=13)
    for i, h in enumerate(["근무자", "발신 병동", "전출월", "카드 다이제스트", "적용 월"]):
        ws.cell(2, 1 + i, h).font = Font(bold=True)
    for r, a in enumerate(applied, start=3):
        for i, k in enumerate(["id", "ward", "left_at", "digest", "applied_month"]):
            ws.cell(r, 1 + i, a.get(k, ""))


def _cell_str(v) -> str:
    if v is None:
        return ""
    if hasattr(v, "isoformat"):
        return v.isoformat()[:10]
    return str(v).strip()


def read_cards(path: str) -> List[dict]:
    """파일에서 카드 시트(첫 칸 '인계카드')를 전부 읽는다. 다이제스트를 다시 계산해
    digest_ok에 적는다 — 손으로 고친 카드는 막지 않고 알린다(수신 쪽 판단)."""
    from openpyxl import load_workbook
    wb = load_workbook(path, data_only=True, read_only=True)
    cards: List[dict] = []
    for ws in wb.worksheets:
        rows = [[_cell_str(c) for c in row] for row in ws.iter_rows(values_only=True)]
        if not rows or not rows[0] or rows[0][0] != CARD_MARK:
            continue
        card = {"carryover": {}, "monthly_nights": {}, "dates": [], "codes": []}
        mode = "head"
        for row in rows[1:]:
            a = row[0] if row else ""
            b = row[1] if len(row) > 1 else ""
            if a == "월별 야간":
                mode = "nights"; continue
            if a == "날짜" and b == "근무":
                mode = "grid"; continue
            if not a:
                continue
            if mode == "head":
                key = LABEL_TO_KEY.get(a)
                if key is None:
                    continue
                if key in dict(CARRY_FIELDS):
                    card["carryover"][key] = b
                else:
                    card[key] = b
            elif mode == "nights":
                try:
                    card["monthly_nights"][a] = int(float(b or 0))
                except ValueError:
                    pass
            else:
                if re.match(r"^\d{4}-\d{2}-\d{2}$", a):
                    card["dates"].append(a); card["codes"].append(b)
        if not card.get("id"):
            raise ExcelInputError(f"'{ws.title}' 시트: 인계카드 표식은 있는데 근무자 이름이 없습니다")
        for k in ("off_balance", "recent_night_score"):
            try:
                card[k] = round(float(card.get(k) or 0.0), 2)
            except ValueError:
                raise ExcelInputError(f"'{ws.title}' 시트: {k}에 숫자가 아닌 값이 있습니다 — {card.get(k)!r}")
        stated = card.get("digest", "")
        card["digest"] = card_digest(card)
        card["digest_ok"] = (stated == card["digest"])
        card["stated_digest"] = stated
        card["sheet"] = ws.title
        cards.append(card)
    if not cards:
        raise ExcelInputError(
            "인계 카드 시트를 찾지 못했습니다 — 전출 병동이 만든 출력②(연간근무표)에는 "
            "'인계카드_이름' 시트가 함께 들어 있습니다. 그 파일을 올려주세요. "
            "(이 칸에는 우리 병동 입력①·②를 올리는 것이 아닙니다)")
    return cards


def duplicate_names(cards: List[dict]) -> Dict[str, List[str]]:
    """같은 이름의 카드가 둘 이상이면 {이름: [발신 병동/전출월, ...]} — E1-d."""
    seen: Dict[str, List[str]] = {}
    for c in cards:
        seen.setdefault(c["id"], []).append(f"{c.get('ward') or '병동 미기재'}/{c.get('left_at') or '?'}")
    return {k: v for k, v in seen.items() if len(v) > 1}


def conflicting_dates(card: dict, annual_dates: List[str], codes: List[str]) -> List[str]:
    """입력②에도 그 사람 기록이 있을 때, 같은 날짜의 코드가 서로 다른 날 — E1-c 셋째 갈래."""
    mine = {d: str(c or "").strip() for d, c in zip(annual_dates, codes) if str(c or "").strip()}
    out = []
    for d, c in zip(card["dates"], card["codes"]):
        c = str(c or "").strip()
        if c and d in mine and mine[d] != c:
            out.append(d)
    return out


def carry_from_card(card: dict) -> dict:
    """카드의 이월 항목을 엔진이 받는 dict로. 값은 문자열로 저장돼 있으므로 되돌린다."""
    raw = card.get("carryover") or {}
    out: dict = {}
    for key, _ in CARRY_FIELDS:
        v = raw.get(key, "")
        if v in ("", None):
            continue
        s = str(v)
        if key == "last_shift_type":
            out[key] = s
        elif key == "night_block_in_progress":
            out[key] = s.lower() in ("true", "1", "예", "y")
        else:
            try:
                out[key] = int(float(s))
            except ValueError:
                pass
    return out

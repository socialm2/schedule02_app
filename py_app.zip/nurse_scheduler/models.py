# -*- coding: utf-8 -*-
"""데이터 모델: Staff, Shift, Carryover, MonthSchedule (설계서 §0, 부록 B)."""
from __future__ import annotations

import calendar as _cal
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Set, Tuple


class Shift(str, Enum):
    A8 = "8A"
    A9 = "9A"          # 09:00~ 시작(8A와 동격, 시작시각만 다름) — 병원 표준 코드
    D = "D"
    E = "E"
    N = "N"
    NK = "NK"
    PRN = "prn"
    OFF = "OFF"
    AL = "연차"
    EDU = "T"        # 교육 — 근무일수 포함, 최소인력 제외
    BEREAVE = "조"     # 조사(예: 사망) — 관리자 지정, 근무인력 제외
    CELEBRATE = "경"   # 경조사(예: 결혼) — 관리자 지정, 근무인력 제외
    AL_1H = "연1"      # 연차(시간제, 1시간) — 연4와 같은 계열, 세부 시간 구분 없이 휴가로 집계
    AL_2H = "연2"      # 연차(시간제, 2시간)
    AL_3H = "연3"      # 연차(시간제, 3시간)
    AL_HALF = "연4"    # 연차(반차) — 0.5 연차 + 0.5 OFF로 집계
    OFFICIAL = "공"    # 공가 — OFF와 동일 취급, 연차 카운트/잔휴 미반영
    SICK = "병"        # 병가 — 연속근무일수(H3-1 포함) 계산에서 제외
    LEAVE = "휴"       # 휴직 — 발생일부터 그 달 나머지 기간 전부 제외
    PROMO_EDU = "승"   # 승급교육 — 공가와 동일 취급
    SLEEP_OFF = "S/"   # 수면오프(야간 근무 뒤 의무 휴식) — 관리자 지정, 잔휴 미반영
    TW = "TW"          # 반근무+반교육(신입/B팀 대상) — 근무일수 포함, 최소인력 제외
    MIL = "군"          # 군 관련 공가 — 공가와 동일 취급

    def __str__(self) -> str:  # 엑셀/리포트 출력용
        return self.value


WORK_SHIFTS = {Shift.A8, Shift.A9, Shift.D, Shift.E, Shift.N, Shift.NK, Shift.PRN,
               Shift.EDU, Shift.TW}
NIGHT_SHIFTS = {Shift.N, Shift.NK}
REST_SHIFTS = {
    Shift.OFF, Shift.AL, Shift.BEREAVE, Shift.CELEBRATE,
    Shift.AL_1H, Shift.AL_2H, Shift.AL_3H, Shift.AL_HALF,
    Shift.OFFICIAL, Shift.SICK, Shift.LEAVE, Shift.PROMO_EDU,
    Shift.SLEEP_OFF, Shift.MIL,
}
DAY_WORK_SHIFTS = {Shift.D, Shift.E, Shift.PRN}  # 주간 일반근무
LEAVE_SHIFTS = {
    Shift.AL, Shift.BEREAVE, Shift.CELEBRATE,
    Shift.AL_1H, Shift.AL_2H, Shift.AL_3H, Shift.AL_HALF,
    Shift.OFFICIAL, Shift.SICK, Shift.LEAVE, Shift.PROMO_EDU,
    Shift.SLEEP_OFF, Shift.MIL,
}  # OFF를 제외한 각종 휴가/휴직 유형 (표시·통계 구분용, 잔휴 계산에서 제외)


_OFF_ALIASES = {"X", "/"}  # 원티드 오프(X)/일반 오프(/) — 출력 표시용, 내부적으로는 둘 다 OFF
_AL_ALIASES = {"연"}  # 병원 OCS 원본에서 "연차"를 줄여 "연"으로 표기(§연*=53건 확인)


def parse_shift(value: str) -> Shift:
    if value.endswith("*") and value != "*":
        value = value[:-1]  # 원티드(신청/관리자 지정) 표시 접미사 — 값 판별에는 무관
    for s in Shift:
        if s.value == value:
            return s
    if value in _OFF_ALIASES:
        return Shift.OFF
    if value in _AL_ALIASES:
        return Shift.AL
    raise ValueError(f"알 수 없는 근무유형: {value!r}")


@dataclass
class Staff:
    id: str
    role: str  # 파트장 | 리더 | 간호사
    level: int
    allowed_shifts: List[Shift]
    flags: List[str] = field(default_factory=list)

    def __post_init__(self):
        # role/flags/allowed_shifts는 생성 후 변경되지 않으므로(엔진 전체에서 재대입
        # 없음 확인됨) 매번 다시 계산하는 @property 대신 1회만 계산해 저장한다 —
        # can_assign_day 등 초당 수백만 번 읽는 핫패스 성능 최적화, 값의 의미는 동일.
        self.is_partjang: bool = self.role == "파트장"
        self.is_leader: bool = self.role == "리더"
        self.is_nk: bool = ("night_only" in self.flags
                            or self.allowed_shifts == [Shift.NK])
        self.no_night: bool = "pregnant" in self.flags or "no_night" in self.flags

    def can(self, shift: Shift) -> bool:
        if shift in REST_SHIFTS or shift in (Shift.EDU, Shift.TW):
            return True
        if shift in NIGHT_SHIFTS and self.no_night:
            return False
        return shift in self.allowed_shifts


@dataclass
class Carryover:
    """전월 말 상태 (H5-3, 부록 A)."""
    last_shift_type: Shift = Shift.OFF
    consecutive_work_days: int = 0
    night_block_remaining_off: int = 0  # 이번 달 초에 이월해야 할 필수 OFF 일수
    night_block_in_progress: bool = False
    trailing_night_count: int = 0  # 전월 말에 이어지던 야간블록 길이(0=없음)
    recent_night_score: float = 0.0  # 최근 몇 달간의 야간 누적(감쇠) — 야간 배정 형평성용
    off_balance: float = 0.0  # 전월말 기준 잔휴(정상 오프 누적잔액) — 병원 표준 '잔휴' 칸

    @classmethod
    def from_dict(cls, d: Optional[dict]) -> "Carryover":
        if not d:
            return cls()
        trailing = int(d.get("trailing_night_count", 0))
        in_prog = bool(d.get("night_block_in_progress", False))
        if in_prog and trailing == 0:
            trailing = 1
        return cls(
            last_shift_type=parse_shift(d.get("last_shift_type", "OFF")),
            consecutive_work_days=int(d.get("consecutive_work_days", 0)),
            night_block_remaining_off=int(d.get("night_block_remaining_off", 0)),
            night_block_in_progress=in_prog,
            trailing_night_count=trailing,
            recent_night_score=float(d.get("recent_night_score", 0.0)),
            off_balance=float(d.get("off_balance", 0.0)),
        )


@dataclass
class Request:
    """원티드(신청). 리스트 순서 = 제출 순서(선착순, §5)."""
    staff_id: str
    date: str  # YYYY-MM-DD
    type: Shift
    priority: int = 1
    # 처리 결과
    accepted: Optional[bool] = None
    reject_reason: str = ""

    @property
    def day_index_cache(self):
        return None


@dataclass
class Violation:
    rule: str          # 예: "H1-1", "S7"
    severity: str      # hard | soft | info
    message: str
    staff_id: str = ""
    day: Optional[int] = None  # 0-based


class _TrackedRow(list):
    """한 직원의 grid 행. 모든 원소 쓰기(단일/슬라이스, sch.set()이든 grid[sid][d]=v
    직접 대입이든)를 가로채 MonthSchedule의 증분 집계 카운터를 갱신한다 — 매 호출마다
    월 전체를 다시 훑는 workdays_in_month/offs_in_month/count_shift 등을 O(1)로
    만들기 위함(엔진 알고리즘 성능 최적화). 값 자체의 의미는 그대로이므로 결과는
    최적화 이전과 완전히 동일해야 한다."""

    def __init__(self, iterable, sch: "MonthSchedule", sid: str):
        super().__init__(iterable)
        self._sch = sch
        self._sid = sid

    def __setitem__(self, key, value):
        sch = self._sch
        sid = self._sid
        if isinstance(key, slice):
            idxs = range(*key.indices(len(self)))
            old_vals = [list.__getitem__(self, i) for i in idxs]
            list.__setitem__(self, key, value)
            for i, old in zip(idxs, old_vals):
                new = list.__getitem__(self, i)
                if old != new:
                    sch._on_cell_change(sid, i, old, new)
        else:
            day = key if key >= 0 else key + len(self)
            old = list.__getitem__(self, key)
            list.__setitem__(self, key, value)
            new = list.__getitem__(self, key)
            if old != new:
                sch._on_cell_change(sid, day, old, new)


class MonthSchedule:
    """한 달 근무표. grid[staff_id][day] = Shift 또는 None(미배정)."""

    def __init__(self, year: int, month: int, staff: List[Staff],
                 carryover: Dict[str, Carryover], team_b: Optional[List[str]] = None):
        self.year = year
        self.month = month
        self.num_days = _cal.monthrange(year, month)[1]
        self.staff: List[Staff] = staff
        self.by_id: Dict[str, Staff] = {s.id: s for s in staff}
        self.carryover: Dict[str, Carryover] = {
            s.id: carryover.get(s.id, Carryover()) for s in staff
        }
        # B팀(신입) — 이름만 관리, 스케줄링/최소인력/제약검사 전부 미개입. 파트장이
        # 근무표(엑셀이든 OCS든)에서 직접 배정한다. 출력 시 이름만 있는 행으로 표시.
        self.team_b_names: List[str] = list(team_b or [])
        # 증분 집계 카운터(성능 최적화용) — 전부 grid가 비어있는 초기상태(None) 기준 0.
        self._wd_count: Dict[str, int] = {s.id: 0 for s in staff}
        self._off_count: Dict[str, int] = {s.id: 0 for s in staff}
        self._night_count: Dict[str, int] = {s.id: 0 for s in staff}
        self._al_count: Dict[str, int] = {s.id: 0 for s in staff}
        self._weekend_wd_count: Dict[str, int] = {s.id: 0 for s in staff}
        self._weekend_days: Set[int] = set()
        self._day_d = [0] * self.num_days
        self._day_e = [0] * self.num_days
        self._day_n = [0] * self.num_days
        self._day_prn = [0] * self.num_days
        self.grid: Dict[str, List[Optional[Shift]]] = {
            s.id: _TrackedRow([None] * self.num_days, self, s.id) for s in staff
        }
        self.locked: Set[Tuple[str, int]] = set()
        # 리더가 8A(prn형)를 서는 칸 (§0.3): 표시는 8A, 인력합계는 prn으로 계산
        self.leader_8a: Set[Tuple[str, int]] = set()
        # H2-9 완화로 개인별 상향된 야간 상한
        self.relaxed_night_cap: Dict[str, int] = {}
        # 승인된 OFF/연차 신청일 (S8 판단용): {(staff_id, day)}
        self.requested_off: Set[Tuple[str, int]] = set()
        # 원티드(신청 채택분 + 리더 수정고정분) — 근무표 표시용(*): {(staff_id, day)}
        self.wanted: Set[Tuple[str, int]] = set()
        # 개인별 이번 달 나이트 목표(4 또는 6, 야간전담 제외) — H6-4 판정용
        self.night_target: Dict[str, int] = {}
        self.logs: List[str] = []

    # ---------- 기본 접근 ----------
    def get(self, sid: str, day: int) -> Optional[Shift]:
        if 0 <= day < self.num_days:
            return self.grid[sid][day]
        return None

    def set(self, sid: str, day: int, shift: Shift, lock: bool = False):
        self.grid[sid][day] = shift
        if lock:
            self.locked.add((sid, day))

    def is_locked(self, sid: str, day: int) -> bool:
        return (sid, day) in self.locked

    def log(self, msg: str):
        self.logs.append(msg)

    # ---------- 증분 집계(성능 최적화) ----------
    def set_weekend_days(self, weekend_days: Set[int]):
        """토/일/공휴일 날짜 인덱스 집합을 등록한다(Generator가 달력 계산 직후 1회 호출).
        _pick_day_candidate의 주말근무일수(wk_load) 집계를 O(1)로 만들기 위함."""
        self._weekend_days = set(weekend_days)

    def mark_leader_8a(self, sid: str, day: int):
        """리더의 8A(prn형) 칸을 표시한다. count_shift(PRN)이 이 칸도 세도록,
        leader_8a.add() 대신 반드시 이 메서드로 등록해야 증분 카운터가 맞는다."""
        if (sid, day) in self.leader_8a:
            return
        self.leader_8a.add((sid, day))
        v = self.grid[sid][day]
        if v in (Shift.A8, Shift.A9):
            staff = self.by_id.get(sid)
            if staff is not None and not staff.is_partjang:
                self._day_prn[day] += 1

    def _on_cell_change(self, sid: str, day: int, old: Optional[Shift],
                        new: Optional[Shift]):
        """grid[sid][day]가 old→new로 바뀔 때마다 호출(단일/슬라이스 대입 모두,
        sch.set()이든 grid[sid][d]=v 직접 대입이든 _TrackedRow가 가로채 호출한다).
        월 전체를 다시 훑던 workdays_in_month/offs_in_month/count_shift 등을
        O(1)로 만드는 증분 카운터를 갱신한다 — 최적화 전과 결과가 완전히 같아야 한다."""
        ow = old in WORK_SHIFTS
        nw = new in WORK_SHIFTS
        if ow != nw:
            self._wd_count[sid] += 1 if nw else -1
            if day in self._weekend_days:
                self._weekend_wd_count[sid] += 1 if nw else -1
        oo = old == Shift.OFF
        no = new == Shift.OFF
        if oo != no:
            self._off_count[sid] += 1 if no else -1
        on_ = old in NIGHT_SHIFTS
        nn = new in NIGHT_SHIFTS
        if on_ != nn:
            self._night_count[sid] += 1 if nn else -1
        oal = old == Shift.AL
        nal = new == Shift.AL
        if oal != nal:
            self._al_count[sid] += 1 if nal else -1

        staff = self.by_id.get(sid)
        if staff is None or staff.is_partjang:
            return
        if on_ != nn:
            self._day_n[day] += 1 if nn else -1
        od = old == Shift.D
        nd_ = new == Shift.D
        if od != nd_:
            self._day_d[day] += 1 if nd_ else -1
        oe = old == Shift.E
        ne = new == Shift.E
        if oe != ne:
            self._day_e[day] += 1 if ne else -1
        in_leader_8a = (sid, day) in self.leader_8a
        opr = (old == Shift.PRN) or (in_leader_8a and old in (Shift.A8, Shift.A9))
        npr = (new == Shift.PRN) or (in_leader_8a and new in (Shift.A8, Shift.A9))
        if opr != npr:
            self._day_prn[day] += 1 if npr else -1

    # ---------- 이전 근무 조회 (월경계 포함) ----------
    def shift_before(self, sid: str, day: int) -> Optional[Shift]:
        """day-1의 근무. day==0이면 전월 말 상태에서 추정."""
        if day - 1 >= 0:
            return self.grid[sid][day - 1]
        co = self.carryover[sid]
        if day == 0:
            return co.last_shift_type
        # day == -1 (전전일): 정확한 데이터 없음 → 보수적으로 추정
        if co.trailing_night_count >= 2:
            return Shift.N
        if co.night_block_remaining_off >= 2:
            return Shift.N
        return Shift.OFF

    def effective(self, sid: str, day: int) -> Shift:
        """패턴 검사용: 월 범위 밖/미배정은 OFF로 간주."""
        if day < 0:
            s = self.shift_before(sid, day + 1)
            return s if s is not None else Shift.OFF
        if day >= self.num_days:
            return Shift.OFF
        v = self.grid[sid][day]
        return v if v is not None else Shift.OFF

    # ---------- 집계 ----------
    # 아래 4개 run 함수는 항상 0<=day<num_days 범위(또는 day==num_days, 그 경우
    # 루프가 즉시 종료되어 effective()의 day>=num_days 분기와 결과가 같음)로만
    # 호출된다 — 그래서 매 반복마다 effective()를 호출하는 대신 grid를 직접 읽는다
    # (호출 함수 한 겹을 줄이는 성능 최적화, day<0 이월 처리 로직은 그대로 유지).
    def work_run_ending(self, sid: str, day: int) -> int:
        """day를 포함해 뒤로 이어진 연속 근무일수(전월 이월 포함)."""
        row = self.grid[sid]
        run = 0
        d = day
        while d >= 0:
            v = row[d]
            if (Shift.OFF if v is None else v) not in WORK_SHIFTS:
                break
            run += 1
            d -= 1
        if d < 0 and run == day + 1:
            co = self.carryover[sid]
            if co.last_shift_type in WORK_SHIFTS:
                run += co.consecutive_work_days
        return run

    def work_run_starting(self, sid: str, day: int) -> int:
        row = self.grid[sid]
        nd = self.num_days
        run = 0
        d = day
        while d < nd:
            v = row[d]
            if (Shift.OFF if v is None else v) not in WORK_SHIFTS:
                break
            run += 1
            d += 1
        return run

    def day_work_run_ending(self, sid: str, day: int) -> int:
        """day를 포함해 뒤로 이어진 연속 D/E/prn 근무일수(H6-1용, 전월 이월 근사 포함)."""
        row = self.grid[sid]
        run = 0
        d = day
        while d >= 0:
            v = row[d]
            if (Shift.OFF if v is None else v) not in DAY_WORK_SHIFTS:
                break
            run += 1
            d -= 1
        if d < 0 and run == day + 1:
            co = self.carryover[sid]
            if co.last_shift_type in DAY_WORK_SHIFTS:
                run += co.consecutive_work_days
        return run

    def day_work_run_starting(self, sid: str, day: int) -> int:
        row = self.grid[sid]
        nd = self.num_days
        run = 0
        d = day
        while d < nd:
            v = row[d]
            if (Shift.OFF if v is None else v) not in DAY_WORK_SHIFTS:
                break
            run += 1
            d += 1
        return run

    def nights_in_month(self, sid: str) -> int:
        return self._night_count[sid]

    def workdays_in_month(self, sid: str) -> int:
        return self._wd_count[sid]

    def offs_in_month(self, sid: str) -> int:
        return self._off_count[sid]

    def als_in_month(self, sid: str) -> int:
        return self._al_count[sid]

    def weekend_workdays_in_month(self, sid: str) -> int:
        return self._weekend_wd_count[sid]

    def last_night_day(self, sid: str, before_day: int) -> Optional[int]:
        for d in range(before_day - 1, -1, -1):
            if self.grid[sid][d] in NIGHT_SHIFTS:
                return d
        return None

    def count_shift(self, day: int, shift: Shift) -> int:
        """일별 인원 합계 (H1-1/H1-4: 파트장 제외, 리더 8A는 prn으로 계산)."""
        if shift == Shift.N:
            return self._day_n[day]
        if shift == Shift.D:
            return self._day_d[day]
        if shift == Shift.E:
            return self._day_e[day]
        if shift == Shift.PRN:
            return self._day_prn[day]
        # 그 외 근무유형은 실사용 경로가 없으나(D/E/N/prn만 호출됨) 안전망으로 유지
        n = 0
        for s in self.staff:
            if s.is_partjang:
                continue
            v = self.grid[s.id][day]
            if v == shift:
                n += 1
        return n

    def night_cap(self, sid: str, base_cap: int) -> int:
        return self.relaxed_night_cap.get(sid, base_cap)

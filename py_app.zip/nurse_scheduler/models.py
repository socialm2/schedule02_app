# -*- coding: utf-8 -*-
"""데이터 모델: Staff, Shift, Carryover, MonthSchedule (설계서 §0, 부록 B)."""
from __future__ import annotations

import calendar as _cal
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Set, Tuple


class Shift(str, Enum):
    A8 = "8A"
    A9 = "9A"          # 09:00~ 시작(8A와 동격, 시작시각만 다름) — 병원 표준 코드
    A10 = "10A"        # 10:00~ 시작(8A와 동격, 시작시각만 다름) — 병원 표준 코드
    D = "D"
    E = "E"
    N = "N"
    NK = "NK"
    PRN = "prn"
    OFF = "OFF"
    AL = "연차"
    EDU = "T"        # 교육 — 근무일수 0(공가처럼), 최소인력 제외, 연속근무엔 포함
    BEREAVE = "조"     # 조사(예: 사망) — 관리자 지정, 근무인력 제외
    CELEBRATE = "경"   # 경조사(예: 결혼) — 관리자 지정, 근무인력 제외
    AL_1H = "연1"      # 연차(시간제, 1시간) — 연4와 같은 계열, 세부 시간 구분 없이 휴가로 집계
    AL_2H = "연2"      # 연차(시간제, 2시간)
    AL_3H = "연3"      # 연차(시간제, 3시간)
    AL_HALF = "연4"    # 연차(반차) — 0.5 연차 + 0.5 근무
    OFFICIAL = "공"    # 공가 — OFF와 동일 취급, 연차 카운트/잔휴 미반영
    SICK = "병"        # 병가 — 연속근무일수(H3-1 포함) 계산에서 제외
    LEAVE = "휴"       # 휴직 — 적은 날짜 하루만 제외(월 나머지 자동채움 없음, 파트장이 날짜마다 지정)
    PROMO_EDU = "승"   # 승급교육 — 공가와 동일 취급
    SLEEP_OFF = "S/"   # 수면오프(야간 근무 뒤 의무 휴식) — 관리자 지정, 잔휴 미반영
    TW = "TW"          # 반근무+반교육(신입/B팀 대상) — 근무일수 포함, 최소인력 제외
    MIL = "군"          # 군 관련 공가 — 공가와 동일 취급

    # ================================================================ 병원 OCS 근무코드
    # 아래는 **엔진이 배정하지 않고 읽기만 하는** 코드다. 파트장이 손으로 넣거나 병원
    # OCS 지난달 근무표에서 넘어온다.
    #
    # 왜 넣나 — 모르는 코드는 반려되지 않고 '빈 칸'이 되는데, 빈 칸은 하류에서 OFF로
    # 처리된다. 즉 **실제로 근무한 날이 쉰 날로 계산**돼 연속근무일수·누적근무일·이월
    # 야간블록이 조용히 틀어진다. 오류도 경고도 없이 다음 달 근무표만 틀리는, 이
    # 프로젝트가 제일 무서워하는 부류다.
    #
    # 배정에는 쓰이지 않는다 — Staff.allowed_shifts에 안 들어가므로 can()이 막고,
    # 생성기도 D/E/N/NK/prn/8A/OFF/연차만 넣는다. 여기 있는 값의 역할은 오직
    # "그날 근무했는가 쉬었는가"를 정확히 아는 것이다.
    # ---- 주간 근무: 출근시각만 다름 (읽기 전용 — 엔진이 배정하지 않는다)
    T05 = "5A"                        # 05:00~
    T05_HALF = "5AH"                  # 05:00~ (Half근무)
    T05_INJ = "5M"                    # 05:00~ (7시간) 주사실
    T06 = "6A"                        # 06:00~
    T07 = "7A"                        # 07:00~
    T07_17 = "7A(10"                  # 07:00~17:00
    T07_18 = "7A(11"                  # 07:00~18:00
    T0730 = "7H"                      # 07:30~
    T08_18 = "8A(10"                  # 08:00~18:00
    T08_17 = "8A*"                    # 08:00~17:00
    T08_HALF = "8AH"                  # 08:00~ (Half근무)
    T08_BAL = "8A◎"                   # 08:00~ (0.5일 잔휴수당)
    T0830 = "8H"                      # 08:30~
    T09_HALF = "9AH"                  # 09:00~ (Half근무)
    T0930 = "9H"                      # 09:30~
    T09_1330 = "9H*"                  # 09:00~13:30
    T1030 = "10H"                     # 10:30~
    T11 = "11A"                       # 11:00~
    T11_20 = "11*"                    # 11:00~20:00
    T1330 = "13H"                     # 13:30~
    T13 = "1P"                        # 13:00~
    T13_22 = "1P*"                    # 전달 1P~10P
    MD = "MD"                         # MD~
    # ---- Half 근무
    #
    # 근무일수를 얼마로 세는지는 이 묶음이 아니라 HALF_WORK_SHIFTS와
    # WORKDAY_UNIT_OVERRIDES가 정한다 — 반일이 여기에만 있는 것이 아니고
    # (5AH·8AH·9AH·9H*는 위 '주간 근무' 묶음에 있다), 이름이 아니라 실제 근무시간이
    # 기준이라 두 목록은 원래 어긋난다. 세는 쪽은 항상 그쪽을 본다.
    D_HALF = "DH"                     # Day Half
    E_HALF = "EH"                     # Evening Half
    EDU_PM = "TDH"                    # D half + 오후교육 → 근무는 0.5
    EDU_AM = "TEH"                    # 오전교육 + E half → 근무는 0.5
    EDU_HALF = "TH"                   # 반일 교육
    # ---- PRN·회복성 근무
    D_PRN = "DP"                      # Day PRN
    E_PRN = "EP"                      # Evening PRN
    RECOVER_D = "RD"                  # 회복성 Day
    RECOVER_E = "RE"                  # 회복성 Evening
    RECOVER_P = "RP"                  # 회복성 PRN
    # ---- 잔휴수당이 붙은 근무
    D_BAL = "D◎"                      # Day (잔휴수당)
    E_BAL = "E◎"                      # Evening (잔휴수당)
    # ---- 공가+연차 조합
    # 대휴(F) 계열 14종(F·F1~F6·F8·특F·2연·4연·6연·8연H·8T연)은 이 병원에서 쓰지 않아
    # 뺐다(파트장 확인, 2026-08). '8공연'만 실제 근무표에 남아 있어 유지한다.
    OFFICIAL_AL_8H = "8공연"            # 8hr (공가+연차)
    # ---- 연차 변형
    AL_6H = "연6"                      # 6hr 연차 → 근무는 0.25
    # ---- 공가 계열
    OFFICIAL_4H = "공4"                # 4hr 공가 (태아검진 포함)
    QUARANTINE = "격"                  # 감염병 관련 공가
    OFFICIAL_COUNCIL = "원"            # 원무협의회 관련 공가
    OFFICIAL_AWARD = "포"              # 포상 관련 공가
    OFFICIAL_HEALING = "힐"            # 힐링 관련 공가
    # ---- 단기 휴가
    FAMILY_CARE = "가"                 # 가족돌봄휴가
    FERTILITY = "난"                   # 난임치료휴가
    MENSTRUAL = "생"                   # 생리휴가(무급)
    LONG_SERVICE = "근"                # 근속휴가 — 잔휴를 깎지 않는다
    MISCARRIAGE = "유"                 # 유사산휴가
    BIRTH = "출"                       # 출산
    SPECIAL_LEAVE = "특"               # 특휴
    WEDDING_SELF = "결*"               # 본인 결혼
    BEREAVE_CLOSE = "조*"              # 사망 — 배우자·(배우자)부모
    # ---- 장기 부재(휴직·장기휴가) — H4-2 '원치 않는 장기 OFF'로 세지 않는다
    RECHARGE = "R"                    # Recharging휴직 / Restart휴가
    LEAVE_PERSONAL = "사"              # 사사휴직
    LEAVE_PRENATAL = "산전"             # 산전휴직(육아연장휴가)
    LEAVE_INJURY = "상"                # 상병휴직
    LEAVE_CHILDCARE = "육법"            # 육아휴직 — 법정(1년)
    LEAVE_CHILDCARE_EXT = "육법*"       # 육아휴직 — 법정연장 추가
    LEAVE_CHILDCARE_LONG = "육연"       # 육아휴직 — 연장
    LEAVE_MATERNITY = "출산"            # 출산전후휴가(90일)

    def __str__(self) -> str:  # 엑셀/리포트 출력용
        return self.value


# 연간근무표(출력②)·월간근무표(출력①) 맨 아래 요약 블록의 라벨.
#
# **쓰는 쪽과 읽는 쪽이 반드시 같은 목록을 봐야 한다.** 내보내기에만 줄을 늘리고 파서가
# 모르면 그 라벨이 사람 이름으로 읽혀 유령 인원이 생기고, 반대로 파서만 알면 요약 줄
# 뒤에 붙은 진짜 사람이 조용히 잘린다. 그래서 목록을 여기 하나만 둔다.
STAFF_TABLE_SUMMARY_LABELS = ("D 인원", "E 인원", "N 인원", "prn 인원",
                              "레벨평균", "Lv4-5", "Lv1-3")

WORK_SHIFTS = {Shift.A8, Shift.A9, Shift.A10, Shift.D, Shift.E, Shift.N, Shift.NK,
               Shift.PRN, Shift.EDU, Shift.TW,
    # 읽기 전용 OCS 근무코드 — 배정은 안 되지만 '그날 근무했다'로 세야 한다
    Shift.T05, Shift.T05_HALF, Shift.T05_INJ, Shift.T06, Shift.T07, Shift.T07_17,
    Shift.T07_18, Shift.T0730, Shift.T08_18, Shift.T08_17, Shift.T08_HALF, Shift.T08_BAL,
    Shift.T0830, Shift.T09_HALF, Shift.T0930, Shift.T09_1330, Shift.T1030, Shift.T11,
    Shift.T11_20, Shift.T1330, Shift.T13, Shift.T13_22, Shift.MD, 
    Shift.D_HALF, Shift.E_HALF, Shift.EDU_PM, Shift.EDU_AM, Shift.EDU_HALF, Shift.D_PRN,
    Shift.E_PRN, Shift.RECOVER_D, Shift.RECOVER_E, Shift.RECOVER_P, Shift.D_BAL, Shift.E_BAL,
}
NIGHT_SHIFTS = {Shift.N, Shift.NK,
}
REST_SHIFTS = {
    Shift.OFF, Shift.AL, Shift.BEREAVE, Shift.CELEBRATE,
    Shift.AL_1H, Shift.AL_2H, Shift.AL_3H, Shift.AL_HALF,
    Shift.OFFICIAL, Shift.SICK, Shift.LEAVE, Shift.PROMO_EDU,
    Shift.SLEEP_OFF, Shift.MIL,
    # 읽기 전용 OCS 휴무코드
    
    Shift.OFFICIAL_AL_8H, Shift.AL_6H, Shift.OFFICIAL_4H,
    Shift.QUARANTINE, Shift.OFFICIAL_COUNCIL, Shift.OFFICIAL_AWARD, Shift.OFFICIAL_HEALING, Shift.FAMILY_CARE,
    Shift.FERTILITY, Shift.MENSTRUAL, Shift.LONG_SERVICE, Shift.MISCARRIAGE, Shift.BIRTH, Shift.SPECIAL_LEAVE, Shift.WEDDING_SELF,
    Shift.BEREAVE_CLOSE, Shift.RECHARGE, Shift.LEAVE_PERSONAL, Shift.LEAVE_PRENATAL, Shift.LEAVE_INJURY, Shift.LEAVE_CHILDCARE,
    Shift.LEAVE_CHILDCARE_EXT, Shift.LEAVE_CHILDCARE_LONG, Shift.LEAVE_MATERNITY,
}
#: 장기 부재(휴직·출산휴가 등) — H4-2 '신청 안 한 연속휴무 5일 이상 금지'가 세면 안 된다.
#: 파트장이 지정한 부재를 '원치 않는 장기 OFF'로 잡으면, 사람이 고칠 수도 없는 위반이
#: 근무표에 상시로 붙는다(휴직에서 실제로 그랬다).
LONG_ABSENCE_SHIFTS = {
    # '휴'는 두 가지로 쓰인다 — 파트장이 찍는 단기부모휴가이면서, 엔진이 월중 전입자의
    # '입사 전 날짜'를 막을 때도 이 코드를 쓴다(lock_pre_join_days). 입사 전 20일이
    # 통째로 '원치 않는 장기 OFF'로 잡히면 사람이 고칠 수도 없는 위반이 붙으므로
    # 여기 남겨둔다. (그 달 나머지를 자동으로 '휴'로 채우던 동작은 없앴다 — 파트장이
    # 지정한 날만 제외한다.)
    Shift.LEAVE,
    Shift.RECHARGE, Shift.LEAVE_PERSONAL, Shift.LEAVE_PRENATAL, Shift.LEAVE_INJURY, Shift.LEAVE_CHILDCARE, Shift.LEAVE_CHILDCARE_EXT,
    Shift.LEAVE_CHILDCARE_LONG, Shift.LEAVE_MATERNITY,
}
#: 하루를 온전히 쓰지 않은 근무 — 누적 근무일수를 소수로 센다.
#:
#: 하루를 1로만 세면 반일 근무가 온종일 근무와 같아져 누적근무일이 실제보다 많아지고,
#: 그 숫자로 형평성을 보는 파트장이 "저 사람은 많이 했다"고 잘못 읽는다.
#:
#: 시간제 연차·공가는 **쉰 시간을 뺀 나머지가 근무**다 — 연1(1시간 연차)은 8시간 중
#: 7시간을 일했으므로 0.875다. 연N의 N이 곧 쉰 시간이라 1 − N/8로 떨어진다
#: (연1 .875 · 연2 .75 · 연3 .625 · 연4 .5 · 연6 .25). 공4(4시간 공가)도 같은 계산으로 0.5.
#: 이 코드들은 REST_SHIFTS에 있어 배정에서는 여전히 '휴가'로 다루고, 여기서 정하는
#: 것은 **연간근무표의 누적근무일 하나뿐**이다(파트장 확인, 2026-08).
HALF_WORK_SHIFTS = {
    Shift.T05_HALF, Shift.T08_HALF, Shift.T09_HALF,
    Shift.D_HALF, Shift.E_HALF, Shift.EDU_HALF,
    # 9H*(09:00~13:30)는 코드 이름에 'Half'가 없지만 4시간 반이라 실질이 반일이다.
    # 표기가 아니라 실제 근무시간을 기준으로 센다.
    Shift.T09_1330,
    # 반일 근무 + 반일 교육. 교육이 근무일에 안 들어가므로(아래 EDU 참고) 남는 근무는
    # 반일뿐이다 — TH와 같은 0.5다(파트장 확인).
    Shift.EDU_PM, Shift.EDU_AM,
}

#: 1.0도 0.0도 0.5도 아닌 근무일수. HALF_WORK_SHIFTS보다 우선한다.
WORKDAY_UNIT_OVERRIDES = {
    Shift.AL_1H: 0.875,      # 1시간 연차 → 7시간 근무
    Shift.AL_2H: 0.75,
    Shift.AL_3H: 0.625,
    Shift.AL_HALF: 0.5,      # 연4 = 4시간 연차(반차)
    Shift.AL_6H: 0.25,       # 연6 = 6시간 연차 → 2시간 근무
    Shift.OFFICIAL_4H: 0.5,  # 공4 = 4시간 공가
    # 교육(T)은 근무일수에 넣지 않는다 — 근무인력에서 빠지고 공가처럼 처리되기 때문이다
    # (파트장 확인). 다만 **연속근무일수(H3-1)에는 포함**돼야 하므로 WORK_SHIFTS에는
    # 그대로 둔다. 거기서 빼면 교육이 연속근무를 끊어버려 6일 연속이 통과한다.
    Shift.EDU: 0.0,
}


def workday_units(shift: "Shift") -> float:
    """그 칸이 근무일수로 얼마인지 — 온종일 1.0, 반일 0.5, 근무가 아니면 0.0.

    ⚠ 이 값은 **누적 통계(연간근무표의 누적근무일)** 전용이다. 배정 알고리즘이 쓰는
    MonthSchedule.workdays_in_month()는 정수 그대로 둔다 — 그쪽은 '몇 칸을 채웠나'로
    균등 배분을 계산하는 자리라 반일을 0.5로 바꾸면 비교 기준이 흔들린다. 게다가
    반일 코드는 엔진이 배정하지 않으므로(읽기 전용) 그 계산에 등장할 일도 없다.
    """
    if shift in WORKDAY_UNIT_OVERRIDES:
        return WORKDAY_UNIT_OVERRIDES[shift]
    if shift in HALF_WORK_SHIFTS:
        return 0.5
    return 1.0 if shift in WORK_SHIFTS else 0.0


#: prn으로 세는 근무코드 전부 — 하단 'prn 인원' 행, 레벨 통계, H1 최소인력 판정이
#: **모두 이 목록 하나만 본다.**
#:
#: 예전엔 세는 곳마다 목록이 따로였다. 인원 행은 prn·8A·9A·10A를, 레벨 행은 prn·8A만,
#: H1은 prn만 봤다 — 같은 날 같은 화면에서 "prn 3명"이라고 써놓고 그 아래 레벨 행은
#: 2명 기준으로 계산하고, 빨간 미달 표시는 또 다른 기준으로 붙었다. 어느 것이 맞는지
#: 화면만 봐서는 알 수가 없었다.
#:
#: 8A·9A·10A는 시작시각만 다른 같은 근무고, 8H·9H·10H도 30분 늦게 시작할 뿐이다.
#: 변형(8A*·8A(10·8AH·8A◎·9AH·9H*)도 마찬가지라 파트장 눈에는 전부 한 덩어리다
#: (파트장 확인, 2026-08).
PRN_LIKE_SHIFTS = {
    Shift.PRN,
    # 8시 계열
    Shift.A8, Shift.T08_17, Shift.T08_18, Shift.T08_HALF, Shift.T08_BAL, Shift.T0830,
    # 9시 계열
    Shift.A9, Shift.T09_HALF, Shift.T0930, Shift.T09_1330,
    # 10시 계열
    Shift.A10, Shift.T1030,
}


#: 하단 인원 4행(D·E·N·prn)에 잡히는 근무 전부 — '지정'을 셀 때 "그날 근무했는가"의
#: 기준이 이것이다. 파트장이 화면에서 보는 것과 같은 기준이어야 "DEN 수에 이미 들어
#: 있는 사람이 지정에도 잡힌다"는 설명이 성립한다.
#:
#: 여기 없는 근무(교육 T·읽기 전용 OCS 코드 대부분)는 인원 행에도 안 잡히므로 지정으로도
#: 안 센다 — 인원 행엔 없는데 지정에만 잡히면 파트장이 숫자를 맞춰볼 수가 없다.
COUNTED_WORK_SHIFTS = {Shift.D, Shift.E, Shift.N, Shift.NK} | PRN_LIKE_SHIFTS

#: 최소인력 표의 '지정' 행 키. D/E/N/prn과 같은 자리에 들어가지만 근무유형이 아니라
#: '그날 지정 가능자가 몇 명 근무해야 하는가'다. 0이면 지정을 쓰지 않는 병동이다.
#: 화면 최소인력 표·엑셀 양식·엔진이 전부 이 글자를 키로 쓴다.
DESIGNATED_KEY = "지정"


def prn_units(shift: "Shift") -> float:
    """그 칸이 'prn 인원' 몇 명치인지 — prn 계열이 아니면 0.0, 반일이면 0.5.

    ⚠ **인원 행과 H1 최소인력 판정 전용이다.** 아래 레벨 통계(레벨평균·Lv4-5·Lv1-3)는
    이 값을 쓰지 않고 사람 단위로 1명씩 센다 — 그쪽은 '그날 이 근무에 고랩이 있느냐'를
    보는 자리라, 반나절만 있어도 그 사람은 있는 것이기 때문이다(파트장 확인).

    반일 판정은 HALF_WORK_SHIFTS를 그대로 쓴다. 여기에 목록을 또 적으면 9H*처럼
    '이름엔 Half가 없지만 실질이 반일'인 코드를 한쪽에만 넣는 일이 생긴다.
    """
    if shift not in PRN_LIKE_SHIFTS:
        return 0.0
    return 0.5 if shift in HALF_WORK_SHIFTS else 1.0


#: flags 중 '가능근무 칸에서 온 것'과 그 칸에 다시 적을 글자.
#: 출력②(연간근무표)를 다음 달 입력②로 다시 올리는 것이 이 앱의 표준 흐름이라,
#: 여기서 안 적으면 **다음 달에 그 사람의 3N·지정이 조용히 사라진다.** 근무표는
#: 정상으로 나오고 오류도 없다 — 지정 인원이 하나 줄어든 채로.
ALLOWED_FLAG_TEXT = [("night_block_2", "2N"), ("night_block_3", "3N"),
                     ("designated", "지정")]


def allowed_shifts_text(allowed, flags) -> str:
    """가능근무 칸에 적을 글자 — 근무코드 + 2N/3N/지정."""
    vals = [a.value if isinstance(a, Shift) else str(a) for a in (allowed or [])]
    have = set(flags or [])
    vals += [text for flag, text in ALLOWED_FLAG_TEXT if flag in have]
    return ",".join(vals)


DAY_WORK_SHIFTS = {Shift.D, Shift.E, Shift.PRN}  # 주간 일반근무
LEAVE_SHIFTS = {
    Shift.AL, Shift.BEREAVE, Shift.CELEBRATE,
    Shift.AL_1H, Shift.AL_2H, Shift.AL_3H, Shift.AL_HALF,
    Shift.OFFICIAL, Shift.SICK, Shift.LEAVE, Shift.PROMO_EDU,
    Shift.SLEEP_OFF, Shift.MIL,
    
    Shift.OFFICIAL_AL_8H, Shift.AL_6H, Shift.OFFICIAL_4H,
    Shift.QUARANTINE, Shift.OFFICIAL_COUNCIL, Shift.OFFICIAL_AWARD, Shift.OFFICIAL_HEALING, Shift.FAMILY_CARE,
    Shift.FERTILITY, Shift.MENSTRUAL, Shift.LONG_SERVICE, Shift.MISCARRIAGE, Shift.BIRTH, Shift.SPECIAL_LEAVE, Shift.WEDDING_SELF,
    Shift.BEREAVE_CLOSE, Shift.RECHARGE, Shift.LEAVE_PERSONAL, Shift.LEAVE_PRENATAL, Shift.LEAVE_INJURY, Shift.LEAVE_CHILDCARE,
    Shift.LEAVE_CHILDCARE_EXT, Shift.LEAVE_CHILDCARE_LONG, Shift.LEAVE_MATERNITY,
}  # OFF를 제외한 각종 휴가/휴직 유형 (표시·통계 구분용, 잔휴 계산에서 제외)


_OFF_ALIASES = {"X", "/"}  # 원티드 오프(X)/일반 오프(/) — 출력 표시용, 내부적으로는 둘 다 OFF
_AL_ALIASES = {"연"}  # 병원 OCS 원본에서 "연차"를 줄여 "연"으로 표기(§연*=53건 확인)

#: 근무 칸 뒤에 붙는 병원 HR 집계 표식. 근무 종류가 아니라 꼬리표다.
#:
#: ®·ⓡ는 원래 OCS 월간표의 **집계 열 이름**이다(D·E·N 개수 다음, 금월·T연·R연 앞).
#: 그런데 근무 칸 안에 붙어 오는 병동이 있다 — B11 2026-01~02에 D®·Dⓡ·E® 15칸.
#: 뜻은 "그날 D(또는 E) 근무를 했고 HR의 ® 항목에도 함께 집계된다"이지 다른 근무가
#: 아니다(파트장 확인, 2026-08). 벗기지 않으면 'D®'가 통째로 미인식이 돼 그 칸이
#: 빈 칸이 되고, **빈 칸은 하류에서 오프로 처리된다** — 근무한 날이 쉰 날로 계산돼
#: 연속근무일수·누적근무일·이월 야간블록이 오류도 경고도 없이 틀어진다.
_HR_TALLY_MARKS = "®ⓡ"


def parse_shift(value: str) -> Shift:
    # ⚠ '*'를 벗기기 **전에** 정확히 일치하는 코드를 먼저 찾는다.
    #
    # 병원 OCS에서 '*'는 두 가지로 쓰인다 — 어떤 코드에선 '희망(원티드)' 표시고
    # (D*=희망Day, E*, N*, 연*), 어떤 코드에선 **이름의 일부**다(11*=11:00~20:00,
    # 당*=전일정규+당직, 결*=본인결혼, 조*=사망-배우자·부모, 육법*=법정연장).
    # 무조건 벗기면 뒤쪽이 다른 코드로 읽힌다 — 조*(사망)가 조(조사 외 휴가)가 되고,
    # 11*(11:00~20:00)은 존재하지 않는 '11'이 돼 통째로 안 읽혔다.
    # 정확히 일치하는 것을 먼저 보면 둘 다 제대로 읽히고, 화면·엑셀에도 원래 표기가
    # 그대로 남아 파트장이 구분해서 볼 수 있다.
    for s in Shift:
        if s.value == value:
            return s
    # HR 집계 표식(®·ⓡ)을 벗긴다. '*'와 달리 이름의 일부인 코드가 하나도 없어
    # 정확히 일치하는 것을 먼저 본 뒤라면 무조건 벗겨도 안전하다.
    stripped = value.rstrip(_HR_TALLY_MARKS)
    if stripped and stripped != value:
        value = stripped
        for s in Shift:
            if s.value == value:
                return s
    if value.endswith("*") and value != "*":
        value = value[:-1]  # 여기까지 왔으면 '희망' 표시다 — 벗기고 다시 찾는다
    for s in Shift:
        if s.value == value:
            return s
    if value in _OFF_ALIASES:
        return Shift.OFF
    if value in _AL_ALIASES:
        return Shift.AL
    # 대소문자만 다른 경우 구제(예: "PRN"↔"prn") — 코드값 간 대소문자 무시 충돌은 없음
    for s in Shift:
        if s.value.lower() == value.lower():
            return s
    raise ValueError(f"알 수 없는 근무유형: {value!r}")


@dataclass
class Staff:
    id: str
    role: str  # 파트장 | 리더 | 간호사
    level: int
    allowed_shifts: List[Shift]
    flags: List[str] = field(default_factory=list)

    def __post_init__(self):
        # role/flags/allowed_shifts는 생성 후 변경되지 않으므로(엔진 전체에서 재대입
        # 없음 확인됨) 매번 다시 계산하는 @property 대신 1회만 계산해 저장한다 —
        # can_assign_day 등 초당 수백만 번 읽는 핫패스 성능 최적화, 값의 의미는 동일.
        self.is_partjang: bool = self.role == "파트장"
        self.is_leader: bool = self.role == "리더"
        self.is_nk: bool = ("night_only" in self.flags
                            or self.allowed_shifts == [Shift.NK])
        self.no_night: bool = "pregnant" in self.flags or "no_night" in self.flags
        # 야간 블록을 몇 일씩 묶어 서고 싶은가 — 가능근무 칸의 2N/3N에서 온다.
        # **아무것도 안 적으면 2다.** 하드 규칙(H2-3)이 원래 2일 블록까지만 허용했으므로,
        # 기본을 2로 두면 기존 입력파일을 그대로 올려도 결과가 안 바뀐다.
        self.night_block_pref: int = 3 if "night_block_3" in self.flags else 2
        # 가능근무 칸에 2N/3N을 **직접 적었는지**. 안 적은 사람은 기본값 2로 돌지만
        # S12(선호와 다른 길이)는 남기지 않는다 — 목표가 홀수인 달에는 3일 블록이
        # 규칙상 필요한데, 안 적은 사람까지 전부 위반으로 남기면 그 달 소프트 위반이
        # 인원 수만큼 늘어 진짜 볼 것이 묻힌다.
        self.night_block_pref_set: bool = ("night_block_2" in self.flags
                                           or "night_block_3" in self.flags)
        # 지정 인원으로 셀 수 있는 사람인가 — 가능근무 칸의 '지정'에서 온다.
        # 이 사람이 그날 D·E·N·prn 아무거나 서면 그날 지정 1명으로 자동으로 세진다.
        self.is_designated: bool = "designated" in self.flags

    def can(self, shift: Shift) -> bool:
        if shift in REST_SHIFTS or shift in (Shift.EDU, Shift.TW):
            return True
        if shift in NIGHT_SHIFTS and self.no_night:
            return False
        return shift in self.allowed_shifts


@dataclass
class Carryover:
    """전월 말 상태 (H5-3, 부록 A)."""
    last_shift_type: Shift = Shift.OFF
    consecutive_work_days: int = 0
    night_block_remaining_off: int = 0  # 이번 달 초에 이월해야 할 필수 OFF 일수
    night_block_in_progress: bool = False
    trailing_night_count: int = 0  # 전월 말에 이어지던 야간블록 길이(0=없음)
    recent_night_score: float = 0.0  # 최근 몇 달간의 야간 누적(감쇠) — 야간 배정 형평성용
    off_balance: float = 0.0  # 전월말 기준 잔휴(정상 오프 누적잔액) — 병원 표준 '잔휴' 칸

    @classmethod
    def from_dict(cls, d: Optional[dict]) -> "Carryover":
        if not d:
            return cls()
        trailing = int(d.get("trailing_night_count", 0))
        in_prog = bool(d.get("night_block_in_progress", False))
        if in_prog and trailing == 0:
            trailing = 1
        return cls(
            last_shift_type=parse_shift(d.get("last_shift_type", "OFF")),
            consecutive_work_days=int(d.get("consecutive_work_days", 0)),
            night_block_remaining_off=int(d.get("night_block_remaining_off", 0)),
            night_block_in_progress=in_prog,
            trailing_night_count=trailing,
            recent_night_score=float(d.get("recent_night_score", 0.0)),
            off_balance=float(d.get("off_balance", 0.0)),
        )


@dataclass
class Request:
    """원티드(신청). 리스트 순서 = 제출 순서(선착순, §5)."""
    staff_id: str
    date: str  # YYYY-MM-DD
    type: Shift
    priority: int = 1
    # 처리 결과
    accepted: Optional[bool] = None
    reject_reason: str = ""

    @property
    def day_index_cache(self):
        return None


@dataclass
class Violation:
    rule: str          # 예: "H1-1", "S7"
    severity: str      # hard | soft | info
    message: str
    staff_id: str = ""
    day: Optional[int] = None  # 0-based


class _TrackedRow(list):
    """한 직원의 grid 행. 모든 원소 쓰기(단일/슬라이스, sch.set()이든 grid[sid][d]=v
    직접 대입이든)를 가로채 MonthSchedule의 증분 집계 카운터를 갱신한다 — 매 호출마다
    월 전체를 다시 훑는 workdays_in_month/offs_in_month/count_shift 등을 O(1)로
    만들기 위함(엔진 알고리즘 성능 최적화). 값 자체의 의미는 그대로이므로 결과는
    최적화 이전과 완전히 동일해야 한다."""

    def __init__(self, iterable, sch: "MonthSchedule", sid: str):
        super().__init__(iterable)
        self._sch = sch
        self._sid = sid

    def __setitem__(self, key, value):
        sch = self._sch
        sid = self._sid
        if isinstance(key, slice):
            idxs = range(*key.indices(len(self)))
            old_vals = [list.__getitem__(self, i) for i in idxs]
            list.__setitem__(self, key, value)
            for i, old in zip(idxs, old_vals):
                new = list.__getitem__(self, i)
                if old != new:
                    sch._on_cell_change(sid, i, old, new)
        else:
            day = key if key >= 0 else key + len(self)
            old = list.__getitem__(self, key)
            list.__setitem__(self, key, value)
            new = list.__getitem__(self, key)
            if old != new:
                sch._on_cell_change(sid, day, old, new)


class MonthSchedule:
    """한 달 근무표. grid[staff_id][day] = Shift 또는 None(미배정)."""

    def __init__(self, year: int, month: int, staff: List[Staff],
                 carryover: Dict[str, Carryover], team_b: Optional[List[str]] = None):
        self.year = year
        self.month = month
        self.num_days = _cal.monthrange(year, month)[1]
        self.staff: List[Staff] = staff
        self.by_id: Dict[str, Staff] = {s.id: s for s in staff}
        # 원본 입력 순서(재시도 seed>0에서 self.staff 자체가 검색 다양성을 위해
        # 섞이므로, 출력용 정렬은 리스트 순서 대신 이 매핑을 따로 참조해야 한다.
        # Generator가 셔플 전에 채워준다 — 미설정(직접 MonthSchedule 구성 등)이면
        # 빈 dict로 두고 호출부에서 폴백 처리).
        self.orig_staff_order: Dict[str, int] = {}
        # 사람별 '이번 달 첫날' 인덱스 — 보통 0(1일)이지만 월중 전입자는 입사일이다.
        # 이월정보(전월 마지막 근무·연속근무일수·이월 야간)를 어느 날에 붙여야 하는지의
        # 기준점이라, 블록 경계를 다루는 검사(night_blocks, _day_work_blocks)가 0 대신
        # 이 값을 봐야 월중 전입자도 계속근무자와 같은 판정을 받는다. Generator가
        # 채워준다 — 미설정(직접 MonthSchedule 구성 등)이면 빈 dict라 전부 0으로 폴백.
        self.month_start_day: Dict[str, int] = {}
        self.carryover: Dict[str, Carryover] = {
            s.id: carryover.get(s.id, Carryover()) for s in staff
        }
        # B팀(신입) — 스케줄링/최소인력/제약검사 전부 미개입. 파트장이 직접 배정한다.
        self.team_b_names: List[str] = list(team_b or [])
        # 그 '직접 배정'을 담아두는 자리. 이름 → 날짜별 근무코드(문자열, 빈칸은 "").
        # 엔진은 이 값을 읽지도 쓰지도 않는다 — 화면에서 파트장이 채워 넣으면 앱이
        # 여기에 얹어주고, 출력 엑셀이 그대로 받아 적는다. 예전엔 담을 자리가 없어서
        # 화면에도 파일에도 빈칸으로만 나갔고, 파트장은 받은 엑셀을 다시 열어 손으로
        # 채워야 했다. 인원 수·레벨 통계에는 여전히 안 들어간다(신입이라 정원 밖이다).
        self.team_b_grid: Dict[str, List[str]] = {}
        # 증분 집계 카운터(성능 최적화용) — 전부 grid가 비어있는 초기상태(None) 기준 0.
        self._wd_count: Dict[str, int] = {s.id: 0 for s in staff}
        self._off_count: Dict[str, int] = {s.id: 0 for s in staff}
        self._night_count: Dict[str, int] = {s.id: 0 for s in staff}
        self._al_count: Dict[str, int] = {s.id: 0 for s in staff}
        self._weekend_wd_count: Dict[str, int] = {s.id: 0 for s in staff}
        self._weekend_days: Set[int] = set()
        self._day_d = [0] * self.num_days
        self._day_e = [0] * self.num_days
        self._day_n = [0] * self.num_days
        # prn은 반일 코드(8AH·9AH·9H*)를 0.5로 세므로 실수다 — PRN_LIKE_SHIFTS 참고.
        self._day_prn = [0.0] * self.num_days
        # 그날 근무 중인 '지정' 가능자 수. 반일도 1명으로 센다 — 지정은 '그 사람이
        # 그날 병동에 있는가'를 보는 값이라 근무시간 길이와 무관하다(파트장 확인).
        self._day_designated = [0] * self.num_days
        self.grid: Dict[str, List[Optional[Shift]]] = {
            s.id: _TrackedRow([None] * self.num_days, self, s.id) for s in staff
        }
        self.locked: Set[Tuple[str, int]] = set()
        # 리더가 8A(prn형)를 서는 칸 (§0.3): 표시는 8A, 인력합계는 prn으로 계산
        self.leader_8a: Set[Tuple[str, int]] = set()
        # H2-9 완화로 개인별 상향된 야간 상한
        self.relaxed_night_cap: Dict[str, int] = {}
        # 승인된 OFF/연차 신청일 (S8 판단용): {(staff_id, day)}
        self.requested_off: Set[Tuple[str, int]] = set()
        # 원티드(신청 채택분 + 리더 수정고정분) — 근무표 표시용(*): {(staff_id, day)}
        self.wanted: Set[Tuple[str, int]] = set()
        # 개인별 이번 달 나이트 목표(4 또는 6, 야간전담 제외) — H6-4 판정용
        self.night_target: Dict[str, int] = {}
        self.logs: List[str] = []
        # generate_best()가 재시도 시간예산을 넘겨 중단했을 때만 True — 화면에서
        # "결과가 나빠서"가 아니라 "시간이 부족해서" 멈췄음을 구분해 보여주는 용도.
        self.timed_out: bool = False

    # ---------- 기본 접근 ----------
    def get(self, sid: str, day: int) -> Optional[Shift]:
        if 0 <= day < self.num_days:
            return self.grid[sid][day]
        return None

    def set(self, sid: str, day: int, shift: Shift, lock: bool = False):
        self.grid[sid][day] = shift
        if lock:
            self.locked.add((sid, day))

    def is_locked(self, sid: str, day: int) -> bool:
        return (sid, day) in self.locked

    def log(self, msg: str):
        self.logs.append(msg)

    # ---------- 증분 집계(성능 최적화) ----------
    def set_weekend_days(self, weekend_days: Set[int]):
        """토/일/공휴일 날짜 인덱스 집합을 등록한다(Generator가 달력 계산 직후 1회 호출).
        _pick_day_candidate의 주말근무일수(wk_load) 집계를 O(1)로 만들기 위함."""
        self._weekend_days = set(weekend_days)

    def mark_leader_8a(self, sid: str, day: int):
        """리더의 8A(prn형) 칸을 표시한다 — H1-2(근무유형 허용) 판정 전용.

        ⚠ 인원 합계는 여기서 건드리지 않는다. 8A·9A·10A는 이제 이 표시와 무관하게
        PRN_LIKE_SHIFTS에 들어 있어 항상 prn으로 세기 때문이다 — 예전처럼 여기서
        한 번 더 더하면 리더의 8A만 두 명으로 잡힌다.
        """
        self.leader_8a.add((sid, day))

    def _on_cell_change(self, sid: str, day: int, old: Optional[Shift],
                        new: Optional[Shift]):
        """grid[sid][day]가 old→new로 바뀔 때마다 호출(단일/슬라이스 대입 모두,
        sch.set()이든 grid[sid][d]=v 직접 대입이든 _TrackedRow가 가로채 호출한다).
        월 전체를 다시 훑던 workdays_in_month/offs_in_month/count_shift 등을
        O(1)로 만드는 증분 카운터를 갱신한다 — 최적화 전과 결과가 완전히 같아야 한다."""
        ow = old in WORK_SHIFTS
        nw = new in WORK_SHIFTS
        if ow != nw:
            self._wd_count[sid] += 1 if nw else -1
            if day in self._weekend_days:
                self._weekend_wd_count[sid] += 1 if nw else -1
        oo = old == Shift.OFF
        no = new == Shift.OFF
        if oo != no:
            self._off_count[sid] += 1 if no else -1
        on_ = old in NIGHT_SHIFTS
        nn = new in NIGHT_SHIFTS
        if on_ != nn:
            self._night_count[sid] += 1 if nn else -1
        oal = old == Shift.AL
        nal = new == Shift.AL
        if oal != nal:
            self._al_count[sid] += 1 if nal else -1

        staff = self.by_id.get(sid)
        if staff is None or staff.is_partjang:
            return
        if on_ != nn:
            self._day_n[day] += 1 if nn else -1
        od = old == Shift.D
        nd_ = new == Shift.D
        if od != nd_:
            self._day_d[day] += 1 if nd_ else -1
        oe = old == Shift.E
        ne = new == Shift.E
        if oe != ne:
            self._day_e[day] += 1 if ne else -1
        # prn 계열은 목록 하나(PRN_LIKE_SHIFTS)로만 판정한다. 리더 표시 여부와
        # 무관하게 8A·9A·10A가 전부 들어가고, 반일 코드는 0.5로 더해진다.
        opr = prn_units(old) if old is not None else 0.0
        npr = prn_units(new) if new is not None else 0.0
        if opr != npr:
            self._day_prn[day] += npr - opr
        if staff.is_designated:
            odg = old in COUNTED_WORK_SHIFTS
            ndg = new in COUNTED_WORK_SHIFTS
            if odg != ndg:
                self._day_designated[day] += 1 if ndg else -1

    # ---------- 이전 근무 조회 (월경계 포함) ----------
    def shift_before(self, sid: str, day: int) -> Optional[Shift]:
        """day-1의 근무. day==0이면 전월 말 상태에서 추정."""
        if day - 1 >= 0:
            return self.grid[sid][day - 1]
        co = self.carryover[sid]
        if day == 0:
            return co.last_shift_type
        # day == -1 (전전일): 정확한 데이터 없음 → 보수적으로 추정
        if co.trailing_night_count >= 2:
            return Shift.N
        if co.night_block_remaining_off >= 2:
            return Shift.N
        return Shift.OFF

    def effective(self, sid: str, day: int) -> Shift:
        """패턴 검사용: 월 범위 밖/미배정은 OFF로 간주."""
        if day < 0:
            s = self.shift_before(sid, day + 1)
            return s if s is not None else Shift.OFF
        if day >= self.num_days:
            return Shift.OFF
        v = self.grid[sid][day]
        return v if v is not None else Shift.OFF

    # ---------- 집계 ----------
    # 아래 4개 run 함수는 항상 0<=day<num_days 범위(또는 day==num_days, 그 경우
    # 루프가 즉시 종료되어 effective()의 day>=num_days 분기와 결과가 같음)로만
    # 호출된다 — 그래서 매 반복마다 effective()를 호출하는 대신 grid를 직접 읽는다
    # (호출 함수 한 겹을 줄이는 성능 최적화, day<0 이월 처리 로직은 그대로 유지).
    def work_run_ending(self, sid: str, day: int) -> int:
        """day를 포함해 뒤로 이어진 연속 근무일수(전월 이월 포함)."""
        row = self.grid[sid]
        run = 0
        d = day
        while d >= 0:
            v = row[d]
            if (Shift.OFF if v is None else v) not in WORK_SHIFTS:
                break
            run += 1
            d -= 1
        if d < 0 and run == day + 1:
            co = self.carryover[sid]
            if co.last_shift_type in WORK_SHIFTS:
                run += co.consecutive_work_days
        return run

    def work_run_starting(self, sid: str, day: int) -> int:
        row = self.grid[sid]
        nd = self.num_days
        run = 0
        d = day
        while d < nd:
            v = row[d]
            if (Shift.OFF if v is None else v) not in WORK_SHIFTS:
                break
            run += 1
            d += 1
        return run

    def day_work_run_ending(self, sid: str, day: int) -> int:
        """day를 포함해 뒤로 이어진 연속 D/E/prn 근무일수(H6-1용, 전월 이월 근사 포함)."""
        row = self.grid[sid]
        run = 0
        d = day
        while d >= 0:
            v = row[d]
            if (Shift.OFF if v is None else v) not in DAY_WORK_SHIFTS:
                break
            run += 1
            d -= 1
        if d < 0 and run == day + 1:
            co = self.carryover[sid]
            if co.last_shift_type in DAY_WORK_SHIFTS:
                run += co.consecutive_work_days
        return run

    def day_work_run_starting(self, sid: str, day: int) -> int:
        row = self.grid[sid]
        nd = self.num_days
        run = 0
        d = day
        while d < nd:
            v = row[d]
            if (Shift.OFF if v is None else v) not in DAY_WORK_SHIFTS:
                break
            run += 1
            d += 1
        return run

    def nights_in_month(self, sid: str) -> int:
        return self._night_count[sid]

    def workdays_in_month(self, sid: str) -> int:
        return self._wd_count[sid]

    def workday_units_in_month(self, sid: str) -> float:
        """누적 통계용 근무일수 — 반일 근무를 0.5로 센다(workday_units 참고).

        증분 카운터를 쓰지 않고 그때그때 훑는다. 이 값은 월말에 연간근무표를 만들 때
        한 번만 쓰이므로 비용이 문제되지 않고, 증분 방식은 셀을 지웠다 다시 채우는
        수리 과정에서 어긋나기 쉽다(예전에 그 드리프트로 실제 사고가 났다)."""
        return round(sum(workday_units(v) for v in self.grid[sid] if v is not None), 2)

    def offs_in_month(self, sid: str) -> int:
        return self._off_count[sid]

    def als_in_month(self, sid: str) -> int:
        return self._al_count[sid]

    def weekend_workdays_in_month(self, sid: str) -> int:
        return self._weekend_wd_count[sid]

    def last_night_day(self, sid: str, before_day: int) -> Optional[int]:
        for d in range(before_day - 1, -1, -1):
            if self.grid[sid][d] in NIGHT_SHIFTS:
                return d
        return None

    def count_shift(self, day: int, shift: Shift) -> float:
        """일별 인원 합계 (H1-1/H1-4: 파트장 제외).

        prn만 실수가 나올 수 있다 — 반일 코드(8AH·9AH·9H*)를 0.5로 세기 때문이다.
        D/E/N은 언제나 정수다."""
        if shift == Shift.N:
            return self._day_n[day]
        if shift == Shift.D:
            return self._day_d[day]
        if shift == Shift.E:
            return self._day_e[day]
        if shift == Shift.PRN:
            return self._day_prn[day]
        # 그 외 근무유형은 실사용 경로가 없으나(D/E/N/prn만 호출됨) 안전망으로 유지
        n = 0
        for s in self.staff:
            if s.is_partjang:
                continue
            v = self.grid[s.id][day]
            if v == shift:
                n += 1
        return n

    def designated_count(self, day: int) -> int:
        """그날 근무 중인 '지정' 가능자 수 (파트장 제외).

        가능근무 칸에 '지정'을 적은 사람이 그날 D·E·N·prn 중 무엇이든 서면 1명이다 —
        엔진이 따로 고르지 않는다(파트장 확인). 그래서 파트장은 입력표만 보고도
        "오늘 지정이 몇 명 가능한지"를 셀 수 있다."""
        return self._day_designated[day]

    def night_cap(self, sid: str, base_cap: int) -> int:
        return self.relaxed_night_cap.get(sid, base_cap)

"""화면을 처음 열었을 때 채워 넣을 기본값.

예전엔 이 값들이 `sample_input.xlsx`(옛 입력① '병동인력표' 양식)에서 왔다. 두 가지가
문제였다.

첫째, 그 파일이 안내 시트에서 스스로를 "입력① 병동인력표"라고 불렀다. 입력 번호를
재정리(②→①, ③→②)하면서 입력①은 원티드표가 됐는데 파일은 옛 이름 그대로였고,
배포판에 그대로 실려 URL로 받아졌다. 파트장이 그 말을 믿고 입력① 칸에 올리면
"월간근무표와 같은 모양인지 확인하세요"라는 엉뚱한 반려가 떠서 빠져나올 수가 없었다.

둘째, 설정·최소인력은 애초에 파일에서 올 이유가 없었다. 생성할 때 쓰는 값은 언제나
화면 칸에서 읽는다(app.js의 buildCfgFromForm). 파일의 값은 '첫 화면을 채우는 씨앗'일
뿐이었고, 씨앗이라면 코드에 있는 편이 낫다 — 파일이면 두 벌로 복사돼 갈라진다.

그래서 설정·최소인력은 여기로 옮기고, 명단만 파트장이 실제로 쓰는 양식(원티드표)에서
읽는다. 두 앱(webapp/app.py·pyodide-app/py/bridge.py)이 이 한 벌을 같이 import하므로
한쪽만 바뀌는 일이 없다.
"""

#: 입력① 양식과 같은 형식(원티드표)으로 만든 샘플 명단 파일 이름.
#: 파트장이 받는 양식은 화면의 현재 명단으로 그때그때 만들어 주므로(연월이 항상 맞다),
#: 이 파일은 '아직 아무것도 안 올린 상태'의 명단으로만 쓴다. 그래서 화면의 양식
#: 다운로드 버튼에는 걸지 않는다 — 걸면 연월이 박힌 옛 파일이 나간다.
SAMPLE_ROSTER_FILENAME = "입력1_원티드표_샘플.xlsx"

#: 근무정보·근무인력 칸의 첫 기본값. 파트장이 자기 병동 값으로 고치면 그 값이
#: 브라우저에 저장되고, 다음부터는 저장분이 이 값을 덮는다.
#:
#: 최소인력은 '파트장을 뺀' 숫자다(H1-1도 그렇게 본다). 이 값을 올리면 생성이 급격히
#: 어려워진다 — 40명 기준으로 전부 +1명만 해도 0.5초에서 15초가 된다(실측). 오프를 줄
#: 자리가 사라지기 때문이라, 기본값은 실제 병동에서 돌아가던 값을 그대로 둔다.
DEFAULT_PARAMS = {
    "min_staff": {
        "weekday": {"D": 9, "E": 9, "N": 6, "prn": 1},
        "saturday": {"D": 8, "E": 7, "N": 5, "prn": 0},
        "sunday_holiday": {"D": 7, "E": 8, "N": 6, "prn": 0},
    },
    "off_max_per_month": 6,        # 화면의 '월 최대야간'
    "max_consecutive_work": 5,     # 화면의 '연속근무제한'
    "night_quota_low": 4,
    "night_quota_high": 6,
    "max_requests_per_person": 20,
    "leader_8a_as_prn": False,
    "advanced_track_staff": [],
}


def default_params() -> dict:
    """DEFAULT_PARAMS의 깊은 사본 — 호출부가 고쳐도 원본이 안 바뀌게."""
    import copy
    return copy.deepcopy(DEFAULT_PARAMS)


def next_month(today=None):
    """만들 달 = 오늘의 다음 달. 화면(app.js의 nextMonth)과 같은 규칙이어야 한다."""
    import datetime as _dt
    d = today or _dt.date.today()
    y, m = (d.year + 1, 1) if d.month == 12 else (d.year, d.month + 1)
    return y, m


def sample_config_dict(roster_path: str, today=None) -> dict:
    """화면 첫 기본값 한 벌 — 명단은 샘플 원티드표에서, 나머지는 위 상수에서.

    연월은 파일에 적힌 값이 아니라 '오늘의 다음 달'로 잡는다. 파일의 연월을 쓰면
    파일을 구운 달이 지나는 순간 화면이 지난 달을 가리키고, 공휴일 표도 그 달 것만
    실려 나간다 — 화면은 nextMonth()로 다음 달을 띄우므로 둘이 어긋난다.
    공휴일은 그 해 전체를 담는다(화면에서 달을 바꿔도 달력이 맞아야 한다).
    """
    from .calendar_utils import KR_HOLIDAYS, _fixed_holidays
    from .excel_input import load_wanted_grid_xlsx

    data = load_wanted_grid_xlsx(roster_path)
    year, month = next_month(today)

    ydata = KR_HOLIDAYS.get(year)
    if ydata:
        holidays, substitutes = list(ydata["holidays"]), list(ydata["substitutes"])
    else:
        holidays, substitutes = _fixed_holidays(year), []

    params = default_params()
    params["holidays"] = holidays
    params["substitute_holidays"] = substitutes
    params["team_b_names"] = list(data.get("team_b_names") or [])
    staff = data.get("staff") or []
    params["nk_count"] = sum(1 for s in staff if "night_only" in (s.get("flags") or []))

    return {"ward_id": "", "year": year, "month": month,
            "staff": staff, "requests": [], "prev_month_carryover": {},
            "params": params}

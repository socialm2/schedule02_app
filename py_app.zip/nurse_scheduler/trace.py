"""생성기가 표를 쌓고 고치는 과정을 칸 단위로 기록한다 — 시각화(월간 보고 11절·docs/시각화 데모)의 입력.

엔진은 손대지 않는다. MonthSchedule이 모든 칸 쓰기를 한 곳(_on_cell_change)으로 받으므로 그걸 감싸
(단계, 사람, 날짜, 새 값)을 모으고, Generator.run()이 부르는 단계 메서드들을 감싸 '지금 단계' 이름을
붙인다. 단계가 끝날 때마다 위반 수와 공평성 지표를 재서 곡선 자료로 남긴다. 결과 표는 같은 입력·시드의
generate_best와 같다(결정적) — 기록은 읽기만 한다. tools/trace_search.py(세 시드 일괄 기록)와 브라우저
api_trace(고른 시드 하나)가 둘 다 이 모듈을 쓴다 — 두 벌이면 단계 목록이 어긋난다."""
from . import generator as G
from . import models as M
from .constraints import all_hard_checks
from .fairness import components

# run()의 순서 그대로. (메서드, 짧은 이름, 한 줄 설명)
STAGES = [
    ("compute_night_targets", "야간 목표", "사람마다 이번 달 야간 4회 또는 6회를 정한다 — 수요와 지난달 누적으로"),
    ("validate_input", "입력 검사", "명단·최소인력·원티드가 말이 되는지"),
    ("lock_pre_join_days", "입사 전", "월중 전입자의 입사 전 날짜는 비운다"),
    ("apply_fixed", "고정 칸", "파트장이 잠근 칸부터 — 아무도 못 건드린다"),
    ("complete_partial_night_blocks", "블록 보완", "하루짜리 야간은 이틀로 — 단독 야간 금지(H2-4)"),
    ("apply_carryover", "전월 이월", "지난달 말 야간 블록 이어 붙이기, 밀린 휴식"),
    ("assign_partjang", "파트장", "파트장은 평일 8A, 주말 OFF"),
    ("assign_nk", "야간전담", "야간전담은 한 달 15일 야간"),
    ("apply_requests", "원티드", "신청한 날은 신청한 대로 — 규칙에 안 걸리면"),
    ("assign_nights", "야간 블록", "밤마다 N 최소인력을 2일 블록으로 — 간격 7일, 뒤에 휴식 2일, 고연차 한 명"),
    ("assign_sleep_offs", "수면오프", "야간 6회인 사람은 하루 더 쉰다(H7-1)"),
    ("fill_day_shifts", "주간 채우기", "1일부터 날짜 순으로 D·E 최소인력을 후보 점수로 — 주말 부담·근무일·OFF·고연차 순"),
    ("finalize_offs", "남은 칸 OFF", "비어 있는 칸은 전부 OFF"),
    ("repair_min_staff", "미달 수리", "최소인력이 빈 날은 쉬는 사람을 당기거나 맞바꾼다"),
    ("fix_alternation", "퐁당퐁당 정리", "근무·OFF·근무·OFF를 붙여서 블록으로"),
    ("fix_short_day_blocks", "짧은 블록 늘리기", "1~2일 주간 블록을 3~4일로(H6-1)"),
    ("equalize_off", "OFF 고르게", "OFF가 많은 사람과 적은 사람을 맞춘다"),
    ("split_long_offs", "긴 OFF 쪼개기", "너무 긴 연휴는 나눈다"),
    ("global_fix_alternation", "퐁당퐁당(전역)", "가까운 날로 못 고친 것을 멀리서 찾아 고친다"),
    ("global_fix_2blocks", "2일 블록(전역)", ""),
    ("reduce_lv1_night_clusters", "신입 밤 풀기", "Lv1끼리 같은 밤에 몰리지 않게(S11)"),
    ("repair_level_coverage", "고연차 수리", "그 조에 Lv4+가 없는 날은 고연차와 맞바꾼다(H1-5)"),
    ("repair_designated", "지정 수리", "그날 지정 인원이 모자라면 비지정자와 맞바꾼다(H1-6)"),
    ("balance_day_types", "D/E 균형", "사람마다 D와 E 비율을 병동 비율에 맞춘다"),
]
POST = [
    ("equalize_nights", "야간 블록 이동", "같은 조건끼리 야간이 많은 사람의 블록을 적은 사람에게"),
    ("equalize_weekends", "주말 맞교환", "같은 조건끼리 주말 몫이 2회 이상 차이 나면 창을 통째로 맞바꾼다"),
]

CODE = {None: "", M.Shift.D: "D", M.Shift.E: "E", M.Shift.N: "N", M.Shift.NK: "NK", M.Shift.OFF: "/",
        M.Shift.PRN: "p"}


def _code(v):
    if v in CODE:
        return CODE[v]
    return str(getattr(v, "value", v))


def run_seed(cfg, seed, do_post, fixed_cells=None):
    gen = G.Generator(cfg, fixed_cells=fixed_cells or None, seed=seed)
    sch = gen.sch
    sidx = {s.id: i for i, s in enumerate(gen.staff)}
    events = []
    stages = []
    cur = {"name": "시작", "idx": -1, "depth": 0}
    orig_hook = M.MonthSchedule._on_cell_change

    raw = []          # 단계 안의 모든 쓰기(시도·되돌림 포함) — 순서 기록용
    start = {"grid": None}

    def hook(self, sid, day, old, new):
        orig_hook(self, sid, day, old, new)
        if self is sch and old != new and sid in sidx:
            raw.append((sidx[sid], day))

    def begin():
        start["grid"] = [[x for x in sch.grid[s.id]] for s in gen.staff]
        raw.clear()

    def snapshot(name, desc):
        # 단계가 실제로 바꾼 칸만 — 맞교환 검사가 써 보고 되돌린 칸은 빼고, 첫 쓰기 순서로 늘어놓는다.
        # 되돌린 쓰기까지 다 그리면 균등화 한 단계가 1만 번 깜빡여 아무것도 안 보인다. 그 수고는 writes로 센다.
        first = {}
        for i, key in enumerate(raw):
            first.setdefault(key, i)
        changed = []
        for si, s in enumerate(gen.staff):
            row = sch.grid[s.id]
            for d in range(sch.num_days):
                if row[d] != start["grid"][si][d]:
                    changed.append((first.get((si, d), 10 ** 9), si, d, _code(row[d])))
        for _, si, d, code in sorted(changed):
            events.append([len(stages), si, d, code])
        writes = len(raw)
        begin()
        v = all_hard_checks(sch, gen.days, gen.params)
        strict = sum(1 for x in v if x.rule not in G._BEST_EFFORT_RULES)
        fc = components(gen, sch)
        filled = sum(1 for s in gen.staff for x in sch.grid[s.id] if x is not None)
        stages.append({"name": name, "desc": desc, "end": len(events), "writes": writes, "strict": strict, "soft": len(v) - strict,
                       "fair": fc["fairness"], "count": fc["count"], "weekend": fc["weekend"], "mix": fc["mix"],
                       "filled": filled, "deficit": gen.count_deficits()})

    wrapped = {}
    for meth, name, desc in STAGES:
        if not hasattr(G.Generator, meth):
            continue
        orig = getattr(G.Generator, meth)

        def make(orig, name, desc):
            def w(self, *a, **k):
                if self is not gen or cur["depth"] > 0:
                    return orig(self, *a, **k)
                cur["depth"] += 1
                cur["name"] = name
                cur["idx"] = len(stages)
                try:
                    return orig(self, *a, **k)
                finally:
                    cur["depth"] -= 1
                    snapshot(name, desc)
            return w
        wrapped[meth] = orig
        setattr(G.Generator, meth, make(orig, name, desc))
    M.MonthSchedule._on_cell_change = hook
    begin()
    try:
        gen.run()
        if raw:
            snapshot("마무리", "단계 밖의 남은 쓰기")
        if do_post:
            import nurse_scheduler.equalize as E
            for fn, name, desc in POST:
                getattr(E, fn)(sch, gen.days, gen.params)
                snapshot(name, desc)
    finally:
        M.MonthSchedule._on_cell_change = orig_hook
        for meth, orig in wrapped.items():
            setattr(G.Generator, meth, orig)
    # 같은 단계가 여러 번 불리면(수리 루프) 이름이 반복된다 — 재생기가 횟수를 붙인다
    return gen, sch, events, stages




def trace_dict(gen, sch, events, stages):
    """기록 하나를 JSON으로 보낼 모양으로 — 사람 순서는 gen.staff(명단 순)이고 events의 둘째 값이 그 인덱스."""
    return {
        "staff": [{"id": s.id, "level": s.level, "partjang": s.is_partjang, "nk": s.is_nk} for s in gen.staff],
        "events": events, "stages": stages,
        "final": [[_code(x) for x in sch.grid[s.id]] for s in gen.staff],
    }

# -*- coding: utf-8 -*-
"""수정 보조 — 맞교환 상대 탐색(D-1)과 수정 취약 칸 지도(D-2).

둘 다 한 가지 질문에 답한다: "이 칸(들)을 이렇게 바꾸면 **지금 표에 없던 필수 위반**이
새로 생기는가". 판정은 생성기·검사기·수리기가 쓰는 constraints의 그 함수들이다 — 여기
규칙을 다시 적지 않는다. 셋이 다르면 한쪽이 괜찮다고 한 것을 다른 쪽이 고치려 들어
다른 규칙을 깨는 오동작이 실제로 있었다(G-03).

왜 전체 검사를 안 쓰나. all_hard_checks 한 번이 40명 병동에서 5~6ms고 브라우저(Pyodide)
에서는 그 서너 배다. 취약 칸 지도는 칸마다 대안 코드마다 한 번씩 — 40명×31일×3~4개 —
검사해야 하므로 전체 검사로는 분 단위가 된다. 그래서 **같은 검사 함수를 범위만 좁혀
부른다**: 날짜 단위 규칙(최소인력·지정·숙련도 배치)은 표 전체에, 사람 단위 규칙(패턴·
연속근무·야간 상한 등)은 바뀐 사람의 행에만. 사람 단위 검사 함수는 전부 `sch.staff`를
돌기 때문에, staff 목록만 바꾼 얕은 복사본을 넘기면 그 사람만 검사한다(grid·카운터는
원본과 공유). 이 분류가 틀리면 tests/test_edit_assist.py의 대조 테스트가 잡는다.
"""
from __future__ import annotations

import copy
from typing import Dict, Iterable, List, Optional, Set, Tuple

from .constraints import (
    all_hard_checks,
    check_h1_designated, check_h1_level_balance, check_h1_min_staff, check_h1_shift_rules,
    check_h2_night_blocks, check_h2_night_cap, check_h2_nk_quota, check_h2_no_night,
    check_h2_patterns, check_h3_consecutive, check_h3_links, check_h4_min_off,
    check_h4_off_run_length, check_h5_carryover, check_h6_day_block_length, check_h6_eod,
    check_h6_night_quota, check_h7_sleep_off,
)
from .models import MonthSchedule, Shift, Staff, Violation

Key = Tuple[str, str, Optional[int]]   # (규칙, 사람, 날짜) — 논문3·특허제안서3의 위반 삼중항


def best_effort_rules() -> Set[str]:
    # generator가 edit_assist를 import하지 않으므로 순환은 없지만, 모듈 적재 비용을
    # 피하려고 필요할 때 가져온다.
    from .generator import _BEST_EFFORT_RULES
    return _BEST_EFFORT_RULES


# ---------------------------------------------------------------- 범위 좁힌 검사

def _day_checks(sch: MonthSchedule, days, params) -> List[Violation]:
    """날짜 단위 규칙 — 한 칸이 바뀌면 그 날의 인원·숙련도 판정이 달라질 수 있으므로
    표 전체에 대해 돌린다(카운터 기반이라 싸다)."""
    out: List[Violation] = []
    out += check_h1_min_staff(sch, days, params.min_staff)
    out += check_h1_designated(sch, days, params.min_staff)
    out += check_h1_level_balance(sch, days)
    return out


def _row_checks(view: MonthSchedule, days, params) -> List[Violation]:
    """사람 단위 규칙 — view.staff에 든 사람만 검사한다."""
    out: List[Violation] = []
    out += check_h1_shift_rules(view, days, params.leader_8a_as_prn)
    out += check_h2_nk_quota(view)
    out += check_h2_night_blocks(view, params)
    out += check_h2_night_cap(view, params.max_nights)
    out += check_h2_no_night(view)
    out += check_h2_patterns(view)
    out += check_h3_consecutive(view, getattr(params, "max_consecutive_work", 5))
    out += check_h3_links(view)
    out += check_h4_min_off(view, days)
    out += check_h4_off_run_length(view)
    out += check_h5_carryover(view)
    out += check_h6_night_quota(view, params)
    out += check_h6_day_block_length(view)
    out += check_h6_eod(view)
    out += check_h7_sleep_off(view)
    return out


def scoped_hard_checks(sch: MonthSchedule, days, params, sids: Iterable[str]) -> List[Violation]:
    """all_hard_checks와 같은 함수들을, 날짜 규칙은 전체·사람 규칙은 sids만 돌린 결과.
    sids가 전원이면 all_hard_checks와 같은 목록이 나와야 한다(테스트가 본다)."""
    view = copy.copy(sch)           # grid·카운터·carryover는 원본과 공유, staff 목록만 바꾼다
    wanted = set(sids)
    view.staff = [s for s in sch.staff if s.id in wanted]
    return _day_checks(sch, days, params) + _row_checks(view, days, params)


def vkeys(viols: Iterable[Violation], strict: bool = True) -> Set[Key]:
    """위반 목록 → (규칙, 사람, 날짜) 집합. strict면 최선노력 규칙은 뺀다 — 구성 B의
    채택 기준(기준표에 없던 새 **필수** 위반)과 같은 정의."""
    be = best_effort_rules() if strict else set()
    return {(v.rule, v.staff_id or "", v.day) for v in viols
            if v.severity == "hard" and v.rule not in be}


def _with_cells(sch: MonthSchedule, cells: Dict[Tuple[str, int], Shift]):
    """칸들을 바꾸고 원래대로 되돌리는 문맥 관리자. 깊은 복사(4ms) 대신 제자리 수정 —
    _TrackedRow가 카운터를 같이 되돌린다."""
    class _Ctx:
        def __enter__(self_):
            self_.old = {k: sch.grid[k[0]][k[1]] for k in cells}
            for (sid, d), v in cells.items():
                sch.grid[sid][d] = v
            return sch

        def __exit__(self_, *exc):
            for (sid, d), v in self_.old.items():
                sch.grid[sid][d] = v
            return False
    return _Ctx()


def new_hard_keys(sch: MonthSchedule, days, params, cells: Dict[Tuple[str, int], Shift],
                  base: Optional[Set[Key]] = None, strict: bool = True) -> Tuple[Set[Key], Set[Key]]:
    """cells를 바꿨을 때 (새로 생기는 필수 위반, 그중 최선노력 규칙) — 둘 다 삼중항 집합.
    base를 주면 그 집합을 기준표 위반으로 쓴다(같은 범위로 계산된 것이어야 한다)."""
    sids = sorted({sid for sid, _ in cells})
    if base is None:
        base = vkeys(scoped_hard_checks(sch, days, params, sids), strict=False)
    with _with_cells(sch, cells):
        after = vkeys(scoped_hard_checks(sch, days, params, sids), strict=False)
    new_all = after - base
    be = best_effort_rules()
    new_strict = {k for k in new_all if k[0] not in be}
    new_soft = new_all - new_strict
    return (new_strict if strict else new_all), new_soft


# ---------------------------------------------------------------- D-2 취약 칸 지도

def alternative_codes(staff: Staff) -> List[Shift]:
    """그 칸에 넣어 볼 코드 — 그 사람의 가능근무와 OFF. 생성기가 배정하는 코드와 같은
    범위다(연차·교육 같은 관리자 지정 코드는 손 수정의 대안으로 세지 않는다)."""
    codes = list(staff.allowed_shifts)
    if Shift.OFF not in codes:
        codes.append(Shift.OFF)
    return codes


def fragile_map(sch: MonthSchedule, days, params, staff_ids=None, day_range=None,
                early_stop: int = 2) -> Dict[Tuple[str, int], dict]:
    """칸마다 {alts: 새 필수 위반 없이 바꿀 수 있는 대안 개수(early_stop에서 멈춤 — 2면
    "둘 이상"), blockers: 대안이 0개일 때 막는 규칙들, row_fragile: 막는 규칙이 전부 그 사람
    행의 규칙인가}.

    row_fragile인 칸은 맞교환 상대로도 쓸 수 없다 — 교환이 그 칸에 넣는 값도 대안 중
    하나이고, 행 규칙은 그 행만 보기 때문이다. 날짜 규칙(최소인력)만이 막는 칸은 맞교환으로는
    풀릴 수 있어(인원 수가 안 변한다) 제외하지 않는다.

    staff_ids·day_range로 일부만 계산할 수 있다 — 브라우저에서는 전체(40명×31일)가 수 초라
    화면이 사람·반달 단위로 나눠 부르고, 그 사이 들어오는 편집이 기다리지 않게 한다."""
    out: Dict[Tuple[str, int], dict] = {}
    d0, d1 = day_range if day_range else (0, sch.num_days)
    for s in sch.staff:
        if staff_ids is not None and s.id not in staff_ids:
            continue
        base = vkeys(scoped_hard_checks(sch, days, params, [s.id]), strict=False)
        codes = alternative_codes(s)
        for d in range(d0, min(d1, sch.num_days)):
            cur = sch.grid[s.id][d]
            alts = 0
            blockers: Set[str] = set()
            row_fragile = True
            for c in codes:
                if c == cur:
                    continue
                new_strict, _ = new_hard_keys(sch, days, params, {(s.id, d): c}, base=base)
                if not new_strict:
                    alts += 1
                    row_fragile = False
                    if alts >= early_stop:
                        break
                else:
                    blockers |= {k[0] for k in new_strict}
                    if not any(k[1] == s.id for k in new_strict):
                        row_fragile = False
            out[(s.id, d)] = {"alts": alts, "blockers": sorted(blockers) if alts == 0 else [],
                              "row_fragile": alts == 0 and row_fragile}
    return out


# ---------------------------------------------------------------- D-1 맞교환 상대 탐색

def _accepted_wish_cells(sch: MonthSchedule, requests) -> Set[Tuple[str, int]]:
    cells = set(sch.wanted)
    for r in requests or []:
        if r.accepted:
            try:
                cells.add((r.staff_id, int(str(r.date)[-2:]) - 1))
            except ValueError:
                pass
    return cells


def _equity_dev(sch: MonthSchedule, params, sid: str, weekend_mean: float) -> float:
    """야간 횟수가 목표에서 벗어난 정도 + 주말 근무일이 평균에서 벗어난 정도."""
    target = sch.night_target.get(sid, params.max_nights)
    return abs(sch.nights_in_month(sid) - target) + abs(sch.weekend_workdays_in_month(sid) - weekend_mean)


def swap_candidates(sch: MonthSchedule, days, params, sid: str, day: int, want: Shift,
                    requests=None, locked: Optional[Set[Tuple[str, int]]] = None,
                    fragile: Optional[Dict[Tuple[str, int], dict]] = None) -> dict:
    """sid의 day 근무를 want로 바꾸고 싶을 때, 그 날 want를 가진 다른 사람과 둘의 그 날
    근무를 서로 바꿔도 새 필수 위반이 없는 상대를 찾아 형평·희망 보존 순으로 돌려준다."""
    me = sch.by_id[sid]
    mine = sch.grid[sid][day]
    locked = locked or set()
    wish = _accepted_wish_cells(sch, requests)
    generals = [s for s in sch.staff if not (s.is_partjang or s.is_nk)]
    weekend_mean = (sum(sch.weekend_workdays_in_month(s.id) for s in generals) / len(generals)
                    if generals else 0.0)
    res = {"staff_id": sid, "day": day, "want": str(want), "current": str(mine),
           "candidates": [], "checked": 0, "skipped_locked": 0, "skipped_fragile": 0,
           "skipped_cannot": 0}
    if mine is None or mine == want:
        res["reason"] = "지금 그 근무라서 바꿀 것이 없습니다" if mine == want else "빈 칸은 맞교환할 수 없습니다"
        return res
    if not me.can(want):
        res["reason"] = f"{sid}은(는) {want} 근무를 설 수 없습니다"
        return res
    for other in sch.staff:
        if other.id == sid or sch.grid[other.id][day] != want:
            continue
        if (other.id, day) in locked:
            res["skipped_locked"] += 1
            continue
        if fragile and fragile.get((other.id, day), {}).get("row_fragile"):
            res["skipped_fragile"] += 1
            continue
        if not other.can(mine):
            res["skipped_cannot"] += 1
            continue
        res["checked"] += 1
        cells = {(sid, day): want, (other.id, day): mine}
        new_strict, new_soft = new_hard_keys(sch, days, params, cells)
        if new_strict:
            continue
        before = _equity_dev(sch, params, sid, weekend_mean) + _equity_dev(sch, params, other.id, weekend_mean)
        with _with_cells(sch, cells):
            after = _equity_dev(sch, params, sid, weekend_mean) + _equity_dev(sch, params, other.id, weekend_mean)
            nights_me, nights_other = sch.nights_in_month(sid), sch.nights_in_month(other.id)
        breaks_wish = (other.id, day) in wish
        res["candidates"].append({
            "partner": other.id, "partner_level": other.level,
            "partner_shift": str(want), "my_shift": str(mine),
            "equity_delta": round(after - before, 2),
            "breaks_wish": breaks_wish,
            "nights_after": {sid: nights_me, other.id: nights_other},
            "warnings": sorted({k[0] for k in new_soft}),
        })
    res["candidates"].sort(key=lambda c: (c["equity_delta"], c["breaks_wish"], c["partner"]))
    if not res["candidates"] and "reason" not in res:
        res["reason"] = "새 위반 없이 바꿀 수 있는 상대가 없습니다 — 재생성(국소)으로 넘깁니다"
    return res

# -*- coding: utf-8 -*-
"""형평성 점수 '한 숫자' — 2026-11-22 정의(docs/report_v0.89/형평성_점수_정의안_261122.html).

**화면이 보여 주는 점수이자, 프로그램이 표를 고르고 다듬는 기준이다**(2026-11-24 앱에 붙임 — 사용자: "형평성 점수 한 숫자
앱에 붙여줘 … 이 방식 일단 적용해 놓고"). 그 전에는 화면 점수(fairscore.py의 백분위 점수)와 표를 고르는 기준(fairness.py의
공평성 합)이 서로 달라, 후보를 늘렸는데 화면 점수가 내려가는 달이 있었다.

    r = one_number(gen, sch)        # r["score"] = 형평성 점수(높을수록 나은 근무표), r["axes"] = 풀이

정의 요약
  · 지표 점수 = 100 × T ÷ (T + x). x = 0.7 × 평균 편차 + 0.3 × 가장 벗어난 사람(날)의 편차, T = 허용치(사람이 느끼는 차이).
  · 축 점수 = 그 축 지표 점수의 평균. 형평 점수 = 축 점수의 무게 평균(사람별 부담 2, 나머지 1 — 고정).
  · 형평성 점수 = 형평 점수 ÷ (1 + 0.12 × 필수 위반 수 + 0.03 × 사람당 추가 검토 수). 필수는 운영·숙련도 구분 없이 같은 무게.
  · 비교 집단 = 연차 띠(1~2 · 3 · 4~5) × 근무 형태(3교대 · 주간만 · prn 전용 · 야간전담). 2명 이상인 집단만 견준다.
  · 목표는 있던 날 수에 비례. 주말은 본인이 신청해 쉰 주말을 '있던 주말'에서 뺀다(신청으로 생긴 차이는 편차가 아니다).
  · 누적 축(최근 6개월)은 아직 세지 않는다 — 없는 축은 빼고 무게 평균한다.
같은 병동·같은 달의 표끼리 견주는 숫자다(병동끼리 견주는 용도가 아니다).

⚠ 허용치(T)와 감점 크기(HARD_W·REVIEW_W)는 사람 채점 결과가 오면 고칠 숫자다(채점 대기 중). 고치면 고르는 표가 달라지므로
기준 병동 168개로 위반·점수·시간을 다시 잰다. 판정 눈금(GRADES)도 그때 같이 본다."""
from .constraints import all_hard_checks, night_blocks
from .fairness import available_days, band_of, sole_senior_deviation
from .models import ABSENCE_SHIFTS, LEAVE_SHIFTS, REST_SHIFTS, Shift

#: 허용치 — 이만큼 벗어나면 그 지표가 50점. 사람 채점 결과로 조정하는 숫자들이다.
T = {"D": 2.0, "E": 2.0, "N": 1.0, "weekend": 1.0, "workdays": 1.0, "night_gap": 2.0, "review_share": 1.0, "burden": 2.0,
     "fatigue": 2.0, "long_run": 1.0, "sole": 2.0, "leader": 1.0, "team": 0.5, "reject_pile": 1.0, "accept_rate": 20.0}
AXIS_WEIGHT = {"person": 2, "fatigue": 1, "seniority": 1, "day": 1, "wanted": 1}
AXIS_NAME = {"person": "사람별 부담", "fatigue": "피로", "seniority": "연차별 책임", "day": "일자별 구성", "wanted": "원티드"}
HARD_W, REVIEW_W = 0.12, 0.03
MEAN_W, WORST_W = 0.7, 0.3
#: 종합 부담 지수 = 주말·공휴일 근무 + 1.5 × 야간 + 0.5 × 피로 점수 — 한 사람이 여러 축에서 한꺼번에 손해 보는 것을 본다
BURDEN_W = {"weekend": 1.0, "night": 1.5, "fatigue": 0.5}


def _kind(s):
    if s.is_nk:
        return "야간전담"
    if s.can(Shift.N) and not s.no_night:
        return "3교대"
    if s.can(Shift.D) or s.can(Shift.E):
        return "주간만"
    return "prn 전용"


def _indicator(key, label, xs, unit):
    """xs = {사람(또는 날): 편차 ≥ 0}. 견줄 것이 없으면 None."""
    if not xs:
        return None
    vals = list(xs.values())
    x = MEAN_W * sum(vals) / len(vals) + WORST_W * max(vals)
    t = T[key]
    worst = sorted(xs.items(), key=lambda kv: (-kv[1], str(kv[0])))[:3]
    return {"key": key, "label": label, "unit": unit, "tolerance": t, "x": round(x, 3), "n": len(vals),
            "mean": round(sum(vals) / len(vals), 3), "max": round(max(vals), 3), "score": round(100 * t / (t + x), 1),
            "within": sum(1 for v in vals if v <= t), "worst": [[k, round(v, 2)] for k, v in worst if v > 0]}


def _axis(key, indicators):
    inds = [i for i in indicators if i]
    if not inds:
        return None
    return {"key": key, "name": AXIS_NAME[key], "weight": AXIS_WEIGHT[key],
            "score": round(sum(i["score"] for i in inds) / len(inds), 1), "indicators": inds}


#: 판정 눈금 — 화면의 좋음·보통·살펴볼 것. 기준 병동 168개 병동-달(9개 중 고른 표, 2026-11-24)의 분포에서 잡은 **임시값**이다:
#: 점수는 12.9~63.0(중앙 53.2), 필수 위반이 없는 110개 달은 49.5 이상(평균 55.6), 있는 58개 달은 평균 38.0이었다.
#: 55 이상 62개 달 · 45~55 74개 달 · 45 미만 32개 달(전부 필수 위반이 있는 달). 사람 채점 결과가 오면 허용치와 함께 다시 본다.
GRADES = ((55, "good", "좋음"), (45, "mid", "보통"), (0, "low", "살펴볼 것"))


def grade_of(score):
    if score is None:
        return {"key": "none", "label": "견줄 수 없음"}
    for floor, key, label in GRADES:
        if score >= floor:
            return {"key": key, "label": label}
    return {"key": "low", "label": "살펴볼 것"}


def split_violations(violations):
    """(필수, 추가 검토) — 최선노력 규칙이 추가 검토다."""
    from .edit_assist import best_effort_rules
    soft = best_effort_rules()
    return [v for v in violations if v.rule not in soft], [v for v in violations if v.rule in soft]


def one_number(gen, sch, violations=None):
    """형평성 점수와 풀이. violations를 주면(이미 센 검사 결과) 다시 세지 않는다."""
    if violations is None:
        violations = all_hard_checks(sch, gen.days, gen.params)
    strict, review = split_violations(violations)
    people = [s for s in gen.staff if not s.is_partjang]
    review_n = {s.id: 0 for s in people}
    for v in review:
        if v.staff_id in review_n:
            review_n[v.staff_id] += 1
    out = fair_part(gen, sch, review_n)
    n_all = max(1, len(people))
    per_person_review = len(review) / n_all
    divisor = 1 + HARD_W * len(strict) + REVIEW_W * per_person_review
    out.update({"score": round(out["fair_exact"] / divisor, 1), "divisor": round(divisor, 3), "hard": len(strict),
                "review": len(review), "review_per_person": round(per_person_review, 2)})
    out["grade"] = grade_of(out["score"])
    return out


def fair_part(gen, sch, review_n):
    """형평 점수(감점 전)와 축별 풀이. review_n = 사람별 '추가 검토' 건수 — 맞교환으로 다듬는 동안에는 위반을 다시 세지 않고
    처음 센 값을 그대로 쓴다(채택 기준이 '위반이 늘지 않는다'라 감점은 그대로다)."""
    from .fairscore import fatigue
    days = gen.days
    nd = sch.num_days
    grid = sch.grid
    people = [s for s in gen.staff if not s.is_partjang]
    general = [s for s in people if not s.is_nk]
    weekend = {i for i, di in enumerate(days) if di.day_type != "weekday"}

    groups = {}
    for s in people:
        groups.setdefault((band_of(s.level), _kind(s)), []).append(s)
    groups = {k: g for k, g in groups.items() if len(g) >= 2}
    singles = [s.id for s in people if (band_of(s.level), _kind(s)) not in groups]

    def within_group(value, weight=None, only=lambda s: True, one_sided=False):
        """집단마다 '가능일 비례 목표'(weight 없으면 집단 평균)에서 벗어난 정도."""
        out = {}
        for g in groups.values():
            g = [s for s in g if only(s)]
            if len(g) < 2:
                continue
            vals = {s.id: value(s) for s in g}
            if weight is None:
                target = {s.id: sum(vals.values()) / len(g) for s in g}
            else:
                w = {s.id: weight(s) for s in g}
                tot_w = sum(w.values())
                if tot_w <= 0:
                    continue
                target = {s.id: sum(vals.values()) * w[s.id] / tot_w for s in g}
            for s in g:
                d = vals[s.id] - target[s.id]
                out[s.id] = max(0.0, d) if one_sided else abs(d)
        return out

    avail = {s.id: available_days(sch, s.id) for s in people}
    # 본인이 신청해 쉰 주말, 휴가·부재, 입사 전은 '있던 주말'이 아니다
    asked_off = set()
    for q in gen.requests:
        if q.accepted and q.type in REST_SHIFTS:
            asked_off.add((q.staff_id, int(q.date[-2:]) - 1))
    away = LEAVE_SHIFTS | ABSENCE_SHIFTS
    avail_wk = {s.id: sum(1 for d in weekend if d >= sch.month_start_day.get(s.id, 0) and grid[s.id][d] not in away
                          and (s.id, d) not in asked_off) for s in people}
    count = lambda code: (lambda s: sum(1 for v in grid[s.id] if v == code))
    fat = {s.id: fatigue(sch, s.id, days) for s in people}
    nights = {s.id: sch.nights_in_month(s.id) for s in people}
    wk = {s.id: sch.weekend_workdays_in_month(s.id) for s in people}
    burden = {s.id: BURDEN_W["weekend"] * wk[s.id] + BURDEN_W["night"] * nights[s.id] + BURDEN_W["fatigue"] * fat[s.id]["score"]
              for s in people}
    def min_gap(s):
        b = night_blocks(sch, s.id)
        gaps = [b[i + 1][0] - b[i][1] - 1 for i in range(len(b) - 1)]
        return min(gaps) if gaps else None
    gaps = {s.id: min_gap(s) for s in general}
    night_dev = {s.id: abs(nights[s.id] - sch.night_target[s.id]) for s in general if sch.night_target.get(s.id) is not None}

    def longest_run(s):
        best = 0
        for d in range(nd):
            if sch.effective(s.id, d) not in REST_SHIFTS:
                best = max(best, sch.work_run_ending(s.id, d))
        return best

    person = _axis("person", [
        _indicator("D", "D 횟수", within_group(count(Shift.D), lambda s: avail[s.id], lambda s: s.can(Shift.D) and not s.is_nk), "회"),
        _indicator("E", "E 횟수", within_group(count(Shift.E), lambda s: avail[s.id], lambda s: s.can(Shift.E) and not s.is_nk), "회"),
        _indicator("N", "야간 횟수(개인 목표 대비)", night_dev, "회"),
        _indicator("weekend", "주말·공휴일 근무", within_group(lambda s: wk[s.id], lambda s: avail_wk[s.id]), "일"),
        _indicator("workdays", "총 근무일", within_group(lambda s: sch.workdays_in_month(s.id), lambda s: avail[s.id]), "일"),
        _indicator("night_gap", "야간 블록 사이 간격(집단 평균보다 짧은 만큼)",
                   {k: v for k, v in within_group(lambda s: -gaps[s.id], None, lambda s: gaps.get(s.id) is not None,
                                                   one_sided=True).items()}, "일"),
        _indicator("review_share", "'추가 검토' 위반 몫", within_group(lambda s: review_n[s.id]), "건"),
        _indicator("burden", "종합 부담(주말 + 1.5×야간 + 0.5×피로)", within_group(lambda s: burden[s.id]), "점"),
    ])
    fatigue_axis = _axis("fatigue", [
        _indicator("fatigue", "피로 점수(낮→밤 직결 2 · 짧은 회복 3 · 연속 주말 1)", within_group(lambda s: fat[s.id]["score"]), "점"),
        _indicator("long_run", "최장 연속근무(집단 평균보다 긴 만큼)", within_group(longest_run, one_sided=True), "일"),
    ])
    _dev, sole = sole_senior_deviation(sch, gen.staff)
    leaders = [s for s in general if s.is_night_leader]
    leader_mean = sum(nights[s.id] for s in leaders) / len(leaders) if len(leaders) >= 2 else None
    seniority = _axis("seniority", [
        _indicator("sole", "혼자 고연차인 조에 선 횟수(같은 띠 안)", within_group(lambda s: sole.get(s.id, 0), None, lambda s: s.id in sole), "회"),
        _indicator("leader", "야간리더로 선 밤", {s.id: abs(nights[s.id] - leader_mean) for s in leaders} if leader_mean is not None else {}, "회"),
    ])

    # 일자별 — 조의 고연차 수·평균 숙련도가 병동에서 벗어난 정도를, 그 조 인원이면 우연히 생기는 흔들림(표준오차)을 1로 둔 단위로
    n_all = len(people)
    p = sum(1 for s in people if s.level >= 4) / n_all
    mu = sum(s.level for s in people) / n_all
    sigma = (sum((s.level - mu) ** 2 for s in people) / n_all) ** 0.5
    day_inds = []
    for key, codes in (("D", (Shift.D,)), ("E", (Shift.E,)), ("N", (Shift.N, Shift.NK))):
        ratio, avg = {}, {}
        for d in range(nd):
            lv = [s.level for s in people if grid[s.id][d] in codes]
            n = len(lv)
            if n < 2 or n >= n_all:
                continue
            fpc = ((n_all - n) / (n_all - 1)) ** 0.5
            if 0 < p < 1:
                ratio[d + 1] = abs(sum(1 for x in lv if x >= 4) - p * n) / ((n * p * (1 - p)) ** 0.5 * fpc)
            if sigma > 0:
                avg[d + 1] = abs(sum(lv) / n - mu) / (sigma / n ** 0.5 * fpc)
        for xs, what in ((ratio, "고연차·저연차 비율"), (avg, "평균 숙련도")):
            i = _indicator("team", f"{key}조 {what}", xs, "흔들림 단위")
            if i:
                i["worst"] = [[f"{k}일", v] for k, v in i["worst"]]
                day_inds.append(i)
    day = _axis("day", day_inds)

    reqs = list(gen.requests)
    wanted = None
    if reqs:
        by = {}
        for q in reqs:
            a = by.setdefault(q.staff_id, [0, 0])
            a[0] += 1
            a[1] += 1 if q.accepted else 0
        rate = sum(a[1] for a in by.values()) / len(reqs)
        rej = {sid: a[0] - a[1] for sid, a in by.items()}
        rej_mean = sum(rej.values()) / len(rej)
        rate_ind = {"key": "accept", "label": "신청 반영률", "unit": "%", "tolerance": None, "x": round(100 * (1 - rate), 1), "n": len(reqs),
                    "mean": None, "max": None, "score": round(100 * rate, 1), "within": None, "worst": []}
        wanted = _axis("wanted", [
            rate_ind,
            _indicator("reject_pile", "반려가 한 사람에게 몰림(사람 평균보다 많은 만큼)", {sid: max(0.0, r - rej_mean) for sid, r in rej.items()}, "건"),
            _indicator("accept_rate", "사람별 신청 반영률(병동 반영률 대비)",
                       {sid: abs(a[1] / a[0] - rate) * 100 for sid, a in by.items() if a[0] >= 2}, "%p"),
        ])

    axes = [a for a in (person, fatigue_axis, seniority, day, wanted) if a]
    wsum = sum(a["weight"] for a in axes)
    fair = sum(a["score"] * a["weight"] for a in axes) / wsum if wsum else 0.0
    lowest = min(axes, key=lambda a: a["score"]) if axes else None
    return {"fair": round(fair, 1), "fair_exact": fair, "axes": axes, "missing_axes": ["누적(지난 달 자료 필요)"], "singles": singles,
            "lowest": ({"key": lowest["key"], "name": lowest["name"], "score": lowest["score"]} if lowest else None),
            "burden": {k: round(v, 2) for k, v in burden.items()},
            "groups": {f"{k[0]}·{k[1]}": len(g) for k, g in sorted(groups.items())}}

# -*- coding: utf-8 -*-
"""완성된 표의 균등화 — 같은 조건 집단 안에서 주말 근무가 몰린 사람과 적은 사람의 자리를 맞바꾼다.

생성기(generator)가 다 만든 표에 **마지막으로** 얹는 단계다. 규칙은 하나도 안 바꾼다. 바꾸는
것은 배치뿐이다: A의 주말 D와 B의 평일 D를 서로 바꾸면 A·B의 D 횟수·OFF 횟수·총근무가 그대로고,
그 두 날의 인원도 그대로다. 바뀌는 건 "누가 주말에 섰나"뿐이라, 횟수 격차(D·E·N이 사람마다
다른 것)는 여기서 줄지 않는다 — 그건 규칙(목표 횟수)의 문제라 별도 정책이다.

채택 기준은 보수적이다. 바꾼 뒤 **새 필수 위반도, 새 최선노력 위반도 없어야** 한다(판정은
edit_assist.new_hard_keys — 생성기·검사기·수리기가 쓰는 constraints 그 함수들). 원티드·잠긴 칸은
건드리지 않는다. 이월정보(다음 달로 넘기는 연속근무·마지막 근무)가 바뀌지 않도록 월말
(연속근무 상한+2일)은 손대지 않는다 — D·E와 OFF만 바꾸므로 야간 이월·잔휴는 애초에 안 변한다.

같은 입력이면 같은 순서로 훑어 같은 표가 나온다(난수 없음). 채택 횟수·검사 횟수에 상한을 둔다.

실측(기준선 201개, 2026-10-22): docs/report_v0.86/bench/baseline_rerun_equalize_261022.json —
수치는 그 파일과 세션요약을 볼 것. 지피티가 자기 작업 공간에서 비슷한 교환을 실험해 210개 중
48개의 주말 편중을 줄였다고 보고했고(코드는 받지 않음), 여기 것은 그 설계를 우리 맞교환
판정(edit_assist) 위에 새로 짠 것이다.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Set, Tuple

import copy
from collections import Counter

from .constraints import SLEEP_OFF_NIGHT_THRESHOLD, check_h1_level_balance
from .edit_assist import _row_checks, _with_cells, best_effort_rules
from .models import LEAVE_SHIFTS, MonthSchedule, Shift, Staff

#: 맞바꾸는 근무 — 주간 두 가지만. prn 계열은 반일·리더 8A가 섞여 "같은 자리"가 아니다.
SWAP_SHIFTS = (Shift.D, Shift.E)


def cohort_key(sch: MonthSchedule, s: Staff) -> tuple:
    """'같은 조건'의 정의 — 이 값이 같은 사람끼리만 주말 횟수를 견준다.

    가능근무·숙련도·야간 블록 선호·지정·야간리더·야간불가·총근무일수·휴가일수·입사일.
    야간 횟수까지 같아야 하지 않나 싶지만, 주간 D·E와 OFF만 바꾸므로 야간은 안 변한다 —
    대신 총근무일수가 같다는 조건이 "야간이 많아 주간이 적은 사람"을 다른 집단으로 가른다."""
    row = sch.grid[s.id]
    leave = sum(1 for v in row if v in LEAVE_SHIFTS)
    # 숙련도·총근무일수는 넣지 않는다 — 넣으면 40명 병동이 2~3명짜리 집단 9개로 쪼개져 견줄 쌍이
    # 7개뿐이었다. 숙련도 배치(H1-5)는 맞바꿀 때마다 검사하므로 집단 조건으로 둘 이유가 없고,
    # 횟수는 맞교환이 보존하므로 총근무가 달라도 주말 몫을 견주는 데 지장이 없다.
    return (tuple(sorted(str(x) for x in s.allowed_shifts)), s.night_block_pref,
            s.is_designated, s.is_night_leader, s.no_night,
            leave, sch.month_start_day.get(s.id, 0))


def cohorts(sch: MonthSchedule) -> List[List[Staff]]:
    groups: Dict[tuple, List[Staff]] = {}
    for s in sch.staff:
        if s.is_partjang or s.is_nk:
            continue
        groups.setdefault(cohort_key(sch, s), []).append(s)
    out = [sorted(g, key=lambda x: x.id) for k, g in sorted(groups.items(), key=lambda kv: kv[0])
           if len(g) >= 2]
    return out


def weekend_spread(sch: MonthSchedule) -> dict:
    """집단별 주말 근무 횟수의 편차 — 전후 비교용. sq: Σ(개인−집단평균)², gap: Σ(최대−최소)."""
    sq = 0.0
    gap = 0
    for g in cohorts(sch):
        w = [sch.weekend_workdays_in_month(s.id) for s in g]
        m = sum(w) / len(w)
        sq += sum((x - m) ** 2 for x in w)
        gap += max(w) - min(w)
    return {"sq": round(sq, 3), "gap": gap, "cohorts": len(cohorts(sch))}


#: 최선노력 중에서도 다른 노란 위반과 건수로 맞바꿀 수 없는 규칙. 수면오프(S/)는 야간 6회의 대가로
#: 근무일 하루를 더 쉬는 것이라, 야간 블록이 옮겨 가 자격(6회)이 사라졌는데 S/가 남으면 그 사람만
#: 근거 없이 하루 덜 일한다 — 오류도 경고도 없이. 12월 재현에서 실제로 생겼다: 야간 6→4로 내준 사람의
#: H7-1 하나가 늘고 H6-1 하나가 줄어 합이 같았고, 합만 보던 채택 검사가 그대로 통과시켰다.
NEVER_TRADED_RULES = ("H7-1",)


def _swap_checks(sch: MonthSchedule, days, params, sids, ignore: Tuple[str, ...] = ()
                 ) -> Tuple[Counter, int, Counter]:
    """맞교환 뒤 달라질 수 있는 검사만 — (필수 위반 삼중항의 개수표, 최선노력 위반 건수,
    맞바꿀 수 없는 최선노력(NEVER_TRADED_RULES)의 사람별 개수표).

    날짜별 인원(D·E·N·prn·지정)은 맞교환이 보존하므로 최소인력(H1-1·H1-4)·지정(H1-6)은 볼 필요가
    없고, 날짜 규칙 중에서는 조의 숙련도 구성(H1-5)만 달라진다. 사람 규칙은 두 사람 행만.
    삼중항을 '집합'이 아니라 '개수표'로 두는 이유: 같은 날 D조와 E조의 H1-5는 삼중항이 같아
    집합으로는 구분이 안 된다 — 실제로 그 틈으로 필수 위반이 하나 늘었다."""
    view = copy.copy(sch)
    want = set(sids)
    view.staff = [s for s in sch.staff if s.id in want]
    viols = check_h1_level_balance(sch, days) + _row_checks(view, days, params)
    be = best_effort_rules()
    strict = Counter((v.rule, v.staff_id or "", v.day) for v in viols
                     if v.severity == "hard" and v.rule not in be)
    soft = sum(1 for v in viols if v.severity == "hard" and v.rule in be and v.rule not in ignore)
    fixed = Counter((v.rule, v.staff_id or "") for v in viols
                    if v.severity == "hard" and v.rule in NEVER_TRADED_RULES)
    return strict, soft, fixed


def swap_is_safe(sch: MonthSchedule, days, params, cells: Dict[Tuple[str, int], Shift],
                 base: Optional[Tuple[Counter, int, Counter]] = None, ignore: Tuple[str, ...] = ()) -> bool:
    """맞교환 채택 기준: 필수 위반이 (위치·개수 모두) 늘지 않고, 두 사람의 최선노력 위반 **건수**가
    늘지 않는다. 최선노력은 위치가 아니라 건수로 본다 — 주간 블록(H6-1) 위반 하나가 다른 날로
    옮겨 가는 것은 나빠진 게 아닌데, 위치로 보면 '새 위반'으로 잡혀 거의 모든 교환이 막혔다
    (40명 병동에서 후보 8개 중 0개 채택). 다만 NEVER_TRADED_RULES(수면오프 H7-1)는 건수 합에
    묻히지 않고 사람마다 늘지 않아야 한다. base는 같은 두 사람에 대해 미리 계산한 '교환 전' 값."""
    sids = sorted({sid for sid, _ in cells})
    strict0, soft0, fixed0 = base if base is not None else _swap_checks(sch, days, params, sids, ignore)
    with _with_cells(sch, cells):
        strict1, soft1, fixed1 = _swap_checks(sch, days, params, sids, ignore)
    if any(n > strict0.get(k, 0) for k, n in strict1.items()):
        return False
    if any(n > fixed0.get(k, 0) for k, n in fixed1.items()):
        return False
    return soft1 <= soft0


def _windows(grid, sid: str, shift: Shift, days_ok, length: int) -> List[int]:
    """sid가 shift를 length일 연속으로 서는 시작일들(전부 days_ok 안)."""
    row = grid[sid]
    out = []
    for d0 in days_ok:
        if all((d0 + k) in days_ok and row[d0 + k] == shift for k in range(length)):
            out.append(d0)
    return out


def equalize_weekends(sch: MonthSchedule, days, params, *, max_accept: int = 12,
                      max_checks: int = 1000, lengths: Tuple[int, ...] = (1, 2, 3),
                      protect: Optional[Set[Tuple[str, int]]] = None) -> dict:
    """주말 편중을 줄이는 맞교환을 채택 상한까지 적용하고 {accepted, checked, before, after}를 돌려준다.

    교환 단위는 1~3일 창이다. 한 칸만 바꾸면 주간 블록 길이(H6-1, 3~4일)가 깨져 거의 채택되지
    않는다 — 토·일 이틀을 통째로 옮겨야 블록 모양이 유지된다(지피티의 실험 기록과 같은 관찰).
    A의 창(주말이 더 많이 든 쪽)과 B의 창(주말이 덜 든 쪽)을 통째로 맞바꾼다: A는 창1에서 OFF가 되고
    창2에서 근무, B는 그 반대. 두 사람의 횟수와 두 창의 날짜별 인원은 그대로다.

    순서: 집단마다 주말 차이가 가장 큰 쌍부터, 쌍 안에서는 짧은 창·D·앞 날짜부터. 채택되면 그 집단의
    횟수를 다시 세어 다음 쌍으로 간다(실패한 후보를 다시 검사하지 않는다). 검사 상한에 닿으면 멈춘다 —
    100명 병동에서 검사 하나가 1.5ms 안팎이라 1000번이면 네이티브 1.5초, 브라우저 서너 초다."""
    nd = sch.num_days
    weekend = set(getattr(sch, "_weekend_days", ()))
    if not weekend:
        weekend = {i for i, di in enumerate(days) if di.day_type != "weekday"}
    safe_last = nd - (int(getattr(params, "max_consecutive_work", 5)) + 2)
    guarded = set(sch.locked) | set(sch.wanted) | set(protect or ())
    grid = sch.grid
    before = weekend_spread(sch)
    days_ok = set(range(max(0, safe_last)))
    state = {"accepted": 0, "checked": 0}

    def free_window(sid: str, d0: int, length: int) -> bool:
        return all((sid, d0 + k) not in guarded for k in range(length))

    def wk(d0: int, length: int) -> int:
        return sum(1 for k in range(length) if (d0 + k) in weekend)

    def try_pair(a: Staff, b: Staff, wa: int, wb: int) -> bool:
        base = None
        for length in lengths:
            for va in SWAP_SHIFTS:
                if not b.can(va) or not a.can(va):
                    continue
                a_wins = [d0 for d0 in _windows(grid, a.id, va, days_ok, length)
                          if wk(d0, length) >= 1
                          and all(grid[b.id][d0 + k] == Shift.OFF for k in range(length))
                          and free_window(a.id, d0, length) and free_window(b.id, d0, length)]
                if not a_wins:
                    continue
                b_wins = [d0 for d0 in _windows(grid, b.id, va, days_ok, length)
                          if all(grid[a.id][d0 + k] == Shift.OFF for k in range(length))
                          and free_window(a.id, d0, length) and free_window(b.id, d0, length)]
                for wd in a_wins:
                    for kd in b_wins:
                        gain = wk(wd, length) - wk(kd, length)
                        if gain < 1 or abs(wd - kd) < length:
                            continue
                        if state["checked"] >= max_checks:
                            return False
                        state["checked"] += 1
                        cells = {}
                        for k in range(length):
                            cells[(a.id, wd + k)] = Shift.OFF
                            cells[(b.id, wd + k)] = va
                            cells[(b.id, kd + k)] = Shift.OFF
                            cells[(a.id, kd + k)] = va
                        if base is None:
                            base = _swap_checks(sch, days, params, [a.id, b.id])
                        if not swap_is_safe(sch, days, params, cells, base):
                            continue
                        for (sid, d), v in cells.items():
                            grid[sid][d] = v
                        state["accepted"] += 1
                        sch.log(f"[균등] 주말 맞교환 {a.id}↔{b.id}: {wd+1}일부터 {length}일 "
                                f"{va.value}/OFF ↔ {kd+1}일부터 {length}일 — 주말 "
                                f"{wa}·{wb}회 → {wa-gain}·{wb+gain}회")
                        return True
        return False

    for _pass in range(3):
        any_accept = False
        for g in cohorts(sch):
            while state["accepted"] < max_accept and state["checked"] < max_checks:
                w = {s.id: sch.weekend_workdays_in_month(s.id) for s in g}
                pairs = sorted(((a, b) for a in g for b in g if w[a.id] - w[b.id] >= 2),
                               key=lambda ab: (-(w[ab[0].id] - w[ab[1].id]), ab[0].id, ab[1].id))
                hit = False
                for a, b in pairs:
                    if try_pair(a, b, w[a.id], w[b.id]):
                        hit = any_accept = True
                        break
                    if state["checked"] >= max_checks:
                        break
                if not hit:
                    break
            if state["accepted"] >= max_accept or state["checked"] >= max_checks:
                break
        if not any_accept or state["accepted"] >= max_accept or state["checked"] >= max_checks:
            break
    after = weekend_spread(sch)
    return {"accepted": state["accepted"], "checked": state["checked"], "before": before, "after": after}


# ---------------------------------------------------------------- 야간 블록 옮기기

def equalize_nights(sch: MonthSchedule, days, params, *, max_accept: int = 10, max_checks: int = 800,
                    protect: Optional[Set[Tuple[str, int]]] = None) -> dict:
    """같은 조건 집단 안에서 야간이 많은 사람의 블록 하나를 적은 사람에게 통째로 옮겨 야간 횟수 편차를 줄인다.

    주말 균등화와 달리 횟수를 바꾼다 — 그게 목적이다(사용자 정의: 특별근무 전담이 아니면 N이 비슷해야).
    목표(4·6) 기준으로 '넘친 사람→모자란 사람'만 보면 거의 아무것도 못 한다: 수요가 적은 달엔 전원이
    목표 아래라 넘친 사람이 없는데, 그 안에서 4회인 사람과 1회인 사람(전월 블록이 1일 걸친 사람이
    흔히 그렇다)이 갈린다. 그래서 기준은 **집단 평균에서의 제곱편차**다 — 블록(길이 L)을 a→b로
    옮기면 a−b > L일 때 줄어든다(4·1 → 2·3은 줄고, 4·2 → 2·4는 그대로라 안 옮긴다). 받는 쪽이
    목표를 넘게는 하지 않는다.

    옮기는 단위는 블록 전체와 그 뒤 휴식 2일(H2-5)의 창이고, 그 창을 두 사람이 통째로 맞바꾼다: b는
    a의 N·N·OFF·OFF를, a는 b가 그 날 서던 D·E·OFF를 받는다. 날짜별 D·E·N 인원이 전부 그대로다(처음엔
    b의 창이 비어 있어야 한다고 했는데, 4회인 사람의 블록 자리에 1회인 사람이 나흘 내리 OFF인 일은 거의
    없어 한 건도 못 옮겼다). 채택 검사는 주말 균등화와 같되 H6-4(야간
    목표)는 뺀다 — 4→2로 내주는 사람에게 새 H6-4 한 건이 생기는 것은 이 교환의 본질이고, 그 대신
    받는 쪽이 목표에 가까워진다(집단 전체로는 편차가 준다). 원티드·잠긴 칸·월말은 손대지 않는다.

    수면오프(S/)는 야간과 함께 간다. S/는 야간 6회의 대가라, 블록을 내줘 6회 아래로 내려가는 사람의
    S/는 보통 OFF로 돌리고, 받아서 6회가 되는 사람은 옮겨 받은 블록의 둘째 휴식일을 S/로 받는다.
    둘 다 쉬는 날이라 날짜별 인원은 그대로이고, 잔휴만 자격을 따라 움직인다(S/는 잔휴에서 안 깎인다).
    예전엔 S/를 그대로 둬서 야간 4회인 사람에게 S/가 남았다 — 그 사람만 근거 없이 하루 덜 일했다."""
    nd = sch.num_days
    safe_last = nd - (int(getattr(params, "max_consecutive_work", 5)) + 2)
    # locked가 아니라 protected다 — 생성기는 자기가 놓은 야간 블록도 잠그므로 locked를 보면 옮길 블록이 없다
    guarded = set(sch.protected if sch.protected is not None else sch.locked) | set(sch.wanted) | set(protect or ())
    grid = sch.grid
    gen_staff = [s for s in sch.staff if not (s.is_partjang or s.is_nk) and s.can(Shift.N)]
    state = {"accepted": 0, "checked": 0}

    def nights(sid):
        return sum(1 for v in grid[sid] if v in (Shift.N, Shift.NK))

    def target(sid):
        return sch.night_target.get(sid)

    def blocks_of(sid):
        """(시작일, 길이) — 월초 이월분(0일부터 시작)과 월말 보호 구간은 제외, 잠기지 않은 완전한 블록만."""
        row = grid[sid]
        out = []
        d = 0
        while d < nd:
            if row[d] in (Shift.N, Shift.NK):
                e = d
                while e + 1 < nd and row[e + 1] in (Shift.N, Shift.NK):
                    e += 1
                if d > 0 and e + 2 < safe_last and all((sid, k) not in guarded for k in range(d, e + 3)):
                    out.append((d, e - d + 1))
                d = e + 1
            else:
                d += 1
        return out

    def spread():
        groups: Dict[tuple, List[int]] = {}
        for s in gen_staff:
            groups.setdefault(cohort_key(sch, s)[:5], []).append(nights(s.id))
        sq = 0.0
        for g in groups.values():
            m = sum(g) / len(g)
            sq += sum((n - m) ** 2 for n in g)
        return round(sq, 2)

    before = spread()
    for _pass in range(max_accept):
        moved = False
        groups: Dict[tuple, List] = {}
        for s in gen_staff:
            groups.setdefault(cohort_key(sch, s)[:5], []).append(s)
        for g in sorted(groups.values(), key=lambda g: g[0].id):
            if len(g) < 2:
                continue
            order = sorted(g, key=lambda s: (-nights(s.id), s.id))
            for a in order:
                for b in reversed(order):
                    if nights(a.id) - nights(b.id) <= 2:        # 가장 짧은 블록(2)으로도 줄지 않으면 뒤 쌍도 마찬가지
                        break
                    tb = target(b.id)
                    for d0, length in blocks_of(a.id):
                        if nights(a.id) - nights(b.id) <= length:
                            continue
                        if tb is not None and nights(b.id) + length > tb:
                            continue
                        span = range(d0, d0 + length + 2)
                        # b의 창에는 주간(D·E)·OFF만 — 휴가·야간·prn이 있으면 다른 블록이거나 바꿀 수 없는 칸
                        if any(grid[b.id][k] not in (None, Shift.OFF, Shift.D, Shift.E) or (b.id, k) in guarded
                               for k in span):
                            continue
                        if any(grid[a.id][k] not in (None, Shift.OFF) for k in range(d0 + length, d0 + length + 2)):
                            continue
                        if state["checked"] >= max_checks:
                            return _night_result(state, before, spread())
                        state["checked"] += 1
                        # 창(블록+휴식 2일)을 통째로 맞바꾼다: b는 a의 N·N·OFF·OFF를, a는 b의 그 날 근무를
                        # 받는다. 날짜별 D·E·N 인원이 전부 그대로라 최소인력·지정은 볼 필요가 없다.
                        cells = {}
                        for k in span:
                            cells[(a.id, k)] = grid[b.id][k] or Shift.OFF
                            cells[(b.id, k)] = grid[a.id][k] or Shift.OFF
                        na, nb = nights(a.id), nights(b.id)
                        note = _move_sleep_off(sch, guarded, cells, a.id, b.id, na, nb, length, d0 + length + 1)
                        if note is None:
                            continue
                        if not swap_is_safe(sch, days, params, cells, ignore=("H6-4",)):
                            continue
                        for (sid, d), v in cells.items():
                            grid[sid][d] = v
                        state["accepted"] += 1
                        sch.log(f"[균등] 야간 블록 이동 {a.id}→{b.id}: {d0 + 1}일부터 {length}일 — 야간 "
                                f"{na}·{nb}회 → {na - length}·{nb + length}회(목표 {target(a.id)}·{tb}){note}")
                        moved = True
                        break
                    if moved:
                        break
                if moved:
                    break
            if moved:
                break
        if not moved or state["accepted"] >= max_accept:
            break
    return _night_result(state, before, spread())


def _move_sleep_off(sch: MonthSchedule, guarded, cells, a: str, b: str, na: int, nb: int, length: int,
                    rest2: int) -> Optional[str]:
    """야간 블록이 a→b로 가면 수면오프(S/) 자격(6회)도 따라가게 cells를 보탠다. 로그 꼬리를 돌려주고,
    S/를 옮길 수 없으면(둘 이상이거나 사람이 정한 칸) None — 그 이동은 하지 않는다.

    내주는 쪽: 6회 아래로 내려가면 S/ → OFF. 받는 쪽: 6회가 되면 옮겨 받은 블록의 둘째 휴식일(rest2)을
    OFF 대신 S/로 받는다(생성기도 S/를 블록 바로 뒤에 둔다). 둘 다 쉬는 날이라 날짜별 인원은 그대로다."""
    T = SLEEP_OFF_NIGHT_THRESHOLD
    note = ""
    if na >= T and na - length < T:
        sdays = [d for d, v in enumerate(sch.grid[a]) if v is Shift.SLEEP_OFF]
        if len(sdays) > 1 or any((a, d) in guarded or (a, d) in cells for d in sdays):
            return None
        if sdays:
            cells[(a, sdays[0])] = Shift.OFF
            note += f", {a}의 S/({sdays[0] + 1}일) → OFF"
    if nb < T and nb + length >= T and not any(v is Shift.SLEEP_OFF for v in sch.grid[b]):
        if cells.get((b, rest2)) is not Shift.OFF:
            return None
        cells[(b, rest2)] = Shift.SLEEP_OFF
        note += f", {b}에게 S/({rest2 + 1}일)"
    return note


def _night_result(state, before, after):
    return {"accepted": state["accepted"], "checked": state["checked"], "before_sq": before, "after_sq": after}

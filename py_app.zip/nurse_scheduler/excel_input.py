# -*- coding: utf-8 -*-
"""엑셀 입력 형식 (원본 설계서 0-2/0-3 표 양식).

시트 구성:
  설정     — 항목/값 (병동명, 연도, 월, 월최대야간). 월신청상한·공휴일·대체공휴일은 입력받지
           않고 코드가 고정값/자동조회(kr_holidays_for_month, 2040년까지)로 채운다.
           야간목표하한/야간목표상한(선택, 기본 4/6) — H6-4 월 야간목표를 조정할 때만
           채운다. 상한을 홀수로 올리면(예: 7) 3일 야간블록도 자동 허용되며, 이때
           월최대야간(H2-6 안전상한)도 상한 이상으로 같이 올려야 실제 배정된다.
  인원     — 순번 | 이름 | 직급 | 숙련도 | 가능근무 | 비고
  최소인력 — 근무 | 평일 | 토요일 | 일요일공휴일  (D/E/N/prn 행, 8A 행은 무시)
  신청     — 이름 | 날짜 | 근무유형 | 우선순위   (선택, 행 순서 = 선착순)
  전월이월 — 이름 | 마지막근무 | 연속근무일수 | 이월OFF일수 | 말일연속야간일수 (선택)

비고 키워드: "야간전담" → night_only, "임부" → pregnant, "야간금지"/"야간 금지" → no_night

  연간근무표 — 다월 자동 연동용(선택 사용, 구 명칭 "인원표"). 순번|이름|직급|숙련도|가능근무|비고 +
           누적통계(최근야간점수|누적야간|누적오프|누적주말야간|누적 2일 블록 야간|
                    누적 3일 블록 야간|반영개월수) +
           연간 근무 그리드(1/1~, 참고용). export_staff_table_xlsx()로 내보내고
           load_staff_table_xlsx()로 다시 읽어 다음 달 생성에 이어붙인다.
"""
from __future__ import annotations

import datetime as _dt
import re
from typing import Dict, List, Optional, Tuple

from .calendar_utils import kr_holidays_for_month
from .models import (DESIGNATED_KEY, STAFF_TABLE_SUMMARY_LABELS_READ, Shift,
                     allowed_shifts_text, parse_shift)

# 월 신청상한(직원 1명당 월 근무형 신청 개수 상한, §5) — 사용자가 매번 입력하지 않도록
# 고정값을 쓴다. 실사용(42명 규모, prn 인력 부족)에서 검증된 값.
DEFAULT_MAX_REQUESTS_PER_PERSON = 20

# '전입'/'전입일'은 전용 입력 칸 — 자유 입력인 비고에 적게 하면 오타·띄어쓰기로 놓치기
# 쉬워서 분리했다. 전입 칸은 드롭다운(목록 제한), 전입일은 엑셀 날짜 셀이라 표기가
# 흔들릴 여지가 없다. 전출은 파트장이 적을 필요가 없다(입력①에 없으면 자동 판정).
#: '야간리더'를 가능근무 칸 안이 아니라 **옆 열**로 둔 이유.
#:
#: 지정·2N·3N은 가능근무 칸에 쉼표로 이어 적는다. 그 칸이 'D,E,N,prn,지정,3N'처럼
#: 길어지면 야간리더를 적어야 하는 사람인지 아닌지가 글자 속에 묻혀 **안 적고 넘어가기
#: 쉽다.** 밤마다 한 명은 반드시 있어야 하는 값(H1-5)이라 빠뜨리면 그 달 야간이
#: 통째로 빨간 위반이 된다. 열로 빼 두면 빈 칸이 눈에 보인다(파트장 판단).
#:
#: 읽을 때는 **둘 다** 받는다 — 가능근무 칸에 '야간리더'라고 적어도 읽힌다. 쓸 때만
#: 이 열 한 곳에 쓴다. 열이 없는 옛 파일도 그대로 읽힌다(열은 이름으로 찾는다).
STAFF_TABLE_STATIC_COLS = ["순번", "이름", "직급", "숙련도", "가능근무", "야간리더",
                            "비고", "전입", "전입일"]
# '설/추석오프'는 누적주말휴일오프와 별개로 센다 — 명절 근무는 주말 근무와 무게가
# 다르다고 보기 때문이다(주말은 매달 돌아오지만 명절은 1년에 두 번뿐이라, 주말 오프
# 횟수가 비슷해도 명절에 3년 내리 근무한 사람이 생길 수 있다). 두 열을 나란히 두면
# 파트장이 그걸 눈으로 잡아낸다.
#
# ⚠ 두 목록은 같은 순서로 짝지어 읽고 쓴다(zip). 한쪽에만 넣으면 열이 밀려서 통계가
#   통째로 옆칸 값을 읽는다 — 오류도 안 나고 숫자만 조용히 틀린다. 반드시 같이 고칠 것.
STAFF_TABLE_STAT_KEYS = ["night", "workday", "off", "weekend_night",
                          "blocks_2", "blocks_3", "months", "recent_night_score",
                          "cum_d", "cum_e", "cum_prn", "cum_weekend_holiday_off",
                          "cum_festival_off",
                          "prev_off_balance", "off_balance"]
STAFF_TABLE_STAT_LABELS = ["누적야간", "누적근무일", "누적오프", "누적주말야간",
                            "누적 2일 블록 야간", "누적 3일 블록 야간", "반영개월수",
                            "최근야간점수(참고용)",
                            "누적D", "누적E", "누적prn(8A)",
                            "누적주말휴일오프_total(설,추석 포함)",
                            "설/추석오프",
                            "전월잔휴", "잔휴"]
assert len(STAFF_TABLE_STAT_KEYS) == len(STAFF_TABLE_STAT_LABELS)


#: 열 제목이 바뀌기 전에 만들어진 연간근무표도 읽어야 한다. 제목으로 열을 찾으므로
#: 이름만 바꾸면 옛 파일에서 그 열을 못 찾고 **조용히 0**이 된다 — 누적 통계는 매달
#: 자기 값을 이어받으므로, 한 번 0이 되면 그 달부터 그 사람 통계가 통째로 사라진다.
#: 새 이름을 먼저 찾고, 없으면 옛 이름으로 되짚는다.
STAFF_TABLE_STAT_LABEL_ALIASES = {
    "누적주말휴일오프_total(설,추석 포함)": ["누적주말휴일오프"],
    # '누적2일블록'은 무엇의 2일인지가 안 적혀 있어 근무일수로 읽히기 쉬웠다.
    # 실제로는 **야간을 2일 연속으로 선 횟수**다(일수가 아니라 건수).
    "누적 2일 블록 야간": ["누적2일블록"],
    "누적 3일 블록 야간": ["누적3일블록"],
}


class ExcelInputError(Exception):
    pass


class WrongInputSlotError(ExcelInputError):
    """올린 칸이 잘못됐을 때 — 파일 자체는 멀쩡하다.

    호출부가 '이 파일은 형식이 깨졌다'는 메시지로 덮어쓰지 않도록 따로 구분한다.
    파일이 깨진 게 아니라 칸을 헷갈린 것이므로, 사용자에게 할 말이 완전히 다르다."""


_INVISIBLE_RE = re.compile(r"[\u200b-\u200f\ufeff\u2060]")


# 이름 상한 — 동명이인 구분("김간호(A)")·공백까지 넉넉히 잡은 값이다. 이보다 길면
# 셀을 잘못 붙여넣었거나 다른 칸 내용이 흘러든 것이라, 화면 표와 엑셀이 통째로
# 망가진 채로 근무표가 나온다.
MAX_NAME_LEN = 40


def _check_name_length(name: str, context: str, errors) -> None:
    if len(name) <= MAX_NAME_LEN:
        return
    msg = (f"{context}: 이름이 {len(name)}자입니다 — {MAX_NAME_LEN}자를 넘습니다. "
           "다른 칸 내용이 이름 칸에 붙여넣어진 경우가 많습니다.")
    if errors is not None:
        errors.add(msg)
    else:
        raise ExcelInputError(msg)


def _clean_name(v) -> str:
    """이름 칸 정규화 — 눈에 안 보이는 차이 때문에 같은 사람이 갈리는 것을 막는다.

    · 제로폭 공백(\u200b 등)은 화면에도 엑셀에도 안 보이는데 문자열로는 다르다.
    · 한글은 같은 글자를 두 가지로 표현할 수 있다(NFC '김' vs NFD 'ㄱ+ㅣ+ㅁ') — 맥에서
      만든 파일과 윈도우 파일을 섞으면 눈에 똑같은 이름이 서로 다른 사람이 된다.
    · 탭·줄바꿈 같은 제어문자도 보이지 않는 차이를 만든다.
    이대로 두면 한 명이 두 번 배정되거나 전입·전출로 잘못 잡힌다.
    """
    import unicodedata
    s = "" if v is None else str(v)
    s = _INVISIBLE_RE.sub("", s).replace("\xa0", " ")
    s = "".join(ch for ch in s if ch == "\t" or unicodedata.category(ch)[0] != "C")
    s = s.replace("\t", " ")
    return unicodedata.normalize("NFC", s).strip()


# 병원 OCS 원본의 성명 칸은 이름 앞에 직급과 표식이 붙어 나온다 —
# "RN 신미령", "파트장 김묘연", "RN ⓜ김수연", "RN ⓜⓟ윤지영" 같은 식이다
# (ⓜ=임신, ⓟ=임신 단축근무). 사람을 가리키는 것은 뒤의 이름뿐인데, 이걸 그대로
# 키로 쓰면 같은 사람이 파일마다 다른 사람이 된다 — 입력①(우리 양식, "김수연")와
# 입력②(OCS, "RN ⓜ김수연")을 대조하는 순간 한 명이 전출 + 전입으로 동시에 잡혀,
# 오류 하나 없이 인원이 두 배가 된 근무표가 나온다.
_OCS_NAME_PREFIXES = ("파트장", "수간호사", "책임", "RN", "NA", "SN")
# ⓐ~ⓩ·Ⓐ~Ⓩ 동그라미 문자만 지운다. ①②③ 같은 동그라미 숫자는 동명이인을 구분하려고
# 붙였을 수 있어 건드리지 않는다(뜻이 갈리는 것은 고쳐 읽지 않는다는 원칙).
_OCS_NAME_MARK_RE = re.compile(r"[\u24b6-\u24e9]")


def _strip_ocs_name_decoration(v) -> str:
    """OCS 성명 칸에서 직급 접두사와 표식을 떼어 이름만 남긴다.

    접두사는 **뒤에 공백이 있을 때만** 뗀다("파트장 김묘연" → "김묘연"). 붙여 쓴
    "파트장A"는 그게 직급인지 이름의 일부인지 알 수 없으므로 건드리지 않는다 —
    실제로 이름이 '파트장A'인 사람이 'A'가 돼버려 팀 구분 행과 뒤섞인 적이 있다.
    뜻이 갈릴 수 있는 것은 알아서 고쳐 읽지 않는다는 이 프로젝트의 원칙 그대로다."""
    s = _OCS_NAME_MARK_RE.sub("", "" if v is None else str(v)).strip()
    for p in _OCS_NAME_PREFIXES:
        if s.startswith(p) and s[len(p):len(p) + 1].isspace():
            rest = s[len(p):].strip()
            if rest:                     # 접두사만 있고 이름이 없으면 원본을 그대로 둔다
                return rest
    return s


def _formula_cells(path: str, limit: int = 3):
    """값이 비어 있는 수식 칸을 찾아 위치를 돌려준다.

    엑셀 수식은 '계산 결과'가 파일에 같이 저장돼 있을 때만 읽을 수 있다. 다른 도구로
    만들었거나 계산 캐시가 없으면 그 칸은 빈칸으로 읽혀서, 최소인력 =1+2가 0명이 되고
    원티드 ="X"가 신청 없음이 되는 식으로 조용히 뜻이 바뀐다. 결과가 저장돼 있는
    수식은 정상적으로 읽히므로 문제 삼지 않는다."""
    from openpyxl import load_workbook
    try:
        raw = load_workbook(path, data_only=False)
        cached = load_workbook(path, data_only=True)
    except Exception:
        return []
    out = []
    for ws in raw.worksheets:
        if ws.title not in cached.sheetnames:
            continue
        cws = cached[ws.title]
        for row in ws.iter_rows():
            for c in row:
                if isinstance(c.value, str) and c.value.startswith("="):
                    v = cws.cell(c.row, c.column).value
                    if v is None or (isinstance(v, str) and not v.strip()):
                        out.append(f"'{ws.title}' 시트 {c.coordinate}")
                        if len(out) >= limit:
                            return out
    return out


def _reject_empty_formulas(path: str) -> None:
    found = _formula_cells(path)
    if found:
        raise ExcelInputError(
            f"계산 결과가 저장되지 않은 수식 칸이 있습니다({', '.join(found)} 등) — "
            "그 칸은 빈칸으로 읽혀서 최소인력이 0명이 되는 식으로 값이 조용히 바뀝니다. "
            "해당 칸을 복사한 뒤 '값 붙여넣기'로 숫자·글자만 남기고 다시 올려주세요.")


def _load_workbook_safe(path: str):
    """openpyxl.load_workbook을 감싸서, 파일 자체가 엑셀이 아니거나(확장자만 xlsx인
    텍스트/csv 파일, 0바이트 등) 손상된 경우 openpyxl이 던지는 영어 원본 예외
    (예: "File is not a zip file")를 그대로 노출하지 않고 이해할 수 있는 한국어
    안내로 바꿔준다."""
    from openpyxl import load_workbook
    from zipfile import BadZipFile
    try:
        return load_workbook(path, data_only=True)
    except BadZipFile:
        raise ExcelInputError(
            "엑셀 파일(.xlsx)로 열 수 없습니다 — 확장자만 xlsx이고 실제로는 다른 형식(예: "
            "csv, txt)이거나 파일이 손상됐을 수 있습니다. 엑셀에서 다시 저장한 뒤 올려보세요."
        )


def _typed_display(v) -> str:
    """안내에 보여줄 '파트장이 실제로 친 값'.

    엑셀이 손댄 값은 되돌려 보여준다 — 날짜 서식 칸에 15를 치면 엑셀이 1900-01-15로
    만드는데, 그걸 그대로 보여주면 자기가 뭘 쳤는지 알아볼 수 없다. 전각·공백은
    일부러 그대로 둔다(전각으로 쳤다는 사실 자체가 알려줄 내용이다)."""
    if isinstance(v, _dt.datetime) and (v.year, v.month) == (1900, 1):
        return str(v.day)
    if isinstance(v, (_dt.date, _dt.datetime)):
        return v.strftime("%Y-%m-%d")
    return str(v).strip() if v is not None else ""


class _LenientNotes:
    """관대하게 읽어준 값을 모아둔다 — 'd'를 D로 읽었다는 사실을 말해주지 않으면
    파트장은 자기 표기가 비표준인 줄 모른 채 다음 달에도 같은 표기를 쓴다. 그러다
    관대함이 닿지 않는 값('휴가' 등)을 만나면 그제야 반려되는데, 그때는 왜 지난달엔
    되던 것이 안 되는지 알 수 없다. 오류가 아니라 안내이므로 생성을 막지 않는다."""

    def __init__(self):
        self.counts: Dict[tuple, int] = {}

    def note(self, field: str, typed, read) -> None:
        """typed를 read로 읽었다 — 같은 표기가 여러 칸에 있으면 세어서 한 줄로 묶는다."""
        typed, read = str(typed).strip(), str(read).strip()
        if not typed or typed == read:
            return
        key = (field, typed, read)
        self.counts[key] = self.counts.get(key, 0) + 1

    def as_list(self) -> List[dict]:
        # 많이 쓴 표기부터 — 고칠 값이 여럿이면 제일 잦은 것부터 보이는 게 낫다.
        items = sorted(self.counts.items(), key=lambda kv: (-kv[1], kv[0]))
        return [{"field": f, "typed": t, "read": r, "count": n}
                for (f, t, r), n in items]


class _ErrorCollector:
    """엑셀 파싱 중 발견한 문제를 첫 건에서 바로 멈추지 않고 모아뒀다가, 끝에서 한
    번에 보고한다 — 실수가 여러 개면 업로드→수정→재업로드를 문제 개수만큼 반복하지
    않도록. 시트 자체가 없거나 헤더를 못 찾는 등 더 이상 읽을 수 없는 구조적 문제는
    (계속 읽어봐야 의미가 없으므로) 이 컬렉터를 안 거치고 그 자리에서 바로 raise한다."""

    def __init__(self):
        self.items: List[str] = []

    def add(self, msg: str) -> None:
        self.items.append(msg)

    def raise_if_any(self) -> None:
        if not self.items:
            return
        if len(self.items) == 1:
            raise ExcelInputError(self.items[0])
        bullet = "\n".join(f"{i + 1}. {m}" for i, m in enumerate(self.items))
        raise ExcelInputError(f"입력 파일에서 문제 {len(self.items)}건을 찾았습니다:\n{bullet}")


# ---------------------------------------------------------------- 읽기

def _sheet_rows(ws) -> List[list]:
    return [[c for c in row] for row in ws.iter_rows(values_only=True)]


def _find_header(rows, first_col_name):
    for i, r in enumerate(rows):
        if r and str(r[0] or "").strip() == first_col_name:
            return i
    return None


def _parse_level(v, context: str = "", errors: Optional[_ErrorCollector] = None) -> int:
    # 'Lv3' 말고도 '레벨3', '3급', 'ｌｖ３', '3.0'처럼 적어도 뜻은 하나다.
    s = _norm_text(v).replace(" ", "")
    low = s.lower()
    for pre in ("lv.", "lv", "레벨", "level"):
        if low.startswith(pre):
            s = s[len(pre):]
            break
    for suf in ("등급", "급", "레벨", "lv"):
        if s.lower().endswith(suf):
            s = s[: -len(suf)]
            break
    try:
        f = float(s)
        # INF/NaN은 float()는 통과하고 int()에서 OverflowError가 난다 — 친절한 한국어
        # 입력 오류 대신 영어 예외 문구가 그대로 화면까지 새 나갔다. 여기서 같이 잡는다.
        if f != f or f in (float("inf"), float("-inf")):
            raise ValueError(s)
        # 3.9를 3으로 깎아 읽으면 오류도 안 나고 그 사람만 한 단계 낮은 숙련도로
        # 배정된다 — 레벨 평균·고랩 기준이 조용히 틀어지는 자리라 소수는 받지 않는다.
        # ('3.0'처럼 엑셀이 정수를 실수로 저장한 경우는 뜻이 하나뿐이라 그대로 받는다.)
        if f != int(f):
            where = f" ({context})" if context else ""
            msg = (f"숙련도는 1~5 사이의 정수여야 합니다{where}: {v!r} — "
                   "소수점은 어느 쪽으로 읽어야 할지 알 수 없어 받지 않습니다.")
            if errors is not None:
                errors.add(msg)
                return 1
            raise ExcelInputError(msg)
        n = int(f)
        if not (1 <= n <= 5):
            # 숙련도는 Lv1~Lv5다. -1이나 999가 통과하면 레벨 평균·고랩 기준이 통째로
            # 망가지는데 화면에는 그냥 숫자로 보여 알아채기 어렵다.
            where = f" ({context})" if context else ""
            msg = f"숙련도는 1~5 사이여야 합니다{where}: {v!r}"
            if errors is not None:
                errors.add(msg)
                return 1
            raise ExcelInputError(msg)
        return n
    except ValueError:
        where = f" ({context})" if context else ""
        msg = f"숙련도 칸에 알 수 없는 값이 있습니다{where}: {v!r}"
        if errors is not None:
            errors.add(msg)
            return 1  # 계속 읽기 위한 임시값 — 오류가 모였으니 최종적으로는 반려된다
        raise ExcelInputError(msg)


def _int_cell(v, context: str, default: Optional[int] = None,
             errors: Optional[_ErrorCollector] = None,
             min_value: Optional[int] = None) -> int:
    """엑셀 칸 값을 정수로 변환 — 실패하면 어느 칸이 문제인지 담은 메시지로 알려준다.

    default가 주어지면 빈 칸(None/"")은 그 값으로 채우고, 값이 있는데 숫자로 못
    바꾸는 경우만 오류로 취급한다(사용자가 실수로 글자를 넣은 경우와 구분). 숫자
    앞뒤에 단위 등 글자가 섞여 있어도(예: "9명", "약 9") 안에 숫자가 정확히 하나뿐이면
    그 값으로 관대하게 읽는다 — 여러 개 섞여 있으면(예: "9~10") 모호하니 포기한다.

    min_value가 주어지면 그보다 작은 값(예: 음수 오타 "-5")도 형식상으로는 숫자라
    앞의 파싱은 통과하지만, 여기서 별도로 걸러 오류로 알려준다(조용히 통과시키면
    "최소인력 0명"처럼 뜻이 뒤바뀌어도 티가 안 남)."""
    if v is None or (isinstance(v, str) and not v.strip()):
        if default is not None:
            return default
        v = 0
    try:
        f = float(v)
        # 8.9를 8월로, 3.9를 3명으로 조용히 깎으면 뜻이 바뀐 채 통과한다 — 소수부가
        # 있으면 오타로 보고 알려준다(3.0처럼 정수와 같은 값은 그대로 받는다).
        if f != int(f):
            msg = f"{context}에 소수점이 있는 값이 있습니다: {v!r} — 정수로 적어주세요."
            if errors is not None:
                errors.add(msg)
                return default if default is not None else 0
            raise ExcelInputError(msg)
        n = int(f)
    except (TypeError, ValueError):
        # 부호를 같이 잡는다 — "-3명"에서 숫자만 떼면 3이 돼, 뜻이 뒤집힌 값이
        # 음수 검사(min_value)까지 통과해버린다.
        digits = re.findall(r"-?\d+", str(v))
        if len(digits) == 1:
            n = int(digits[0])
        else:
            msg = f"{context}에 숫자가 아닌 값이 있습니다: {v!r}"
            if errors is not None:
                errors.add(msg)
                return default if default is not None else 0
            raise ExcelInputError(msg)
    if min_value is not None and n < min_value:
        msg = f"{context}에 {min_value} 미만의 값이 있습니다: {n} — 음수나 오타가 아닌지 확인하세요."
        if errors is not None:
            errors.add(msg)
            return default if default is not None else 0
        raise ExcelInputError(msg)
    return n



# ---------------------------------------------------------------- 관대한 입력 처리
# 파트장이 손으로 채우는 파일이라 "뜻은 분명한데 표기만 어긋난" 입력이 흔하다. 그런 건
# 반려하지 말고 알아서 맞춰 읽는다. 다만 '뜻이 갈릴 수 있는 것'(월 8.9, 숙련도 999,
# 날짜열 순서 등)은 여기 넣지 않는다 — 조용히 고치면 틀린 근무표가 나오기 때문.

def _to_halfwidth(s: str) -> str:
    """전각 문자를 반각으로 — 한글 입력기에서 숫자·영문을 치면 'Ｄ', '３'처럼 전각으로
    들어가는 일이 잦다. 눈에는 똑같은데 코드는 다른 글자로 본다."""
    out = []
    for ch in s:
        o = ord(ch)
        if 0xFF01 <= o <= 0xFF5E:        # 전각 ! ~ ~
            out.append(chr(o - 0xFEE0))
        elif o == 0x3000:                # 전각 공백
            out.append(" ")
        else:
            out.append(ch)
    return "".join(out)


def _norm_text(v) -> str:
    """셀 글자값 공통 정리 — 전각→반각, 보이지 않는 문자 제거, 앞뒤 공백 제거."""
    if v is None:
        return ""
    return _INVISIBLE_RE.sub("", _to_halfwidth(str(v))).replace("\xa0", " ").strip()


# 직급은 뜻이 하나뿐이라 표기 흔들림을 받아준다(영문·대소문자·공백·흔한 표기).
_ROLE_ALIASES = {
    "파트장": "파트장", "partjang": "파트장", "part": "파트장", "수간호사": "파트장",
    "um": "파트장", "unitmanager": "파트장", "유닛매니저": "파트장", "팀장": "파트장",
    "파트": "파트장", "partleader": "파트장",
    "리더": "리더", "leader": "리더", "l": "리더", "책임": "리더", "책임간호사": "리더",
    "cn": "리더", "charge": "리더", "chargenurse": "리더", "책임자": "리더",
    "간호사": "간호사", "nurse": "간호사", "n": "간호사", "일반": "간호사",
    "일반간호사": "간호사", "rn": "간호사", "평간호사": "간호사", "스탭": "간호사",
    "스태프": "간호사", "staff": "간호사",
}
# 직급 뒤에 붙는 존칭·군더더기 — '수간호사님'을 못 알아보고 반려하면, 파트장은 명단에서
# 사람 이름 옆 존칭을 일일이 지워야 한다. 떼고 나서 뜻이 하나뿐이면 그대로 읽는다.
# 긴 것부터 본다 — '간호사선생님'에서 '님'만 떼면 '간호사선생'이 남아 또 못 알아본다.
_ROLE_SUFFIXES = ("선생님", "선생", "쌤", "님")


def _canon_role(v):
    """직급 표기를 정규 이름으로 — 못 알아보면 None(호출부가 오류로 처리)."""
    t = _norm_text(v).replace(" ", "")
    if not t:
        return ""
    hit = _ROLE_ALIASES.get(t.lower())
    if hit:
        return hit
    for suf in _ROLE_SUFFIXES:
        if len(t) > len(suf) and t.endswith(suf):
            hit = _ROLE_ALIASES.get(t[: -len(suf)].lower())
            if hit:
                return hit
    return None

def _check_shift_code(code: str, context: str,
                      errors: Optional[_ErrorCollector] = None) -> bool:
    """가능근무 칸의 코드 하나가 이 앱이 아는 근무유형인지 확인 — 오타/미지원 코드를
    조용히 삼키지 않고 어느 사람의 어느 칸인지와 함께 바로 알려준다. 반환값은 코드가
    유효했는지(True/False) — errors가 주어지면 무효해도 예외 대신 이 값으로 알려준다."""
    try:
        parse_shift(code)
        return True
    except ValueError:
        msg = (f"{context}에 알 수 없는 근무유형이 있습니다: {code!r} "
               "(D/E/N/8A/9A/10A/NK/prn/T/TW, 그리고 2N/3N/지정만 인식됩니다)")
        if errors is not None:
            errors.add(msg)
            return False
        raise ExcelInputError(msg)


#: 가능근무 칸에 적지만 **근무코드가 아닌** 값들 → Staff.flags로 옮겨진다.
#:
#: 2N/3N은 '야간을 몇 일씩 묶어 서고 싶은가'라는 선호고, 지정은 '이 사람은 지정 인원으로
#: 셀 수 있다'는 표시다. 셋 다 근무표 칸에 찍히는 코드가 아니라 그 사람의 성질이므로
#: allowed_shifts가 아니라 flags로 간다 — allowed_shifts에 넣으면 H1-3(허용범위)이
#: '2N이라는 근무를 배정할 수 있다'고 읽어 엉뚱한 자리에서 통과시킨다.
#:
#: 2N/3N은 **N을 안 적어도 야간 가능자로 본다**(파트장 확인). 'D,E,3N'처럼 적는 것이
#: 자연스럽다는 판단인데, 대신 N을 지우고 3N만 남긴 실수는 걸러낼 수 없다.
_ALLOWED_EXTRA_FLAGS = {
    "2n": ("night_block_2", ["N"]),
    "3n": ("night_block_3", ["N"]),
    "지정": ("designated", []),
    # 야간리더는 2N/3N과 같이 **N을 안 적어도 야간 가능자로 본다** — '밤을 맡길 수
    # 있다'고 적어두고 야간을 못 서는 것은 말이 안 되기 때문이다.
    "야간리더": ("night_leader", ["N"]),
    "n리더": ("night_leader", ["N"]),
}


#: '야간리더' 칸에서 **'그렇다'로만 읽히는** 표기. 뜻이 하나뿐인 것만 넣는다.
_NIGHT_LEADER_YES = {"o", "ｏ", "○", "◯", "●", "v", "ｖ", "y", "yes",
                     "예", "네", "ㅇ", "야간리더", "n리더", "리더",
                     "√", "✓", "☑", "체크", "true"}

#: **뜻이 갈리는** 표기 — 받지 않고 반려한다.
#:
#: 처음엔 'X'와 '0'도 '그렇다'로 읽었다. 엑셀에서 체크를 X로 하는 사람이 많다는
#: 이유였는데, 반대로 'X = 아님'으로 쓰는 사람도 그만큼 많다. 글자만 봐서는 어느
#: 쪽인지 알 수 없다 — 그런데도 받아들이면 **야간리더가 아닌 사람이 야간리더가 되고**
#: 그 밤은 Lv4 없이도 통과한다. 오류도 경고도 없다(v0.85 독립 QA, QA-03).
#:
#: 이 저장소의 규칙은 "읽는 방법이 하나뿐이면 알아서 고쳐 읽고, 두 가지로 읽힐 수
#: 있으면 반려하고 이유를 알려준다"이다. X·0은 뒤쪽이다.
_NIGHT_LEADER_AMBIGUOUS = {"x", "ｘ", "×", "✗", "0", "０", "no", "n",
                           "아니오", "아님", "해당없음", "false", "-"}


def night_leader_mark(value, context: str = "",
                      errors: Optional[_ErrorCollector] = None):
    """'야간리더' 칸 한 칸을 읽는다 — True/False, 못 읽으면 반려한다.

    빈 칸은 '아님'이다(양식 안내와 샘플이 "해당자만 O"로 통일돼 있다).
    """
    if value is None:
        return False
    t = _norm_text(value).replace(" ", "").lower()
    if not t:
        return False
    if t in _NIGHT_LEADER_YES:
        return True
    where = f"{context} " if context else ""
    if t in _NIGHT_LEADER_AMBIGUOUS:
        msg = (f"{where}'야간리더' 칸의 {_typed_display(value)} — 체크로 쓰신 건지 "
               "'아님'으로 쓰신 건지 알 수 없습니다. 해당자만 'O'를 적고 나머지는 "
               "비워주세요(빈 칸이 '아님'입니다).")
    else:
        msg = (f"{where}'야간리더' 칸의 {_typed_display(value)}를 읽지 못했습니다 — "
               "해당자만 'O'를 적고 나머지는 비워주세요.")
    if errors is not None:
        errors.add(msg)
    else:
        raise ExcelInputError(msg)
    return False


def _with_night_leader(flags: List[str], marked: bool) -> List[str]:
    """'야간리더' 열이 표시돼 있으면 flags에 더한다(이미 있으면 그대로).

    가능근무 칸에 '야간리더'라고 적은 경우는 _split_allowed가 이미 넣어 둔다 —
    둘 다 받되 중복되지 않게 한 곳에서 합친다."""
    if marked and "night_leader" not in flags:
        return flags + ["night_leader"]
    return flags


def _split_allowed(allowed_raw, context: str,
                   errors: Optional[_ErrorCollector] = None):
    """가능근무 칸의 토큰들을 (근무코드, 추가 flags)로 나눈다.

    세 곳(인원 시트·원티드표·연간근무표)이 같은 칸을 읽으므로 한 곳에만 둔다. 예전에
    같은 파싱이 세 벌로 흩어져 있었다면 2N을 인원 시트에서만 알아듣고 원티드표에서는
    '알 수 없는 근무유형'으로 반려하는 상태가 됐을 것이다."""
    codes, flags = [], []
    had_unknown = False
    for a in allowed_raw:
        key = _norm_text(a).replace(" ", "").lower()
        hit = _ALLOWED_EXTRA_FLAGS.get(key)
        if hit:
            flag, implies = hit
            if flag not in flags:
                flags.append(flag)
            for c in implies:
                if c not in codes:
                    codes.append(c)
            continue
        if _check_shift_code(a, context=context, errors=errors):
            codes.append(a)
        else:
            had_unknown = True
    if "night_block_2" in flags and "night_block_3" in flags:
        # 2일 블록과 3일 블록은 같이 만족시킬 수 없다 — 뜻이 갈리므로 반려한다.
        msg = (f"{context}에 2N과 3N이 함께 적혀 있습니다 — 야간을 2일씩 묶을지 3일씩 "
               "묶을지 하나만 골라주세요.")
        if errors is not None:
            errors.add(msg)
        else:
            raise ExcelInputError(msg)
        flags = [f for f in flags if f not in ("night_block_2", "night_block_3")]
    if allowed_raw and not codes and not had_unknown:
        # '지정'만 적힌 경우 — 칸이 비어 있진 않지만 배정할 근무는 하나도 없다.
        # 모르는 코드가 섞여 있었다면 _check_shift_code가 이미 각각 알려줬으므로
        # 여기서 또 말하지 않는다(같은 실수를 두 줄로 알리면 몇 건인지 헷갈린다).
        msg = (f"{context}에 근무코드가 하나도 없습니다 — '지정'은 근무가 아니라 표시라서, "
               "D·E·N 같은 근무를 함께 적어야 배정됩니다.")
        if errors is not None:
            errors.add(msg)
        else:
            raise ExcelInputError(msg)
    return codes, flags


# 직급은 '파트장'/'리더'가 규칙에 직접 걸린다(파트장은 8A 고정·편집 잠금, 리더는 리더
# 보유 규칙). 오타로 '리덩'이라 적으면 그 사람은 그냥 간호사로 취급돼, 리더 없는 근무표가
# 정상처럼 나온다 — 조용히 뜻이 바뀌므로 아는 직급만 받는다.
KNOWN_ROLES = ("파트장", "리더", "간호사")


def _check_role(role: str, context: str, errors: Optional[_ErrorCollector] = None) -> str:
    """직급 정규화 — 'LEADER', ' 리더 ', 'ｎｕｒｓｅ'처럼 표기만 다른 건 받아주고,
    '리덩'처럼 뜻을 알 수 없는 것만 반려한다(그 사람이 조용히 간호사가 되면 리더 배정
    규칙이 통째로 빠진다)."""
    canon = _canon_role(role)
    if canon == "":
        return "간호사"
    if canon:
        return canon
    r = _norm_text(role)
    msg = (f"{context}에 알 수 없는 직급이 있습니다: {r!r} "
           f"({' / '.join(KNOWN_ROLES)} 중에서 적어주세요 — 오타면 그 사람이 "
           "간호사로 처리돼 리더 배정 규칙이 조용히 빠집니다)")
    if errors is not None:
        errors.add(msg)
        return "간호사"
    raise ExcelInputError(msg)


def _is_known_shift_code(code: str) -> bool:
    """예외도 오류수집도 없이 '아는 코드인지'만 조용히 판별 — 전입자가 가져온 전 병동
    기록처럼, 모르는 표기를 반려 대신 건너뛰고 목록으로만 알려줘야 하는 곳에서 쓴다."""
    try:
        parse_shift(code)
        return True
    except ValueError:
        return False


_DATE_SEP_RE = re.compile(r"^(\d{4})\s*[-./]\s*(\d{1,2})\s*[-./]\s*(\d{1,2})$")
_DATE_KOREAN_RE = re.compile(r"^(\d{1,2})\s*월\s*(\d{1,2})\s*일$")


def _normalize_date(raw, year_hint: int, context: str,
                    errors: Optional[_ErrorCollector] = None) -> Optional[str]:
    """신청 시트의 날짜 칸을 최대한 관대하게 읽어 'YYYY-MM-DD'로 돌려준다 — 엑셀 날짜
    셀은 물론, "2026.9.5"/"2026/9/5" 같은 구분자 표기나 "9월 5일"(연도는 이 함수에
    넘겨준 설정 시트 연도로 채움)도 인식한다. 못 알아보면 errors에 담고 None을
    돌려준다(그 신청 한 줄만 건너뛴다)."""
    if hasattr(raw, "strftime"):
        return raw.strftime("%Y-%m-%d")
    s = str(raw).strip()
    m = _DATE_SEP_RE.match(s)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        return f"{y:04d}-{mo:02d}-{d:02d}"
    m = _DATE_KOREAN_RE.match(s)
    if m:
        mo, d = int(m.group(1)), int(m.group(2))
        return f"{year_hint:04d}-{mo:02d}-{d:02d}"
    msg = (f"{context}: 날짜 칸을 알아볼 수 없습니다: {raw!r} — "
           "날짜 형식(예: 2026-09-05, 2026.9.5, 9월 5일)인지 확인하세요.")
    if errors is not None:
        errors.add(msg)
        return None
    raise ExcelInputError(msg)


# 비고에 적는 근무 제약 표기. 같은 뜻을 사람마다 다르게 적는다 — '임부'만 알아듣던
# 시절엔 '임신'이라고 적은 사람의 임부 보호가 통째로 빠졌다. 그것도 조용히: 비고는
# 자유 입력이라 못 알아들어도 아무 말이 없고, 근무표는 정상으로 보인다.
_FLAG_ALIASES = (
    ("night_only", ("야간전담", "나이트전담", "n전담", "야간고정", "나이트고정",
                    "야간전용", "나이트전용", "야간only")),
    ("pregnant", ("임부", "임신", "임산부")),
    ("no_night", ("야간금지", "나이트금지", "야간불가", "나이트불가",
                  "야간제외", "나이트제외", "야간x")),
)
# 위 표에 없는 표현도 '무엇을(주어) 어떻게(서술어)'가 함께 있으면 뜻이 하나뿐이다 —
# '야간 안됨'·'나이트 빼주세요'를 반려하면 파트장은 정답 표기를 외워야 한다. 표는
# 자주 쓰는 말을 빨리 잡기 위한 것이고, 아래 조합이 실제 판정이다.
_FLAG_NIGHT_RE = re.compile(r"야간|나이트|night")
_FLAG_PREGNANT_RE = re.compile(r"임신|임부|임산부")
_FLAG_ONLY_RE = re.compile(r"전담|전용|고정|only")
_FLAG_DENY_RE = re.compile(r"금지|불가|제외|배제|안됨|못함|안돼|안함|빼|x")


# 안내에 쓸 표준 표기 — 파트장이 다르게 적었을 때 "다음엔 이렇게" 하고 보여줄 말.
_FLAG_STANDARD_WORD = {"night_leader": "야간리더",
                       "night_only": "야간전담", "pregnant": "임부",
                       "no_night": "야간금지"}


def _parse_flags(note: str) -> List[str]:
    note = _norm_text(note).replace(" ", "").lower()
    flags = []
    for flag, words in _FLAG_ALIASES:
        if any(w in note for w in words):
            flags.append(flag)
    if "pregnant" not in flags and _FLAG_PREGNANT_RE.search(note):
        flags.append("pregnant")
    if _FLAG_NIGHT_RE.search(note):
        if "night_only" not in flags and _FLAG_ONLY_RE.search(note):
            flags.append("night_only")
        elif "no_night" not in flags and _FLAG_DENY_RE.search(note):
            flags.append("no_night")
    # 임부는 야간금지를 이미 포함한다 — 둘 다 붙이면 같은 제약이 두 번 잡힌다.
    if "pregnant" in flags and "no_night" in flags:
        flags.remove("no_night")
    # '야간전담'과 '야간금지'가 한 칸에 같이 적혀 있으면 어느 쪽인지 알 수 없다.
    if "night_only" in flags and "no_night" in flags:
        return []
    return sorted(set(flags))


def _merge_flags(note_flags: List[str], allowed_flags: List[str]) -> List[str]:
    """비고에서 읽은 flags와 가능근무 칸에서 읽은 flags를 합친다.

    _parse_flags가 정렬된 목록을 돌려주므로 여기서도 정렬해 돌려준다 — 순서가 들쭉날쭉하면
    같은 사람인데 출력②를 거칠 때마다 값이 달라 보인다."""
    return sorted(set(note_flags) | set(allowed_flags))


def _flag_note_looks_unread(note: str, flags: List[str]) -> bool:
    """비고에 제약을 적으려 한 것 같은데 아무 규칙도 안 잡혔는지.

    비고는 자유 입력이라 못 알아들어도 아무 말이 없다 — 그 침묵이 위험하다. 근무유형
    말이 있는데 규칙이 하나도 안 잡혔으면(서술어를 못 알아봤거나 전담·금지가 한 칸에
    같이 적혀 뜻이 갈리는 경우) 알려준다. '3년차' 같은 단순 메모는 잡지 않는다."""
    if flags:
        return False
    t = _norm_text(note).replace(" ", "").lower()
    if not t:
        return False
    return bool((_FLAG_NIGHT_RE.search(t) or _FLAG_PREGNANT_RE.search(t))
                and (_FLAG_ONLY_RE.search(t) or _FLAG_DENY_RE.search(t)))


# 전입자 표식 — 파트장이 연간근무표에 전입자 행을 추가하고 비고에 이 말을 적으면,
# 그 행의 날짜 칸에 붙여넣은 전 병동 근무기록을 이월정보·야간형평성 계산에만 쓴다.
# 누적통계(누적야간·반영개월수 등 부서 실적)는 우리 병동 입사 시점부터 0에서 시작한다
# (전 병동 실적이 부서 연말 집계에 섞이면 안 되므로 — 확정된 운영 방침).
_TRANSFER_IN_MARK = "전입"
# 드롭다운으로 고르는 칸이지만 직접 타이핑하는 경우도 있다 — 뜻이 하나뿐인 표기는 받아준다.
_TRANSFER_IN_ALIASES = ("전입", "전입자", "이동", "전과", "o", "ㅇ", "y", "yes", "예", "네", "v")
# 비고의 전입일 표기 — "전입 2026-02-15" / "전입 2026.2.15" / "전입 2026/2/15" 모두 인식
# (공백은 이미 제거한 문자열에서 찾는다). 날짜가 없으면 월초(1일자) 전입으로 본다.
_TRANSFER_DATE_RE = re.compile(r"(\d{4})[-./](\d{1,2})[-./](\d{1,2})")
# "2026년 8월 5일"처럼 한글로 적은 날짜도 뜻이 하나뿐이다 — 못 읽고 되돌려보내면
# 파트장은 무엇이 문제인지 모른 채 같은 값을 다시 적게 된다.
_TRANSFER_DATE_KO_RE = re.compile(r"(\d{4})년(\d{1,2})월(\d{1,2})일?")
# 연도를 뺀 표기 — 양식이 이미 "2026년 9월 원티드표"라서, 그 안의 "15"·"9월15일"·"9/15"는
# 읽는 방법이 하나뿐이다. 실제로 파트장이 가장 많이 치는 것이 이 셋인데 예전엔 전부
# '못 읽음'으로 되돌려보내고 1일자 전입으로 처리했다 — 경고는 떴지만, 경고를 놓치면
# 입사 전 날짜에 근무가 들어간다. 뜻이 하나면 받아주는 편이 안전하다.
_TRANSFER_DATE_DAY_RE = re.compile(r"^(\d{1,2})일?$")
_TRANSFER_DATE_MD_KO_RE = re.compile(r"^(\d{1,2})월(\d{1,2})일?$")
_TRANSFER_DATE_MD_RE = re.compile(r"^(\d{1,2})[-./](\d{1,2})$")

# 누적통계 중 '우리 병동 실적'에 해당해 전입자는 0에서 시작해야 하는 항목.
# 잔휴(off_balance)와 최근야간점수(recent_night_score)는 그 사람에게 귀속되는
# 값이라 전 병동 것을 그대로 이어받는다(잔휴는 전 병동에서 받아온 숫자를 적는다).
_WARD_CUMULATIVE_KEYS = ("night", "workday", "off", "weekend_night",
                         "blocks_2", "blocks_3", "months",
                         "cum_d", "cum_e", "cum_prn", "cum_weekend_holiday_off",
                         "cum_festival_off")


def _reject_bad_transfer_dates(errors, bad: List[str], out_of_month: List[str],
                               ym: Optional[Tuple[int, int]]) -> None:
    """전입일이 뜻이 안 잡히면 반려한다.

    예전엔 경고만 하고 **1일자 전입으로 처리**했다. 경고를 놓치면 입사 전 날짜에 근무가
    들어가고, 근무표만 봐서는 틀린 줄 알 수가 없다 — 급여·출근과 연결되는 값이라 이
    저장소에서 제일 나쁜 부류다.

    칸이 비어 있는 것과 값이 있는데 못 읽는 것은 다르게 다룬다. **비어 있으면 그대로
    1일자 전입**이다(뜻이 하나뿐이다). 뭔가 적혀 있다는 것은 '월중 전입'이라는 뜻인데
    며칠인지 모른 채 1일로 넣는 것은 추측이다 — 뜻이 갈리면 반려한다.

    이 달 밖의 날짜도 같이 반려한다. 적어놓고 안 먹은 줄 모르면 파트장은 월중 전입
    처리가 된 줄로 알고 넘어간다(하류가 이번 달 것만 걸러 쓴다)."""
    if bad:
        if ym:
            year, month = ym
            how = (f"{year}년 {month}월 안의 날짜로 적어주세요. "
                   f"'15'·'{month}월15일'·'{month}/15'·'{year}-{month:04d}-15'"
                   .replace(f"{month:04d}", f"{month:02d}") + " 다 됩니다.")
        else:
            how = "'2026-09-15'처럼 연·월·일을 다 적어주세요."
        errors.add(
            f"'전입일' 칸을 읽지 못했습니다 {len(bad)}건({', '.join(bad)}) — {how} "
            "월초(1일) 전입이면 칸을 비워두시면 됩니다.")
    if out_of_month and ym:
        year, month = ym
        errors.add(
            f"'전입일'이 {year}년 {month}월 밖입니다 {len(out_of_month)}건"
            f"({', '.join(out_of_month)}) — 이 파일은 {year}년 {month}월 근무표에 쓰이므로 "
            "그 날짜는 이번 달 배정에 반영되지 않습니다. 월중 전입이면 이 달 안의 날짜로, "
            "지난달에 이미 오신 분이면 칸을 비워주세요.")


def _read_transfer_date_cell(v, who: str, bad: List[str],
                             default_ym: Optional[Tuple[int, int]] = None) -> Optional[str]:
    """'전입일' 칸 — 엑셀 날짜 셀이면 그대로, 글자로 적혔으면 관대하게 읽는다.

    default_ym은 이 파일이 가리키는 (연, 월)이다. 주면 연도·월을 뺀 표기("15",
    "9월15일", "9/15")도 그 값으로 채워 읽는다 — 양식 제목에 연월이 박혀 있으니
    읽는 방법이 하나뿐이다. 안 주면 예전처럼 네 자리 연도가 있어야만 읽는다.

    달력에 없는 날짜(2/31 등)나 못 알아볼 값은 돌려주지 않고 bad에 담는다. 그냥
    무시하면 월초 전입으로 조용히 처리돼 입사 전 날짜에 근무가 들어가버린다."""
    if v is None or (isinstance(v, str) and not v.strip()):
        return None
    # 날짜 서식 칸에 0이나 소수를 치면 엑셀은 그것을 '시각'으로 본다(0 → 00:00:00).
    # datetime.time에는 연·월·일이 아예 없어서 날짜로 읽을 방법이 없다 — 예전엔
    # strftime이 조용히 1900-01-01을 만들어 그 사람이 1900년 전입으로 처리됐다.
    if isinstance(v, _dt.time) and not isinstance(v, _dt.datetime):
        bad.append(f"{who}: {v}")
        return None
    if isinstance(v, (_dt.date, _dt.datetime)):
        # 이 칸은 날짜 서식이라, 파트장이 그냥 "15"를 치면 엑셀이 일련번호 15로 받아
        # 1900-01-15로 만든다. 글자 "15"는 15일로 읽으면서 숫자 15만 1900년이 되면
        # 앞뒤가 안 맞고, 무엇보다 파트장이 뜻한 건 언제나 '이 달 15일'이다.
        # 1900년 1월은 그 일련번호 1~31이 그대로 날짜가 된 경우뿐이라 되돌릴 수 있다.
        if v.year < 1970:
            if (v.year, v.month) == (1900, 1):
                # 되돌린 숫자로 알려준다 — 파트장이 친 것은 '31'이지 '1900-01-31'이 아니라,
                # 엑셀이 만든 날짜를 그대로 보여주면 무엇을 고쳐야 할지 알 수 없다.
                if default_ym:
                    try:
                        return _dt.date(default_ym[0], default_ym[1], v.day).isoformat()
                    except ValueError:
                        pass
                bad.append(f"{who}: {v.day}")
                return None
            bad.append(f"{who}: {v}")
            return None
        return v.strftime("%Y-%m-%d")
    # 전각으로 친 숫자·구분자(２０２６．９．５)도 눈에는 같은 날짜다 — 반각으로 맞춰 읽는다.
    text = _to_halfwidth(str(v)).replace(" ", "").replace("．", ".")
    # 엑셀이 "15"를 숫자로 들고 있으면 str()이 "15.0"으로 준다 — 눈에 보이는 건 15다.
    if text.endswith(".0") and text[:-2].isdigit():
        text = text[:-2]
    ymd = None
    m = _TRANSFER_DATE_RE.search(text) or _TRANSFER_DATE_KO_RE.search(text)
    if m:
        ymd = (int(m.group(1)), int(m.group(2)), int(m.group(3)))
    elif default_ym:
        y, mon = default_ym
        md = _TRANSFER_DATE_MD_KO_RE.match(text) or _TRANSFER_DATE_MD_RE.match(text)
        if md:
            ymd = (y, int(md.group(1)), int(md.group(2)))
        else:
            dd = _TRANSFER_DATE_DAY_RE.match(text)
            if dd:
                ymd = (y, mon, int(dd.group(1)))
    if ymd:
        try:
            return _dt.date(*ymd).isoformat()
        except ValueError:
            bad.append(f"{who}: {v}")
            return None
    bad.append(f"{who}: {v}")
    return None


def _split_list(v) -> List[str]:
    """"D,E,N" 형태를 항목 리스트로 — 쉼표·가운뎃점 말고도 슬래시·세미콜론·공백·줄바꿈
    으로 구분해도 관대하게 받아준다(예: "D E N", "D/E/N" 모두 ["D","E","N"])."""
    if v is None:
        return []
    items = [x for x in re.split(r"[,·/;\s]+", _norm_text(v)) if x]
    # 같은 코드를 두 번 적어도(D,D,E) 뜻은 하나다 — 순서만 지키고 중복은 지운다.
    seen, out = set(), []
    for x in items:
        k = x.upper()
        if k not in seen:
            seen.add(k)
            out.append(x)
    return out


def load_input_xlsx(path: str) -> dict:
    """입력 엑셀 → 설정 dict (JSON 입력과 동일 스키마)."""
    _reject_empty_formulas(path)
    wb = _load_workbook_safe(path)

    for need in ("설정", "인원", "최소인력"):
        if need not in wb.sheetnames:
            raise ExcelInputError(f"필수 시트 누락: {need}")

    # -------- 설정
    kv: Dict[str, object] = {}
    dup_keys: List[str] = []
    for row in wb["설정"].iter_rows(values_only=True):
        if row and row[0] is not None and str(row[0]).strip() not in ("항목", ""):
            key = str(row[0]).strip()
            val = row[1] if len(row) > 1 else None
            # 같은 항목이 두 줄이어도 값이 같으면(복사하다 줄이 겹친 경우) 그냥 받는다.
            # 값이 다를 때만 막는다 — 어느 줄이 반영됐는지 모른 채 설정이 바뀌니까.
            if key in kv and _norm_text(kv[key]) != _norm_text(val):
                dup_keys.append(key)
            kv[key] = val
    if dup_keys:
        raise ExcelInputError(
            f"설정 시트에 같은 항목이 서로 다른 값으로 두 번 이상 있습니다: "
            f"{', '.join(sorted(set(dup_keys)))} — 어느 값을 써야 할지 알 수 없으니 "
            "한 줄만 남겨주세요.")

    errors = _ErrorCollector()
    if "연도" not in kv or "월" not in kv or kv["연도"] in (None, "") or kv["월"] in (None, ""):
        raise ExcelInputError("설정 시트에 연도/월이 없습니다")
    # 연·월도 다른 숫자 칸과 같은 파서를 쓴다 — 예전엔 int()로 바로 잘라서 8.9가
    # 8월로 조용히 통과했다.
    year = _int_cell(kv["연도"], "설정 시트 '연도' 칸")
    month = _int_cell(kv["월"], "설정 시트 '월' 칸")
    if not (1 <= month <= 12):
        raise ExcelInputError(f"설정 시트의 월 값이 1~12월 범위를 벗어났습니다: {month!r}")
    if not (2020 <= year <= 2040):
        raise ExcelInputError(
            f"설정 시트의 연도가 지원 범위(2020~2040)를 벗어났습니다: {year} — "
            "공휴일 표가 2040년까지라 그 밖의 연도는 정확한 근무표를 만들 수 없습니다.")

    # -------- 인원
    rows = _sheet_rows(wb["인원"])
    h = _find_header(rows, "순번")
    if h is None:
        raise ExcelInputError("인원 시트에 '순번' 헤더가 없습니다")
    staff = []
    seen_names: Dict[str, int] = {}
    for row_no, r in enumerate(rows[h + 1:], start=h + 2):
        if not r or all(c is None or not str(c).strip() for c in r):
            continue  # 완전히 빈 행(표 아래 여백 등) — 조용히 건너뜀
        if r[1] is None or not str(r[1]).strip():
            # 이름 칸만 비어 있고 직급/숙련도/가능근무 등 다른 칸엔 값이 있는 행 —
            # 이름을 실수로 지웠거나 안 채운 경우일 가능성이 높아, 그 사람을 조용히
            # 빠뜨리는 대신(인원수가 예상보다 적어져도 티가 안 남) 바로 알려준다.
            errors.add(f"인원 시트 {row_no}행: 다른 칸은 채워져 있는데 이름 칸이 비어 있습니다.")
            continue
        name = _clean_name(r[1])
        if name in seen_names:
            errors.add(
                f"인원 시트 {row_no}행: 이름 '{name}'이 {seen_names[name]}행과 중복됩니다 "
                "— 이름은 한 명당 한 번만 적어야 합니다.")
            continue
        seen_names[name] = row_no
        _check_name_length(name, f"인원 시트 {row_no}행", errors)
        role = _check_role(r[2], f"인원 시트 {row_no}행({name}) 직급", errors)
        level = _parse_level(r[3], context=f"인원 시트 {row_no}행({name})", errors=errors)
        allowed_raw = _split_list(r[4])
        note = str(r[5] or "") if len(r) > 5 else ""
        allowed, allowed_flags = _split_allowed(
            allowed_raw, f"인원 시트 {row_no}행({name}) 가능근무", errors)
        if not allowed_raw:
            # 칸에 코드를 하나라도 적었는데 전부 알 수 없는 코드였던 경우는 위
            # _check_shift_code에서 이미 각각 알려줬으니 여기서 또 알릴 필요 없다 —
            # 칸 자체가 처음부터 완전히 비어 있던 경우만 별도로 알린다.
            errors.add(
                f"인원 시트 {row_no}행({name}): 가능근무 칸이 비어 있습니다 — "
                "이 사람에게 배정할 수 있는 근무가 하나도 없다는 뜻이라, 대개는 입력 실수입니다."
            )
        staff.append({
            "id": name, "role": role, "level": level,
            "allowed_shifts": allowed,
            "flags": _merge_flags(_parse_flags(note), allowed_flags),
        })
    if not staff:
        raise ExcelInputError("인원 시트가 비어 있습니다 — 순번 아래에 최소 1명은 입력해야 합니다.")

    # -------- 최소인력
    rows = _sheet_rows(wb["최소인력"])
    h = _find_header(rows, "근무")
    if h is None:
        raise ExcelInputError("최소인력 시트에 '근무' 헤더가 없습니다")
    mins = {"weekday": {}, "saturday": {}, "sunday_holiday": {}}
    # 대소문자를 관대하게 받아준다(예: "PRN"→"prn") — 인원 시트 가능근무 칸과 동일한
    # 정책. "8A" 등은 파트장이 자동으로 채우는 정보성 행이라 원래부터 값 없이도 되고,
    # 그 외 알아볼 수 없는 표기는(예전엔 조용히 통째로 무시됐다) 이제 문제로 모아둔다.
    # '지정'은 근무유형이 아니라 "그날 지정 가능자가 몇 명 근무해야 하는가"다. 값이
    # 근무유형별 최소인력과 같은 표에 있어야 요일별로 다르게 줄 수 있어서 여기에 둔다.
    _MIN_STAFF_KEY_MAP = {"d": "D", "e": "E", "n": "N", "prn": "prn",
                          DESIGNATED_KEY: DESIGNATED_KEY}
    _MIN_STAFF_INFO_ROWS = {"8a", "9a", "10a"}
    # 평일을 요일별(월~금)로 따로 지정하는 병동을 위한 선택 열 — "평일" 칸(1번) 뒤에
    # 이 5개 헤더가 정확히 이 순서로 있으면(옛 파일엔 없음 — 하위호환) 그 요일 칸을
    # 그 요일만의 값으로 읽는다. 칸을 비워두면(어떤 근무 행이든) 그 요일은 "평일"
    # 공통값을 그대로 쓴다 — 요일 전부를 다 채울 필요 없이 다른 요일만 있는 병동도 지원.
    _WEEKDAY_DOW_COLS = [(4, "0", "월"), (5, "1", "화"), (6, "2", "수"),
                        (7, "3", "목"), (8, "4", "금")]
    header_row = rows[h] if rows[h] else ()
    has_dow_cols = all(
        len(header_row) > col and str(header_row[col] or "").strip() == label
        for col, _, label in _WEEKDAY_DOW_COLS)
    weekday_by_dow: Dict[str, Dict[str, int]] = {}
    for r in rows[h + 1:]:
        if not r or r[0] is None or not str(r[0]).strip():
            continue
        raw_key = str(r[0]).strip()
        key = _MIN_STAFF_KEY_MAP.get(raw_key.lower())
        if key is None:
            if raw_key.lower() in _MIN_STAFF_INFO_ROWS:
                continue  # 파트장 자동 배정 안내용 행 — 값 없이 지나감
            errors.add(
                f"최소인력 시트: '근무' 칸에 알 수 없는 값이 있습니다: {raw_key!r} "
                "(D/E/N/prn/지정만 인식됩니다)")
            continue
        mins["weekday"][key] = _int_cell(r[1], f"최소인력 시트 '{key}' 행 평일 칸",
                                         default=0, errors=errors, min_value=0)
        mins["saturday"][key] = _int_cell(r[2], f"최소인력 시트 '{key}' 행 토요일 칸",
                                          default=0, errors=errors, min_value=0)
        mins["sunday_holiday"][key] = _int_cell(
            r[3], f"최소인력 시트 '{key}' 행 일요일·공휴일 칸", default=0, errors=errors,
            min_value=0)
        if has_dow_cols:
            for col, dow, label in _WEEKDAY_DOW_COLS:
                cell = r[col] if len(r) > col else None
                if cell is None or str(cell).strip() == "":
                    continue
                v = _int_cell(cell, f"최소인력 시트 '{key}' 행 {label} 칸",
                              errors=errors, min_value=0)
                weekday_by_dow.setdefault(dow, {})[key] = v
    if weekday_by_dow:
        mins["weekday_by_dow"] = weekday_by_dow
    # '지정' 행이 없는 옛 파일도 그대로 읽는다 — 없으면 0(지정을 쓰지 않는 병동)이다.
    # 여기서 채워두면 화면·저장·다시 읽기를 오가도 값이 생겼다 없어졌다 하지 않는다.
    for _dt in ("weekday", "saturday", "sunday_holiday"):
        mins[_dt].setdefault(DESIGNATED_KEY, 0)

    # -------- 신청 (선택)
    requests = []
    if "신청" in wb.sheetnames:
        rows = _sheet_rows(wb["신청"])
        h = _find_header(rows, "이름")
        if h is not None:
            for row_no, r in enumerate(rows[h + 1:], start=h + 2):
                if not r or r[0] is None or not str(r[0]).strip():
                    continue
                who = str(r[0]).strip()
                date_str = _normalize_date(
                    r[1], year, context=f"신청 시트 {row_no}행({who})", errors=errors)
                if date_str is None:
                    continue  # 날짜를 못 읽었으면 이 신청 한 줄만 건너뜀(errors엔 이미 기록됨)
                if r[2] is None or not str(r[2]).strip():
                    errors.add(f"신청 시트 {row_no}행({who}): 근무유형 칸이 비어 있습니다.")
                    continue
                requests.append({
                    "staff_id": who,
                    "date": date_str,
                    "type": str(r[2]).strip(),
                    "priority": _int_cell(r[3], f"신청 시트 {row_no}행({who}) 우선순위 칸",
                                          default=1, errors=errors, min_value=0)
                                if len(r) > 3 else 1,
                })

    # -------- 전월이월 (선택)
    carry = {}
    if "전월이월" in wb.sheetnames:
        rows = _sheet_rows(wb["전월이월"])
        h = _find_header(rows, "이름")
        if h is not None:
            for row_no, r in enumerate(rows[h + 1:], start=h + 2):
                if not r or r[0] is None or not str(r[0]).strip():
                    continue
                who = str(r[0]).strip()
                trailing = _int_cell(
                    r[4], f"전월이월 시트 {row_no}행({who}) 말일연속야간일수 칸",
                    default=0, errors=errors, min_value=0
                ) if len(r) > 4 else 0
                carry[who] = {
                    "last_shift_type": str(r[1] or "OFF").strip(),
                    "consecutive_work_days": _int_cell(
                        r[2], f"전월이월 시트 {row_no}행({who}) 연속근무일수 칸",
                        default=0, errors=errors, min_value=0),
                    "night_block_remaining_off": _int_cell(
                        r[3], f"전월이월 시트 {row_no}행({who}) 이월OFF일수 칸",
                        default=0, errors=errors, min_value=0),
                    "night_block_in_progress": trailing == 1,
                    "trailing_night_count": trailing,
                }

    errors.raise_if_any()

    # -------- B팀(신입, 선택) — 이름만. 스케줄링에 관여하지 않고 출력 시 이름만 표시.
    team_b_names = []
    if "B팀" in wb.sheetnames:
        rows = _sheet_rows(wb["B팀"])
        h = _find_header(rows, "이름")
        if h is not None:
            for r in rows[h + 1:]:
                if r and r[0] is not None and str(r[0]).strip():
                    team_b_names.append(str(r[0]).strip())

    nk_count = sum(1 for s in staff if "night_only" in s["flags"])
    # 공휴일/대체공휴일은 입력엑셀에서 직접 받지 않고 항상 자동으로 채운다(kr_holidays_for_month,
    # 2040년까지 알려진 규칙 기반 — 사용자가 매번 날짜를 나열할 필요 없게 단순화).
    holidays, substitute_holidays = kr_holidays_for_month(year, month)
    return {
        "ward_id": str(kv.get("병동명", "") or ""),
        "year": year, "month": month,
        "staff": staff,
        "params": {
            "nk_count": _int_cell(kv.get("NK인원수"), "설정 시트 'NK인원수' 칸",
                                  default=nk_count, min_value=0),
            "min_staff": mins,
            # 리더8A운용은 웹 UI에도 없는 설정이라 엑셀에서도 뺐다 — 항상 기본값(False)만 쓴다.
            "leader_8a_as_prn": False,
            "off_max_per_month": _int_cell(kv.get("월최대야간"), "설정 시트 '월최대야간' 칸",
                                           default=6, min_value=0),
            # 월신청상한도 입력엑셀에서 직접 받지 않고 고정값을 쓴다(단순화).
            "max_requests_per_person": DEFAULT_MAX_REQUESTS_PER_PERSON,
            "holidays": holidays,
            "substitute_holidays": substitute_holidays,
            "advanced_track_staff": _split_list(kv.get("심화과정대상")),
            "team_b_names": team_b_names,
            # H6-4 월 야간목표 하한/상한 — 선택 입력(기본 4/6일). 상한을 홀수로
            # 올리면(예: 7) 3일 블록도 자동 허용되니 월최대야간도 함께 올려야 한다.
            "night_quota_low": _int_cell(kv.get("야간목표하한"), "설정 시트 '야간목표하한' 칸",
                                         default=4, min_value=0),
            "night_quota_high": _int_cell(kv.get("야간목표상한"), "설정 시트 '야간목표상한' 칸",
                                          default=6, min_value=0),
            # H3-1 안전 규칙(연속근무 상한) — 선택 입력(기본 5일). 낮출수록 배치
            # 자유도가 줄어 §H6-1(주간 3~4일 블록) 등이 더 자주 못 지켜질 수 있다.
            # 최소 1(0 이하면 아무도 하루도 일할 수 없어 배정 자체가 불가능해진다).
            "max_consecutive_work": _int_cell(
                kv.get("연속근무제한"), "설정 시트 '연속근무제한' 칸", default=5, min_value=1),
        },
        "prev_month_carryover": carry,
        "requests": requests,
    }


# ---------------------------------------------------------------- 월간근무표 형태 엑셀 공통 (제목행 + 이름|1일|2일|...)

def _parse_monthly_grid_shape(ws):
    """제목 행(A1) 'YYYY년 M월' + 2행 일자 헤더 + 4행부터 이름|근무... 모양 파싱.

    "월간근무표"(이 앱이 내보낸 근무표) 다운로드/전월이월 자동채움/원티드 업로드가
    전부 이 모양을 공유한다. 반환: (year, month, num_days, first_day_col).
    """
    import re
    # 제목 앞에 공백이 있거나 전각으로 쳤어도 뜻은 같다 — 표기만 맞춰 읽는다.
    title = _norm_text(ws.cell(1, 1).value)
    m = re.search(r"(\d{4})\s*년\s*(\d{1,2})\s*월", title)
    if not m:
        raise ExcelInputError(
            "제목 행(A1)에서 'YYYY년 M월' 형식을 찾지 못했습니다 — "
            "월간근무표와 같은 모양(이름|1일|2일|...)인지 확인하세요."
        )
    year, month = int(m.group(1)), int(m.group(2))
    # 일자 열: 예전 포맷(3열부터 1일)과 잔휴 2열이 추가된 신규 포맷(5열부터 1일) 둘 다
    # 읽을 수 있도록, 2행에서 "1"이 나오는 열을 찾아 첫 일자 열로 삼는다(고정 열번호
    # 대신 동적 탐지 — 선두 열이 몇 개든 견고하게 동작).
    first_day_col = None
    # 탐색 폭은 정적 칸 수보다 넉넉해야 한다. 예전엔 range(1, 10)이었는데 '야간리더'
    # 칸이 늘어 1일이 9열이 되면서 여유가 사라졌다 — 헤더가 한 칸만 더 밀리거나
    # 어긋나도 "1일 열을 못 찾았다"로 반려되고, 파트장은 무엇이 문제인지 알 수 없다.
    # 정적 칸 목록에서 계산해 앞으로 칸이 늘어도 따라오게 한다.
    for col in range(1, len(_WANTED_STATIC_LABELS) + 6):
        if ws.cell(2, col).value == 1:
            first_day_col = col
            break
    if first_day_col is None:
        raise ExcelInputError("2행에서 1일(숫자 1) 열을 찾지 못했습니다.")
    col = first_day_col
    while isinstance(ws.cell(2, col).value, (int, float)):
        col += 1
    num_days = col - first_day_col
    if not (28 <= num_days <= 31):
        raise ExcelInputError(f"일자 열을 인식하지 못했습니다 (인식된 일수: {num_days})")
    # 일자 헤더가 1일부터 말일까지 순서대로 빠짐없이 있는지 확인한다. 순서가 바뀌거나
    # 하나가 비면 그 열의 신청이 엉뚱한 날로 읽히거나 조용히 사라진다(1일과 2일 헤더를
    # 맞바꾸면 1일 신청이 0건이 되는 식).
    import calendar as _cal
    got = [ws.cell(2, first_day_col + i).value for i in range(num_days)]
    want = list(range(1, num_days + 1))
    if [int(v) for v in got] != want:
        bad = next((i for i, (g, w) in enumerate(zip(got, want)) if int(g) != w), 0)
        raise ExcelInputError(
            f"일자 헤더가 1일부터 순서대로 있지 않습니다 — {bad + 1}번째 일자 칸이 "
            f"{got[bad]!r}입니다(있어야 할 값: {want[bad]}). 헤더를 고치시거나 "
            "'양식(다운로드)'로 새 양식을 받아 채워주세요.")
    real_days = _cal.monthrange(year, month)[1]
    if num_days != real_days:
        raise ExcelInputError(
            f"제목은 {year}년 {month}월({real_days}일)인데 일자 칸은 {num_days}일치입니다 — "
            "제목(A1)의 연·월과 일자 칸 수가 맞는지 확인해주세요.")
    return year, month, num_days, first_day_col


def _try_parse_hospital_ocs_shape(ws):
    """병원 OCS 시스템이 직접 내보낸 근무표 원본(예: '간호스케줄') 모양 인식 시도.

    확인된 실제 구조: 1행 '간호스케줄', 2행 '조회 : YYYY년MM월', 3행에 일자 헤더
    ('전월' 라벨 + 1~말일 + D/E/N/®/ⓡ/금월/T연/R연/부서), 4행에 요일(같은 열에
    '성  명' 라벨), 5행부터 데이터(파트장 특별행 → 'A' 팀 구분 행 → 순번 매긴 일반
    직원 → 'B' 팀 구분 행 → B팀 직원). 순번은 1열, 성명은 2열.

    우리 자체 포맷(_parse_monthly_grid_shape)과 달리 실패해도 예외를 던지지 않고
    None을 돌려준다 — 호출 쪽에서 우리 포맷을 먼저 시도하고 실패했을 때만 이
    함수로 폴백하기 위함(서로 다른 두 실제 파일 모양을 각각 안전하게 인식).
    반환: {"year","month","num_days","first_day_col","header_row","name_col"} 또는 None.
    """
    import re
    year = month = None
    for r in range(1, 4):
        for c in range(1, 7):
            v = str(ws.cell(r, c).value or "")
            m = re.search(r"(\d{4})\s*년\s*(\d{1,2})\s*월", v)
            if m:
                year, month = int(m.group(1)), int(m.group(2))
                break
        if year:
            break
    if year is None:
        return None

    header_row = first_day_col = num_days = None
    for r in range(1, 7):
        for c in range(1, 10):
            if ws.cell(r, c).value == 1:
                c2, n = c, 1
                while ws.cell(r, c2 + 1).value == n + 1:
                    c2 += 1
                    n += 1
                if 28 <= n <= 31:
                    header_row, first_day_col, num_days = r, c, n
                    break
        if header_row:
            break
    if header_row is None:
        return None

    # 성명 열: 일자 헤더 다음 행(요일 행)에서 '성명'/'이름' 라벨이 있는 열을 찾는다.
    name_col = None
    for c in range(1, first_day_col):
        label = "".join(str(ws.cell(header_row + 1, c).value or "").split())
        if "성명" in label or "이름" in label:
            name_col = c
            break
    if name_col is None:
        return None

    return {"year": year, "month": month, "num_days": num_days,
            "first_day_col": first_day_col, "header_row": header_row,
            "name_col": name_col}


def _find_grid_sheet(wb):
    """월간근무표 모양의 시트를 찾는다.

    엑셀에서 마지막으로 보고 있던 시트(wb.active)를 우선 시도하되, 안내/설명용
    시트가 같이 들어있어 그게 활성 시트로 저장된 경우에도 문제없이 읽히도록
    나머지 시트를 전부 훑어 'YYYY년 M월' 형식의 진짜 데이터 시트를 찾는다.

    후보가 여럿이면서 서로 다른 연/월을 가리키면(예: 실수로 지난달 시트를 안
    지우고 새 달 시트를 옆에 또 만든 경우) 어느 쪽을 써야 할지 조용히 하나를
    골라버리지 않고, 어떤 시트들이 서로 충돌하는지 알려주고 멈춘다.
    반환: (ws, year, month, num_days, first_day_col)"""
    candidates = [wb.active] + [ws for ws in wb.worksheets if ws is not wb.active]
    matches = []  # [(ws, year, month, num_days, first_day_col)]
    last_err = None
    for ws in candidates:
        try:
            year, month, num_days, first_day_col = _parse_monthly_grid_shape(ws)
            matches.append((ws, year, month, num_days, first_day_col))
        except ExcelInputError as e:
            last_err = e
    if not matches:
        raise last_err or ExcelInputError("월간근무표 모양의 시트를 찾지 못했습니다.")
    distinct_months = {(m[1], m[2]) for m in matches}
    if len(distinct_months) > 1:
        detail = ", ".join(f"'{m[0].title}'({m[1]}년 {m[2]}월)" for m in matches)
        raise ExcelInputError(
            f"서로 다른 달을 가리키는 시트가 여러 개 있어 어느 것을 써야 할지 알 수 없습니다: "
            f"{detail} — 쓰지 않는 시트는 지우고 하나만 남겨주세요."
        )
    if len(matches) > 1:
        # 같은 달을 가리키는 시트가 둘 이상 — 예전엔 활성 시트를 조용히 골랐다. 두 시트의
        # 신청 내용이 다르면 어느 쪽이 쓰였는지 알 수 없는 채로 근무표가 나온다.
        # 다만 시트를 복사만 해두고 고치지 않은 경우(내용이 완전히 같음)는 고를 게 없으니
        # 그냥 받는다 — 표기 실수까지 반려하면 파트장만 번거롭다.
        def _snapshot(ws):
            return tuple(tuple("" if c is None else str(c).strip() for c in row)
                         for row in ws.iter_rows(values_only=True))
        snaps = {_snapshot(m[0]) for m in matches}
        if len(snaps) > 1:
            names = ", ".join(f"'{m[0].title}'" for m in matches)
            raise ExcelInputError(
                f"같은 달({matches[0][1]}년 {matches[0][2]}월)을 담은 시트가 여러 개인데 "
                f"내용이 서로 다릅니다: {names} — 어느 쪽을 써야 할지 알 수 없어 받지 않습니다. "
                "쓰지 않는 시트는 지우고 하나만 남겨주세요.")
    return matches[0]


def _is_team_divider_row(ws, row: int, name_col: int, first_day_col: int, num_days: int) -> bool:
    """'A'/'B' 팀 구분 행 판별(export_excel도, 병원 OCS 원본도 이름 칸에만 'A'/'B'를
    쓰고 나머지(일자 칸)는 비워둔다).

    이름이 정확히 'A'/'B' 한 글자이면서 일자 칸이 전부 비어 있을 때만 구분 행으로
    본다 — 직원 이름이 우연히 'A'/'B'인 경우를 오인하지 않도록 이중으로 확인."""
    name = str(ws.cell(row, name_col).value or "").strip()
    if name not in ("A", "B"):
        return False
    return all(ws.cell(row, first_day_col + d).value in (None, "") for d in range(num_days))


def _read_grid_rows(ws, name_col: int, first_day_col: int, num_days: int,
                    data_start_row: int, has_off_balance: bool,
                    ocs_names: bool = False):
    """이름 열/일자 시작 열이 주어졌을 때 공통 행 읽기 루프.

    'A'/'B' 팀 구분 행은 건너뛰고, has_off_balance면 잔휴(이후, 일자 시작 열
    바로 앞 칸)도 함께 읽는다. ocs_names면 성명 칸의 직급 접두사·표식을 떼어
    우리 쪽 이름과 같은 키가 되게 한다. 반환: (grid, off_balance, blanks).

    빈 칸은 grid에 'OFF'로 채워 넣는다 — 근무표에서 아무것도 안 적힌 날은 쉰 날이다.
    다만 **B팀(신입) 행은 그렇지 않다**: 파트장이 아직 안 정한 칸이라 빈칸 그대로여야
    하는데, 여기서 OFF로 바꿔 놓으면 되올리기 한 번에 신입 한 달이 통째로 '쉼'으로
    확정된다(고친 것 없이 내려받아 그대로 올려도 그렇다). 그래서 '원래 비어 있었다'를
    blanks로 함께 돌려주고, 그 판단은 부르는 쪽에 맡긴다.
    """
    grid: Dict[str, List[str]] = {}
    off_balance: Dict[str, float] = {}
    blanks: Dict[str, List[bool]] = {}
    row = data_start_row
    while True:
        name = ws.cell(row, name_col).value
        if name is None or str(name).strip() == "":
            break
        if _is_team_divider_row(ws, row, name_col, first_day_col, num_days):
            row += 1
            continue
        sid = (_clean_name(_strip_ocs_name_decoration(name)) if ocs_names
               else str(name).strip())
        shifts, empty = [], []
        for d in range(num_days):
            v = ws.cell(row, first_day_col + d).value
            blank = v in (None, "") or not str(v).strip()
            shifts.append("OFF" if blank else str(v).strip())
            empty.append(blank)
        grid[sid] = shifts
        blanks[sid] = empty
        if has_off_balance:
            v = ws.cell(row, first_day_col - 1).value
            try:
                off_balance[sid] = float(v)
            except (TypeError, ValueError):
                pass
        row += 1
    return grid, off_balance, blanks


# ---------------------------------------------------------------- 지난달 확정 근무표 읽기 (이월/히스토리용)

def _reject_wanted_grid_as_prev_month(wb) -> None:
    """입력①(원티드표)을 입력② 칸에 잘못 올린 경우를 잡아낸다.

    두 파일은 모양이 비슷해서(이름 옆에 날짜 칸이 늘어선 표) 그대로 통과했고, 앱은
    '이번 달 신청서'를 '지난달에 실제로 근무한 기록'으로 읽었다. 이월정보·연속근무·
    야간 후 휴식이 전부 그 위에서 계산되므로, 오류도 경고도 없이 근무표만 틀어진다.
    파일을 서로 바꿔 올리는 건 처음 쓰는 사람이 가장 흔히 하는 실수다.

    원티드표에는 지난달 근무표에 없는 표시가 분명히 있다 — 시트 이름이 '원티드표'이고,
    제목에 '원티드'가 들어가며, 2행에 직급·숙련도·가능근무 같은 인원 정보 제목이 있다.
    셋 중 하나라도 걸리면 반려한다."""
    for ws in wb.worksheets:
        if _norm_text(ws.title).replace(" ", "") == "원티드표":
            break
        title = _norm_text(ws.cell(1, 1).value)
        if "원티드" in title:
            break
        labels = {_norm_text(ws.cell(2, c).value).replace(" ", "") for c in range(1, 9)}
        if {"직급", "숙련도", "가능근무"} <= labels:
            break
    else:
        return
    raise WrongInputSlotError(
        "입력①(원티드표) 파일로 보입니다 — 입력② 칸에는 지난달 파일을 올려주세요. "
        "지난달에 이 프로그램으로 만드셨다면 그때 받은 '출력2_연간근무표', 처음 쓰는 "
        "달이면 OCS에서 받은 지난달 근무표입니다. 원티드표를 지난달 기록으로 읽으면 "
        "이월정보(연속근무·야간 후 휴식·잔휴)가 통째로 틀어집니다.")


def _reject_formula_cells(path: str, sheet_title: str, name_col: int,
                          first_day_col: int, num_days: int, data_start_row: int) -> None:
    """날짜 칸에 **수식**이 들어 있으면 반려한다.

    값이 아니라 수식으로 저장된 칸은 계산값이 파일에 없으면 읽을 때 `None`이 된다 —
    그러면 빈 칸으로 보이고, 빈 칸은 OFF다. 즉 **근무한 날이 조용히 오프가 된다.**
    실측: D였던 칸에 `=1+1`을 쓰고 되올렸더니 그 칸이 OFF가 되고 그날 D 인원이
    9명에서 8명으로 떨어졌다. 오류도 경고도 없었다.

    파트장이 일부러 수식을 쓰지 않아도 생긴다 — 칸을 잘라내기·붙여넣기 하다 참조가
    남거나, '=' 로 시작하는 값을 치면 엑셀이 수식으로 저장한다.

    우리가 내보내는 파일에도 수식이 있지만(합계 열) 그건 날짜 칸 **밖**이라 안 걸린다.
    """
    from openpyxl import load_workbook
    try:
        wb = load_workbook(path, data_only=False)
    except Exception:
        return                      # 값으로는 열렸는데 여기서 실패하면 그냥 넘어간다
    if sheet_title not in wb.sheetnames:
        return
    ws = wb[sheet_title]
    bad: List[str] = []
    for row in range(data_start_row, ws.max_row + 1):
        name = ws.cell(row, name_col).value
        if name is None or not str(name).strip():
            break
        for d in range(num_days):
            v = ws.cell(row, first_day_col + d).value
            if isinstance(v, str) and v.startswith("="):
                bad.append(f"{str(name).strip()} {d + 1}일 '{v}'")
                if len(bad) >= 10:
                    break
        if len(bad) >= 10:
            break
    if bad:
        head = ", ".join(bad[:5]) + (f" 외 {len(bad) - 5}칸" if len(bad) > 5 else "")
        raise ExcelInputError(
            f"날짜 칸에 수식이 들어 있습니다 — {head}. 수식은 값이 아니라 계산식이라 "
            "읽을 때 빈 칸으로 보이고, 그 칸이 오프로 바뀝니다. 해당 칸을 복사한 뒤 "
            "'선택하여 붙여넣기 → 값'으로 바꾸거나, 근무코드를 직접 적어서 올려주세요.")


def load_prev_month_schedule_xlsx(path: str) -> dict:
    """월간근무표(이 앱이 내보낸 근무표 엑셀, 또는 병원 OCS가 직접 내보낸 원본)를
    읽어 그리드로 복원.

    먼저 우리 자체 포맷(제목 'YYYY년 M월'로 시작)으로 시도하고, 어느 시트에서도
    맞지 않으면 병원 OCS 원본 모양('간호스케줄'/'조회 : ...')으로 재시도한다 —
    서로 다른 두 실제 파일 모양을 각각 안전하게 인식하고, 어느 쪽에도 맞지
    않으면(형식이 또 다르면) 조용히 잘못 읽는 대신 에러를 낸다.

    수기로 값만 고친 파일도 읽을 수 있도록, 서식/수식이 아니라 셀 값만 본다.
    'A'/'B' 팀 구분 행은 건너뛴다. 잔휴 열이 있으면 '잔휴(이후)' 값도 함께 읽어
    다음 달 이월용으로 돌려준다.
    반환: {"year", "month", "num_days", "grid": {staff_id: [shift_str, ...]},
           "off_balance": {staff_id: float}}  # 잔휴 열이 없으면 빈 dict
    """
    wb = _load_workbook_safe(path)
    _reject_wanted_grid_as_prev_month(wb)
    try:
        ws, year, month, num_days, first_day_col = _find_grid_sheet(wb)
        grid, off_balance, blanks = _read_grid_rows(ws, 1, first_day_col, num_days, 4,
                                                    has_off_balance=first_day_col >= 5)
        # 수식 검사는 try 밖에서 한다 — 여기서 던지면 아래 OCS 재시도가 삼켜버린다.
        shape_seen = (ws.title, 1, first_day_col, num_days, 4)
    except ExcelInputError as our_err:
        grid, blanks, shape_seen = {}, {}, None
        year = month = num_days = None
        for ws in wb.worksheets:
            shape = _try_parse_hospital_ocs_shape(ws)
            if shape is None:
                continue
            year, month, num_days = shape["year"], shape["month"], shape["num_days"]
            grid, off_balance, blanks = _read_grid_rows(
                ws, shape["name_col"], shape["first_day_col"], num_days,
                shape["header_row"] + 2, has_off_balance=True, ocs_names=True)
            if grid:
                shape_seen = (ws.title, shape["name_col"], shape["first_day_col"],
                              num_days, shape["header_row"] + 2)
                break
        if not grid:
            raise our_err

    if not grid:
        raise ExcelInputError("근무표에서 인원 행을 찾지 못했습니다.")

    # 값으로 읽는 데는 성공했지만, 날짜 칸이 수식이면 그 칸은 빈 칸으로 보인다 —
    # 빈 칸은 OFF다. 여기서 안 막으면 근무한 날이 조용히 오프가 된다.
    if shape_seen:
        _reject_formula_cells(path, *shape_seen)

    return {"year": year, "month": month, "num_days": num_days, "grid": grid,
            "off_balance": off_balance, "blanks": blanks}


#: 파트장에게 줄 수 없는 근무 — 병동 교대를 채우는 자리다. 최소인력·레벨 통계가
#: 파트장을 빼고 세기 때문에, 파트장에게 D를 주면 그날 사람이 하나 더 있는 것처럼
#: 보이는데 어느 숫자에도 안 잡힌다. 파트장이 하는 것은 상근(8A 계열)이다.
#:
#: 화면(app.js의 PARTJANG_BLOCK)·편집 API가 막는 다섯이 앞의 다섯이다. 화면 피커는
#: 애초에 이 다섯을 포함한 24가지만 보여주므로 그것으로 충분하지만, **파일 업로드는
#: 엔진이 아는 근무코드 전부를 통과시킨다** — 그래서 여기에는 같은 자리를 뜻하는
#: OCS 표기(DH·DP·RD·D◎ 등)까지 넣는다. 화면에서 고를 수도 없는 코드가 파일로는
#: 파트장 행에 들어가면, 파트장은 피커에서 그 값을 다시 볼 수도 없다.
#:
#: 상근(8A·9A·10A·5A·6A·7A·11A·MD)·교육(T·TW·TH…)·휴무·휴직은 막지 않는다 —
#: 파트장도 연차를 쓰고 교육을 가고 휴직을 한다.
PARTJANG_BLOCKED_SHIFTS = (
    "D", "E", "N", "NK", "prn",          # 화면·편집 API가 막는 다섯
    "DH", "EH",                          # D·E 반일
    "DP", "EP",                          # D·E prn
    "RD", "RE", "RP",                    # 회복성 D·E·prn
    "D◎", "E◎",                          # D·E (잔휴수당)
)


def month_upload_problems(data: dict, year: int, month: int, num_days: int,
                          staff_ids, partjang_ids=(), team_b_names=()) -> List[str]:
    """내려받아 고친 월간근무표를 다시 올렸을 때, 지금 화면의 근무표와 맞는지 검사한다.

    문제를 한국어 문장 목록으로 돌려준다(빈 목록이면 이상 없음). **여기서 걸러내지
    못한 어긋남은 조용히 근무표를 갈아치운다** — 다른 달 파일을 올리면 날짜가 밀린
    채로, 명단이 다른 파일을 올리면 없는 사람이 생기거나 있는 사람이 사라진 채로
    화면이 바뀐다. 그래서 '읽히면 일단 적용'이 아니라 하나라도 어긋나면 반려한다.

    로컬 웹앱(webapp/app.py)과 브라우저판(pyodide-app/py/bridge.py)이 같은 규칙을
    보게 하려고 엔진 쪽에 둔다 — 두 곳에 나눠 적으면 한쪽만 고쳐진다.
    """
    out: List[str] = []
    if data.get("year") != year or data.get("month") != month:
        out.append(
            f"{data.get('year')}년 {data.get('month')}월 근무표입니다 — "
            f"지금 화면은 {year}년 {month}월입니다. 같은 달 파일을 올려주세요.")
        return out           # 달이 다르면 아래 검사는 의미가 없다
    if data.get("num_days") != num_days:
        out.append(f"날짜 칸이 {data.get('num_days')}일인데 {year}년 {month}월은 "
                   f"{num_days}일입니다.")
        return out

    # 내보낸 월간근무표에는 B팀(신입) 행도 들어 있다. 명단에 없다고 반려하면
    # **B팀이 있는 병동은 정상적인 왕복조차 통째로 거부된다** — 고친 것도 없이
    # 내려받아 그대로 올려도 반려다.
    grid = data.get("grid") or {}
    here, there = set(staff_ids) | set(team_b_names), set(grid)
    missing, extra = sorted(here - there), sorted(there - here)
    if missing:
        head = ", ".join(missing[:5]) + (f" 외 {len(missing) - 5}명" if len(missing) > 5 else "")
        out.append(f"화면에 있는 인원이 파일에 없습니다 — {head}. "
                   "행을 지우지 말고 근무 칸만 고쳐서 올려주세요.")
    if extra:
        head = ", ".join(extra[:5]) + (f" 외 {len(extra) - 5}명" if len(extra) > 5 else "")
        out.append(f"화면에 없는 인원이 파일에 있습니다 — {head}. "
                   "인원을 바꾸려면 입력①부터 다시 시작해야 합니다.")

    # ⚠ 반드시 **표준 코드로 바꾼 뒤** 비교한다. 원문 그대로 비교하던 때는
    # `PRN`·`d`·`D*`·`D®`·`NK*`가 전부 검사를 지나갔고, 반영 단계는 그것들을
    # D·prn·NK로 정규화해 넣었다 — 파트장 행에 금지근무가 조용히 들어갔고 화면
    # 인원 수는 그 사람을 빼고 세니 어느 숫자에도 안 잡혔다.
    for pid in partjang_ids:
        bad = set()
        for v in grid.get(pid) or []:
            text = str(v).strip()
            if not text:
                continue
            try:
                code = str(parse_shift(text))
            except ValueError:
                continue        # 모르는 코드는 부르는 쪽의 코드 검사가 따로 잡는다
            if code in PARTJANG_BLOCKED_SHIFTS:
                bad.add(code)
        bad = sorted(bad)
        if bad:
            out.append(
                f"파트장({pid}) 행에 {'·'.join(bad)} 근무가 있습니다 — 최소인력과 "
                "레벨 통계가 파트장을 빼고 세기 때문에 그날 사람이 하나 더 있는 것처럼 "
                "보이지만 어느 숫자에도 잡히지 않습니다. 상근(8A)·교육·연차·휴가는 됩니다.")
    return out


def apply_month_upload(sch, data: dict, team_b_grid: dict, team_b_names,
                       locked_cells: dict, requests=()) -> int:
    """올린 월간근무표를 지금 근무표에 반영한다. 바뀐 칸 수를 돌려준다.

    로컬 웹앱(webapp/app.py)과 브라우저판(pyodide-app/py/bridge.py)이 **같은 한 벌**을
    쓰게 하려고 엔진에 둔다. 예전에 이 반영 루프가 두 파일에 따로 적혀 있었는데, 이런
    쌍은 한쪽만 고쳐지는 것이 이 저장소의 반복 사고다 — 그러면 같은 파일을 올려도 두
    판의 결과가 달라진다.

    세 가지를 함께 처리한다.

    1) **셀은 반드시 sch.set()으로 넣는다.** grid를 직접 갈아끼우면 날짜별 인원·야간
       카운터가 옛값으로 남아 최소인력 판정만 조용히 틀어진다.
    2) **B팀(신입)의 빈 칸은 빈 칸으로 둔다.** 읽는 쪽은 빈 칸을 'OFF'로 채워 주는데,
       그건 근무표 인원에게 맞는 규칙이다. 신입 행에 그대로 적용하면 고친 것 없이
       내려받아 그대로 올리기만 해도 신입 한 달이 통째로 '쉼'으로 확정된다.
    3) **덮어써진 원티드 신청은 '반영 안 됨'으로 되돌린다.** 안 그러면 화면은 계속
       "원티드 반영 91/91"이라고 말하는데 정작 그 칸은 다른 근무다 — 파트장이 무엇을
       못 지켰는지 알 방법이 사라진다.
    """
    grid = data.get("grid") or {}
    blanks = data.get("blanks") or {}
    team_b = set(team_b_names or [])
    changed = 0
    for sid, row in grid.items():
        blank_row = blanks.get(sid) or []
        for d in range(sch.num_days):
            raw = str(row[d]).strip() if d < len(row) and row[d] else ""
            was_blank = blank_row[d] if d < len(blank_row) else False
            if sid in team_b:
                # 신입은 최소인력·레벨 통계·제약검사 어디에도 안 들어간다.
                # 별도 표에 문자열로만 담기므로 잠글 것도 없다.
                team_b_grid[sid][d] = "" if (was_blank or not raw) else str(parse_shift(raw))
                continue
            new = parse_shift(raw) if raw else Shift.OFF
            if sch.get(sid, d) == new:
                continue
            _mark_request_unmet(requests, sid, d, new)
            # 화면 편집 → 재생성 경로(Generator.apply_fixed)와 **같은 표시**를 남긴다.
            # 그쪽은 고정 칸을 sch.wanted에 넣어 엑셀에 굵은 테두리와 * 를 찍는데,
            # 여기서 안 넣으면 같은 칸이 되올리기 직후에는 맨 칸, 재생성 뒤에는
            # 별표 칸으로 보인다 — 같은 뜻의 칸이 경로에 따라 달라 보이면 안 된다.
            sch.set(sid, d, new, lock=True)
            sch.wanted.add((sid, d))
            staff = sch.by_id.get(sid)
            if new == Shift.A8 and staff is not None and staff.is_leader:
                sch.mark_leader_8a(sid, d)
            locked_cells[(sid, d)] = new
            changed += 1
    return changed


def _mark_request_unmet(requests, sid: str, day: int, new) -> None:
    """그 칸에 걸려 있던 원티드 신청을 '반영 안 됨'으로 되돌린다.

    값이 바뀐 칸에서만 부르고, **새 값**과 비교한다 — 근무표에 넣기 전에 부르든 뒤에
    부르든 같은 판단이 나와야 한다.

    칸의 '파트장이 정함' 표시(sch.wanted)는 여기서 건드리지 않는다. 그건 신청이
    아니라 고정 표시이고, 되올린 칸에도 화면 편집→재생성 경로와 똑같이 붙어야 한다.
    """
    for req in requests or ():
        if req.staff_id != sid or not req.accepted:
            continue
        try:
            dt = _dt.date.fromisoformat(req.date)
        except (TypeError, ValueError):
            continue
        if dt.day - 1 != day:
            continue
        if new == req.type:
            continue        # 같은 근무로 다시 적어 넣은 것이면 그대로 반영된 것이다
        req.accepted = False
        req.reject_reason = "올린 수정본에서 다른 근무로 바뀜"


# ---------------------------------------------------------------- 원티드 신청 읽기 (월간근무표 모양 + 신청 표기)

_WANTED_WORK_CODES = {"D": "D", "E": "E", "N": "N", "8A": "8A", "9A": "9A",
                      "10A": "10A", "NK": "NK", "T": "T", "TW": "TW", "prn": "prn"}
_WANTED_AL_CODES = {"연": "연차", "연차": "연차",
                    "연1": "연1", "연2": "연2", "연3": "연3", "연4": "연4"}
# 세부 사유가 명확한 휴가류는 각자의 코드로, 그 외(포상휴가 등 미분류 특수코드)는
# 뭉뚱그려 OFF 희망으로 해석한다.
_WANTED_LEAVE_CODES = {
    "조": "조", "경": "경", "공": "공", "병": "병", "휴": "휴", "승": "승",
    "군": "군",
}

# 원티드로 '신청할 수 없는' 코드. 뜻을 못 알아본 것이 아니라 규칙상 받지 않는 것이라,
# '인식 못 한 표시'로 뭉뚱그리지 않고 이유를 따로 알려준다 — 파트장이 표기를 고치면
# 될 문제로 오해하면 계속 다시 올리게 된다.
_WANTED_BLOCKED_CODES = {
    "s/": "수면오프는 신청할 수 없습니다 — 월 야간 6회 이상이면 프로그램이 자동으로 붙입니다",
}
_WANTED_OFF_CODES = {"X", "OFF", "포"}

# 원티드 칸은 파트장이 40칸 × 30일을 손으로 채우는 자리라 표기가 가장 많이 흔들린다.
# 예전엔 대소문자·전각을 그대로 대조해서 'd'·'off'·'x'·'Ｄ'가 전부 '인식 못 한 표시'로
# 빠졌다 — 신청이 통째로 반영 안 된 채 근무표가 나오고, 파트장은 목록을 보고 파일을
# 고쳐 다시 올려야 했다. 뜻이 하나뿐인 표기는 여기서 받아준다.
_WANTED_CODE_LOOKUP: Dict[str, str] = {}
for _src in (_WANTED_WORK_CODES, _WANTED_AL_CODES, _WANTED_LEAVE_CODES):
    for _k, _v in _src.items():
        _WANTED_CODE_LOOKUP[_k.lower()] = _v
for _k in _WANTED_OFF_CODES:
    _WANTED_CODE_LOOKUP[_k.lower()] = "OFF"
# 한글로 적는 사람도 있다. '휴가'는 연차인지 휴(휴가코드)인지 갈려서 일부러 뺐다 —
# 갈리는 것을 짐작해 넣으면 그 사람 휴가 종류가 조용히 바뀐다.
_WANTED_CODE_LOOKUP.update({"데이": "D", "이브닝": "E", "이브": "E", "나이트": "N",
                            "오프": "OFF", "휴무": "OFF"})


def _norm_wanted_code(v) -> str:
    """원티드 칸 한 칸 — 전각·보이지 않는 문자·공백을 걷어낸 표기."""
    return _norm_text(v).replace(" ", "")


_WANTED_STATIC_LABELS = ["이름", "직급", "숙련도", "가능근무", "야간리더", "비고",
                         "전입", "전입일"]


# 인원 정보를 담은 원티드표라면 반드시 있어야 하는 헤더. '전입'·'전입일'은 나중에 늘어난
# 칸이라 없어도 되지만, 이 넷 중 하나라도 없으면 인원 정보를 읽을 수 없다.
_WANTED_REQUIRED_LABELS = ["직급", "숙련도", "가능근무", "비고"]


def _wanted_static_cols(ws, first_day_col: int) -> Dict[str, int]:
    """원티드표 2행 헤더에서 인원 정보 칸의 열 번호를 이름으로 찾는다.

    이름 옆이 바로 날짜인 옛 파일(정적 칸이 '이름' 하나뿐)에서는 빈 dict가 되고, 호출부가
    '인원 정보 없는 원티드 신청만 있는 파일'로 처리한다.

    정적 칸이 있는데 제목이 겹치거나 빠졌으면 반려한다. 예전엔 조용히 옛 형식으로 취급해
    인원 0명을 돌려줬는데, 앱은 인원 0명을 '이 파일엔 명단이 없다'로 읽고 지난달 명단을
    그대로 쓴다 — 전입·전출·숙련도·가능근무 변경이 전부 사라진 채 근무표가 나온다.
    업로드는 성공했다고 뜨고 경고도 없다."""
    out: Dict[str, int] = {}
    dups: List[str] = []
    for c in range(1, first_day_col):
        label = _norm_text(ws.cell(2, c).value).replace(" ", "")
        if label not in _WANTED_STATIC_LABELS:
            continue
        if label in out:
            dups.append(label)
        else:
            out[label] = c
    if dups:
        raise ExcelInputError(
            f"원티드표에 같은 제목의 열이 두 번 있습니다: {', '.join(sorted(set(dups)))} — "
            "어느 칸이 진짜인지 알 수 없습니다. 제목 줄(2행)을 고치시거나 "
            "'양식(다운로드)'로 새 양식을 받아주세요.")
    # '이 파일이 인원 정보를 담은 양식인가'는 제목이 하나라도 남아 있는지, 아니면 정적 칸이
    # 최신 양식만큼 넓은지로 판단한다(현재 양식은 이름·직급·숙련도·가능근무·비고·전입·전입일
    # 7칸이라 날짜가 H열부터 시작한다). 이름 옆이 바로 날짜인 옛 파일은 둘 다 아니다.
    claims_staff_cols = (any(lab in out for lab in _WANTED_REQUIRED_LABELS)
                         or first_day_col >= 6)
    if claims_staff_cols:
        missing = [lab for lab in _WANTED_REQUIRED_LABELS if lab not in out]
        if missing:
            raise ExcelInputError(
                f"원티드표 제목 줄(2행)에 {', '.join(missing)} 칸이 없습니다 — "
                "이 파일의 인원 정보를 읽을 수 없어 지난달 명단으로 근무표가 만들어질 수 "
                "있습니다. 제목을 정확히 적으시거나 '양식(다운로드)'로 새 양식을 받아주세요.")
    return out


def load_wanted_grid_xlsx(path: str) -> dict:
    """월간근무표와 같은 모양(이름|1일|2일|...) 엑셀에서 원티드 신청을 읽어온다.

    표기 규칙: "D*"/"E*"/"N*"/"8A*"/"9A*"/"10A*"/"NK*"/"T*"/"TW*"/"prn*"(또는 별표 없이도 인식) = 그 근무 희망,
    "조"/"경"/"공"/"병"/"휴"/"승"/"군"/"S/"/"연"/"연차"/"연1"/"연2"/"연3"/"연4" = 각자의
    휴가유형 희망, "X"/그 외 미분류 표기(포상휴가 등)는 OFF 희망으로 해석한다. 빈 칸은 건너뛴다.

    이름 옆에 직급·숙련도·가능근무·비고(+전입·전입일)가 있으면 인원 정보도 같이 읽어
    돌려준다 — 병동인력표가 없어진 뒤로 이 파일이 인원 정보의 유일한 창구이기 때문. 그 칸들의
    위치는 고정 열번호가 아니라 **2행 헤더 이름**으로 찾는다(열이 늘어도 예전에 내려간
    파일이 계속 바르게 읽힌다). 한 명이라도 그 칸을 채운 흔적이 있으면 파일 전체가 인원
    정보를 담고 있다고 보고, 모든 사람에게 직급·숙련도가 있어야 한다(일부만 채워진 채로
    조용히 그 사람만 빠지면 안 되므로 — 전부 아니면 오류). 헤더 이름이 없는 옛 형식이면
    staff는 빈 리스트로 돌려준다(원티드 신청만 있는 파일도 여전히 지원).

    날짜 칸은 파트장이 OCS 화면에서 그대로 복사해 붙여넣는 것을 전제로 한다 — **말일 칸
    오른쪽은 읽지 않는다.** 복붙하면 D/E/N·®·ⓡ·금월·T연·R연·부서가 같이 딸려오는데,
    그걸 근무코드로 해석하면 '인식 못 한 표시'가 사람 수만큼 쏟아진다.

    일반 인원 명단 아래 이름 칸에 'B' 한 글자만 있고 나머지가 빈 구분 행이 있으면(생성
    템플릿이 예시로 채워주는 형태), 그 아래 이어지는 이름들은 B팀(신입)으로 인식한다 —
    직급·숙련도 없이 이름만 받고, 원티드 신청도 읽지 않는다.

    반환: {"year", "month", "requests": [{"staff_id","date","type"}, ...],
           "unknown_marks": [str, ...],  # 인식 못 한 표시(참고용)
           "staff": [{"id","role","level","allowed_shifts","flags"}, ...],  # 없으면 빈 리스트
           "team_b_names": [str, ...],   # 없으면 빈 리스트
           "transferred_in": [str, ...],          # '전입' 칸을 고른 사람들
           "transfer_in_dates": {name: "YYYY-MM-DD"},  # 월중 전입자의 입사일
           "transfer_bad_dates": [str, ...],      # 전입일을 못 읽은 칸(그냥 넘기지 않는다)
           "unknown_transfer_marks": [str, ...],  # '전입' 칸에서 못 알아본 값
           "has_transfer_cols": bool}
    """
    _reject_empty_formulas(path)
    wb = _load_workbook_safe(path)
    ws, year, month, num_days, first_day_col = _find_grid_sheet(wb)
    # 인원 정보 칸의 위치는 고정 번호가 아니라 2행 헤더의 이름으로 찾는다 — '전입'·'전입일'
    # 처럼 열이 늘어날 때마다 번호를 옮겨 적으면, 예전 양식을 올린 사람의 '비고'가 '전입'으로
    # 읽히는 식으로 조용히 어긋난다(에러도 안 나고 근무표만 틀려진다).
    cols = _wanted_static_cols(ws, first_day_col)
    role_col, level_col = cols.get("직급"), cols.get("숙련도")
    allowed_col, note_col = cols.get("가능근무"), cols.get("비고")
    night_leader_col = cols.get("야간리더")      # 없는 옛 양식이면 None
    transfer_col, transfer_date_col = cols.get("전입"), cols.get("전입일")
    has_staff_cols = None not in (role_col, level_col, allowed_col, note_col)

    errors = _ErrorCollector()
    lenient = _LenientNotes()
    requests: List[dict] = []
    unknown = set()
    blocked = set()          # 신청할 수 없는 코드가 적힌 칸(S/ 등)
    staff_rows: List[dict] = []
    team_b_names: List[str] = []
    transferred_in: List[str] = []
    transfer_in_dates: Dict[str, str] = {}
    transfer_bad_dates: List[str] = []
    transfer_date_out_of_month: List[str] = []
    unknown_transfer_marks: List[str] = []
    any_staff_data = False
    in_team_b = False
    # 이름 칸이 비면 "표가 끝났다"고 보고 멈추면, 명단 중간에서 이름만 실수로 지워진 행이
    # 하나 있을 때 그 아래 사람들이 통째로, 오류 하나 없이 사라진다(14명이 2명이 되는 식).
    # 인원수가 줄어든 걸 눈치채지 못하면 병동 절반이 빠진 근무표가 그대로 나가므로,
    # 데이터가 있는 마지막 행까지 훑고 중간의 '이름 없는 행'은 오류로 알려준다.
    last_col = first_day_col + num_days - 1
    last_row = 3
    for r in range(4, ws.max_row + 1):
        if any(ws.cell(r, c).value not in (None, "") for c in range(1, last_col + 1)):
            last_row = r
    seen_names: Dict[str, int] = {}
    for row in range(4, last_row + 1):
        name = ws.cell(row, 1).value
        if name is None or str(name).strip() == "":
            if any(ws.cell(row, c).value not in (None, "") for c in range(2, last_col + 1)):
                errors.add(
                    f"원티드표 {row}행: 다른 칸은 채워져 있는데 이름 칸이 비어 있습니다 — "
                    "이름을 채우거나 그 행을 통째로 삭제해주세요.")
            continue
        if _is_team_divider_row(ws, row, 1, first_day_col, num_days):
            in_team_b = str(name).strip() == "B"
            continue
        sid = _clean_name(name)
        if in_team_b:
            if sid in seen_names:
                errors.add(f"원티드표 {row}행: B팀 이름 '{sid}'이 현재 인원 명단에도 있습니다 — 같은 사람이 두 번 잡히므로 한쪽을 지워주세요.")
                continue
            team_b_names.append(sid)
            continue
        if sid in seen_names:
            # 이름이 사람을 가리키는 키라, 중복을 그냥 받으면 신청·인원정보가 서로 덮어써진다.
            errors.add(
                f"원티드표 {row}행: 이름 '{sid}'이 {seen_names[sid]}행과 중복됩니다 — "
                "동명이인이면 '김간호(A)'처럼 구분해서 적어주세요.")
            continue
        seen_names[sid] = row
        _check_name_length(sid, f"원티드표 {row}행", errors)

        if has_staff_cols:
            role_v = ws.cell(row, role_col).value
            level_v = ws.cell(row, level_col).value
            allowed_v = ws.cell(row, allowed_col).value
            note_v = ws.cell(row, note_col).value
            if any(v not in (None, "") for v in (role_v, level_v, allowed_v, note_v)):
                any_staff_data = True
            if role_v in (None, "") or level_v in (None, ""):
                errors.add(
                    f"원티드표 {row}행({sid}): 직급 또는 숙련도 칸이 비어 있습니다 — 이 파일로 "
                    "인원 정보를 갱신하려면 모든 사람의 직급·숙련도를 채워야 합니다.")
            else:
                role = _check_role(role_v, f"원티드표 {row}행({sid}) 직급", errors)
                level = _parse_level(level_v, context=f"원티드표 {row}행({sid}) 숙련도",
                                     errors=errors)
                lenient.note("직급", _typed_display(role_v), role)
                lenient.note("숙련도", _typed_display(level_v), f"Lv{level}")
                allowed_raw = _split_list(allowed_v)
                allowed, allowed_flags = _split_allowed(
                    allowed_raw, f"원티드표 {row}행({sid}) 가능근무", errors)
                if not allowed_raw:
                    # 그냥 받으면 그 사람만 한 달 내내 근무가 0일로 나온다 — 오류도 없이
                    # 인원부족 경고만 잔뜩 뜨는 통에 원인이 이 빈칸이라는 걸 알기 어렵다.
                    errors.add(
                        f"원티드표 {row}행({sid}): 가능근무 칸이 비어 있습니다 — 이 사람에게 "
                        "배정할 수 있는 근무가 하나도 없다는 뜻이라, 대개는 입력 실수입니다.")
                note_s = str(note_v or "")
                # 비고에서 온 것과 가능근무 칸에서 온 것을 갈라 둔다. 아래 두 검사는
                # **비고만** 봐야 한다 — 표준표기 안내는 비고에 적은 말을 고쳐주는
                # 것이고, '못 읽었다' 경고는 비고가 통째로 무시됐는지를 보는 것이다.
                note_flags = _parse_flags(note_s)
                flags = _with_night_leader(
                    _merge_flags(note_flags, allowed_flags),
                    night_leader_col is not None
                    and night_leader_mark(ws.cell(row, night_leader_col).value,
                                          f"원티드표 {row}행({sid})", errors))
                for _f in note_flags:
                    std = _FLAG_STANDARD_WORD[_f]
                    if std not in _norm_text(note_s).replace(" ", ""):
                        lenient.note("비고", _typed_display(note_v), std)
                if _flag_note_looks_unread(note_s, note_flags):
                    # 비고는 자유 입력이라 못 알아들어도 아무 말이 없다 — 근무 제약을
                    # 적으려던 것으로 보이는데 규칙이 하나도 안 잡혔으면 알려준다.
                    errors.add(
                        f"원티드표 {row}행({sid}) 비고: {note_s!r} — 근무 제약을 적으신 것 "
                        "같은데 규칙으로 읽지 못했습니다. '야간전담'·'임부'·'야간금지' 중 "
                        "하나로 적어주세요(이대로 두면 그 제약 없이 배정됩니다).")
                staff_rows.append({"id": sid, "role": role, "level": level,
                                   "allowed_shifts": allowed, "flags": flags})

        # 전입·전입일 — 병동인력표가 없어지고 입력②가 OCS 원본으로 들어올 수도 있게 되면서,
        # 전입자를 알려줄 수 있는 자리가 이 파일뿐이 됐다. 여기서 못 받으면 월중 전입자의
        # 입사 전 날짜에 근무가 배정되고도 아무 표시가 안 난다.
        if transfer_col is not None:
            mark = _norm_text(ws.cell(row, transfer_col).value).lower()
            if mark and mark.replace(" ", "") in _TRANSFER_IN_ALIASES:
                transferred_in.append(sid)
                lenient.note("전입", mark, _TRANSFER_IN_MARK)
                d = _read_transfer_date_cell(
                    ws.cell(row, transfer_date_col).value if transfer_date_col else None,
                    f"원티드표 {row}행({sid})", transfer_bad_dates,
                    default_ym=(year, month))
                if d:
                    transfer_in_dates[sid] = d
                    lenient.note("전입일", _typed_display(
                        ws.cell(row, transfer_date_col).value
                        if transfer_date_col else ""), d)
                    # 이 파일이 가리키는 달 밖의 입사일은 이번 달 배정에 반영되지 않는다
                    # (하류에서 이번 달 것만 걸러 쓴다). 적어놓고 안 먹은 줄 모르면
                    # 파트장은 월중 전입 처리가 된 줄로 안다.
                    if d[:7] != f"{year:04d}-{month:02d}":
                        transfer_date_out_of_month.append(f"{sid}: {d}")
            elif mark:
                unknown_transfer_marks.append(f"{sid}: {ws.cell(row, transfer_col).value}")

        for d in range(num_days):
            v = ws.cell(row, first_day_col + d).value
            if v in (None, ""):
                continue
            raw = _typed_display(v)
            v = _norm_wanted_code(v)
            if not v:
                continue
            star = v.endswith("*")
            base = v[:-1] if star else v
            if base.lower() in _WANTED_BLOCKED_CODES:
                blocked.add(f"{sid} {d + 1}일 {base}")
                continue
            t = _WANTED_CODE_LOOKUP.get(base.lower())
            if t is None:
                unknown.add(v)
                continue
            # 표준 표기와 다르게 쳤으면 무엇을 무엇으로 읽었는지 남긴다. 비교는 정규화
            # 전 원본으로 한다 — 전각 'Ｄ'는 정규화하면 'D'가 되어버려, 정규화 뒤에
            # 견주면 전각으로 쳤다는 사실이 안내에서 사라진다.
            std = t + ("*" if star else "")
            if raw != std and not (base in _WANTED_AL_CODES or base in _WANTED_LEAVE_CODES):
                lenient.note("원티드 신청", raw, std)
            requests.append({"staff_id": sid, "date": f"{year}-{month:02d}-{d + 1:02d}",
                             "type": t})

    if not any_staff_data:
        errors.items = [e for e in errors.items if "직급 또는 숙련도" not in e]
    _reject_bad_transfer_dates(errors, transfer_bad_dates, transfer_date_out_of_month,
                               (year, month))
    errors.raise_if_any()

    # 인원 정보만 먼저 채우고 원티드 표시는 아직 없는 업로드(직급/숙련도만 갱신하려는
    # 경우)도 정상 케이스이므로, 신청·인식못한표시·인원정보·B팀 넷 다 없을 때만 반려한다.
    if not requests and not unknown and not staff_rows and not team_b_names:
        raise ExcelInputError("표에서 원티드 표시나 인원 정보를 하나도 찾지 못했습니다.")

    # 파트장을 맨 위로 올린다(나머지 순서는 파일 그대로). 출력 넷 — 월간근무표 두 형식,
    # 연간근무표, 화면 근무표 — 은 전부 파트장을 맨 위에 두는데 입력① 양식만 파일에 적힌
    # 순서를 그대로 따라서, 같은 병동인데 화면·양식에서는 맨 아래, 출력에서는 맨 위에
    # 있었다. 순서는 사람이 눈으로 사람을 찾는 단서라 넷이 어긋나면 매번 다시 훑어야 한다.
    staff_rows.sort(key=lambda s: 0 if s.get("role") == "파트장" else 1)

    return {"year": year, "month": month, "requests": requests,
           "normalized": lenient.as_list(),
           "staff": staff_rows if any_staff_data else [],
           "unknown_marks": sorted(unknown),
            "blocked_marks": sorted(blocked),
           "team_b_names": team_b_names,
           "transferred_in": transferred_in,
           "transfer_in_dates": transfer_in_dates,
           "transfer_bad_dates": transfer_bad_dates,
           "transfer_date_out_of_month": transfer_date_out_of_month,
           "unknown_transfer_marks": unknown_transfer_marks,
           "has_transfer_cols": transfer_col is not None}


# --------------------------------------------- 지난달 근무표 한 장 → 연간근무표 모양 (첫 달)

def staff_table_from_prev_month(data: dict) -> dict:
    """지난달 근무표 한 장(OCS 원본 또는 우리 월간근무표)을 '연간근무표'와 같은 모양으로.

    입력②에 연간근무표 대신 지난달 근무표가 들어오는 경우 — 이 앱을 처음 쓰는 달이다.
    그 파일에는 부서 누적 실적(누적야간·반영개월수 등)도, 직급·숙련도도 없다. 없는 값을
    그럴듯하게 지어내면 야간 형평성이 조용히 틀어지므로 **누적통계는 전부 0에서 시작**하고,
    지난달 그리드에서 실제로 계산할 수 있는 것(연속근무일수·말일 야간블록·이월OFF)과
    파일에 적혀 있는 잔휴만 이월한다. 둘째 달부터는 출력②(연간근무표)가 이어받아 쌓인다.

    인원 명단(직급·숙련도·가능근무)은 여기서 만들지 않는다 — 근무표에는 그 정보가 없어서
    비워 넘기면 화면 명단이 반쪽짜리로 덮여버린다. 명단의 기준은 입력①(원티드표)이고,
    여기서 얻은 이름은 전출 대조용(roster_names)으로만 쓴다.
    반환 모양은 load_staff_table_xlsx()와 같다(호출부가 구분 없이 쓸 수 있도록)."""
    year, month, nd = int(data["year"]), int(data["month"]), int(data["num_days"])
    grid = data.get("grid") or {}
    off_bal = data.get("off_balance") or {}
    dates = [_dt.date(year, month, d + 1).isoformat() for d in range(nd)]
    stats = {}
    # 잔휴 칸이 없거나 비어 있던 사람 — _read_grid_rows()가 읽지 못한 칸은 키 자체를
    # 안 넣으므로 '빈 칸'과 '정말 0'이 구분된다. 연간근무표 경로와 같은 이름으로
    # 넘겨서, 호출부가 어느 형식으로 들어왔든 같은 안내를 띄울 수 있게 한다.
    off_balance_blank = [sid for sid in grid if sid not in off_bal]
    for sid in grid:
        st = {k: 0 for k in STAFF_TABLE_STAT_KEYS}
        st["off_balance"] = round(float(off_bal.get(sid, 0.0) or 0.0), 2)
        st["prev_off_balance"] = 0.0
        st["recent_night_score"] = 0.0
        stats[sid] = st
    return {"staff": [], "roster_names": list(grid),
            "stats": stats, "annual_dates": dates,
            "annual_grid": {sid: list(codes) for sid, codes in grid.items()},
            "team_b_names": [], "departed": [], "transferred_in": [],
            "transfer_in_dates": {}, "transfer_bad_dates": [],
            "unknown_transfer_marks": [], "transfer_no_off_balance": [],
            "off_balance_blank": off_balance_blank,
            # OCS 지난달 근무표에는 전월잔휴 칸 자체가 없다 — 첫 달이라 0에서 시작하는
            # 것이 맞으므로 '빠뜨렸다'고 알릴 것이 없다.
            "prev_off_balance_missing": [], "has_prev_off_balance_col": True,
            "unknown_grid_marks": [],
            "rows_after_summary": [],
            "source": "prev_month", "source_year": year, "source_month": month}


# ---------------------------------------------------------------- 연간근무표 읽기 (다월 자동 연동용)

def load_staff_table_xlsx(path: str) -> dict:
    """'연간근무표' 파일 읽기 — 로스터 + 누적 통계(형평성 참고용) + 연간 근무 그리드(1/1~, 참고용).

    시트명은 "연간근무표"를 우선 찾고, 예전에 내보낸 파일(구 명칭 "인원표")도
    그대로 읽을 수 있도록 하위호환으로 받아준다.

    반환: {
      "staff": [{"id","role","level","allowed_shifts","flags"}, ...],
      "stats": {staff_id: {"recent_night_score","night","off","weekend_night",
                            "blocks_2","blocks_3","months"}},
      "annual_dates": ["YYYY-MM-DD", ...],   # 이미 쌓여있던 연간 그리드의 날짜(있으면)
      "annual_grid": {staff_id: [code, ...]},  # annual_dates와 나란히
      "team_b_names": [str, ...],  # 'B' 구분 행 아래 이름들(없으면 빈 리스트)
      "departed": [{"id","role","level","allowed_shifts","left_at","stats","codes"}, ...],
          # '전출' 구분 행 아래 — 과거 재직자의 이력 보존분(현재 인원 아님)
      "transferred_in": [str, ...],        # 비고에 '전입'이라 적힌 사람들
      "transfer_in_dates": {name: "YYYY-MM-DD"},  # 비고에 날짜까지 적은 월중 전입자
      "unknown_transfer_marks": [str, ...],  # 전입자 행에서 인식 못 한 근무표기("이름: 코드")
      "transfer_no_off_balance": [str, ...], # 전입자인데 잔휴 칸이 비어 있는 사람들
    }

    이 파일은 '과거'(지난달까지 확정된 실적)를 담는다 — 이번 달 인원 명단의 기준은
    입력①(원티드표)이며, 여기 staff는 지난달 명단이다. 둘의 차이가 곧 전입(②에만 있음)·
    전출(입력②에만 있음)이므로, 호출부는 이 staff로 현재 명단을 덮어쓰지 말고 대조에 써야 한다.

    전입자(비고에 '전입')는 파트장이 전 병동 근무기록을 날짜 칸에 붙여넣은 행이다.
    그 기록은 이월정보(마지막근무·연속근무일·야간블록)와 야간 형평성 계산에만 쓰고,
    부서 누적 실적(누적야간·반영개월수 등)은 우리 병동 입사 시점부터 0에서 시작한다 —
    전 병동 실적이 부서 연말 집계에 섞이지 않게 하는 운영 방침이다. 잔휴는 근무표에서
    계산할 수 없는 누적 잔액이라 전 병동에서 받은 숫자를 잔휴 칸에 적어야 한다.
    """
    _reject_empty_formulas(path)
    wb = _load_workbook_safe(path)
    sheet_name = "연간근무표" if "연간근무표" in wb.sheetnames else "인원표"
    if sheet_name not in wb.sheetnames:
        raise ExcelInputError("필수 시트 누락: 연간근무표")

    rows = _sheet_rows(wb[sheet_name])
    h = _find_header(rows, "순번")
    if h is None:
        raise ExcelInputError("연간근무표 시트에 '순번' 헤더가 없습니다")
    header_row = rows[h]
    # 열 위치는 고정 인덱스가 아니라 헤더 이름으로 찾는다 — 앞으로 열이 늘거나 순서가
    # 바뀌어도 파서를 손댈 필요가 없다. 날짜 영역은 '헤더가 날짜 셀인 첫 열'부터로 판별한다.
    # (다만 '전입'/'전입일'은 없으면 안 되는 열이라 아래에서 따로 막는다.)
    def _col(label: str) -> Optional[int]:
        for name in [label] + STAFF_TABLE_STAT_LABEL_ALIASES.get(label, []):
            for i, v in enumerate(header_row):
                if isinstance(v, str) and v.strip() == name:
                    return i
        return None

    first_day_idx = next(
        (i for i, v in enumerate(header_row) if hasattr(v, "strftime")), None)
    if first_day_idx is None:                    # 연간 그리드가 아직 없는 파일
        first_day_idx = len(header_row)
    # 열은 이름으로 찾는데, 같은 제목이 두 번 있으면 _col()은 첫 칸만 돌려주고 원래
    # 그 자리에 있어야 할 제목은 사라진다 — 그 통계가 통째로 0이 되는데 화면에는
    # 그냥 숫자로 보여 알아챌 방법이 없다(누적야간을 두 번 적었더니 누적근무일이 0).
    _seen: Dict[str, int] = {}
    _dups: List[str] = []
    for _i, _v in enumerate(header_row):
        if not isinstance(_v, str) or not _v.strip():
            continue
        _lab = _v.strip()
        if _lab in _seen and _lab in (STAFF_TABLE_STAT_LABELS + STAFF_TABLE_STATIC_COLS):
            _dups.append(_lab)
        _seen.setdefault(_lab, _i)
    if _dups:
        raise ExcelInputError(
            f"연간근무표에 같은 제목의 열이 두 번 있습니다: {', '.join(sorted(set(_dups)))} — "
            "어느 칸을 써야 할지 알 수 없고, 원래 그 자리에 있어야 할 통계가 통째로 "
            "0이 됩니다. 제목 줄을 고치시거나 '양식(다운로드)'로 새 양식을 받아주세요.")
    stat_idx = {key: _col(label)
                for key, label in zip(STAFF_TABLE_STAT_KEYS, STAFF_TABLE_STAT_LABELS)}
    transfer_col = _col("전입")
    transfer_date_col = _col("전입일")
    night_leader_idx = _col("야간리더")           # 없는 옛 양식이면 None
    # '전입'·'전입일' 열이 없는 예전 양식은 받지 않는다. 읽히기는 하지만 그 파일로는
    # 전입자를 표시할 방법이 아예 없어서, 파트장이 전입자를 넣었다고 생각해도 조용히
    # 누락된다(야간 형평성·이월정보가 틀어진 근무표가 그대로 나온다). 조용히 잘못
    # 도는 것보다 여기서 막고 새 양식을 받게 하는 편이 안전하다.
    missing_cols = [lb for lb, idx in (("전입", transfer_col), ("전입일", transfer_date_col))
                    if idx is None]
    if missing_cols:
        raise ExcelInputError(
            f"예전 양식입니다 — 연간근무표에 '{'·'.join(missing_cols)}' 열이 없습니다. "
            "이 파일로는 전입자를 표시할 수 없어 받지 않습니다. "
            "입력②의 '양식(다운로드)'로 새 양식을 받으시거나, "
            "이번 달 근무표를 만든 뒤 받은 '연간근무표'(출력②)를 올려주세요."
        )
    name_idx = _col("이름")
    if name_idx is None:
        name_idx = 1                             # 예전 양식(고정 위치) 후퇴
    # 직급·숙련도·가능근무·비고도 **이름으로** 찾는다. 예전엔 이름 칸 기준 상대
    # 위치(+1·+2·+3·+4)로 읽었는데, 가능근무 옆에 '야간리더' 열이 들어가자 비고가
    # 한 칸 밀려 '야간전담' 표시가 통째로 사라졌다 — 그 사람이 야간전담이 아닌 것으로
    # 읽히고 오류도 경고도 없다. 열이 늘 때마다 깨지는 방식이라 이름 기준으로 바꾼다.
    # (이름을 못 찾은 옛 양식에서만 상대 위치로 후퇴한다.)
    def _col_or(label: str, fallback: int) -> int:
        got = _col(label)
        return fallback if got is None else got

    role_idx = _col_or("직급", name_idx + 1)
    level_idx = _col_or("숙련도", name_idx + 2)
    allowed_idx = _col_or("가능근무", name_idx + 3)
    note_idx = _col_or("비고", name_idx + 4)

    annual_dates: List[str] = []
    i = first_day_idx
    while i < len(header_row) and hasattr(header_row[i], "strftime"):
        annual_dates.append(header_row[i].strftime("%Y-%m-%d"))
        i += 1

    # 연간 그리드의 '시간축'을 검증한다. 이 날짜열이 곧 과거 이력의 순서라, 중복·역순·
    # 중간 빈칸이 있으면 이월 휴식·연속근무·누적통계가 통째로 어긋난다.
    #  · 중간이 비면 거기서 읽기를 멈추므로 뒤쪽 이력이 조용히 잘린다(31일 → 10일).
    #  · 역순·중복이면 같은 날이 두 번 세어지거나 시간이 거꾸로 흐른다.
    if annual_dates:
        prev = _dt.date.fromisoformat(annual_dates[0])
        for k, ds in enumerate(annual_dates[1:], start=1):
            cur = _dt.date.fromisoformat(ds)
            if cur <= prev:
                raise ExcelInputError(
                    f"연간 근무표의 날짜가 순서대로 있지 않습니다 — {prev.isoformat()} 다음이 "
                    f"{cur.isoformat()}입니다(중복이거나 거꾸로 놓였습니다). 날짜 헤더를 "
                    "고치시거나 '양식(다운로드)'로 새 양식을 받아주세요.")
            if (cur - prev).days != 1:
                raise ExcelInputError(
                    f"연간 근무표의 날짜가 하루씩 이어지지 않습니다 — {prev.isoformat()} 다음이 "
                    f"{cur.isoformat()}입니다(사이 {(cur - prev).days - 1}일이 빠졌습니다). "
                    "빠진 날짜 열을 채우시거나 '양식(다운로드)'로 새 양식을 받아주세요.")
            prev = cur
        # 날짜가 끊긴 자리 뒤에 데이터가 더 있으면, 그 뒤는 통째로 안 읽힌 것이다.
        tail = [v for v in header_row[i:] if v not in (None, "") and str(v).strip()]
        if tail:
            raise ExcelInputError(
                f"연간 근무표 날짜가 {annual_dates[-1]}에서 끊겼는데 그 오른쪽에 "
                f"{len(tail)}칸의 데이터가 더 있습니다 — 날짜 헤더가 비어 있으면 그 뒤 기록은 "
                "전부 무시되므로 받지 않습니다. 날짜 헤더를 복구하시거나 "
                "'양식(다운로드)'로 새 양식을 받아주세요.")

    # 잔휴는 마이너스가 정상값(오프를 당겨 쓴 상태)이지만, 나머지 누적치는 '몇 번 했나'라
    # 음수가 될 수 없다. 글자가 적혀 있으면 0으로 조용히 바꾸지 않고 알려준다 —
    # 0이 되면 그 사람이 야간을 한 번도 안 선 것으로 잡혀 형평성 계산이 뒤집힌다.
    _MAY_BE_NEGATIVE = {"off_balance", "prev_off_balance"}

    def _num(r, i, key: str = "", who: str = "") -> float:
        v = r[i] if i < len(r) else None
        if v in (None, ""):
            return 0.0
        try:
            f = float(v)
            # NaN/INF는 숫자로는 변환되지만 이후 계산을 전부 오염시킨다(비교가 늘 거짓이
            # 되거나 합계가 INF가 된다). 예전엔 NaN이 파이썬 원본 오류로 튀어나왔다.
            if f != f or f in (float("inf"), float("-inf")):
                raise ValueError("not finite")
        except (TypeError, ValueError):
            label = STAFF_TABLE_STAT_LABELS[STAFF_TABLE_STAT_KEYS.index(key)] if key else "누적통계"
            errors.add(f"연간근무표{f'({who})' if who else ''} '{label}' 칸에 "
                       f"숫자가 아닌 값이 있습니다: {v!r}")
            return 0.0
        if f < 0 and key and key not in _MAY_BE_NEGATIVE:
            label = STAFF_TABLE_STAT_LABELS[STAFF_TABLE_STAT_KEYS.index(key)]
            errors.add(f"연간근무표{f'({who})' if who else ''} '{label}' 칸이 음수입니다: {f:g} "
                       "— 누적 횟수는 0 이상이어야 합니다.")
            return 0.0
        return f

    errors = _ErrorCollector()
    lenient = _LenientNotes()
    staff, stats, annual_grid = [], {}, {}
    team_b_names: List[str] = []
    departed: List[dict] = []
    transferred_in: List[str] = []
    unknown_transfer_marks: List[str] = []
    # '전입' 칸에 적혔는데 전입 표식으로 못 알아본 값. 담을 자리가 없어서 그냥 무시됐다 —
    # 전입자로 안 잡히고 아무 말도 없으니, 전 병동 실적이 우리 병동 누적에 섞여 들어간다.
    unknown_transfer_col: List[str] = []
    transfer_no_off_balance: List[str] = []
    off_balance_blank: List[str] = []
    prev_off_balance_missing: List[str] = []
    unknown_grid_marks: List[str] = []
    transfer_in_dates: Dict[str, str] = {}
    transfer_bad_dates: List[str] = []
    rows_after_summary: List[str] = []
    seen_row_names: set = set()
    section = "active"

    # 소수를 그대로 읽어야 하는 열. 나머지는 int로 자른다.
    #
    # '누적근무일'이 여기 있는 이유 — 반일 근무(DH·EH·TH…)를 0.5로 세기 시작하면서
    # 이 열에 소수가 들어오게 됐는데, 읽을 때 int로 자르면 **재업로드할 때마다 반일이
    # 통째로 사라진다.** 게다가 한 번으로 끝나지 않는다: 이 파일은 매달 자기 값을
    # 이어받아 갱신하므로, 잘린 값이 다음 달의 출발점이 돼 오차가 계속 쌓인다.
    # 에러도 경고도 없이 누적근무일만 조금씩 작아지고, 그 숫자로 형평성을 보는
    # 파트장은 반일을 많이 선 사람을 "덜 일했다"고 읽게 된다.
    _ROUNDED = {"recent_night_score", "off_balance", "prev_off_balance", "workday"}

    def _read_stats(r, who: str = "") -> dict:
        out = {}
        for key in STAFF_TABLE_STAT_KEYS:
            i = stat_idx.get(key)
            v = _num(r, i, key, who) if i is not None else 0.0
            out[key] = round(v, 2) if key in _ROUNDED else int(v)
        # 잔휴만은 '빈 칸'과 '정말 0'을 구분해 둔다 — _num()은 빈 칸을 그냥 0.0으로
        # 돌려주므로 여기서 원본 칸을 다시 본다. 잔휴가 틀리면 이번 달 오프 배분이
        # 통째로 어긋나는데, 0으로 조용히 채워지면 파트장이 알아챌 방법이 없다.
        # 막지는 않고(0으로 보고 진행) 누가 비었는지만 호출부에 넘겨 알리게 한다.
        if who:
            i = stat_idx.get("off_balance")
            if i is None or i >= len(r) or r[i] in (None, ""):
                off_balance_blank.append(who)
            # '전월잔휴'도 같은 이유로 따로 본다. 엔진이 실제로 쓰는 건 '잔휴'지만,
            # 전월잔휴는 파트장이 OCS에서 옮겨 적는 칸이라 비어 있으면 옮겨 적기를
            # 빠뜨린 것이다 — 두 칸을 구분해 알려줘야 어느 칸을 채울지 알 수 있다.
            i = stat_idx.get("prev_off_balance")
            if i is None or i >= len(r) or r[i] in (None, ""):
                prev_off_balance_missing.append(who)
        return out

    # 연도·월을 뺀 전입일("15", "9/15")을 채워 넣을 기준 달. 이 파일은 마지막 반영일까지
    # 쌓인 표이고 전입은 그 '다음 달'에 오는 사람이라, 다음 달 1일에서 월을 가져온다.
    _next_ym = None
    if annual_dates:
        _last = _dt.date.fromisoformat(annual_dates[-1])
        _nxt = _last.replace(day=1) + _dt.timedelta(days=32)
        _next_ym = (_nxt.year, _nxt.month)

    def _read_transfer_date(r, who: str) -> Optional[str]:
        """'전입일' 칸 — 규칙은 원티드표와 같다(_read_transfer_date_cell)."""
        if transfer_date_col is None or transfer_date_col >= len(r):
            return None
        return _read_transfer_date_cell(r[transfer_date_col], who, transfer_bad_dates,
                                        default_ym=_next_ym)

    def _read_codes(r) -> List[str]:
        codes = []
        for d in range(len(annual_dates)):
            idx = first_day_idx + d
            v = r[idx] if idx < len(r) else None
            codes.append(str(v).strip() if v not in (None, "") else "")
        return codes

    for r in rows[h + 1:]:
        # 1열이 'B'/'전출'(구분 행, 2열은 비어 있음)이면 그 아래는 전부 해당 구역이다.
        # B팀(신입)은 순번·통계·연간 그리드가 없는 이름뿐인 행, 전출자는 재직 중 이력을
        # 보존만 하는 행이라 둘 다 현재 인원으로 파싱하면 안 된다. '레벨평균' 등 요약 행
        # (export_staff_table_xlsx가 맨 아래에 덧붙이는 통계)도 마찬가지로 건너뛴다.
        def _cell(i):
            return r[i] if (i is not None and i < len(r)) else None

        if r and (_cell(name_idx) is None or not str(_cell(name_idx)).strip()):
            marker = str(r[0] or "").strip()
            if marker == "B":
                section = "team_b"
                continue
            if marker == "전출":
                section = "departed"
                continue
        if not r or _cell(name_idx) is None or not str(_cell(name_idx)).strip():
            # 이름 칸만 비고 다른 칸엔 값이 있는 행 — 이름을 실수로 지웠을 가능성이
            # 높다. 조용히 건너뛰면 그 사람이 통째로 빠진 채 근무표가 나오므로 알려준다.
            # 날짜 칸은 보지 않는다 — 헤더 바로 아래 '요일' 행이 날짜 칸만 채워져 있어
            # 그것까지 세면 정상 파일이 반려된다. 사람 정보/통계 칸만 본다.
            if r and any(v not in (None, "") and str(v).strip()
                         for i, v in enumerate(r[:first_day_idx]) if i != name_idx):
                errors.add(
                    f"연간근무표: 다른 칸은 채워져 있는데 이름 칸이 비어 있는 행이 있습니다"
                    f"(순번 {str(r[0]).strip() if r[0] not in (None, '') else '?'}) — "
                    "이름을 채우거나 그 행을 통째로 삭제해주세요.")
            continue
        name = _clean_name(_cell(name_idx))
        if name in STAFF_TABLE_SUMMARY_LABELS_READ:
            # 요약 통계 블록에 도달 — 여기부터는 사람 행이 아니다. 다만 파트장이 파일
            # 맨 아래에 사람(전입자 등)을 덧붙이면 조용히 무시돼 버리므로, 그런 행이
            # 있으면 이름을 모아 호출부가 알려줄 수 있게 한다(조용한 누락 방지).
            for rest in rows[rows.index(r) + 1:]:
                nv = rest[name_idx] if (rest and name_idx < len(rest)) else None
                if nv is None or not str(nv).strip():
                    continue
                nm = str(nv).strip()
                if nm not in STAFF_TABLE_SUMMARY_LABELS_READ:
                    rows_after_summary.append(nm)
            if rows_after_summary:
                # 경고만 하고 진행하면 그 사람들이 빠진 채 근무표가 나온다 — 인원 중간에
                # 'D 인원' 같은 요약 라벨이 잘못 들어가면 뒤가 통째로 잘리기도 한다.
                # 메시지에 라벨을 박아두지 않는 이유: 요약 블록은 맨 위가 '레벨평균'이었다가
                # 'D 인원'으로 바뀐 적이 있다. 옛 라벨을 안내하면 파트장이 파일에서 그 줄을
                # 찾아 그 위에 넣고 또 반려된다 — 실제로 걸린 라벨을 그대로 보여준다.
                errors.add(
                    f"연간근무표: 맨 아래 요약 줄('{name}'부터) 뒤에 사람 행이 있습니다"
                    f"({', '.join(rows_after_summary[:5])}"
                    f"{f' 외 {len(rows_after_summary) - 5}명' if len(rows_after_summary) > 5 else ''}) — "
                    "그 아래는 읽히지 않으므로 사람 행은 요약 줄 위로 옮겨주세요.")
            break
        if section == "team_b":
            if name in seen_row_names:
                errors.add(f"연간근무표: B팀 이름 '{name}'이 현재 인원 명단에도 있습니다 — 같은 사람이 두 번 잡히므로 한쪽을 지워주세요.")
                continue
            team_b_names.append(name)
            continue
        if name in seen_row_names:
            # 이름이 사람을 가리키는 키라, 중복을 받으면 누적 통계·연간 이력이 서로
            # 덮어써져 한 사람의 실적이 다른 사람 것으로 합쳐진다.
            errors.add(
                f"연간근무표: 이름 '{name}'이 두 번 이상 나옵니다 — "
                "동명이인이면 '김간호(A)'처럼 구분해서 적어주세요.")
            continue
        seen_row_names.add(name)
        _check_name_length(name, f"연간근무표 시트({name[:20]})", errors)
        note = str(_cell(note_idx) or "")
        if section == "departed":
            # 전출자는 통계·그리드만 그대로 실어 나른다(현재 인원 아님) — 숙련도/가능근무가
            # 비어 있어도 오류로 막지 않는다(과거 기록 보존이 목적이라 관대하게 읽는다).
            try:
                level = int(str(_cell(level_idx) or "1").strip().lstrip("Lv") or 1)
            except (TypeError, ValueError):
                level = 1
            departed.append({
                "id": name, "role": str(_cell(role_idx) or "간호사").strip(), "level": level,
                "allowed_shifts": _split_list(_cell(allowed_idx)),
                "left_at": note.replace("전출", "").strip(),
                "stats": _read_stats(r, name),
                "codes": _read_codes(r) if annual_dates else [],
            })
            continue
        role = _check_role(_cell(role_idx), f"연간근무표({name}) 직급", errors)
        level = _parse_level(_cell(level_idx), context=f"연간근무표 시트({name})",
                             errors=errors)
        lenient.note("직급", _typed_display(_cell(role_idx)), role)
        lenient.note("숙련도", _typed_display(_cell(level_idx)), f"Lv{level}")
        allowed_raw = _split_list(_cell(allowed_idx))
        allowed, allowed_flags = _split_allowed(
            allowed_raw, f"연간근무표 시트({name}) 가능근무", errors)
        if not allowed_raw:
            errors.add(
                f"연간근무표 시트({name}): 가능근무 칸이 비어 있습니다 — 이 사람에게 "
                "배정할 수 있는 근무가 하나도 없다는 뜻이라, 대개는 입력 실수입니다.")
        # 비고에서 온 것과 가능근무 칸에서 온 것을 갈라 둔다(원티드표 쪽과 같은 이유).
        note_flags = _parse_flags(note)
        flags = _with_night_leader(
            _merge_flags(note_flags, allowed_flags),
            night_leader_idx is not None
            and night_leader_mark(_cell(night_leader_idx),
                                  f"연간근무표 시트({name})", errors))
        for _f in note_flags:
            _std = _FLAG_STANDARD_WORD[_f]
            if _std not in _norm_text(note).replace(" ", ""):
                lenient.note("비고", _typed_display(note), _std)
        if _flag_note_looks_unread(note, note_flags):
            errors.add(
                f"연간근무표 시트({name}) 비고: {note!r} — 근무 제약을 적으신 것 같은데 "
                "규칙으로 읽지 못했습니다. '야간전담'·'임부'·'야간금지' 중 하나로 "
                "적어주세요(이대로 두면 그 제약 없이 배정됩니다).")
        staff.append({"id": name, "role": role, "level": level,
                       "allowed_shifts": allowed, "flags": flags})

        st = _read_stats(r, name)
        codes = _read_codes(r) if annual_dates else []
        note_flat = note.replace(" ", "")
        # 전입 여부는 전용 '전입' 칸(드롭다운)으로 판별한다 — 자유 입력인 비고에 적으면
        # 오타·띄어쓰기로 놓치기 쉬워 전용 칸으로 옮겼다. 예전 양식으로 만든 파일과
        # 손으로 비고에 적은 경우도 계속 읽히도록 비고 표기는 후퇴 경로로 남겨둔다.
        marked_col = _norm_text(_cell(transfer_col)).replace(" ", "").lower()
        marked = (marked_col in _TRANSFER_IN_ALIASES
                  or _TRANSFER_IN_MARK in marked_col
                  or _TRANSFER_IN_MARK in note_flat)
        if not marked and marked_col:
            unknown_transfer_col.append(f"{name}: {_cell(transfer_col)}")
        if marked:
            # 전입자 — 붙여넣은 전 병동 기록은 이월정보·야간형평성 계산에만 쓰고,
            # 부서 누적 실적은 0에서 시작한다(운영 방침: 분리).
            transferred_in.append(name)
            if marked_col:
                lenient.note("전입", _typed_display(_cell(transfer_col)),
                             _TRANSFER_IN_MARK)
            # '전입일' 칸에 날짜가 있으면 월중 전입(없으면 그 달 1일자 전입). 월중이면
            # 입사 전 날짜를 배정에서 빼고 잔휴도 재직 구간만 적립해야 하므로 날짜가
            # 필요하다. 엑셀 날짜 셀이라 표기 흔들림이 없고, 비고에 적은 옛 방식도 받는다.
            ds = _read_transfer_date(r, name)
            if ds is None:
                m = _TRANSFER_DATE_RE.search(note_flat)
                if m:
                    ds = f"{int(m.group(1)):04d}-{int(m.group(2)):02d}-{int(m.group(3)):02d}"
            if ds:
                transfer_in_dates[name] = ds
                lenient.note("전입일", _typed_display(_cell(transfer_date_col)
                                                    if transfer_date_col is not None
                                                    else ""), ds)
            for k in _WARD_CUMULATIVE_KEYS:
                st[k] = 0
            # 전 병동 코드 중 이 앱이 모르는 표기는 통째로 반려하지 말고 빈칸으로 비우고
            # 목록만 알려준다 — 이력을 옮겨 붙이는 작업이라 표기가 조금 다를 수 있고,
            # 한 칸 때문에 전체가 막히면 곤란하다(빈칸은 하류에서 OFF로 처리됨).
            cleaned = []
            for c in codes:
                if c and not _is_known_shift_code(c):
                    unknown_transfer_marks.append(f"{name}: {c}")
                    cleaned.append("")
                else:
                    cleaned.append(c)
            codes = cleaned
            if not st.get("off_balance"):
                transfer_no_off_balance.append(name)
        else:
            # 현원 행도 같은 검사를 한다. 이 앱이 만든 출력②를 그대로 올리는 게 정상
            # 경로지만 파트장이 손으로 고치는 일이 있고, 모르는 표기가 조용히 빈칸(=OFF)이
            # 되면 연속근무일수·야간블록 이월이 그만큼 틀어진 채로 다음 달이 만들어진다.
            # 한 칸 때문에 전체를 막지는 않되, 무엇이 안 읽혔는지는 반드시 알려준다.
            cleaned = []
            for c in codes:
                if c and not _is_known_shift_code(c):
                    unknown_grid_marks.append(f"{name}: {c}")
                    cleaned.append("")
                else:
                    cleaned.append(c)
            codes = cleaned

        stats[name] = st
        if annual_dates:
            annual_grid[name] = codes

    if not staff:
        raise ExcelInputError("연간근무표 시트가 비어 있습니다")
    # 못 읽은 전입일만 반려한다. '이 달 밖' 판정은 여기서 하지 않는다 — 이 파일은
    # 전입자의 전 병동 근무기록을 날짜에 맞춰 붙여넣는 것이 정상 흐름이라(안내 시트 ④)
    # 그리드가 우리 병동의 마지막 반영 달보다 뒤까지 뻗어 있을 수 있고, 그걸 기준으로
    # 삼으면 정상 파일을 반려한다. 만들 달이 제목에 박혀 있는 원티드표에서만 본다.
    _reject_bad_transfer_dates(errors, transfer_bad_dates, [], _next_ym)
    errors.raise_if_any()

    return {"staff": staff, "stats": stats,
            "normalized": lenient.as_list(),
            "annual_dates": annual_dates, "annual_grid": annual_grid,
            "team_b_names": team_b_names, "departed": departed,
            "transferred_in": transferred_in,
            "transfer_in_dates": transfer_in_dates,
            "transfer_bad_dates": transfer_bad_dates,
            "unknown_transfer_marks": sorted(set(unknown_transfer_marks)),
            "unknown_transfer_col": sorted(set(unknown_transfer_col)),
            "transfer_no_off_balance": transfer_no_off_balance,
            "off_balance_blank": off_balance_blank,
            "prev_off_balance_missing": prev_off_balance_missing,
            "has_prev_off_balance_col": stat_idx.get("prev_off_balance") is not None,
            "unknown_grid_marks": sorted(set(unknown_grid_marks)),
            "rows_after_summary": sorted(set(rows_after_summary))}


# ---------------------------------------------------------------- 쓰기

def write_input_xlsx(cfg: dict, path: str):
    """설정 dict → 입력 엑셀 (원본 0-2/0-3 표 양식)."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment

    wb = Workbook()
    head = Font(bold=True)
    fill = PatternFill("solid", fgColor="DDEBE7")

    ws = wb.active
    ws.title = "설정"
    p = cfg.get("params", {})
    # 월신청상한·공휴일·대체공휴일은 더 이상 입력엑셀에서 받지 않는다(고정값/자동채움) —
    # "설정" 시트를 병동마다 매번 채워야 하는 항목만 남긴다.
    rows = [("항목", "값"),
            ("병동명", cfg.get("ward_id", "")),
            ("연도", cfg["year"]), ("월", cfg["month"]),
            ("월최대야간", p.get("off_max_per_month", 6)),
            ("연속근무제한", p.get("max_consecutive_work", 5))]
    for r in rows:
        ws.append(list(r))
    for c in ws[1]:
        c.font = head
        c.fill = fill
    ws.column_dimensions["A"].width = 14
    ws.column_dimensions["B"].width = 30

    ws = wb.create_sheet("인원")
    ws.append(["순번", "이름", "직급", "숙련도", "가능근무", "비고"])
    for c in ws[1]:
        c.font = head
        c.fill = fill
    for i, s in enumerate(cfg["staff"], 1):
        flags = s.get("flags", [])
        notes = []
        if "night_only" in flags:
            notes.append("야간전담")
        if "pregnant" in flags:
            notes.append("임부(야간 금지)")
        elif "no_night" in flags:
            notes.append("야간금지")
        if s["role"] == "파트장":
            notes.append("카운트 제외, 상근(평일)")
        # ⚠ '인원' 시트(옛 병동인력표)에는 '야간리더' 열을 **넣지 않는다.** 이 시트는
        # 읽는 쪽이 아직 위치 기반이라 열을 끼우면 비고가 한 칸 밀려 '임부'·'야간전담'
        # 표시가 통째로 사라진다 — 오류도 경고도 없이 그 사람이 야간을 서게 된다.
        # 야간리더는 가능근무 칸 표기('야간리더')로도 읽히므로 여기서는 그 길을 쓴다.
        # (지금 쓰는 양식은 원티드표·연간근무표이고, 둘 다 이름으로 열을 찾는다.)
        ws.append([i, s["id"], s["role"], f"Lv{s['level']}",
                   allowed_shifts_text(s["allowed_shifts"], s.get("flags")),
                   ", ".join(notes)])
    for col, w in (("A", 6), ("B", 12), ("C", 9), ("D", 8), ("E", 18), ("F", 24)):
        ws.column_dimensions[col].width = w

    ws = wb.create_sheet("최소인력")
    m = p.get("min_staff", {})
    by_dow = m.get("weekday_by_dow") or {}
    header = ["근무", "평일", "토요일", "일요일공휴일"]
    if by_dow:
        header += ["월", "화", "수", "목", "금"]
    ws.append(header)
    for c in ws[1]:
        c.font = head
        c.fill = fill
    for key in ("D", "E", "N", "prn", DESIGNATED_KEY):
        row = [key, m.get("weekday", {}).get(key, 0),
               m.get("saturday", {}).get(key, 0),
               m.get("sunday_holiday", {}).get(key, 0)]
        if by_dow:
            # 요일별로 지정 안 한 날은 빈 칸으로 남긴다 — 읽을 때 빈 칸은 "평일"
            # 공통값을 그대로 쓰는 것으로 해석되므로, 값을 억지로 채워 넣지 않는다.
            for dow in ("0", "1", "2", "3", "4"):
                row.append(by_dow.get(dow, {}).get(key, ""))
        ws.append(row)
    ws.append(["8A", "1(파트장)", 0, 0] + ([""] * 5 if by_dow else []))

    reqs = cfg.get("requests") or []
    if reqs:
        ws = wb.create_sheet("신청")
        ws.append(["이름", "날짜", "근무유형", "우선순위"])
        for c in ws[1]:
            c.font = head
            c.fill = fill
        for r in reqs:
            ws.append([r["staff_id"], r["date"], r["type"], r.get("priority", 1)])
        ws.column_dimensions["B"].width = 12

    carry = cfg.get("prev_month_carryover") or {}
    if carry:
        ws = wb.create_sheet("전월이월")
        ws.append(["이름", "마지막근무", "연속근무일수", "이월OFF일수", "말일연속야간일수"])
        for c in ws[1]:
            c.font = head
            c.fill = fill
        for sid, v in carry.items():
            ws.append([sid, v.get("last_shift_type", "OFF"),
                       v.get("consecutive_work_days", 0),
                       v.get("night_block_remaining_off", 0),
                       v.get("trailing_night_count", 0)])
        for col in ("A", "B", "C", "D", "E"):
            ws.column_dimensions[col].width = 14

    team_b_names = p.get("team_b_names") or []
    if team_b_names:
        ws = wb.create_sheet("B팀")
        ws.append(["이름"])
        for c in ws[1]:
            c.font = head
            c.fill = fill
        for name in team_b_names:
            ws.append([name])
        ws.column_dimensions["A"].width = 14

    wb.save(path)

# -*- coding: utf-8 -*-
"""엑셀 입력 형식 (원본 설계서 0-2/0-3 표 양식).

시트 구성:
  설정     — 항목/값 (병동명, 연도, 월, 월최대야간). 월신청상한·공휴일·대체공휴일은 입력받지
           않고 코드가 고정값/자동조회(kr_holidays_for_month, 2040년까지)로 채운다.
           야간목표하한/야간목표상한(선택, 기본 4/6) — H6-4 월 야간목표를 조정할 때만
           채운다. 상한을 홀수로 올리면(예: 7) 3일 야간블록도 자동 허용되며, 이때
           월최대야간(H2-6 안전상한)도 상한 이상으로 같이 올려야 실제 배정된다.
  인원     — 순번 | 이름 | 직급 | 숙련도 | 가능근무 | 비고
  최소인력 — 근무 | 평일 | 토요일 | 일요일공휴일  (D/E/N/prn 행, 8A 행은 무시)
  신청     — 이름 | 날짜 | 근무유형 | 우선순위   (선택, 행 순서 = 선착순)
  전월이월 — 이름 | 마지막근무 | 연속근무일수 | 이월OFF일수 | 말일연속야간일수 (선택)

비고 키워드: "야간전담" → night_only, "임부" → pregnant, "야간금지"/"야간 금지" → no_night

  연간근무표 — 다월 자동 연동용(선택 사용, 구 명칭 "인원표"). 순번|이름|직급|숙련도|가능근무|비고 +
           누적통계(최근야간점수|누적야간|누적오프|누적주말야간|누적2일블록|누적3일블록|반영개월수) +
           연간 근무 그리드(1/1~, 참고용). export_staff_table_xlsx()로 내보내고
           load_staff_table_xlsx()로 다시 읽어 다음 달 생성에 이어붙인다.
"""
from __future__ import annotations

import re
from typing import Dict, List, Optional

from .calendar_utils import kr_holidays_for_month
from .models import Shift, parse_shift

# 월 신청상한(직원 1명당 월 근무형 신청 개수 상한, §5) — 사용자가 매번 입력하지 않도록
# 고정값을 쓴다. 실사용(42명 규모, prn 인력 부족)에서 검증된 값.
DEFAULT_MAX_REQUESTS_PER_PERSON = 20

STAFF_TABLE_STATIC_COLS = ["순번", "이름", "직급", "숙련도", "가능근무", "비고"]
STAFF_TABLE_STAT_KEYS = ["night", "workday", "off", "weekend_night",
                          "blocks_2", "blocks_3", "months", "recent_night_score",
                          "cum_d", "cum_e", "cum_prn", "cum_weekend_holiday_off",
                          "off_balance"]
STAFF_TABLE_STAT_LABELS = ["누적야간", "누적근무일", "누적오프", "누적주말야간",
                            "누적2일블록", "누적3일블록", "반영개월수",
                            "최근야간점수(참고용)",
                            "누적D", "누적E", "누적prn(8A)", "누적주말휴일오프",
                            "잔휴"]


class ExcelInputError(Exception):
    pass


class _ErrorCollector:
    """엑셀 파싱 중 발견한 문제를 첫 건에서 바로 멈추지 않고 모아뒀다가, 끝에서 한
    번에 보고한다 — 실수가 여러 개면 업로드→수정→재업로드를 문제 개수만큼 반복하지
    않도록. 시트 자체가 없거나 헤더를 못 찾는 등 더 이상 읽을 수 없는 구조적 문제는
    (계속 읽어봐야 의미가 없으므로) 이 컬렉터를 안 거치고 그 자리에서 바로 raise한다."""

    def __init__(self):
        self.items: List[str] = []

    def add(self, msg: str) -> None:
        self.items.append(msg)

    def raise_if_any(self) -> None:
        if not self.items:
            return
        if len(self.items) == 1:
            raise ExcelInputError(self.items[0])
        bullet = "\n".join(f"{i + 1}. {m}" for i, m in enumerate(self.items))
        raise ExcelInputError(f"입력 파일에서 문제 {len(self.items)}건을 찾았습니다:\n{bullet}")


# ---------------------------------------------------------------- 읽기

def _sheet_rows(ws) -> List[list]:
    return [[c for c in row] for row in ws.iter_rows(values_only=True)]


def _find_header(rows, first_col_name):
    for i, r in enumerate(rows):
        if r and str(r[0] or "").strip() == first_col_name:
            return i
    return None


def _parse_level(v, context: str = "", errors: Optional[_ErrorCollector] = None) -> int:
    s = str(v).strip()
    if s.lower().startswith("lv"):
        s = s[2:]
    try:
        return int(float(s))
    except ValueError:
        where = f" ({context})" if context else ""
        msg = f"숙련도 칸에 알 수 없는 값이 있습니다{where}: {v!r}"
        if errors is not None:
            errors.add(msg)
            return 1  # 계속 읽기 위한 임시값 — 오류가 모였으니 최종적으로는 반려된다
        raise ExcelInputError(msg)


def _int_cell(v, context: str, default: Optional[int] = None,
             errors: Optional[_ErrorCollector] = None) -> int:
    """엑셀 칸 값을 정수로 변환 — 실패하면 어느 칸이 문제인지 담은 메시지로 알려준다.

    default가 주어지면 빈 칸(None/"")은 그 값으로 채우고, 값이 있는데 숫자로 못
    바꾸는 경우만 오류로 취급한다(사용자가 실수로 글자를 넣은 경우와 구분). 숫자
    앞뒤에 단위 등 글자가 섞여 있어도(예: "9명", "약 9") 안에 숫자가 정확히 하나뿐이면
    그 값으로 관대하게 읽는다 — 여러 개 섞여 있으면(예: "9~10") 모호하니 포기한다."""
    if v is None or (isinstance(v, str) and not v.strip()):
        if default is not None:
            return default
        v = 0
    try:
        return int(float(v))
    except (TypeError, ValueError):
        digits = re.findall(r"\d+", str(v))
        if len(digits) == 1:
            return int(digits[0])
        msg = f"{context}에 숫자가 아닌 값이 있습니다: {v!r}"
        if errors is not None:
            errors.add(msg)
            return default if default is not None else 0
        raise ExcelInputError(msg)


def _check_shift_code(code: str, context: str,
                      errors: Optional[_ErrorCollector] = None) -> bool:
    """가능근무 칸의 코드 하나가 이 앱이 아는 근무유형인지 확인 — 오타/미지원 코드를
    조용히 삼키지 않고 어느 사람의 어느 칸인지와 함께 바로 알려준다. 반환값은 코드가
    유효했는지(True/False) — errors가 주어지면 무효해도 예외 대신 이 값으로 알려준다."""
    try:
        parse_shift(code)
        return True
    except ValueError:
        msg = (f"{context}에 알 수 없는 근무유형이 있습니다: {code!r} "
               "(D/E/N/8A/9A/10A/NK/prn/T/TW 등만 인식됩니다)")
        if errors is not None:
            errors.add(msg)
            return False
        raise ExcelInputError(msg)


_DATE_SEP_RE = re.compile(r"^(\d{4})\s*[-./]\s*(\d{1,2})\s*[-./]\s*(\d{1,2})$")
_DATE_KOREAN_RE = re.compile(r"^(\d{1,2})\s*월\s*(\d{1,2})\s*일$")


def _normalize_date(raw, year_hint: int, context: str,
                    errors: Optional[_ErrorCollector] = None) -> Optional[str]:
    """신청 시트의 날짜 칸을 최대한 관대하게 읽어 'YYYY-MM-DD'로 돌려준다 — 엑셀 날짜
    셀은 물론, "2026.9.5"/"2026/9/5" 같은 구분자 표기나 "9월 5일"(연도는 이 함수에
    넘겨준 설정 시트 연도로 채움)도 인식한다. 못 알아보면 errors에 담고 None을
    돌려준다(그 신청 한 줄만 건너뛴다)."""
    if hasattr(raw, "strftime"):
        return raw.strftime("%Y-%m-%d")
    s = str(raw).strip()
    m = _DATE_SEP_RE.match(s)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        return f"{y:04d}-{mo:02d}-{d:02d}"
    m = _DATE_KOREAN_RE.match(s)
    if m:
        mo, d = int(m.group(1)), int(m.group(2))
        return f"{year_hint:04d}-{mo:02d}-{d:02d}"
    msg = (f"{context}: 날짜 칸을 알아볼 수 없습니다: {raw!r} — "
           "날짜 형식(예: 2026-09-05, 2026.9.5, 9월 5일)인지 확인하세요.")
    if errors is not None:
        errors.add(msg)
        return None
    raise ExcelInputError(msg)


def _parse_flags(note: str) -> List[str]:
    note = (note or "").replace(" ", "")
    flags = []
    if "야간전담" in note:
        flags.append("night_only")
    if "임부" in note:
        flags.append("pregnant")
    if "야간금지" in note and "pregnant" not in flags:
        flags.append("no_night")
    return flags


def _split_list(v) -> List[str]:
    """"D,E,N" 형태를 항목 리스트로 — 쉼표·가운뎃점 말고도 슬래시·세미콜론·공백·줄바꿈
    으로 구분해도 관대하게 받아준다(예: "D E N", "D/E/N" 모두 ["D","E","N"])."""
    if v is None:
        return []
    return [x for x in re.split(r"[,·/;\s]+", str(v).strip()) if x]


def load_input_xlsx(path: str) -> dict:
    """입력 엑셀 → 설정 dict (JSON 입력과 동일 스키마)."""
    from openpyxl import load_workbook
    wb = load_workbook(path, data_only=True)

    for need in ("설정", "인원", "최소인력"):
        if need not in wb.sheetnames:
            raise ExcelInputError(f"필수 시트 누락: {need}")

    # -------- 설정
    kv: Dict[str, object] = {}
    for row in wb["설정"].iter_rows(values_only=True):
        if row and row[0] is not None and str(row[0]).strip() not in ("항목", ""):
            kv[str(row[0]).strip()] = row[1] if len(row) > 1 else None
    try:
        year = int(kv["연도"])
        month = int(kv["월"])
    except (KeyError, TypeError, ValueError):
        raise ExcelInputError("설정 시트에 연도/월이 없습니다")
    if not (1 <= month <= 12):
        raise ExcelInputError(f"설정 시트의 월 값이 1~12월 범위를 벗어났습니다: {month!r}")

    errors = _ErrorCollector()

    # -------- 인원
    rows = _sheet_rows(wb["인원"])
    h = _find_header(rows, "순번")
    if h is None:
        raise ExcelInputError("인원 시트에 '순번' 헤더가 없습니다")
    staff = []
    seen_names: Dict[str, int] = {}
    for row_no, r in enumerate(rows[h + 1:], start=h + 2):
        if not r or r[1] is None or not str(r[1]).strip():
            continue
        name = str(r[1]).strip()
        if name in seen_names:
            errors.add(
                f"인원 시트 {row_no}행: 이름 '{name}'이 {seen_names[name]}행과 중복됩니다 "
                "— 이름은 한 명당 한 번만 적어야 합니다.")
            continue
        seen_names[name] = row_no
        role = str(r[2] or "간호사").strip()
        level = _parse_level(r[3], context=f"인원 시트 {row_no}행({name})", errors=errors)
        allowed = _split_list(r[4])
        note = str(r[5] or "") if len(r) > 5 else ""
        allowed = [a for a in allowed
                  if _check_shift_code(a, context=f"인원 시트 {row_no}행({name}) 가능근무",
                                       errors=errors)]
        staff.append({
            "id": name, "role": role, "level": level,
            "allowed_shifts": allowed, "flags": _parse_flags(note),
        })
    if not staff:
        raise ExcelInputError("인원 시트가 비어 있습니다 — 순번 아래에 최소 1명은 입력해야 합니다.")

    # -------- 최소인력
    rows = _sheet_rows(wb["최소인력"])
    h = _find_header(rows, "근무")
    if h is None:
        raise ExcelInputError("최소인력 시트에 '근무' 헤더가 없습니다")
    mins = {"weekday": {}, "saturday": {}, "sunday_holiday": {}}
    # 대소문자를 관대하게 받아준다(예: "PRN"→"prn") — 인원 시트 가능근무 칸과 동일한
    # 정책. "8A" 등은 파트장이 자동으로 채우는 정보성 행이라 원래부터 값 없이도 되고,
    # 그 외 알아볼 수 없는 표기는(예전엔 조용히 통째로 무시됐다) 이제 문제로 모아둔다.
    _MIN_STAFF_KEY_MAP = {"d": "D", "e": "E", "n": "N", "prn": "prn"}
    _MIN_STAFF_INFO_ROWS = {"8a", "9a", "10a"}
    for r in rows[h + 1:]:
        if not r or r[0] is None or not str(r[0]).strip():
            continue
        raw_key = str(r[0]).strip()
        key = _MIN_STAFF_KEY_MAP.get(raw_key.lower())
        if key is None:
            if raw_key.lower() in _MIN_STAFF_INFO_ROWS:
                continue  # 파트장 자동 배정 안내용 행 — 값 없이 지나감
            errors.add(
                f"최소인력 시트: '근무' 칸에 알 수 없는 값이 있습니다: {raw_key!r} "
                "(D/E/N/prn만 인식됩니다)")
            continue
        mins["weekday"][key] = _int_cell(r[1], f"최소인력 시트 '{key}' 행 평일 칸",
                                         default=0, errors=errors)
        mins["saturday"][key] = _int_cell(r[2], f"최소인력 시트 '{key}' 행 토요일 칸",
                                          default=0, errors=errors)
        mins["sunday_holiday"][key] = _int_cell(
            r[3], f"최소인력 시트 '{key}' 행 일요일·공휴일 칸", default=0, errors=errors)

    # -------- 신청 (선택)
    requests = []
    if "신청" in wb.sheetnames:
        rows = _sheet_rows(wb["신청"])
        h = _find_header(rows, "이름")
        if h is not None:
            for row_no, r in enumerate(rows[h + 1:], start=h + 2):
                if not r or r[0] is None or not str(r[0]).strip():
                    continue
                who = str(r[0]).strip()
                date_str = _normalize_date(
                    r[1], year, context=f"신청 시트 {row_no}행({who})", errors=errors)
                if date_str is None:
                    continue  # 날짜를 못 읽었으면 이 신청 한 줄만 건너뜀(errors엔 이미 기록됨)
                if r[2] is None or not str(r[2]).strip():
                    errors.add(f"신청 시트 {row_no}행({who}): 근무유형 칸이 비어 있습니다.")
                    continue
                requests.append({
                    "staff_id": who,
                    "date": date_str,
                    "type": str(r[2]).strip(),
                    "priority": _int_cell(r[3], f"신청 시트 {row_no}행({who}) 우선순위 칸",
                                          default=1, errors=errors)
                                if len(r) > 3 else 1,
                })

    # -------- 전월이월 (선택)
    carry = {}
    if "전월이월" in wb.sheetnames:
        rows = _sheet_rows(wb["전월이월"])
        h = _find_header(rows, "이름")
        if h is not None:
            for row_no, r in enumerate(rows[h + 1:], start=h + 2):
                if not r or r[0] is None or not str(r[0]).strip():
                    continue
                who = str(r[0]).strip()
                trailing = _int_cell(
                    r[4], f"전월이월 시트 {row_no}행({who}) 말일연속야간일수 칸",
                    default=0, errors=errors
                ) if len(r) > 4 else 0
                carry[who] = {
                    "last_shift_type": str(r[1] or "OFF").strip(),
                    "consecutive_work_days": _int_cell(
                        r[2], f"전월이월 시트 {row_no}행({who}) 연속근무일수 칸",
                        default=0, errors=errors),
                    "night_block_remaining_off": _int_cell(
                        r[3], f"전월이월 시트 {row_no}행({who}) 이월OFF일수 칸",
                        default=0, errors=errors),
                    "night_block_in_progress": trailing == 1,
                    "trailing_night_count": trailing,
                }

    errors.raise_if_any()

    # -------- B팀(신입, 선택) — 이름만. 스케줄링에 관여하지 않고 출력 시 이름만 표시.
    team_b_names = []
    if "B팀" in wb.sheetnames:
        rows = _sheet_rows(wb["B팀"])
        h = _find_header(rows, "이름")
        if h is not None:
            for r in rows[h + 1:]:
                if r and r[0] is not None and str(r[0]).strip():
                    team_b_names.append(str(r[0]).strip())

    nk_count = sum(1 for s in staff if "night_only" in s["flags"])
    # 공휴일/대체공휴일은 입력엑셀에서 직접 받지 않고 항상 자동으로 채운다(kr_holidays_for_month,
    # 2040년까지 알려진 규칙 기반 — 사용자가 매번 날짜를 나열할 필요 없게 단순화).
    holidays, substitute_holidays = kr_holidays_for_month(year, month)
    return {
        "ward_id": str(kv.get("병동명", "") or ""),
        "year": year, "month": month,
        "staff": staff,
        "params": {
            "nk_count": _int_cell(kv.get("NK인원수"), "설정 시트 'NK인원수' 칸", default=nk_count),
            "min_staff": mins,
            # 리더8A운용은 웹 UI에도 없는 설정이라 엑셀에서도 뺐다 — 항상 기본값(False)만 쓴다.
            "leader_8a_as_prn": False,
            "off_max_per_month": _int_cell(kv.get("월최대야간"), "설정 시트 '월최대야간' 칸", default=6),
            # 월신청상한도 입력엑셀에서 직접 받지 않고 고정값을 쓴다(단순화).
            "max_requests_per_person": DEFAULT_MAX_REQUESTS_PER_PERSON,
            "holidays": holidays,
            "substitute_holidays": substitute_holidays,
            "advanced_track_staff": _split_list(kv.get("심화과정대상")),
            "team_b_names": team_b_names,
            # H6-4 월 야간목표 하한/상한 — 선택 입력(기본 4/6일). 상한을 홀수로
            # 올리면(예: 7) 3일 블록도 자동 허용되니 월최대야간도 함께 올려야 한다.
            "night_quota_low": _int_cell(kv.get("야간목표하한"), "설정 시트 '야간목표하한' 칸", default=4),
            "night_quota_high": _int_cell(kv.get("야간목표상한"), "설정 시트 '야간목표상한' 칸", default=6),
            # H3-1 안전 규칙(연속근무 상한) — 선택 입력(기본 5일). 낮출수록 배치
            # 자유도가 줄어 §H6-1(주간 3~4일 블록) 등이 더 자주 못 지켜질 수 있다.
            "max_consecutive_work": _int_cell(
                kv.get("연속근무제한"), "설정 시트 '연속근무제한' 칸", default=5),
        },
        "prev_month_carryover": carry,
        "requests": requests,
    }


# ---------------------------------------------------------------- 월간근무표 형태 엑셀 공통 (제목행 + 이름|1일|2일|...)

def _parse_monthly_grid_shape(ws):
    """제목 행(A1) 'YYYY년 M월' + 2행 일자 헤더 + 4행부터 이름|근무... 모양 파싱.

    "월간근무표"(이 앱이 내보낸 근무표) 다운로드/전월이월 자동채움/원티드 업로드가
    전부 이 모양을 공유한다. 반환: (year, month, num_days, first_day_col).
    """
    import re
    title = str(ws.cell(1, 1).value or "")
    m = re.match(r"(\d{4})\s*년\s*(\d{1,2})\s*월", title)
    if not m:
        raise ExcelInputError(
            "제목 행(A1)에서 'YYYY년 M월' 형식을 찾지 못했습니다 — "
            "월간근무표와 같은 모양(이름|1일|2일|...)인지 확인하세요."
        )
    year, month = int(m.group(1)), int(m.group(2))
    # 일자 열: 예전 포맷(3열부터 1일)과 잔휴 2열이 추가된 신규 포맷(5열부터 1일) 둘 다
    # 읽을 수 있도록, 2행에서 "1"이 나오는 열을 찾아 첫 일자 열로 삼는다(고정 열번호
    # 대신 동적 탐지 — 선두 열이 몇 개든 견고하게 동작).
    first_day_col = None
    for col in range(1, 10):
        if ws.cell(2, col).value == 1:
            first_day_col = col
            break
    if first_day_col is None:
        raise ExcelInputError("2행에서 1일(숫자 1) 열을 찾지 못했습니다.")
    col = first_day_col
    while isinstance(ws.cell(2, col).value, (int, float)):
        col += 1
    num_days = col - first_day_col
    if not (28 <= num_days <= 31):
        raise ExcelInputError(f"일자 열을 인식하지 못했습니다 (인식된 일수: {num_days})")
    return year, month, num_days, first_day_col


def _try_parse_hospital_ocs_shape(ws):
    """병원 OCS 시스템이 직접 내보낸 근무표 원본(예: '간호스케줄') 모양 인식 시도.

    확인된 실제 구조: 1행 '간호스케줄', 2행 '조회 : YYYY년MM월', 3행에 일자 헤더
    ('전월' 라벨 + 1~말일 + D/E/N/®/ⓡ/금월/T연/R연/부서), 4행에 요일(같은 열에
    '성  명' 라벨), 5행부터 데이터(파트장 특별행 → 'A' 팀 구분 행 → 순번 매긴 일반
    직원 → 'B' 팀 구분 행 → B팀 직원). 순번은 1열, 성명은 2열.

    우리 자체 포맷(_parse_monthly_grid_shape)과 달리 실패해도 예외를 던지지 않고
    None을 돌려준다 — 호출 쪽에서 우리 포맷을 먼저 시도하고 실패했을 때만 이
    함수로 폴백하기 위함(서로 다른 두 실제 파일 모양을 각각 안전하게 인식).
    반환: {"year","month","num_days","first_day_col","header_row","name_col"} 또는 None.
    """
    import re
    year = month = None
    for r in range(1, 4):
        for c in range(1, 7):
            v = str(ws.cell(r, c).value or "")
            m = re.search(r"(\d{4})\s*년\s*(\d{1,2})\s*월", v)
            if m:
                year, month = int(m.group(1)), int(m.group(2))
                break
        if year:
            break
    if year is None:
        return None

    header_row = first_day_col = num_days = None
    for r in range(1, 7):
        for c in range(1, 10):
            if ws.cell(r, c).value == 1:
                c2, n = c, 1
                while ws.cell(r, c2 + 1).value == n + 1:
                    c2 += 1
                    n += 1
                if 28 <= n <= 31:
                    header_row, first_day_col, num_days = r, c, n
                    break
        if header_row:
            break
    if header_row is None:
        return None

    # 성명 열: 일자 헤더 다음 행(요일 행)에서 '성명'/'이름' 라벨이 있는 열을 찾는다.
    name_col = None
    for c in range(1, first_day_col):
        label = "".join(str(ws.cell(header_row + 1, c).value or "").split())
        if "성명" in label or "이름" in label:
            name_col = c
            break
    if name_col is None:
        return None

    return {"year": year, "month": month, "num_days": num_days,
            "first_day_col": first_day_col, "header_row": header_row,
            "name_col": name_col}


def _find_grid_sheet(wb):
    """월간근무표 모양의 시트를 찾는다.

    엑셀에서 마지막으로 보고 있던 시트(wb.active)를 우선 시도하되, 안내/설명용
    시트가 같이 들어있어 그게 활성 시트로 저장된 경우에도 문제없이 읽히도록
    나머지 시트를 전부 훑어 'YYYY년 M월' 형식의 진짜 데이터 시트를 찾는다.

    후보가 여럿이면서 서로 다른 연/월을 가리키면(예: 실수로 지난달 시트를 안
    지우고 새 달 시트를 옆에 또 만든 경우) 어느 쪽을 써야 할지 조용히 하나를
    골라버리지 않고, 어떤 시트들이 서로 충돌하는지 알려주고 멈춘다.
    반환: (ws, year, month, num_days, first_day_col)"""
    candidates = [wb.active] + [ws for ws in wb.worksheets if ws is not wb.active]
    matches = []  # [(ws, year, month, num_days, first_day_col)]
    last_err = None
    for ws in candidates:
        try:
            year, month, num_days, first_day_col = _parse_monthly_grid_shape(ws)
            matches.append((ws, year, month, num_days, first_day_col))
        except ExcelInputError as e:
            last_err = e
    if not matches:
        raise last_err or ExcelInputError("월간근무표 모양의 시트를 찾지 못했습니다.")
    distinct_months = {(m[1], m[2]) for m in matches}
    if len(distinct_months) > 1:
        detail = ", ".join(f"'{m[0].title}'({m[1]}년 {m[2]}월)" for m in matches)
        raise ExcelInputError(
            f"서로 다른 달을 가리키는 시트가 여러 개 있어 어느 것을 써야 할지 알 수 없습니다: "
            f"{detail} — 쓰지 않는 시트는 지우고 하나만 남겨주세요."
        )
    return matches[0]


def _is_team_divider_row(ws, row: int, name_col: int, first_day_col: int, num_days: int) -> bool:
    """'A'/'B' 팀 구분 행 판별(export_excel도, 병원 OCS 원본도 이름 칸에만 'A'/'B'를
    쓰고 나머지(일자 칸)는 비워둔다).

    이름이 정확히 'A'/'B' 한 글자이면서 일자 칸이 전부 비어 있을 때만 구분 행으로
    본다 — 직원 이름이 우연히 'A'/'B'인 경우를 오인하지 않도록 이중으로 확인."""
    name = str(ws.cell(row, name_col).value or "").strip()
    if name not in ("A", "B"):
        return False
    return all(ws.cell(row, first_day_col + d).value in (None, "") for d in range(num_days))


def _read_grid_rows(ws, name_col: int, first_day_col: int, num_days: int,
                    data_start_row: int, has_off_balance: bool):
    """이름 열/일자 시작 열이 주어졌을 때 공통 행 읽기 루프.

    'A'/'B' 팀 구분 행은 건너뛰고, has_off_balance면 잔휴(이후, 일자 시작 열
    바로 앞 칸)도 함께 읽는다. 반환: (grid, off_balance)."""
    grid: Dict[str, List[str]] = {}
    off_balance: Dict[str, float] = {}
    row = data_start_row
    while True:
        name = ws.cell(row, name_col).value
        if name is None or str(name).strip() == "":
            break
        if _is_team_divider_row(ws, row, name_col, first_day_col, num_days):
            row += 1
            continue
        sid = str(name).strip()
        shifts = []
        for d in range(num_days):
            v = ws.cell(row, first_day_col + d).value
            shifts.append(str(v).strip() if v not in (None, "") else "OFF")
        grid[sid] = shifts
        if has_off_balance:
            v = ws.cell(row, first_day_col - 1).value
            try:
                off_balance[sid] = float(v)
            except (TypeError, ValueError):
                pass
        row += 1
    return grid, off_balance


# ---------------------------------------------------------------- 지난달 확정 근무표 읽기 (이월/히스토리용)

def load_prev_month_schedule_xlsx(path: str) -> dict:
    """월간근무표(이 앱이 내보낸 근무표 엑셀, 또는 병원 OCS가 직접 내보낸 원본)를
    읽어 그리드로 복원.

    먼저 우리 자체 포맷(제목 'YYYY년 M월'로 시작)으로 시도하고, 어느 시트에서도
    맞지 않으면 병원 OCS 원본 모양('간호스케줄'/'조회 : ...')으로 재시도한다 —
    서로 다른 두 실제 파일 모양을 각각 안전하게 인식하고, 어느 쪽에도 맞지
    않으면(형식이 또 다르면) 조용히 잘못 읽는 대신 에러를 낸다.

    수기로 값만 고친 파일도 읽을 수 있도록, 서식/수식이 아니라 셀 값만 본다.
    'A'/'B' 팀 구분 행은 건너뛴다. 잔휴 열이 있으면 '잔휴(이후)' 값도 함께 읽어
    다음 달 이월용으로 돌려준다.
    반환: {"year", "month", "num_days", "grid": {staff_id: [shift_str, ...]},
           "off_balance": {staff_id: float}}  # 잔휴 열이 없으면 빈 dict
    """
    from openpyxl import load_workbook

    wb = load_workbook(path, data_only=True)
    try:
        ws, year, month, num_days, first_day_col = _find_grid_sheet(wb)
        grid, off_balance = _read_grid_rows(ws, 1, first_day_col, num_days, 4,
                                            has_off_balance=first_day_col >= 5)
    except ExcelInputError as our_err:
        grid = {}
        year = month = num_days = None
        for ws in wb.worksheets:
            shape = _try_parse_hospital_ocs_shape(ws)
            if shape is None:
                continue
            year, month, num_days = shape["year"], shape["month"], shape["num_days"]
            grid, off_balance = _read_grid_rows(
                ws, shape["name_col"], shape["first_day_col"], num_days,
                shape["header_row"] + 2, has_off_balance=True)
            if grid:
                break
        if not grid:
            raise our_err

    if not grid:
        raise ExcelInputError("근무표에서 인원 행을 찾지 못했습니다.")

    return {"year": year, "month": month, "num_days": num_days, "grid": grid,
            "off_balance": off_balance}


# ---------------------------------------------------------------- 원티드 신청 읽기 (월간근무표 모양 + 신청 표기)

_WANTED_WORK_CODES = {"D": "D", "E": "E", "N": "N", "8A": "8A", "9A": "9A",
                      "10A": "10A", "NK": "NK", "T": "T", "TW": "TW", "prn": "prn"}
_WANTED_AL_CODES = {"연": "연차", "연차": "연차",
                    "연1": "연1", "연2": "연2", "연3": "연3", "연4": "연4"}
# 세부 사유가 명확한 휴가류는 각자의 코드로, 그 외(포상휴가 등 미분류 특수코드)는
# 뭉뚱그려 OFF 희망으로 해석한다.
_WANTED_LEAVE_CODES = {
    "조": "조", "경": "경", "공": "공", "병": "병", "휴": "휴", "승": "승",
    "군": "군", "S/": "S/",
}
_WANTED_OFF_CODES = {"X", "OFF", "포"}


def load_wanted_grid_xlsx(path: str) -> dict:
    """월간근무표와 같은 모양(이름|1일|2일|...) 엑셀에서 원티드 신청만 읽어온다.

    표기 규칙: "D*"/"E*"/"N*"/"8A*"/"9A*"/"10A*"/"NK*"/"T*"/"TW*"/"prn*"(또는 별표 없이도 인식) = 그 근무 희망,
    "조"/"경"/"공"/"병"/"휴"/"승"/"군"/"S/"/"연"/"연차"/"연1"/"연2"/"연3"/"연4" = 각자의
    휴가유형 희망, "X"/그 외 미분류 표기(포상휴가 등)는 OFF 희망으로 해석한다. 빈 칸은 건너뛴다.

    반환: {"year", "month", "requests": [{"staff_id","date","type"}, ...],
           "unknown_marks": [str, ...]}  # 인식 못 한 표시(참고용)
    """
    from openpyxl import load_workbook

    wb = load_workbook(path, data_only=True)
    ws, year, month, num_days, first_day_col = _find_grid_sheet(wb)

    requests: List[dict] = []
    unknown = set()
    row = 4
    while True:
        name = ws.cell(row, 1).value
        if name is None or str(name).strip() == "":
            break
        if _is_team_divider_row(ws, row, 1, first_day_col, num_days):
            row += 1
            continue
        sid = str(name).strip()
        for d in range(num_days):
            v = ws.cell(row, first_day_col + d).value
            if v in (None, ""):
                continue
            v = str(v).strip()
            base = v[:-1] if v.endswith("*") else v
            if base in _WANTED_WORK_CODES:
                t = _WANTED_WORK_CODES[base]
            elif base in _WANTED_AL_CODES:
                t = _WANTED_AL_CODES[base]
            elif base in _WANTED_LEAVE_CODES:
                t = _WANTED_LEAVE_CODES[base]
            elif base in _WANTED_OFF_CODES:
                t = "OFF"
            else:
                unknown.add(v)
                continue
            requests.append({"staff_id": sid, "date": f"{year}-{month:02d}-{d + 1:02d}",
                             "type": t})
        row += 1

    if not requests and not unknown:
        raise ExcelInputError("표에서 원티드 표시를 하나도 찾지 못했습니다.")

    return {"year": year, "month": month, "requests": requests,
           "unknown_marks": sorted(unknown)}


# ---------------------------------------------------------------- 연간근무표 읽기 (다월 자동 연동용)

def load_staff_table_xlsx(path: str) -> dict:
    """'연간근무표' 파일 읽기 — 로스터 + 누적 통계(형평성 참고용) + 연간 근무 그리드(1/1~, 참고용).

    시트명은 "연간근무표"를 우선 찾고, 예전에 내보낸 파일(구 명칭 "인원표")도
    그대로 읽을 수 있도록 하위호환으로 받아준다.

    반환: {
      "staff": [{"id","role","level","allowed_shifts","flags"}, ...],
      "stats": {staff_id: {"recent_night_score","night","off","weekend_night",
                            "blocks_2","blocks_3","months"}},
      "annual_dates": ["YYYY-MM-DD", ...],   # 이미 쌓여있던 연간 그리드의 날짜(있으면)
      "annual_grid": {staff_id: [code, ...]},  # annual_dates와 나란히
    }
    """
    from openpyxl import load_workbook

    wb = load_workbook(path, data_only=True)
    sheet_name = "연간근무표" if "연간근무표" in wb.sheetnames else "인원표"
    if sheet_name not in wb.sheetnames:
        raise ExcelInputError("필수 시트 누락: 연간근무표")

    rows = _sheet_rows(wb[sheet_name])
    h = _find_header(rows, "순번")
    if h is None:
        raise ExcelInputError("연간근무표 시트에 '순번' 헤더가 없습니다")
    header_row = rows[h]
    n_static = len(STAFF_TABLE_STATIC_COLS)
    n_stat = len(STAFF_TABLE_STAT_KEYS)
    first_day_idx = n_static + n_stat  # 0-based

    annual_dates: List[str] = []
    i = first_day_idx
    while i < len(header_row) and hasattr(header_row[i], "strftime"):
        annual_dates.append(header_row[i].strftime("%Y-%m-%d"))
        i += 1

    def _num(r, i) -> float:
        v = r[i] if i < len(r) else None
        try:
            return float(v) if v not in (None, "") else 0.0
        except (TypeError, ValueError):
            return 0.0

    errors = _ErrorCollector()
    staff, stats, annual_grid = [], {}, {}
    for r in rows[h + 1:]:
        if not r or r[1] is None or not str(r[1]).strip():
            continue
        name = str(r[1]).strip()
        role = str(r[2] or "간호사").strip()
        level = _parse_level(r[3], context=f"연간근무표 시트({name})", errors=errors)
        allowed = _split_list(r[4])
        note = str(r[5] or "") if len(r) > 5 else ""
        allowed = [a for a in allowed
                  if _check_shift_code(a, context=f"연간근무표 시트({name}) 가능근무",
                                       errors=errors)]
        staff.append({"id": name, "role": role, "level": level,
                       "allowed_shifts": allowed, "flags": _parse_flags(note)})

        stats[name] = {
            "night": int(_num(r, n_static + 0)),
            "workday": int(_num(r, n_static + 1)),
            "off": int(_num(r, n_static + 2)),
            "weekend_night": int(_num(r, n_static + 3)),
            "blocks_2": int(_num(r, n_static + 4)),
            "blocks_3": int(_num(r, n_static + 5)),
            "months": int(_num(r, n_static + 6)),
            "recent_night_score": round(_num(r, n_static + 7), 2),
            "cum_d": int(_num(r, n_static + 8)),
            "cum_e": int(_num(r, n_static + 9)),
            "cum_prn": int(_num(r, n_static + 10)),
            "cum_weekend_holiday_off": int(_num(r, n_static + 11)),
            "off_balance": round(_num(r, n_static + 12), 2),
        }

        if annual_dates:
            codes = []
            for d in range(len(annual_dates)):
                idx = first_day_idx + d
                v = r[idx] if idx < len(r) else None
                codes.append(str(v).strip() if v not in (None, "") else "")
            annual_grid[name] = codes

    if not staff:
        raise ExcelInputError("연간근무표 시트가 비어 있습니다")
    errors.raise_if_any()

    return {"staff": staff, "stats": stats,
            "annual_dates": annual_dates, "annual_grid": annual_grid}


# ---------------------------------------------------------------- 쓰기

def write_input_xlsx(cfg: dict, path: str):
    """설정 dict → 입력 엑셀 (원본 0-2/0-3 표 양식)."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment

    wb = Workbook()
    head = Font(bold=True)
    fill = PatternFill("solid", fgColor="DDEBE7")

    ws = wb.active
    ws.title = "설정"
    p = cfg.get("params", {})
    # 월신청상한·공휴일·대체공휴일은 더 이상 입력엑셀에서 받지 않는다(고정값/자동채움) —
    # "설정" 시트를 병동마다 매번 채워야 하는 항목만 남긴다.
    rows = [("항목", "값"),
            ("병동명", cfg.get("ward_id", "")),
            ("연도", cfg["year"]), ("월", cfg["month"]),
            ("월최대야간", p.get("off_max_per_month", 6)),
            ("연속근무제한", p.get("max_consecutive_work", 5))]
    for r in rows:
        ws.append(list(r))
    for c in ws[1]:
        c.font = head
        c.fill = fill
    ws.column_dimensions["A"].width = 14
    ws.column_dimensions["B"].width = 30

    ws = wb.create_sheet("인원")
    ws.append(["순번", "이름", "직급", "숙련도", "가능근무", "비고"])
    for c in ws[1]:
        c.font = head
        c.fill = fill
    for i, s in enumerate(cfg["staff"], 1):
        flags = s.get("flags", [])
        notes = []
        if "night_only" in flags:
            notes.append("야간전담")
        if "pregnant" in flags:
            notes.append("임부(야간 금지)")
        elif "no_night" in flags:
            notes.append("야간금지")
        if s["role"] == "파트장":
            notes.append("카운트 제외, 상근(평일)")
        ws.append([i, s["id"], s["role"], f"Lv{s['level']}",
                   ",".join(s["allowed_shifts"]), ", ".join(notes)])
    for col, w in (("A", 6), ("B", 12), ("C", 9), ("D", 8), ("E", 18), ("F", 24)):
        ws.column_dimensions[col].width = w

    ws = wb.create_sheet("최소인력")
    ws.append(["근무", "평일", "토요일", "일요일공휴일"])
    for c in ws[1]:
        c.font = head
        c.fill = fill
    m = p.get("min_staff", {})
    for key in ("D", "E", "N", "prn"):
        ws.append([key, m.get("weekday", {}).get(key, 0),
                   m.get("saturday", {}).get(key, 0),
                   m.get("sunday_holiday", {}).get(key, 0)])
    ws.append(["8A", "1(파트장)", 0, 0])

    reqs = cfg.get("requests") or []
    if reqs:
        ws = wb.create_sheet("신청")
        ws.append(["이름", "날짜", "근무유형", "우선순위"])
        for c in ws[1]:
            c.font = head
            c.fill = fill
        for r in reqs:
            ws.append([r["staff_id"], r["date"], r["type"], r.get("priority", 1)])
        ws.column_dimensions["B"].width = 12

    carry = cfg.get("prev_month_carryover") or {}
    if carry:
        ws = wb.create_sheet("전월이월")
        ws.append(["이름", "마지막근무", "연속근무일수", "이월OFF일수", "말일연속야간일수"])
        for c in ws[1]:
            c.font = head
            c.fill = fill
        for sid, v in carry.items():
            ws.append([sid, v.get("last_shift_type", "OFF"),
                       v.get("consecutive_work_days", 0),
                       v.get("night_block_remaining_off", 0),
                       v.get("trailing_night_count", 0)])
        for col in ("A", "B", "C", "D", "E"):
            ws.column_dimensions[col].width = 14

    team_b_names = p.get("team_b_names") or []
    if team_b_names:
        ws = wb.create_sheet("B팀")
        ws.append(["이름"])
        for c in ws[1]:
            c.font = head
            c.fill = fill
        for name in team_b_names:
            ws.append([name])
        ws.column_dimensions["A"].width = 14

    wb.save(path)

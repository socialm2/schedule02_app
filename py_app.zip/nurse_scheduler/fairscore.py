# -*- coding: utf-8 -*-
"""공정성 점수(0~100)와 사람별 '내 달 요약' — 보여 주는 층이다. 시도 고르기(generator.attempt_key)는
fairness.py의 합을 그대로 쓰고, 여기는 그 구성값을 사람이 읽을 숫자로 바꾸기만 한다.

왜 따로 두나. fairness.py의 합(2×횟수+주말+조구성+단독+미반영)은 '사람·일'의 절대 합이라 40명 병동의
12와 20명 병동의 8을 견줄 수 없고, "이 달은 좋은 달인가"에 답하지 못한다. 그래서
  1) 축마다 '사람당(조당) 편차'로 바꾸고,
  2) 그 값이 기준선 201개 달(docs/report_v0.86/bench/fairness_equal_new_261022.json, 20~100명 ×
     유형 × 달)의 분포 어디에 놓이는지(백분위)를 점수로 삼는다 — 100은 기준선 어느 달보다 고름,
     0은 어느 달보다 쏠림, 50은 기준선의 중간쯤.
좋은 달의 기준을 사람이 정하지 않아도 되고, 병동 크기·달 길이 차이가 자동으로 흡수된다.
기준선 표는 tools/fairscore_baseline.py가 만들고 tests가 벤치 파일과 대조한다.

원티드 축은 백분위가 아니라 반영률 그대로다(신청 n건 중 m건은 그 자체가 0~100).

세 낱말을 가른다 — 균등성: 같은 조건이면 똑같이(집단 안 편차). 형평성: 휴가·전입·야간불가 같은 사정을
반영한 목표 대비(가능일 비례 목표, 집단 나누기 — fairness.py가 이미 그렇게 한다). 절차 공정성: 원티드가
누구에게나 같은 기준으로 처리되고 설명되는지(반영률, 미반영 사유).

사람별 '내 달 요약'은 당사자에게 보낼 한 줄이다 — 주말·야간·D/E가 같은 조건 집단의 평균(목표)과 얼마나
다른지, 피로 점수(낮→밤 직결·짧은 회복·연속 주말), 원티드 반영/미반영과 사유. 가중치는 시작값이고
파트장이 바꾸기 전까지의 약속이다(2026-11-09)."""
from __future__ import annotations

from typing import Dict, List, Optional

from .calendar_utils import DAY_WEEKDAY
from .equalize import cohorts
from .fairness import (available_days, count_cohort_key, components, general_staff,
                       sole_senior_deviation)
from .models import MonthSchedule, Shift, WORK_SHIFTS

#: 기준선 분포 — 축별 '단위당 편차'의 0·5·…·100 백분위 값(오름차순). tools/fairscore_baseline.py 출력.
BASELINE_N = 201
BASELINE = {
    'count': [1.0395, 1.3375, 1.4349, 1.5313, 1.6215, 1.6902, 1.7335, 1.7811, 1.8068, 1.8377, 1.8718, 1.9044, 1.9422, 1.9811, 2.0161, 2.1079, 2.1727, 2.2364, 2.3692, 2.6969, 3.43],
    'weekend': [0.4911, 0.7423, 0.8384, 0.8862, 0.9328, 0.9605, 0.9916, 1.0256, 1.0432, 1.0669, 1.0864, 1.1095, 1.1195, 1.1318, 1.1482, 1.1685, 1.1949, 1.2277, 1.2735, 1.3024, 1.6479],
    'night': [0.1538, 0.3131, 0.3333, 0.3684, 0.3846, 0.3898, 0.4211, 0.4737, 0.5263, 0.5354, 0.557, 0.5758, 0.5823, 0.5823, 0.6667, 0.6835, 0.6949, 0.6962, 0.7458, 0.8475, 0.8475],
    'mix': [0.6926, 0.7804, 0.8242, 0.8908, 1.041, 1.1473, 1.2162, 1.2391, 1.3043, 1.3589, 1.449, 1.521, 1.5459, 1.6185, 1.7029, 1.7809, 1.8257, 1.8958, 1.9494, 2.032, 2.2251],
}

#: 축: (키, 이름, 가중치, 단위 설명). 가중치는 fairness.py의 '횟수 2배'를 그대로 따른다(사용자 결정).
AXES = (
    ("count", "근무횟수 균등", 2, "사람당 D·E·N이 목표에서 벗어난 날수"),
    ("weekend", "주말 균등", 1, "사람당 주말 근무가 집단 평균에서 벗어난 날수"),
    ("night", "야간 균등", 1, "사람당 야간이 개인 목표에서 벗어난 횟수"),
    ("wanted", "원티드 반영", 1, "신청 중 반영된 비율"),
    ("mix", "숙련 분산", 1, "조당 레벨 띠 구성이 병동 비율에서 벗어난 사람 수"),
)

#: 피로 점수 가중치 — 시작값. 낮→밤 직결(D·E 다음날 바로 N)은 수면 기회를 반나절 잃고, 짧은 회복(밤 묶음 뒤
#: 쉬는 날 하루만 두고 D·E)은 생체리듬이 돌아오기 전에 출근하는 것이라 더 무겁다. 연속 주말은 사회적 피로.
FATIGUE_W = {"quick_to_night": 2, "short_recovery": 3, "consecutive_weekends": 1}

GRADES = ((75, "good", "좋음"), (40, "mid", "보통"), (0, "low", "살펴볼 것"))

_NIGHT = (Shift.N, Shift.NK)
_DAYEVE = (Shift.D, Shift.E)


def percentile_score(key: str, per_unit: float) -> float:
    """단위당 편차가 기준선 분포에서 얼마나 좋은 쪽인지, 0~100(높을수록 고름)."""
    q = BASELINE[key]
    if per_unit <= q[0]:
        return 100.0
    if per_unit >= q[-1]:
        return 0.0
    step = 100.0 / (len(q) - 1)
    for i in range(len(q) - 1):
        lo, hi = q[i], q[i + 1]
        if lo <= per_unit <= hi:
            frac = (per_unit - lo) / (hi - lo) if hi > lo else 0.0
            return round(100.0 - (i + frac) * step, 1)
    return 0.0


def grade_of(score: Optional[float]) -> dict:
    if score is None:
        return {"key": "none", "label": "견줄 수 없음"}
    for floor, key, label in GRADES:
        if score >= floor:
            return {"key": key, "label": label}
    return {"key": "low", "label": "살펴볼 것"}


def _weekend_groups(days) -> List[List[int]]:
    """주말·공휴일이 이어진 덩이(토·일, 연휴)의 날짜 인덱스 묶음."""
    groups: List[List[int]] = []
    for d, di in enumerate(days):
        if di.day_type == DAY_WEEKDAY:
            continue
        if groups and groups[-1][-1] == d - 1:
            groups[-1].append(d)
        else:
            groups.append([d])
    return groups


def fatigue(sch: MonthSchedule, sid: str, days) -> dict:
    """한 사람의 피로 요소 — 밤 묶음 수, 낮→밤 직결, 짧은 회복, 연속 주말(이어진 주말 덩이를 둘 다 일한 쌍)."""
    nd = sch.num_days
    eff = [sch.effective(sid, d) for d in range(nd)]
    prev = sch.effective(sid, -1)
    blocks = quick = short = 0
    for d in range(nd):
        cur, before = eff[d], (eff[d - 1] if d > 0 else prev)
        if cur in _NIGHT and before not in _NIGHT:
            blocks += 1
            if before in _DAYEVE:
                quick += 1
        # 밤 묶음이 d-2에서 끝나고 d-1 하루만 쉬고 d에 D·E
        if cur in _DAYEVE and d >= 1:
            rest = eff[d - 1] if d >= 1 else prev
            two_back = eff[d - 2] if d >= 2 else prev
            if rest not in WORK_SHIFTS and two_back in _NIGHT:
                short += 1
    groups = _weekend_groups(days)
    worked = [any(eff[d] in WORK_SHIFTS for d in g) for g in groups]
    consec = sum(1 for a, b in zip(worked, worked[1:]) if a and b)
    score = (FATIGUE_W["quick_to_night"] * quick + FATIGUE_W["short_recovery"] * short
             + FATIGUE_W["consecutive_weekends"] * consec)
    return {"night_blocks": blocks, "quick_to_night": quick, "short_recovery": short,
            "consecutive_weekends": consec, "weekends_worked": sum(worked), "weekends": len(groups),
            "score": score}


def axis_scores(gen, sch: MonthSchedule) -> dict:
    """축 다섯의 점수와 종합. comp는 fairness.components(같은 정의)의 결과를 다시 쓴다."""
    staff = gen.staff
    comp = components(gen, sch)
    gen_staff = general_staff(staff)
    nd = sch.num_days
    # 단위당 값의 분모는 기준선과 같은 근사(파트장을 뺀 인원)로 맞춘다 — 기준선 파일에는 집단 구성이
    # 없어 size−1로 나눴다. 여기서 집단 인원으로 나누면 같은 표가 기준선보다 나쁘게 읽힌다.
    n_norm = sum(1 for s in staff if not s.is_partjang) or 1

    # 횟수: 2명 이상인 횟수 집단에 든 사람 수로 나눈다
    groups: Dict[tuple, int] = {}
    for s in gen_staff:
        groups[count_cohort_key(sch, s)] = groups.get(count_cohort_key(sch, s), 0) + 1
    n_count = sum(n for n in groups.values() if n >= 2)
    # 주말: 주말 집단(equalize.cohorts, 2명 이상)에 든 사람 수
    wk_groups = cohorts(sch)
    n_wk = sum(len(g) for g in wk_groups)
    wk_vals = [sch.weekend_workdays_in_month(s.id) for s in gen_staff]
    wk_out = 0
    for g in wk_groups:
        m = sum(sch.weekend_workdays_in_month(s.id) for s in g) / len(g)
        wk_out += sum(1 for s in g if abs(sch.weekend_workdays_in_month(s.id) - m) >= 2)
    # 야간: 개인 목표가 있는 사람 수
    tgt = [(s, sch.night_target.get(s.id)) for s in gen_staff]
    tgt = [(s, t) for s, t in tgt if t is not None]
    n_night = len(tgt)
    night_off = [(s.id, sch.nights_in_month(s.id), t) for s, t in tgt if sch.nights_in_month(s.id) != t]
    # 숙련: 날짜×조(D·E·N) 수
    n_mix = 3 * nd
    sole_dev, sole_per = sole_senior_deviation(sch, staff)
    # 원티드
    total = len(gen.requests)
    accepted = sum(1 for q in gen.requests if q.accepted)

    def axis(key, per_unit, n_units, detail):
        name, w, unit = next((a[1], a[2], a[3]) for a in AXES if a[0] == key)
        score = percentile_score(key, per_unit) if n_units else None
        return {"key": key, "name": name, "weight": w, "unit": unit, "per_unit": round(per_unit, 3),
                "n_units": n_units, "score": score, "grade": grade_of(score), **detail}

    axes = [
        axis("count", comp["count"] / n_norm, n_count, {
            "raw": comp["count"], "gap": {"D": comp["gap_D"], "E": comp["gap_E"], "N": comp["gap_N"]},
            "text": (f"D·E·N 횟수의 집단 안 최대−최소: D {comp['gap_D']} · E {comp['gap_E']} · N {comp['gap_N']}"
                     if n_count else "같은 조건인 사람이 둘 이상인 집단이 없어 견줄 수 없습니다")}),
        axis("weekend", comp["weekend"] / n_norm, n_wk, {
            "raw": comp["weekend"], "mean": round(sum(wk_vals) / len(wk_vals), 1) if wk_vals else 0,
            "max": max(wk_vals) if wk_vals else 0, "min": min(wk_vals) if wk_vals else 0, "outliers": wk_out,
            "text": (f"주말 근무 평균 {sum(wk_vals) / len(wk_vals):.1f}일, 최대 {max(wk_vals)} 최소 {min(wk_vals)}, "
                     f"집단 평균에서 2일 넘게 벗어난 사람 {wk_out}명" if n_wk else "견줄 집단이 없습니다")}),
        axis("night", comp["night"] / n_norm, n_night, {
            "raw": comp["night"], "off_target": len(night_off),
            "max_diff": max((abs(n - t) for _, n, t in night_off), default=0),
            "text": (f"야간 목표(4·6)와 다른 사람 {len(night_off)}명" + (
                f", 가장 큰 차이 {max(abs(n - t) for _, n, t in night_off)}회" if night_off else "")
                if n_night else "야간 목표가 있는 사람이 없습니다")}),
    ]
    w_score = round(100.0 * accepted / total, 1) if total else 100.0
    axes.append({"key": "wanted", "name": "원티드 반영", "weight": 1, "unit": "신청 중 반영된 비율",
                 "per_unit": round(1 - accepted / total, 3) if total else 0.0, "n_units": total,
                 "score": w_score, "grade": grade_of(w_score), "total": total, "accepted": accepted,
                 "rejected": total - accepted,
                 "text": f"신청 {total}건 중 {accepted}건 반영" + (f", 반려 {total - accepted}건" if total - accepted else "")
                 if total else "원티드 신청이 없습니다(반영률은 100으로 둡니다)"})
    axes.append(axis("mix", comp["mix"] / n_mix, n_mix, {
        "raw": comp["mix"], "sole": sole_dev,
        "sole_max": max(sole_per.values()) if sole_per else 0,
        "text": f"조마다 레벨 띠(Lv1-2·3·4-5)가 병동 비율에서 벗어난 사람 평균 {comp['mix'] / n_mix:.2f}명"
                + (f" · 혼자 Lv4+인 조에 선 횟수 편차 {sole_dev}" if sole_per else "")}))

    scored = [a for a in axes if a["score"] is not None]
    wsum = sum(a["weight"] for a in scored)
    total_score = round(sum(a["score"] * a["weight"] for a in scored) / wsum, 1) if wsum else None
    return {"total": total_score, "grade": grade_of(total_score), "axes": axes,
            "fairness_sum": comp["fairness"], "baseline_n": BASELINE_N,
            "weights_note": "종합 = 가중 평균(근무횟수 2 · 주말 1 · 야간 1 · 원티드 1 · 숙련 1). "
                            f"점수는 기준선 {BASELINE_N}개 달 중 이 달보다 쏠린 달의 비율 — 100이면 어느 달보다 고름, "
                            "50이면 기준선의 중간. 원티드만 반영률 그대로."}


def person_summaries(gen, sch: MonthSchedule, days) -> List[dict]:
    """사람별 '내 달 요약'. 파트장은 뺀다(근무를 서지 않는다)."""
    staff = [s for s in gen.staff if not s.is_partjang]
    gen_staff = general_staff(gen.staff)
    # 주말 집단 평균
    wk_mean: Dict[str, Optional[float]] = {}
    for g in cohorts(sch):
        m = sum(sch.weekend_workdays_in_month(s.id) for s in g) / len(g)
        for s in g:
            wk_mean[s.id] = m
    all_mean = (sum(sch.weekend_workdays_in_month(s.id) for s in gen_staff) / len(gen_staff)) if gen_staff else 0.0
    # D·E 목표(가능일 비례, 횟수 집단 안)
    de_target: Dict[str, Dict[str, float]] = {}
    groups: Dict[tuple, list] = {}
    for s in gen_staff:
        groups.setdefault(count_cohort_key(sch, s), []).append(s)
    for g in groups.values():
        if len(g) < 2:
            continue
        avail = {s.id: available_days(sch, s.id) for s in g}
        tot_avail = sum(avail.values()) or 1
        for key, codes in (("D", (Shift.D,)), ("E", (Shift.E,))):
            total = sum(1 for s in g for v in sch.grid[s.id] if v in codes)
            for s in g:
                de_target.setdefault(s.id, {})[key] = total * avail[s.id] / tot_avail
    req_by: Dict[str, list] = {}
    for q in gen.requests:
        req_by.setdefault(q.staff_id, []).append(q)
    out = []
    for s in staff:
        row = sch.grid[s.id]
        wk = sch.weekend_workdays_in_month(s.id)
        nights = sch.nights_in_month(s.id)
        tgt = gen.nk_target if s.is_nk else sch.night_target.get(s.id)
        d_cnt = sum(1 for v in row if v == Shift.D)
        e_cnt = sum(1 for v in row if v == Shift.E)
        ft = fatigue(sch, s.id, days)
        reqs = req_by.get(s.id, [])
        rejected = [{"date": q.date, "type": str(q.type), "reason": q.reject_reason} for q in reqs if q.accepted is False]
        m = wk_mean.get(s.id)
        parts = []
        if s.is_nk:
            parts.append(f"주말 {wk}일(야간전담)")
        elif m is not None:
            parts.append(f"주말 {wk}일(같은 조건 평균 {m:.1f} · {wk - m:+.1f})")
        else:
            parts.append(f"주말 {wk}일(전체 평균 {all_mean:.1f} · 견줄 같은 조건 없음)")
        parts.append(f"야간 {nights}/{tgt}" if tgt is not None else f"야간 {nights}회")
        de = de_target.get(s.id)
        if de and not s.is_nk:
            dd = d_cnt - de.get("D", d_cnt)
            ee = e_cnt - de.get("E", e_cnt)
            tilt = f"D {dd:+.1f} E {ee:+.1f}" if max(abs(dd), abs(ee)) >= 1.5 else "쏠림 없음"
            parts.append(f"D {d_cnt} E {e_cnt} ({tilt})")
        else:
            parts.append(f"D {d_cnt} E {e_cnt}")
        parts.append(f"피로 {ft['score']}점(낮→밤 직결 {ft['quick_to_night']} · 짧은 회복 {ft['short_recovery']} · 연속 주말 {ft['consecutive_weekends']})")
        if reqs:
            acc = sum(1 for q in reqs if q.accepted)
            parts.append(f"원티드 {len(reqs)}건 중 {acc}건 반영" + (
                " — 미반영: " + "; ".join(f"{r['date'][-5:]} {r['type']} ({r['reason']})" for r in rejected) if rejected else ""))
        else:
            parts.append("원티드 없음")
        out.append({"id": s.id, "is_nk": s.is_nk, "weekend": wk,
                    "weekend_mean": round(m, 2) if m is not None else None,
                    "weekend_delta": round(wk - m, 2) if m is not None else None,
                    "nights": nights, "night_target": tgt,
                    "d": d_cnt, "e": e_cnt,
                    "d_target": round(de["D"], 2) if de else None, "e_target": round(de["E"], 2) if de else None,
                    "fatigue": ft,
                    "wanted": {"total": len(reqs), "accepted": sum(1 for q in reqs if q.accepted), "rejected": rejected},
                    "line": " · ".join(parts)})
    return out


def summary(gen, sch: MonthSchedule, days) -> dict:
    return {**axis_scores(gen, sch), "persons": person_summaries(gen, sch, days)}

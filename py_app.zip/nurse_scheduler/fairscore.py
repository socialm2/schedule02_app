# -*- coding: utf-8 -*-
"""공정성 점수(0~100)와 사람별 '내 달 요약' — 보여 주는 층이다. 시도 고르기(generator.attempt_key)는
fairness.py의 합을 그대로 쓰고, 여기는 그 구성값을 사람이 읽을 숫자로 바꾸기만 한다.

왜 따로 두나. fairness.py의 합(2×횟수+주말+조구성+단독+미반영)은 '사람·일'의 절대 합이라 40명 병동의
12와 20명 병동의 8을 견줄 수 없고, "이 달은 좋은 달인가"에 답하지 못한다. 그래서
  1) 축마다 '사람당(조당) 편차'로 바꾸고,
  2) 그 값이 기준선 201개 달(docs/report_v0.86/bench/fairness_equal_new_261022.json, 20~100명 ×
     유형 × 달)의 분포 어디에 놓이는지(백분위)를 점수로 삼는다 — 100은 기준선 어느 달보다 고름,
     0은 어느 달보다 쏠림, 50은 기준선의 중간쯤.
좋은 달의 기준을 사람이 정하지 않아도 되고, 병동 크기·달 길이 차이가 자동으로 흡수된다.
기준선 표는 tools/fairscore_baseline.py가 만들고 tests가 벤치 파일과 대조한다.

원티드 축은 백분위가 아니라 반영률 그대로다(신청 n건 중 m건은 그 자체가 0~100).

세 낱말을 가른다 — 균등성: 같은 조건이면 똑같이(집단 안 편차). 형평성: 휴가·전입·야간불가 같은 사정을
반영한 목표 대비(가능일 비례 목표, 집단 나누기 — fairness.py가 이미 그렇게 한다). 절차 공정성: 원티드가
누구에게나 같은 기준으로 처리되고 설명되는지(반영률, 미반영 사유).

사람별 '내 달 요약'은 당사자에게 보낼 한 줄이다 — 주말·야간·D/E가 같은 조건 집단의 평균(목표)과 얼마나
다른지, 피로 점수(낮→밤 직결·짧은 회복·연속 주말), 원티드 반영/미반영과 사유. 가중치는 시작값이고
파트장이 바꾸기 전까지의 약속이다(2026-11-09)."""
from __future__ import annotations

from typing import Dict, List, Optional

from .calendar_utils import DAY_WEEKDAY, kr_holidays_for_month
from .equalize import cohorts
from .fairness import (available_days, count_cohort_key, components, general_staff,
                       sole_senior_deviation)
from .models import LEAVE_SHIFTS, MonthSchedule, Shift, WORK_SHIFTS, parse_shift

#: 기준선 분포 — 축별 '단위당 편차'의 0·5·…·100 백분위 값(오름차순). tools/fairscore_baseline.py 출력.
#: 기준선은 2026-10-22 엔진이 만든 표다. 그 뒤 엔진이 좋아질수록 같은 입력의 점수가 저절로 오른다(기준선
#: 인플레이션) — 그래서 날짜를 박아 화면에 보이고, 버전마다(매달이 아니라) 다시 만든다. 매달 다시 만들면 점수가
#: 늘 50 근처로 돌아가 추세를 못 본다.
BASELINE_DATE = "2026-10-22"
BASELINE_N = 201
BASELINE = {
    'count': [1.0395, 1.3375, 1.4349, 1.5313, 1.6215, 1.6902, 1.7335, 1.7811, 1.8068, 1.8377, 1.8718, 1.9044, 1.9422, 1.9811, 2.0161, 2.1079, 2.1727, 2.2364, 2.3692, 2.6969, 3.43],
    'weekend': [0.4911, 0.7423, 0.8384, 0.8862, 0.9328, 0.9605, 0.9916, 1.0256, 1.0432, 1.0669, 1.0864, 1.1095, 1.1195, 1.1318, 1.1482, 1.1685, 1.1949, 1.2277, 1.2735, 1.3024, 1.6479],
    'night': [0.1538, 0.3131, 0.3333, 0.3684, 0.3846, 0.3898, 0.4211, 0.4737, 0.5263, 0.5354, 0.557, 0.5758, 0.5823, 0.5823, 0.6667, 0.6835, 0.6949, 0.6962, 0.7458, 0.8475, 0.8475],
    'mix': [0.6926, 0.7804, 0.8242, 0.8908, 1.041, 1.1473, 1.2162, 1.2391, 1.3043, 1.3589, 1.449, 1.521, 1.5459, 1.6185, 1.7029, 1.7809, 1.8257, 1.8958, 1.9494, 2.032, 2.2251],
}

#: 축: (키, 이름, 가중치, 단위 설명). 가중치는 fairness.py의 '횟수 2배'를 그대로 따른다(사용자 결정).
AXES = (
    ("count", "근무횟수 균등", 2, "사람당 D·E·N이 목표에서 벗어난 날수"),
    ("weekend", "주말 균등", 1, "사람당 주말 근무가 집단 평균에서 벗어난 날수"),
    ("night", "야간 균등", 1, "사람당 야간이 개인 목표에서 벗어난 횟수"),
    ("wanted", "원티드 반영", 1, "신청 중 반영된 비율"),
    ("mix", "숙련 분산", 1, "조당 레벨 띠 구성이 병동 비율에서 벗어난 사람 수"),
)

#: 피로 점수 가중치 — 시작값. 낮→밤 직결(D·E 다음날 바로 N)은 수면 기회를 반나절 잃고, 짧은 회복(밤 묶음 뒤
#: 쉬는 날 하루만 두고 D·E)은 생체리듬이 돌아오기 전에 출근하는 것이라 더 무겁다. 연속 주말은 사회적 피로.
FATIGUE_W = {"quick_to_night": 2, "short_recovery": 3, "consecutive_weekends": 1}

GRADES = ((75, "good", "좋음"), (40, "mid", "보통"), (0, "low", "살펴볼 것"))

#: 가중치 조정 범위 — 0은 '이 축은 안 본다', 5가 상한. 더 크면 한 축이 종합을 삼킨다.
WEIGHT_MAX = 5.0
DEFAULT_AXIS_WEIGHTS = {a[0]: float(a[2]) for a in AXES}

#: 누적 형평성에서 '쏠렸다'고 올리는 문턱 — 주말은 3일, 야간은 2회(한 달 문턱 2일·0회보다 느슨하게,
#: 여러 달 합이라 자연 편차가 커진다).
CUM_WEEKEND_GAP = 3
CUM_NIGHT_GAP = 2


def clean_weights(raw, defaults: Dict[str, float]) -> Dict[str, float]:
    """파트장이 보낸 가중치를 0~WEIGHT_MAX 숫자로 고른다. 모르는 키·숫자 아님·범위 밖은 기본값.
    조용히 틀리지 않게 — 화면은 돌려받은 값을 그대로 보여 주므로 잘려도 눈에 띈다."""
    out = dict(defaults)
    if not isinstance(raw, dict):
        return out
    for k in defaults:
        v = raw.get(k)
        if isinstance(v, bool) or not isinstance(v, (int, float)):
            continue
        out[k] = float(max(0.0, min(WEIGHT_MAX, v)))
    return out

_NIGHT = (Shift.N, Shift.NK)
_DAYEVE = (Shift.D, Shift.E)


#: 반려 종류 — 규칙 번호로 가른다. '자리 경쟁'(정원·최소인력에 밀림)만 유효 미반영이라 장기 우선권 후보다.
#: 안전·자격(야간불가·E→D·단독 야간·가능근무 아님·고정 칸 충돌)은 신청 자체가 설 수 없던 것이고, 형식(이 달 날짜
#: 아님·명단에 없는 이름)은 입력 오류다. 반려 비율 차이만으로 차별을 말할 수 없다는 GPT 검토 §04-6의 구분.
REJECT_KINDS = (("compete", "자리 경쟁"), ("safety", "안전·자격"), ("format", "형식"))


def reject_kind(rule: str, reason: str = "") -> str:
    r = (rule or "").strip()
    if "고정된 칸" in (reason or ""):
        return "safety"
    if r in ("S13", "H1-1"):
        return "compete"
    if r.startswith(("H2-", "H3-", "H5-", "H6-", "H7-")) or r == "H1-3":
        return "safety"
    return "format"


def percentile_score(key: str, per_unit: float) -> float:
    """단위당 편차가 기준선 분포에서 얼마나 좋은 쪽인지, 0~100(높을수록 고름)."""
    q = BASELINE[key]
    if per_unit <= q[0]:
        return 100.0
    if per_unit >= q[-1]:
        return 0.0
    step = 100.0 / (len(q) - 1)
    for i in range(len(q) - 1):
        lo, hi = q[i], q[i + 1]
        if lo <= per_unit <= hi:
            frac = (per_unit - lo) / (hi - lo) if hi > lo else 0.0
            return round(100.0 - (i + frac) * step, 1)
    return 0.0


def score_from_components(comp: dict, n_norm: int, num_days: int, n_requests: int,
                          weights: Optional[Dict[str, float]] = None) -> dict:
    """fairness.components 결과(또는 점수표 한 줄)에서 축별 점수와 종합을 센다 — 화면 '공정성 점수'와 점수표의
    '표시점수' 열이 같은 함수를 써야 "같은 표인데 숫자가 다르다"가 안 생긴다. 축을 견줄 수 없을 때(n_units=0)의
    처리는 axis_scores가 하고, 여기는 산식만이다."""
    weights = clean_weights(weights, DEFAULT_AXIS_WEIGHTS)
    n_norm = max(1, n_norm)
    total_req = int(n_requests or 0)
    rejected = int(comp.get("wanted", 0) or 0)
    sc = {
        "count": percentile_score("count", comp.get("count", 0.0) / n_norm),
        "weekend": percentile_score("weekend", comp.get("weekend", 0.0) / n_norm),
        "night": percentile_score("night", comp.get("night", 0) / n_norm),
        "wanted": round(100.0 * (total_req - rejected) / total_req, 1) if total_req else 100.0,
        "mix": percentile_score("mix", comp.get("mix", 0.0) / (3 * max(1, num_days))),
    }
    scored = [k for k in sc if weights[k] > 0]
    wsum = sum(weights[k] for k in scored)
    total = round(sum(sc[k] * weights[k] for k in scored) / wsum, 1) if wsum else None
    return {"axes": sc, "total": total}


def grade_of(score: Optional[float]) -> dict:
    if score is None:
        return {"key": "none", "label": "견줄 수 없음"}
    for floor, key, label in GRADES:
        if score >= floor:
            return {"key": key, "label": label}
    return {"key": "low", "label": "살펴볼 것"}


def _weekend_groups(days) -> List[List[int]]:
    """주말·공휴일이 이어진 덩이(토·일, 연휴)의 날짜 인덱스 묶음."""
    groups: List[List[int]] = []
    for d, di in enumerate(days):
        if di.day_type == DAY_WEEKDAY:
            continue
        if groups and groups[-1][-1] == d - 1:
            groups[-1].append(d)
        else:
            groups.append([d])
    return groups


def fatigue(sch: MonthSchedule, sid: str, days, w: Optional[Dict[str, float]] = None) -> dict:
    """한 사람의 피로 요소 — 밤 묶음 수, 낮→밤 직결, 짧은 회복, 연속 주말(이어진 주말 덩이를 둘 다 일한 쌍)."""
    w = w or FATIGUE_W
    nd = sch.num_days
    eff = [sch.effective(sid, d) for d in range(nd)]
    prev = sch.effective(sid, -1)
    blocks = quick = short = 0
    for d in range(nd):
        cur, before = eff[d], (eff[d - 1] if d > 0 else prev)
        if cur in _NIGHT and before not in _NIGHT:
            blocks += 1
            if before in _DAYEVE:
                quick += 1
        # 밤 묶음이 d-2에서 끝나고 d-1 하루만 쉬고 d에 D·E
        if cur in _DAYEVE and d >= 1:
            rest = eff[d - 1] if d >= 1 else prev
            two_back = eff[d - 2] if d >= 2 else prev
            if rest not in WORK_SHIFTS and two_back in _NIGHT:
                short += 1
    groups = _weekend_groups(days)
    worked = [any(eff[d] in WORK_SHIFTS for d in g) for g in groups]
    consec = sum(1 for a, b in zip(worked, worked[1:]) if a and b)
    score = round(w["quick_to_night"] * quick + w["short_recovery"] * short
                  + w["consecutive_weekends"] * consec, 1)
    if score == int(score):
        score = int(score)
    return {"night_blocks": blocks, "quick_to_night": quick, "short_recovery": short,
            "consecutive_weekends": consec, "weekends_worked": sum(worked), "weekends": len(groups),
            "score": score}


def axis_scores(gen, sch: MonthSchedule, weights: Optional[Dict[str, float]] = None,
                change: Optional[dict] = None) -> dict:
    """축 다섯의 점수와 종합. comp는 fairness.components(같은 정의)의 결과를 다시 쓴다.
    weights: 축 가중치(없으면 AXES의 기본). change: 직전 재생성이 바꾼 칸 수(bridge가 센다)."""
    weights = clean_weights(weights, DEFAULT_AXIS_WEIGHTS)
    staff = gen.staff
    comp = components(gen, sch)
    gen_staff = general_staff(staff)
    nd = sch.num_days
    # 단위당 값의 분모는 기준선과 같은 근사(파트장을 뺀 인원)로 맞춘다 — 기준선 파일에는 집단 구성이
    # 없어 size−1로 나눴다. 여기서 집단 인원으로 나누면 같은 표가 기준선보다 나쁘게 읽힌다.
    n_norm = sum(1 for s in staff if not s.is_partjang) or 1

    # 횟수: 2명 이상인 횟수 집단에 든 사람 수로 나눈다
    groups: Dict[tuple, int] = {}
    for s in gen_staff:
        groups[count_cohort_key(sch, s)] = groups.get(count_cohort_key(sch, s), 0) + 1
    n_count = sum(n for n in groups.values() if n >= 2)
    # 주말: 주말 집단(equalize.cohorts, 2명 이상)에 든 사람 수
    wk_groups = cohorts(sch)
    n_wk = sum(len(g) for g in wk_groups)
    wk_vals = [sch.weekend_workdays_in_month(s.id) for s in gen_staff]
    wk_out = 0
    for g in wk_groups:
        m = sum(sch.weekend_workdays_in_month(s.id) for s in g) / len(g)
        wk_out += sum(1 for s in g if abs(sch.weekend_workdays_in_month(s.id) - m) >= 2)
    # 야간: 개인 목표가 있는 사람 수
    tgt = [(s, sch.night_target.get(s.id)) for s in gen_staff]
    tgt = [(s, t) for s, t in tgt if t is not None]
    n_night = len(tgt)
    night_off = [(s.id, sch.nights_in_month(s.id), t) for s, t in tgt if sch.nights_in_month(s.id) != t]
    # 숙련: 날짜×조(D·E·N) 수
    n_mix = 3 * nd
    sole_dev, sole_per = sole_senior_deviation(sch, staff)
    # 원티드
    total = len(gen.requests)
    accepted = sum(1 for q in gen.requests if q.accepted)

    n_people = len(gen_staff)
    # 빠진 사람 — 점수가 좋다는 말이 "견준 사람끼리만 좋다"로 조용히 바뀌지 않게 축마다 센다
    singles_count = sum(n for n in groups.values() if n < 2)
    wk_in = {s.id for g in wk_groups for s in g}
    singles_wk = sum(1 for s in gen_staff if s.id not in wk_in)
    roles_out = sum(1 for s in staff if not s.is_partjang and s.is_nk)   # 야간전담은 모든 축의 비교에서 역할로 빠진다
    no_target = sum(1 for s in gen_staff if sch.night_target.get(s.id) is None)

    def axis(key, per_unit, n_units, detail):
        name, unit = next((a[1], a[3]) for a in AXES if a[0] == key)
        w = weights[key]
        score = percentile_score(key, per_unit) if n_units else None
        return {"key": key, "name": name, "weight": w, "unit": unit, "per_unit": round(per_unit, 3),
                "n_units": n_units, "score": score, "grade": grade_of(score), **detail}

    axes = [
        axis("count", comp["count"] / n_norm, n_count, {
            "raw": comp["count"], "gap": {"D": comp["gap_D"], "E": comp["gap_E"], "N": comp["gap_N"]},
            "compared": n_count, "excluded": {"single": singles_count, "role": roles_out},
            "raw_text": f"사람당 {comp['count'] / n_norm:.1f}일",
            "text": (f"D·E·N 횟수의 집단 안 최대−최소: D {comp['gap_D']} · E {comp['gap_E']} · N {comp['gap_N']}"
                     if n_count else "같은 조건인 사람이 둘 이상인 집단이 없어 견줄 수 없습니다")}),
        axis("weekend", comp["weekend"] / n_norm, n_wk, {
            "compared": n_wk, "excluded": {"single": singles_wk, "role": roles_out},
            "raw_text": f"사람당 {comp['weekend'] / n_norm:.1f}일",
            "raw": comp["weekend"], "mean": round(sum(wk_vals) / len(wk_vals), 1) if wk_vals else 0,
            "max": max(wk_vals) if wk_vals else 0, "min": min(wk_vals) if wk_vals else 0, "outliers": wk_out,
            "text": (f"주말 근무 평균 {sum(wk_vals) / len(wk_vals):.1f}일, 최대 {max(wk_vals)} 최소 {min(wk_vals)}, "
                     f"집단 평균에서 2일 넘게 벗어난 사람 {wk_out}명" if n_wk else "견줄 집단이 없습니다")}),
        axis("night", comp["night"] / n_norm, n_night, {
            "compared": n_night, "excluded": {"no_target": no_target, "role": roles_out},
            "raw_text": f"사람당 {comp['night'] / n_norm:.2f}회",
            "raw": comp["night"], "off_target": len(night_off),
            "max_diff": max((abs(n - t) for _, n, t in night_off), default=0),
            "text": (f"야간 목표(4·6)와 다른 사람 {len(night_off)}명" + (
                f", 가장 큰 차이 {max(abs(n - t) for _, n, t in night_off)}회" if night_off else "")
                if n_night else "야간 목표가 있는 사람이 없습니다")}),
    ]
    w_score = round(100.0 * accepted / total, 1) if total else 100.0
    # 절차 공정성 — 반려가 특정 사람에게 몰리는가, 반려마다 사유가 붙었는가. 분배가 고르더라도 "늘 내 신청만
    # 거절된다"는 느낌은 여기서 생긴다. 신청 2건 이상인데 반영률이 전체보다 20%p 넘게 낮으면 올린다.
    by_person: Dict[str, Dict[str, int]] = {}
    kinds = {k: 0 for k, _ in REJECT_KINDS}
    for q in gen.requests:
        d = by_person.setdefault(q.staff_id, {"total": 0, "accepted": 0, "unexplained": 0, "compete": 0})
        d["total"] += 1
        if q.accepted:
            d["accepted"] += 1
        elif q.accepted is False:
            k = reject_kind(q.reject_rule, q.reject_reason)
            kinds[k] += 1
            if k == "compete":
                d["compete"] += 1
            if not (q.reject_reason or "").strip():
                d["unexplained"] += 1
    # 반려 쏠림은 '자리 경쟁'으로 밀린 유효 신청만 센다 — 안전·형식 반려는 사람의 몫이 아니라 신청의 문제다
    valid_total = sum(d["total"] for d in by_person.values()) - kinds["safety"] - kinds["format"]
    valid_rate = (accepted / valid_total) if valid_total else 1.0
    concentrated = sorted(
        [{"id": sid, **d, "rate": round(d["accepted"] / (d["accepted"] + d["compete"]), 2)}
         for sid, d in by_person.items()
         if d["accepted"] + d["compete"] >= 2 and d["compete"] >= 1
         and d["accepted"] / (d["accepted"] + d["compete"]) <= valid_rate - 0.2],
        key=lambda x: (x["rate"], x["id"]))
    unexplained = sum(d["unexplained"] for d in by_person.values())
    w_text = (f"신청 {total}건 중 {accepted}건 반영" + (f", 반려 {total - accepted}건" if total - accepted else "")
              if total else "원티드 신청이 없습니다(반영률은 100으로 둡니다)")
    if total - accepted:
        w_text += "(" + " · ".join(f"{name} {kinds[k]}" for k, name in REJECT_KINDS if kinds[k]) + ")"
    if concentrated:
        w_text += " · 자리 경쟁에 밀림이 몰린 사람: " + ", ".join(f"{c['id']}({c['accepted']}/{c['accepted'] + c['compete']})" for c in concentrated[:5])
    if unexplained:
        w_text += f" · 사유 없는 반려 {unexplained}건"
    axes.append({"key": "wanted", "name": "원티드 반영", "weight": weights["wanted"], "unit": "신청 중 반영된 비율",
                 "per_unit": round(1 - accepted / total, 3) if total else 0.0, "n_units": total,
                 "score": w_score, "grade": grade_of(w_score), "total": total, "accepted": accepted,
                 "rejected": total - accepted, "concentrated": concentrated, "unexplained": unexplained,
                 "kinds": kinds, "kind_names": dict(REJECT_KINDS),
                 "by_person": len(by_person), "compared": len(by_person), "excluded": {},
                 "raw_text": f"{accepted}/{total}건" if total else "신청 없음", "text": w_text})
    axes.append(axis("mix", comp["mix"] / n_mix, n_mix, {
        "compared": n_mix, "excluded": {}, "raw_text": f"조당 {comp['mix'] / n_mix:.2f}명",
        "raw": comp["mix"], "sole": sole_dev,
        "sole_max": max(sole_per.values()) if sole_per else 0,
        "text": f"조마다 레벨 띠(Lv1-2·3·4-5)가 병동 비율에서 벗어난 사람 평균 {comp['mix'] / n_mix:.2f}명"
                + (f" · 혼자 Lv4+인 조에 선 횟수 편차 {sole_dev}" if sole_per else "")}))

    scored = [a for a in axes if a["score"] is not None and a["weight"] > 0]
    wsum = sum(a["weight"] for a in scored)
    total_score = round(sum(a["score"] * a["weight"] for a in scored) / wsum, 1) if wsum else None
    wtxt = " · ".join(f"{a[1]} {weights[a[0]]:g}" for a in AXES)
    # 변경 최소성 — 재생성·적용이 고정 칸 밖에서 바꾼 칸 수. 결과가 고르더라도 "내 표가 갑자기 다 바뀌었다"는
    # 불공정 느낌은 여기서 온다. bridge가 직전 표와 대조해 센 값을 그대로 싣는다(없으면 첫 생성).
    change_text = None
    if change and change.get("cells") is not None:
        change_text = (f"직전 표에서 바뀐 칸 {change['cells']}개({change.get('people', 0)}명)"
                       + (f", 고정 칸 {change['locked']}개는 그대로" if change.get("locked") else ""))
    # 가장 낮은 축 — 가중 평균에 가려진 축을 한 글자로 드러낸다(가중치 0인 축은 뺀다)
    lowest = min(scored, key=lambda a: a["score"]) if scored else None
    # 견준 인원이 적으면 백분위는 서도 뜻이 흔들린다 — 10명 밑이면 표시를 붙인다
    few = n_people < 10
    return {"total": total_score, "grade": grade_of(total_score), "axes": axes,
            "lowest": ({"key": lowest["key"], "name": lowest["name"], "score": lowest["score"]} if lowest else None),
            "people": n_people, "few_people": few,
            "weights": weights, "default_weights": DEFAULT_AXIS_WEIGHTS, "weight_max": WEIGHT_MAX,
            "change": change, "change_text": change_text,
            "fairness_sum": comp["fairness"], "baseline_n": BASELINE_N, "baseline_date": BASELINE_DATE,
            "selection_note": "시드를 고르는 기준은 운영 필수 → 숙련도 → 공평성 합(2×횟수+주말+조구성+단독+미반영) → 전체 위반 "
                              "순이고, 이 점수는 그 재료를 읽기 쉬운 눈금으로 바꾼 것입니다. 가중치를 바꿔도 표는 바뀌지 않습니다.",
            "weights_note": f"종합 = 가중 평균({wtxt}). "
                            f"점수는 기준선 {BASELINE_N}개 달({BASELINE_DATE} 엔진) 중 이 달보다 쏠린 달의 비율 — 100이면 어느 달보다 고름, "
                            "50이면 기준선의 중간. 원티드만 반영률 그대로."}


def person_summaries(gen, sch: MonthSchedule, days, fatigue_w: Optional[Dict[str, float]] = None,
                     cum: Optional[dict] = None) -> List[dict]:
    """사람별 '내 달 요약'. 파트장은 뺀다(근무를 서지 않는다). cum: cumulative()의 결과(있으면 누적 줄을 덧붙인다)."""
    fatigue_w = clean_weights(fatigue_w, {k: float(v) for k, v in FATIGUE_W.items()})
    staff = [s for s in gen.staff if not s.is_partjang]
    gen_staff = general_staff(gen.staff)
    # 주말 집단 평균
    wk_mean: Dict[str, Optional[float]] = {}
    for g in cohorts(sch):
        m = sum(sch.weekend_workdays_in_month(s.id) for s in g) / len(g)
        for s in g:
            wk_mean[s.id] = m
    all_mean = (sum(sch.weekend_workdays_in_month(s.id) for s in gen_staff) / len(gen_staff)) if gen_staff else 0.0
    # D·E 목표(가능일 비례, 횟수 집단 안)
    de_target: Dict[str, Dict[str, float]] = {}
    groups: Dict[tuple, list] = {}
    for s in gen_staff:
        groups.setdefault(count_cohort_key(sch, s), []).append(s)
    for g in groups.values():
        if len(g) < 2:
            continue
        avail = {s.id: available_days(sch, s.id) for s in g}
        tot_avail = sum(avail.values()) or 1
        for key, codes in (("D", (Shift.D,)), ("E", (Shift.E,))):
            total = sum(1 for s in g for v in sch.grid[s.id] if v in codes)
            for s in g:
                de_target.setdefault(s.id, {})[key] = total * avail[s.id] / tot_avail
    req_by: Dict[str, list] = {}
    for q in gen.requests:
        req_by.setdefault(q.staff_id, []).append(q)
    out = []
    for s in staff:
        row = sch.grid[s.id]
        wk = sch.weekend_workdays_in_month(s.id)
        nights = sch.nights_in_month(s.id)
        tgt = gen.nk_target if s.is_nk else sch.night_target.get(s.id)
        d_cnt = sum(1 for v in row if v == Shift.D)
        e_cnt = sum(1 for v in row if v == Shift.E)
        ft = fatigue(sch, s.id, days, fatigue_w)
        reqs = req_by.get(s.id, [])
        rejected = [{"date": q.date, "type": str(q.type), "reason": q.reject_reason} for q in reqs if q.accepted is False]
        m = wk_mean.get(s.id)
        parts = []
        if s.is_nk:
            parts.append(f"주말 {wk}일(야간전담)")
        elif m is not None:
            parts.append(f"주말 {wk}일(같은 조건 평균 {m:.1f} · {wk - m:+.1f})")
        else:
            parts.append(f"주말 {wk}일(전체 평균 {all_mean:.1f} · 견줄 같은 조건 없음)")
        parts.append(f"야간 {nights}/{tgt}" if tgt is not None else f"야간 {nights}회")
        de = de_target.get(s.id)
        if de and not s.is_nk:
            dd = d_cnt - de.get("D", d_cnt)
            ee = e_cnt - de.get("E", e_cnt)
            tilt = f"D {dd:+.1f} E {ee:+.1f}" if max(abs(dd), abs(ee)) >= 1.5 else "쏠림 없음"
            parts.append(f"D {d_cnt} E {e_cnt} ({tilt})")
        else:
            parts.append(f"D {d_cnt} E {e_cnt}")
        parts.append(f"피로 {ft['score']}점(낮→밤 직결 {ft['quick_to_night']} · 짧은 회복 {ft['short_recovery']} · 연속 주말 {ft['consecutive_weekends']})")
        if reqs:
            acc = sum(1 for q in reqs if q.accepted)
            parts.append(f"원티드 {len(reqs)}건 중 {acc}건 반영" + (
                " — 미반영: " + "; ".join(f"{r['date'][-5:]} {r['type']} ({r['reason']})" for r in rejected) if rejected else ""))
        else:
            parts.append("원티드 없음")
        cp = (cum or {}).get("persons", {}).get(s.id)
        if cp and cp.get("weekend_cmp"):
            cum_txt = f"누적 {cum['n_months']}개월 주말 {cp['weekend']}일(적정 {cp['weekend_target']:g}, {cp['weekend_excess']:+.1f})"
            if cp.get("nights_cmp"):
                cum_txt += f" · 야간 {cp['nights']}회(적정 {cp['nights_target']:g}, {cp['nights_excess']:+.1f})"
            parts.append(cum_txt)
        bias = float(getattr(sch.carryover.get(s.id), "weekend_bias", 0.0) or 0.0)
        if bias:
            parts.append(f"이번 달 주말 몫 보정 {'-1일(덜)' if bias > 0 else '+1일(더)'}")
        out.append({"id": s.id, "is_nk": s.is_nk, "weekend": wk, "weekend_bias": bias,
                    "weekend_mean": round(m, 2) if m is not None else None,
                    "weekend_delta": round(wk - m, 2) if m is not None else None,
                    "nights": nights, "night_target": tgt,
                    "d": d_cnt, "e": e_cnt,
                    "d_target": round(de["D"], 2) if de else None, "e_target": round(de["E"], 2) if de else None,
                    "fatigue": ft, "cumulative": cp,
                    "wanted": {"total": len(reqs), "accepted": sum(1 for q in reqs if q.accepted), "rejected": rejected},
                    "line": " · ".join(parts)})
    return out


def _is_weekend_date(ds: str, holset) -> bool:
    import datetime as _dt
    try:
        dt_ = _dt.date.fromisoformat(ds)
    except ValueError:
        return False
    return dt_.weekday() >= 5 or ds in holset


def _month_tally(dates, grid, year: int, month: int, sids) -> Optional[Dict[str, dict]]:
    """연간근무표(입력②)에서 한 달치 사람별 주말 근무·야간과 **기회**(그 달 주말 중 쉴 수 있었던 날이 아닌 날 수,
    야간을 설 수 있었던 날 수)를 센다. 그 달 날짜가 하나도 없으면 None.

    기회 = 기록이 있는 날 중 휴가류(LEAVE_SHIFTS)가 아닌 날. 승인 휴가·전입 전·퇴직 뒤는 기회에서 빠진다 —
    "기록이 있다"와 "같은 기회가 있었다"는 다르다(2026-11-09 GPT 검토 §04-4). 코드 → parse_shift,
    '/'·'X'는 쉼(기회 있음), 빈칸은 기록 없음(기회 없음)."""
    prefix = f"{year}-{month:02d}-"
    idx = [i for i, ds in enumerate(dates) if str(ds)[:8] == prefix]
    if not idx:
        return None
    hol, sub = kr_holidays_for_month(year, month)
    holset = set(hol) | set(sub)
    weekend_idx = {i for i in idx if _is_weekend_date(str(dates[i])[:10], holset)}
    out: Dict[str, dict] = {}
    for sid in sids:
        row = grid.get(sid)
        if not row:
            continue
        w = n = filled = wk_opp = day_opp = 0
        for i in idx:
            code = row[i] if i < len(row) else ""
            if code in (None, "") or not str(code).strip():
                continue
            sv = str(code).strip()
            if sv in ("/", "X"):
                sh = Shift.OFF
            else:
                try:
                    sh = parse_shift(sv)
                except ValueError:
                    continue
            filled += 1
            if sh not in LEAVE_SHIFTS:
                day_opp += 1
                if i in weekend_idx:
                    wk_opp += 1
            if sh in WORK_SHIFTS and i in weekend_idx:
                w += 1
            if sh in _NIGHT:
                n += 1
        if filled * 2 < len(idx):
            continue
        out[sid] = {"weekend": w, "nights": n, "weekend_opp": wk_opp, "day_opp": day_opp}
    return out


def _this_month_tally(sch: MonthSchedule, days, sids) -> Dict[str, dict]:
    """이번 달 표에서 같은 네 숫자(주말 근무·야간·주말 기회·가능일)."""
    out = {}
    wk_days = {d for d, di in enumerate(days) if di.day_type != DAY_WEEKDAY}
    for sid in sids:
        row = sch.grid[sid]
        wk_opp = day_opp = 0
        for d in range(sch.num_days):
            v = row[d] if row[d] is not None else Shift.OFF
            if v not in LEAVE_SHIFTS:
                day_opp += 1
                if d in wk_days:
                    wk_opp += 1
        out[sid] = {"weekend": sch.weekend_workdays_in_month(sid), "nights": sch.nights_in_month(sid),
                    "weekend_opp": wk_opp, "day_opp": day_opp}
    return out


#: 누적 형평의 기간 — 6개월. 3개월은 연휴 한 번에 뒤집히고, 감쇠를 넣으면 "석 달 전 양보는 반만 쳐 준다"를 당사자에게
#: 설명할 수 없다. 연간근무표가 최대 12개월을 들고 있어 파일만으로 된다.
CUM_MONTHS = 6


def cumulative(staff_table: Optional[dict], gen, sch: MonthSchedule, days=None, max_months: int = CUM_MONTHS) -> Optional[dict]:
    """누적 형평성 — 연간근무표(입력②)의 지난달들 + 이번 달에 대해, 사람별 **적정 몫 대비 초과**를 더한다.

    달마다 q(i) = T × a(i) / Σa — T는 비교 집단이 실제로 선 주말 근무(야간) 합, a(i)는 그 사람의 그 달 기회
    (휴가가 아닌 주말 수·가능일). e(i) = 실제 − q(i)를 달마다 더한 것이 누적 초과 D(i)다. 합을 평균과 견주던
    예전 방식은 긴 휴가·월중 전입·야간 제한이 있는 사람을 "적음"에 올렸다 — 합이 작은 것은 공평해서가 아니라
    기회가 없어서였다(GPT 검토 §04-4). 수요가 많은 달(연휴)은 T가 커져 모두의 목표가 같이 오른다.

    견주는 사람: 주말은 D·E·N을 서는 일반 간호사, 야간은 N을 설 수 있고 야간불가가 아닌 사람. 기록이 반도 없는
    달이 있으면(complete=False) 그 사람은 평균(T·Σa)에서 뺀다 — 자료 공백은 공백으로. 입력②가 없으면 None."""
    if not staff_table or gen is None:
        return None
    dates = staff_table.get("annual_dates") or []
    grid = staff_table.get("annual_grid") or {}
    if not dates or not grid:
        return None
    days = days if days is not None else gen.days
    y, m = gen.year, gen.month
    sids = [s.id for s in gen.staff if not s.is_partjang]
    months: List[str] = []
    tallies: List[Dict[str, dict]] = []
    yy, mm = y, m
    for _ in range(max_months - 1):
        yy, mm = (yy - 1, 12) if mm == 1 else (yy, mm - 1)
        t = _month_tally(dates, grid, yy, mm, sids)
        if t is None:
            break
        months.insert(0, f"{yy}-{mm:02d}")
        tallies.insert(0, t)
    if not months:
        return None
    tallies.append(_this_month_tally(sch, days, sids))
    generals = {s.id: s for s in general_staff(gen.staff)}
    wk_ok = {sid for sid, st in generals.items() if any(st.can(x) for x in (Shift.D, Shift.E, Shift.N))}
    n_ok = {sid for sid, st in generals.items() if st.can(Shift.N) and not st.no_night}
    persons: Dict[str, dict] = {}
    for sid in sids:
        present = [t[sid] for t in tallies if sid in t]
        complete = len(present) == len(tallies)
        persons[sid] = {"weekend": sum(x["weekend"] for x in present), "nights": sum(x["nights"] for x in present),
                        "weekend_opp": sum(x["weekend_opp"] for x in present), "day_opp": sum(x["day_opp"] for x in present),
                        "months_present": len(present), "complete": complete,
                        "weekend_cmp": complete and sid in wk_ok, "nights_cmp": complete and sid in n_ok,
                        "weekend_target": 0.0, "nights_target": 0.0}
    wk_pool = [sid for sid, p in persons.items() if p["weekend_cmp"]]
    n_pool = [sid for sid, p in persons.items() if p["nights_cmp"]]
    if len(wk_pool) < 2:
        for p in persons.values():
            p["weekend_cmp"] = p["nights_cmp"] = False
            p["weekend_excess"] = p["nights_excess"] = None
        return {"months": months, "n_months": len(tallies), "persons": persons, "pool": len(wk_pool), "items": [],
                "text": f"연간근무표에 지난 {len(months)}개월이 있지만 전 기간 기록이 있는 일반 간호사가 {len(wk_pool)}명이라 견주지 못합니다"}
    # 달마다 적정 몫 — 기회 비례
    for t in tallies:
        for key, pool, opp_key in (("weekend", wk_pool, "weekend_opp"), ("nights", n_pool, "day_opp")):
            members = [sid for sid in pool if sid in t]
            total = sum(t[sid][key] for sid in members)
            opp_sum = sum(t[sid][opp_key] for sid in members)
            for sid in members:
                q = total * t[sid][opp_key] / opp_sum if opp_sum else 0.0
                persons[sid][key + "_target"] += q
    for sid, p in persons.items():
        p["weekend_target"] = round(p["weekend_target"], 1)
        p["nights_target"] = round(p["nights_target"], 1)
        p["weekend_excess"] = round(p["weekend"] - p["weekend_target"], 1) if p["weekend_cmp"] else None
        p["nights_excess"] = round(p["nights"] - p["nights_target"], 1) if p["nights_cmp"] else None
        # 이전 호환 키(화면·테스트가 delta를 읽었다) — 이제 '초과'와 같은 뜻
        p["weekend_delta"], p["nights_delta"] = p["weekend_excess"], p["nights_excess"]

    def pick(key, cmp_key, gap, sign):
        rows = [(sid, p) for sid, p in persons.items() if p[cmp_key] and sign * p[key] >= gap]
        return sorted(rows, key=lambda x: -sign * x[1][key])
    hi_w, lo_w = pick("weekend_excess", "weekend_cmp", CUM_WEEKEND_GAP, 1), pick("weekend_excess", "weekend_cmp", CUM_WEEKEND_GAP, -1)
    hi_n, lo_n = pick("nights_excess", "nights_cmp", CUM_NIGHT_GAP, 1), pick("nights_excess", "nights_cmp", CUM_NIGHT_GAP, -1)
    wk_vals = [persons[s]["weekend"] for s in wk_pool]
    n_vals = [persons[s]["nights"] for s in n_pool] or [0]
    mw = sum(wk_vals) / len(wk_vals)
    mn = sum(n_vals) / len(n_vals)
    span = f"{months[0][5:].lstrip('0')}월~이번 달" if len(months) > 1 else f"{months[0][5:].lstrip('0')}월+이번 달"
    items = []
    if hi_w:
        items.append("주말 초과: " + ", ".join(f"{sid} {p['weekend']}일(목표 {p['weekend_target']:g}, +{p['weekend_excess']:g})" for sid, p in hi_w[:6]))
    if lo_w:
        items.append("주말 부족: " + ", ".join(f"{sid} {p['weekend']}일(목표 {p['weekend_target']:g}, {p['weekend_excess']:g})" for sid, p in lo_w[:6]))
    if hi_n:
        items.append("야간 초과: " + ", ".join(f"{sid} {p['nights']}회(목표 {p['nights_target']:g}, +{p['nights_excess']:g})" for sid, p in hi_n[:6]))
    if lo_n:
        items.append("야간 부족: " + ", ".join(f"{sid} {p['nights']}회(목표 {p['nights_target']:g}, {p['nights_excess']:g})" for sid, p in lo_n[:6]))
    return {"months": months, "n_months": len(tallies), "span": span, "pool": len(wk_pool), "night_pool": len(n_pool),
            "persons": persons, "mean_weekend": round(mw, 1), "mean_nights": round(mn, 1),
            "weekend_range": [min(wk_vals), max(wk_vals)], "nights_range": [min(n_vals), max(n_vals)],
            "outliers": {"weekend_hi": [s for s, _ in hi_w], "weekend_lo": [s for s, _ in lo_w],
                         "nights_hi": [s for s, _ in hi_n], "nights_lo": [s for s, _ in lo_n]},
            "items": items,
            "method": "기회 보정 — 달마다 적정 몫 = 집단 총량 × 내 기회(휴가 아닌 주말 수·가능일) ÷ 집단 기회 합, 초과 = 실제 − 적정 몫의 누적",
            "text": (f"{span} {len(tallies)}개월 누적(주말 {len(wk_pool)}명 · 야간 {len(n_pool)}명 견줌, 기회 보정): "
                     f"주말 평균 {mw:.1f}일(최대 {max(wk_vals)} 최소 {min(wk_vals)}), "
                     f"야간 평균 {mn:.1f}회(최대 {max(n_vals)} 최소 {min(n_vals)})")}


def prior_weekend_excess(staff_table: Optional[dict], roster: list, year: int, month: int,
                         max_months: int = CUM_MONTHS - 1) -> Dict[str, float]:
    """이번 달 생성 **전에** 지난 달들의 주말 '적정 몫 대비 초과'를 사람별로 — cumulative()와 같은 산식(기회 보정),
    이번 달만 빠진다. roster는 입력①의 사람 dict 목록({id, role, allowed_shifts, flags}). 견주는 사람은 파트장·
    야간전담이 아니고 D·E·N 중 하나라도 서는 사람. 연간근무표가 없거나 지난달이 없으면 빈 dict."""
    if not staff_table or not roster:
        return {}
    dates = staff_table.get("annual_dates") or []
    grid = staff_table.get("annual_grid") or {}
    if not dates or not grid:
        return {}
    pool = []
    for st in roster:
        sid = str(st.get("id", "")).strip()
        if not sid or str(st.get("role", "")).strip() == "파트장":
            continue
        flags = set(st.get("flags") or [])
        allowed = {str(x).strip() for x in (st.get("allowed_shifts") or [])}
        if "night_only" in flags or not (allowed & {"D", "E", "N"}):
            continue
        pool.append(sid)
    if len(pool) < 2:
        return {}
    tallies = []
    yy, mm = year, month
    for _ in range(max_months):
        yy, mm = (yy - 1, 12) if mm == 1 else (yy, mm - 1)
        t = _month_tally(dates, grid, yy, mm, pool)
        if t is None:
            break
        tallies.insert(0, t)
    if not tallies:
        return {}
    excess = {sid: 0.0 for sid in pool}
    complete = {sid for sid in pool if all(sid in t for t in tallies)}
    for t in tallies:
        members = [sid for sid in complete if sid in t]
        total = sum(t[sid]["weekend"] for sid in members)
        opp_sum = sum(t[sid]["weekend_opp"] for sid in members)
        for sid in members:
            q = total * t[sid]["weekend_opp"] / opp_sum if opp_sum else 0.0
            excess[sid] += t[sid]["weekend"] - q
    return {sid: round(e, 2) for sid, e in excess.items() if sid in complete}


def weekend_bias_from_excess(excess: float, cap: float = 1.0, min_excess: float = 1.0) -> float:
    """누적 초과 → 이번 달 보정. ±cap일로 자른다 — 상한 없는 보상은 새 불공평을 만든다. |초과| < min_excess는 보정하지
    않는다(불가분한 칸 하나 때문에 생긴 소폭 차이까지 갚으려 들면 표가 흔들린다)."""
    if excess >= min_excess:
        return min(cap, round(excess, 1))
    if excess <= -min_excess:
        return max(-cap, round(excess, 1))
    return 0.0


def summary(gen, sch: MonthSchedule, days, staff_table: Optional[dict] = None,
            weights: Optional[Dict[str, float]] = None, fatigue_w: Optional[Dict[str, float]] = None,
            change: Optional[dict] = None) -> dict:
    cum = cumulative(staff_table, gen, sch, days)
    out = axis_scores(gen, sch, weights, change)
    out["fatigue_weights"] = clean_weights(fatigue_w, {k: float(v) for k, v in FATIGUE_W.items()})
    out["default_fatigue_weights"] = dict(FATIGUE_W)
    out["cumulative"] = cum
    out["persons"] = person_summaries(gen, sch, days, fatigue_w, cum)
    # 추가 지표 — 종합에는 안 넣는다(기준선이 없다). 피로는 '고르냐'가 아니라 '힘드냐'라 따로 읽는다.
    gens = [p for p in out["persons"] if not p["is_nk"]]
    if gens:
        avg = sum(p["fatigue"]["score"] for p in gens) / len(gens)
        top = max(gens, key=lambda p: (p["fatigue"]["score"], p["id"]))
        out["fatigue_avg"] = round(avg, 1)
        out["fatigue_max"] = {"id": top["id"], "score": top["fatigue"]["score"]}
        out["fatigue_text"] = (f"피로 점수 평균 {avg:.1f}점, 가장 높은 사람 {top['id']} {top['fatigue']['score']}점"
                               f"(낮→밤 직결 {top['fatigue']['quick_to_night']} · 짧은 회복 {top['fatigue']['short_recovery']} · 연속 주말 {top['fatigue']['consecutive_weekends']})")
    else:
        out["fatigue_avg"] = None
        out["fatigue_max"] = None
        out["fatigue_text"] = ""
    out["note"] = ("점수는 참고용입니다. 낮아도 병동 사정(연휴·휴가·교육·개인 요청)을 아는 파트장이 그대로 두거나 "
                   "고칠 수 있고, 고치는 동안에는 '수정 후' 점수가 함께 뜹니다.")
    return out

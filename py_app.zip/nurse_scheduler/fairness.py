# -*- coding: utf-8 -*-
"""공평성·균등성 지표 — 한 달 표가 '사람마다 비슷하게, 조마다 골고루' 됐는지를 숫자로.

왜 따로 두나. 생성기(후보 점수)·시도 비교(점수표)·보고서가 같은 정의를 써야 한다. 세 곳이 따로
적으면 한 곳만 바뀌어 "점수표는 좋아졌다는데 보고서는 아니다"가 된다. 전부 '사람·일' 단위라
그대로 더할 수 있고, 낮을수록 좋다.

지표(2026-10-22, 사용자 정의 "특별근무 전담이 아니면 D·E·N이 비슷해야 하고, 조마다 레벨이 골고루"):
  count   — 같은 조건 집단 안에서 D·E·N 횟수가 가능일 비례 목표에서 벗어난 날수의 합
  weekend — 같은 조건 집단 안에서 주말 근무가 집단 평균에서 벗어난 날수의 합
  mix     — 날짜·조(D/E/N)마다 레벨 띠(Lv1-2·Lv3·Lv4-5) 구성이 병동 비율에서 벗어난 사람 수의 합
  sole    — 혼자 Lv4+인 조에 선 횟수가 고연차 평균에서 벗어난 횟수의 합
  wanted  — 반려된 원티드 건수
  night   — 야간 횟수가 개인 목표(4·6)에서 벗어난 날수의 합(참고 — count의 N 항목과 겹치므로 합에는 안 넣는다)
  fairness = 2×count + weekend + mix + sole + wanted  (횟수 균등이 가장 무겁다 — 사용자 결정)
"""
from __future__ import annotations

from typing import Dict, List, Tuple

from .models import LEAVE_SHIFTS, MonthSchedule, Shift, Staff, WORK_SHIFTS

BANDS = (("lo", 1, 2), ("mid", 3, 3), ("hi", 4, 5))


def band_of(level: int) -> str:
    if level <= 2:
        return "lo"
    if level == 3:
        return "mid"
    return "hi"


def general_staff(staff: List[Staff]) -> List[Staff]:
    """횟수를 견줄 사람 — 파트장·야간전담 제외(특별근무 전담)."""
    return [s for s in staff if not (s.is_partjang or s.is_nk)]


def count_cohort_key(sch: MonthSchedule, s: Staff) -> tuple:
    """횟수 집단: 가능근무가 같고 야간 블록 선호·야간불가가 같은 사람끼리. 휴가일수는 목표에
    가능일 비례로 반영하므로 집단 조건에는 안 넣는다."""
    return (tuple(sorted(str(x) for x in s.allowed_shifts)), s.night_block_pref, s.no_night,
            sch.month_start_day.get(s.id, 0))


def available_days(sch: MonthSchedule, sid: str) -> int:
    row = sch.grid[sid]
    start = sch.month_start_day.get(sid, 0)
    leave = sum(1 for v in row if v in LEAVE_SHIFTS)
    return max(0, sch.num_days - start - leave)


def count_deviation(sch: MonthSchedule, staff: List[Staff]) -> Dict[str, float]:
    """근무유형(D·E·N)마다, 집단 안에서 개인 횟수가 '가능일 비례 목표'에서 벗어난 날수의 합과
    집단별 최대−최소의 합. 목표 = 집단 총횟수 × 내 가능일 ÷ 집단 가능일 합."""
    groups: Dict[tuple, List[Staff]] = {}
    for s in general_staff(staff):
        groups.setdefault(count_cohort_key(sch, s), []).append(s)
    dev = {"D": 0.0, "E": 0.0, "N": 0.0}
    gap = {"D": 0, "E": 0, "N": 0}
    for g in groups.values():
        if len(g) < 2:
            continue
        avail = {s.id: available_days(sch, s.id) for s in g}
        tot_avail = sum(avail.values()) or 1
        for key, codes in (("D", (Shift.D,)), ("E", (Shift.E,)), ("N", (Shift.N, Shift.NK))):
            if not any(s.can(codes[0]) for s in g):
                continue
            cnt = {s.id: sum(1 for v in sch.grid[s.id] if v in codes) for s in g}
            total = sum(cnt.values())
            for s in g:
                target = total * avail[s.id] / tot_avail
                dev[key] += abs(cnt[s.id] - target)
            gap[key] += max(cnt.values()) - min(cnt.values())
    return {"count_D": round(dev["D"], 2), "count_E": round(dev["E"], 2), "count_N": round(dev["N"], 2),
            "count": round(dev["D"] + dev["E"] + dev["N"], 2),
            "gap_D": gap["D"], "gap_E": gap["E"], "gap_N": gap["N"]}


def ward_band_share(staff: List[Staff]) -> Dict[str, float]:
    gen = general_staff(staff)
    n = len(gen) or 1
    share = {b: 0.0 for b, _, _ in BANDS}
    for s in gen:
        share[band_of(s.level)] += 1.0 / n
    return share


def team_mix_deviation(sch: MonthSchedule, staff: List[Staff], share: Dict[str, float] = None) -> float:
    """날짜·조마다 레벨 띠 구성이 병동 비율에서 벗어난 사람 수(Σ|실제−기대|/2)의 합.
    평균이 아니라 구성을 본다 — Lv5 셋+Lv1 셋과 Lv3 여섯은 평균이 같지만 구성은 다르다."""
    share = share or ward_band_share(staff)
    gen = general_staff(staff)
    total = 0.0
    for d in range(sch.num_days):
        for codes in ((Shift.D,), (Shift.E,), (Shift.N, Shift.NK)):
            members = [s for s in gen if sch.grid[s.id][d] in codes]
            if len(members) < 2:
                continue
            n = len(members)
            cnt = {b: 0 for b, _, _ in BANDS}
            for s in members:
                cnt[band_of(s.level)] += 1
            total += sum(abs(cnt[b] - share[b] * n) for b in cnt) / 2.0
    return round(total, 2)


def mix_gain(team_levels: List[int], level: int, share: Dict[str, float]) -> float:
    """후보 점수용: 이 사람을 조에 넣으면 구성 편차가 얼마나 줄어드나(양수 = 좋아짐), 0~1로 가둠."""
    n = len(team_levels)
    cnt = {b: 0 for b, _, _ in BANDS}
    for lv in team_levels:
        cnt[band_of(lv)] += 1
    before = sum(abs(cnt[b] - share[b] * n) for b in cnt) / 2.0
    cnt[band_of(level)] += 1
    after = sum(abs(cnt[b] - share[b] * (n + 1)) for b in cnt) / 2.0
    return max(-1.0, min(1.0, before - after))


def sole_senior_deviation(sch: MonthSchedule, staff: List[Staff]) -> Tuple[float, Dict[str, int]]:
    """혼자 Lv4+인 조에 선 횟수(사람별)와, 고연차끼리 평균에서 벗어난 횟수의 합."""
    gen = general_staff(staff)
    seniors = [s for s in gen if s.level >= 4]
    per = {s.id: 0 for s in seniors}
    for d in range(sch.num_days):
        for codes in ((Shift.D,), (Shift.E,), (Shift.N, Shift.NK)):
            hi = [s for s in gen if sch.grid[s.id][d] in codes and s.level >= 4]
            if len(hi) == 1:
                per[hi[0].id] += 1
    if not per:
        return 0.0, per
    m = sum(per.values()) / len(per)
    return round(sum(abs(v - m) for v in per.values()), 2), per


def weekend_deviation(sch: MonthSchedule) -> float:
    from .equalize import cohorts
    total = 0.0
    for g in cohorts(sch):
        w = [sch.weekend_workdays_in_month(s.id) for s in g]
        m = sum(w) / len(w)
        total += sum(abs(x - m) for x in w)
    return round(total, 2)


def components(gen, sch: MonthSchedule) -> dict:
    """점수표·보고서가 쓰는 한 벌. gen: Generator(staff·requests·night_target 접근용)."""
    staff = gen.staff
    out = count_deviation(sch, staff)
    out["weekend"] = weekend_deviation(sch)
    out["mix"] = team_mix_deviation(sch, staff)
    sole, _ = sole_senior_deviation(sch, staff)
    out["sole"] = sole
    out["wanted"] = sum(1 for q in gen.requests if q.accepted is False)
    night = 0
    for s in general_staff(staff):
        tgt = sch.night_target.get(s.id)
        if tgt is not None:
            night += abs(sch.nights_in_month(s.id) - tgt)
    out["night"] = night
    # D/E 쏠림(옛 지표, 참고) — count_D·count_E가 대신한다
    out["fairness"] = round(2 * out["count"] + out["weekend"] + out["mix"] + out["sole"] + out["wanted"], 2)
    return out

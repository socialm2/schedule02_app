# -*- coding: utf-8 -*-
"""공평성·균등성 지표 — 한 달 표가 '사람마다 비슷하게, 조마다 골고루' 됐는지를 숫자로.

왜 따로 두나. 생성기(후보 점수)·시도 비교(점수표)·보고서가 같은 정의를 써야 한다. 세 곳이 따로
적으면 한 곳만 바뀌어 "점수표는 좋아졌다는데 보고서는 아니다"가 된다. 전부 '사람·일' 단위라
그대로 더할 수 있고, 낮을수록 좋다.

지표(2026-10-22, 사용자 정의 "특별근무 전담이 아니면 D·E·N이 비슷해야 하고, 조마다 레벨이 골고루"):
  count   — 같은 조건 집단 안에서 D·E·N 횟수가 가능일 비례 목표에서 벗어난 날수의 합
  weekend — 같은 조건 집단 안에서 주말 근무가 집단 평균에서 벗어난 날수의 합
  mix     — 날짜·조(D/E/N)마다 레벨 띠(Lv1-2·Lv3·Lv4-5) 구성이 병동 비율에서 벗어난 사람 수의 합
  mix_avg — 날짜·조마다 평균 숙련도가 병동 평균에서 벗어난 정도의 합(참고 — 합에는 안 넣는다. 점수의 숙련 분산
            축은 mix와 mix_avg를 반씩 본다, fairscore.py)
  sole    — 혼자 Lv4+인 조에 선 횟수가 고연차 평균에서 벗어난 횟수의 합
  wanted  — 반려된 원티드 건수
  night   — 야간 횟수가 개인 목표(4·6)에서 벗어난 날수의 합(참고 — count의 N 항목과 겹치므로 합에는 안 넣는다)
  fairness = 2×count + weekend + mix + sole + wanted  (횟수 균등이 가장 무겁다 — 사용자 결정)
"""
from __future__ import annotations

from typing import Dict, List, Tuple

from .models import LEAVE_SHIFTS, MonthSchedule, Shift, Staff, WORK_SHIFTS

BANDS = (("lo", 1, 2), ("mid", 3, 3), ("hi", 4, 5))


def band_of(level: int) -> str:
    if level <= 2:
        return "lo"
    if level == 3:
        return "mid"
    return "hi"


def general_staff(staff: List[Staff]) -> List[Staff]:
    """횟수를 견줄 사람 — 파트장·야간전담 제외(특별근무 전담)."""
    return [s for s in staff if not (s.is_partjang or s.is_nk)]


def count_cohort_key(sch: MonthSchedule, s: Staff) -> tuple:
    """횟수 집단: 가능근무가 같고 야간 블록 선호·야간불가가 같은 사람끼리. 휴가일수는 목표에
    가능일 비례로 반영하므로 집단 조건에는 안 넣는다."""
    return (tuple(sorted(str(x) for x in s.allowed_shifts)), s.night_block_pref, s.no_night,
            sch.month_start_day.get(s.id, 0))


def available_days(sch: MonthSchedule, sid: str) -> int:
    """이 달에 이 사람에게 근무를 줄 수 있었던 날 수 = 병동에 온 날부터 말일까지에서 휴가·부재를 뺀 것.

    월중 전입자의 전입 전 날짜는 표에 '휴'로 채워져 있다. 예전에는 그 '휴'를 휴가로 한 번, 전입일로 또 한 번 빼서
    1월 15일 전입자(남은 17일)가 3일로, 2월 28일 전입자(당일 근무)가 0일로 나왔다(2026-11-26 GPT 종합검증). 이 값은 '가능일
    비례 목표'의 분모라, 작게 나오면 그 사람은 조금만 일해도 제 몫을 넘긴 것으로 세어진다 — 형평성 점수와 D·E 횟수 맞추기가
    전입자에게 불리하게 기운다. 휴가는 **온 날부터** 센다."""
    row = sch.grid[sid]
    start = sch.month_start_day.get(sid, 0)
    leave = sum(1 for v in row[start:] if v in LEAVE_SHIFTS)
    return max(0, sch.num_days - start - leave)


def count_deviation(sch: MonthSchedule, staff: List[Staff]) -> Dict[str, float]:
    """근무유형(D·E·N)마다, 집단 안에서 개인 횟수가 '가능일 비례 목표'에서 벗어난 날수의 합과
    집단별 최대−최소의 합. 목표 = 집단 총횟수 × 내 가능일 ÷ 집단 가능일 합."""
    groups: Dict[tuple, List[Staff]] = {}
    for s in general_staff(staff):
        groups.setdefault(count_cohort_key(sch, s), []).append(s)
    dev = {"D": 0.0, "E": 0.0, "N": 0.0}
    gap = {"D": 0, "E": 0, "N": 0}
    for g in groups.values():
        if len(g) < 2:
            continue
        avail = {s.id: available_days(sch, s.id) for s in g}
        tot_avail = sum(avail.values()) or 1
        for key, codes in (("D", (Shift.D,)), ("E", (Shift.E,)), ("N", (Shift.N, Shift.NK))):
            if not any(s.can(codes[0]) for s in g):
                continue
            cnt = {s.id: sum(1 for v in sch.grid[s.id] if v in codes) for s in g}
            total = sum(cnt.values())
            for s in g:
                target = total * avail[s.id] / tot_avail
                dev[key] += abs(cnt[s.id] - target)
            gap[key] += max(cnt.values()) - min(cnt.values())
    return {"count_D": round(dev["D"], 2), "count_E": round(dev["E"], 2), "count_N": round(dev["N"], 2),
            "count": round(dev["D"] + dev["E"] + dev["N"], 2),
            "gap_D": gap["D"], "gap_E": gap["E"], "gap_N": gap["N"]}


def ward_band_share(staff: List[Staff]) -> Dict[str, float]:
    gen = general_staff(staff)
    n = len(gen) or 1
    share = {b: 0.0 for b, _, _ in BANDS}
    for s in gen:
        share[band_of(s.level)] += 1.0 / n
    return share


def team_mix_deviation(sch: MonthSchedule, staff: List[Staff], share: Dict[str, float] = None) -> float:
    """날짜·조마다 레벨 띠 구성이 병동 비율에서 벗어난 사람 수(Σ|실제−기대|/2)의 합.
    평균이 아니라 구성을 본다 — Lv5 셋+Lv1 셋과 Lv3 여섯은 평균이 같지만 구성은 다르다."""
    share = share or ward_band_share(staff)
    gen = general_staff(staff)
    total = 0.0
    for d in range(sch.num_days):
        for codes in ((Shift.D,), (Shift.E,), (Shift.N, Shift.NK)):
            members = [s for s in gen if sch.grid[s.id][d] in codes]
            if len(members) < 2:
                continue
            n = len(members)
            cnt = {b: 0 for b, _, _ in BANDS}
            for s in members:
                cnt[band_of(s.level)] += 1
            total += sum(abs(cnt[b] - share[b] * n) for b in cnt) / 2.0
    return round(total, 2)


def team_level_avg_deviation(sch: MonthSchedule, staff: List[Staff]) -> float:
    """날짜·조(D/E/N)마다 조의 평균 숙련도가 병동 평균에서 벗어난 정도의 합 — **그 조 인원이면 우연히 생기는 흔들림**
    을 1로 둔 단위로 센다(|조 평균 − 병동 평균| ÷ 표준오차).

    구성(team_mix_deviation)과 짝이다 — 구성은 Lv1 둘과 Lv2 둘을 못 가르고(같은 띠), 평균은 Lv5+Lv1과 Lv3+Lv3을
    못 가른다. 화면 아래 'D 평균' 줄이 날마다 얼마나 출렁이는지를 센다(사용자 2026-11-22 "비율도 비슷하고 평균도 비슷해야").
    처음엔 평균 차이를 그대로 더했는데, 조가 작으면 한 명만 바뀌어도 평균이 크게 움직여 작은 병동은 표와 상관없이
    나쁘게 나왔다(예시 40명 병동이 기준선 40~100명에 견줘 100점 중 2~14점). 조 인원 n, 병동 N명, 숙련도 표준편차 σ일 때
    무작위로 뽑은 n명의 평균은 σ/√n·√((N−n)/(N−1))만큼 흔들린다 — 그것으로 나누면 병동 크기와 상관없이 견줄 수 있고,
    아무렇게나 짠 조가 대략 0.8, 고르게 짤수록 0에 가깝다. 구성과 같은 사람들(파트장·야간전담 제외)과 같은 조(2명 이상)를 센다."""
    gen = general_staff(staff)
    n_all = len(gen)
    if n_all < 2:
        return 0.0
    ward = sum(s.level for s in gen) / n_all
    sigma = (sum((s.level - ward) ** 2 for s in gen) / n_all) ** 0.5
    if sigma == 0:
        return 0.0                                     # 모두 같은 숙련도 — 평균이 다를 수가 없다
    total = 0.0
    for d in range(sch.num_days):
        for codes in ((Shift.D,), (Shift.E,), (Shift.N, Shift.NK)):
            levels = [s.level for s in gen if sch.grid[s.id][d] in codes]
            n = len(levels)
            if n < 2 or n >= n_all:
                continue
            se = sigma / n ** 0.5 * ((n_all - n) / (n_all - 1)) ** 0.5
            total += abs(sum(levels) / n - ward) / se
    return round(total, 3)


def mix_gain(team_levels: List[int], level: int, share: Dict[str, float]) -> float:
    """후보 점수용: 이 사람을 조에 넣으면 구성 편차가 얼마나 줄어드나(양수 = 좋아짐), 0~1로 가둠."""
    n = len(team_levels)
    cnt = {b: 0 for b, _, _ in BANDS}
    for lv in team_levels:
        cnt[band_of(lv)] += 1
    before = sum(abs(cnt[b] - share[b] * n) for b in cnt) / 2.0
    cnt[band_of(level)] += 1
    after = sum(abs(cnt[b] - share[b] * (n + 1)) for b in cnt) / 2.0
    return max(-1.0, min(1.0, before - after))


def sole_senior_deviation(sch: MonthSchedule, staff: List[Staff]) -> Tuple[float, Dict[str, int]]:
    """혼자 Lv4+인 조에 선 횟수(사람별)와, 고연차끼리 평균에서 벗어난 횟수의 합."""
    gen = general_staff(staff)
    seniors = [s for s in gen if s.level >= 4]
    per = {s.id: 0 for s in seniors}
    for d in range(sch.num_days):
        for codes in ((Shift.D,), (Shift.E,), (Shift.N, Shift.NK)):
            hi = [s for s in gen if sch.grid[s.id][d] in codes and s.level >= 4]
            if len(hi) == 1:
                per[hi[0].id] += 1
    if not per:
        return 0.0, per
    m = sum(per.values()) / len(per)
    return round(sum(abs(v - m) for v in per.values()), 2), per


def weekend_deviation(sch: MonthSchedule) -> float:
    from .equalize import cohorts
    total = 0.0
    for g in cohorts(sch):
        w = [sch.weekend_workdays_in_month(s.id) for s in g]
        m = sum(w) / len(w)
        total += sum(abs(x - m) for x in w)
    return round(total, 2)


def adjacent_same(sch: MonthSchedule, staff: List[Staff]) -> Tuple[int, float]:
    """명단에서 이웃한 두 사람이 같은 날 같은 근무(D·E·N)인 칸 수와, 근무가 서로 무관할 때의 기댓값.

    공평성 지표가 아니라 '표가 띠처럼 보이나'의 지표다 — 명단이 레벨순이면 이웃 = 비슷한 레벨이라,
    이 수가 기댓값보다 크면 비슷한 레벨끼리 같은 근무가 몰려 보인다. 합에는 안 넣는다."""
    gen = general_staff(staff)
    same = 0
    expect = 0.0
    for d in range(sch.num_days):
        col = [sch.grid[s.id][d] for s in gen]
        work = [v for v in col if v in (Shift.D, Shift.E, Shift.N, Shift.NK)]
        if len(gen) >= 2 and work:
            p = {k: sum(1 for v in work if v == k) / len(gen) for k in (Shift.D, Shift.E, Shift.N)}
            expect += sum(p[k] ** 2 for k in p) * (len(gen) - 1)
        for a, b in zip(col, col[1:]):
            if a is not None and a == b and a in (Shift.D, Shift.E, Shift.N):
                same += 1
    return same, round(expect, 1)


def components(gen, sch: MonthSchedule) -> dict:
    """점수표·보고서가 쓰는 한 벌. gen: Generator(staff·requests·night_target 접근용)."""
    staff = gen.staff
    out = count_deviation(sch, staff)
    out["weekend"] = weekend_deviation(sch)
    out["mix"] = team_mix_deviation(sch, staff)
    out["mix_avg"] = team_level_avg_deviation(sch, staff)   # 점수(fairscore)의 숙련 분산 축 절반 — 아래 합에는 안 넣는다
    sole, _ = sole_senior_deviation(sch, staff)
    out["sole"] = sole
    out["wanted"] = sum(1 for q in gen.requests if q.accepted is False)
    night = 0
    for s in general_staff(staff):
        tgt = sch.night_target.get(s.id)
        if tgt is not None:
            night += abs(sch.nights_in_month(s.id) - tgt)
    out["night"] = night
    out["adjacent"], out["adjacent_expect"] = adjacent_same(sch, staff)
    # D/E 쏠림(옛 지표, 참고) — count_D·count_E가 대신한다
    out["fairness"] = round(2 * out["count"] + out["weekend"] + out["mix"] + out["sole"] + out["wanted"], 2)
    return out

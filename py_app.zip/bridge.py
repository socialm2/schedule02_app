# -*- coding: utf-8 -*-
"""브라우저(Pyodide) 전용 브릿지.

앱의 API 계층 전부다. HTTP 서버 없이 JS(pyworker.js)가 직접 호출하는 평범한 함수로
노출한다(예전엔 같은 로직의 로컬 Flask판 webapp/app.py가 따로 있었다 — 2026-10에 없앴다). 모든 함수는 JSON 문자열을 인자로 받고 JSON 문자열을
반환한다(다운로드용 바이너리 함수만 예외). 성공/실패는 HTTP 상태 코드 대신
반환 JSON에 "error" 키가 있는지로 구분한다 — JS 쪽 api() 어댑터가 이 규약을 안다.

이 모듈은 Web Worker 안에서 실행된다(메인 스레드가 생성 계산 중 멈추지 않게 하려고).
달 사이의 이어짐(이월정보·누적 통계)은 **파일로만** 간다 — 출력②(연간근무표)를 다음 달
입력②로 올린다. 예전엔 '확정 저장'이 그 달을 브라우저 localStorage에 기록하고 '연간
보기'가 그걸 읽는 길이 따로 있었는데, 2026-08부터 화면에서 숨겨져 아무도 쓰지 않는 채로
수정·테스트만 쌓였다. 2026-10-13에 걷어냈다(되살리려면 그 커밋 직전을 볼 것).
"""
from __future__ import annotations

import copy
import functools
import io
import json
import os
import re
import time
import unicodedata
import tempfile
import zipfile

from nurse_scheduler.calendar_utils import (DAY_WEEKDAY, build_calendar, kr_holidays_for_month,
                                            lunar_festival_dates, min_staff_for)
from nurse_scheduler.constraints import all_hard_checks, check_soft
from nurse_scheduler.excel_export import (
    export_excel, export_excel_ocs, export_staff_table_xlsx, generate_wanted_template_xlsx,
)
from nurse_scheduler.excel_input import (
    ExcelInputError, WrongInputSlotError, partjang_allowed_problem,
    PARTJANG_BLOCKED_SHIFTS, apply_month_upload, load_prev_month_schedule_xlsx,
    month_upload_problems,
    staff_table_from_prev_month,
    load_staff_table_xlsx, load_wanted_grid_xlsx,
)
from nurse_scheduler.fairscore import (summary as fairscore_summary, score_from_components as fairscore_display,
                                       prior_weekend_excess, weekend_bias_from_excess)
from nurse_scheduler.generator import (
    Generator, InputError, _BEST_EFFORT_RULES,
    attempt_stats, carryover_from_history_before, finish_candidate,
    carryover_from_staff_table, choose_attempt, generate_best,
    night_score_from_grid_history,
    reconcile_roster,
)
from nurse_scheduler.edit_assist import fragile_map, new_hard_keys, swap_candidates
from nurse_scheduler.models import (NIGHT_SHIFTS, REST_SHIFTS, STAFF_TABLE_SUMMARY_LABELS, Shift, WORK_SHIFTS,
                                    parse_shift)
from nurse_scheduler.reporting import build_report
from nurse_scheduler.sample_defaults import sample_config_dict, sample_requests_for

# 화면 첫 기본값 중 '명단'만 파일에서 온다 — 파트장이 실제로 쓰는 양식(원티드표)과
# 같은 형식이다. 설정·최소인력은 nurse_scheduler/sample_defaults.py에 있다.
# pyworker.js가 부팅할 때 이 경로로 써 넣는다.
SAMPLE_ROSTER_PATH = "/입력1_원티드표_샘플.xlsx"


class State:
    """프로세스(=탭) 전역 세션 상태."""

    def __init__(self):
        self.cfg: dict | None = None
        self.gen = None
        self.sch = None
        self.locked_cells: dict[tuple[str, int], Shift] = {}
        self.pending_edits: dict[tuple[str, int], Shift] = {}
        self.round: int = 0
        # [야간 먼저] — night_stage: 지금 화면이 '야간만 보기' 단계인가(화면은 야간 외 칸을 흐리게 그린다).
        # nights_fixed: 파트장이 야간을 확정했는가. 확정 뒤의 모든 생성(적용·재생성·시드 바꾸기·도우미 시도)은
        # 새 야간을 만들지 않는다 — 한 길이라도 빠지면 그 길로 다시 짠 표만 야간이 바뀌어, 확정이 조용히 풀린다.
        self.night_stage: bool = False
        self.nights_fixed: bool = False
        self.staff_table_in: dict | None = None
        # set_config에서 계산한 전입·전출 대조 결과 — 연간근무표 갱신본에서 전출자
        # 이력을 이어붙일 때 쓴다.
        self.roster_moves: dict | None = None
        # B팀(신입) 근무 — 이름 → 날짜별 근무코드. 엔진은 신입을 배정하지 않으므로
        # 파트장이 화면에서 직접 채우고, 그 값을 여기 담아 출력 엑셀까지 들고 간다.
        # 근무표(S.sch)가 아니라 세션에 두는 이유: 재생성하면 MonthSchedule이 새로
        # 만들어지는데, 거기에만 있으면 재생성 한 번에 파트장이 채운 값이 조용히 사라진다.
        self.team_b_grid: dict[str, list[str]] = {}
        # 수정 취약 칸 지도(D-2) — (지도를 만든 근무표의 id, 지도). 근무표가 새로 만들어지면
        # id가 달라져 자동으로 버려진다. 생성 뒤 화면이 한 번 요청해 채우고, 맞교환
        # 탐색(D-1)이 행 취약 칸을 상대에서 거를 때 다시 쓴다.
        self.fragile: tuple | None = None
        # 시도 점수표 — 평가한 시드마다 (운영 필수·숙련도·전체 하드·공평성 구성) + 선택 표시.
        # 순차 생성은 generate_best가, 병렬 생성은 api_pick_attempt가 채운다. 화면 결과창에 보인다.
        self.attempt_table: list | None = None
        # 평가한 시드별 (Generator, MonthSchedule). 점수표에서 다른 시드를 누르면 여기서 꺼내 바꾼다.
        # 병렬 생성은 도우미가 통계만 보내므로 없는 시드는 누를 때 그 시드로 한 번 더 돌려 채운다.
        self.candidates: dict[int, tuple] = {}
        # 공정성 점수 가중치(축·피로) — 파트장이 화면에서 바꾸면 여기 두고 state마다 다시 센다. 세션(탭) 안에서만
        # 산다; 기억은 화면(localStorage)이 하고 생성 요청마다 함께 보낸다(_gen_opts).
        self.fair_weights: dict = {}
        self.fatigue_weights: dict = {}
        # 직전 재생성·적용이 고정 칸 밖에서 바꾼 칸 수 — 변경 최소성. 새 입력(set_config)이면 비운다.
        self.last_change: dict | None = None
        # 작업 기록 — 이 탭에서 상태를 바꾼 요청을 순서대로(경로·본문·올린 파일·오류). '문의 파일'(api_download_voc)이
        # 통째로 담아 가고, 받는 쪽(tools/voc_replay.py)이 같은 순서로 다시 불러 그 화면을 재현한다.
        # Worker 메모리에만 있다 — 탭을 닫으면 사라지고, 사용자가 '문의 파일 받기'에서 파일을 받기 전에는 어디로도 안 나간다.
        self.journal: list = []
        self.journal_dropped: int = 0          # 상한을 넘어 버린 앞쪽 기록 수(0이 아니면 처음부터의 재현은 안 된다)
        self.journal_seq: int = 0
        self.voc_filename: str = ""            # 직전에 만든 문의 파일의 이름(api_download_filename_voc)


S = State()


class ApiError(Exception):
    pass


def _err(msg: str) -> str:
    return json.dumps({"error": msg}, ensure_ascii=False)


# ---------------------------------------------------------------- 작업 기록(문의 파일용)
# 파트장이 "이상해요"라고 알려올 때 필요한 것은 그 화면에 이르기까지 무엇을 넣고 무엇을 눌렀는가다. 말로 받으면
# 빠지고 틀린다 — 그래서 상태를 바꾸는 API마다 요청을 그대로 적어 둔다(@_journaled). 경로 이름은 pyworker.js의
# 경로표와 같은 글자여야 한다: 받는 쪽이 그 경로로 다시 부르기 때문이다(tests/test_voc_bundle.py가 대조한다).
# 기록 줄 수 상한 — 넘으면 앞에서부터 버리고 journal_dropped를 올린다. 400이던 것을 올렸다(2026-11-12): 새로고침 뒤
# '직전 작업 복원'은 고정 칸을 한 칸씩 편집으로 다시 올리는데, [야간 먼저]로 야간을 확정한 표는 고정 칸이 2~3백 개라
# 복원 한 번에 상한 가까이 찼다. 앞이 잘린 문의는 처음부터 다시 밟을 수 없다(관리자 모드가 기록된 표만 얹어 보여 준다).
# 칸 수정 한 줄은 200바이트 남짓이라 2000줄이어도 문의 파일은 1MB를 넘지 않는다.
JOURNAL_MAX = 2000
JOURNAL_FILE_BYTES = 8_000_000    # 기록이 붙들고 있는 올린 파일 합계 상한(입력①②는 수십 KB라 수십 번은 들어간다)
#: 결과로 새 표가 나오는 경로 — 기록에 그때의 표(grid)·시드·필수 위반 수·형평성 점수를 같이 남긴다.
#: '생성 직후 표'와 '지금 표'의 차이가 곧 파트장이 손으로 고친 자리다.
_JOURNAL_SNAPSHOT = {"/api/generate", "/api/generate_seed", "/api/apply", "/api/regenerate",
                     "/api/select_attempt", "/api/upload_month"}
#: 기록하는 경로 → 함수 이름. 데코레이터가 채운다.
JOURNALED: dict = {}


def _journal_trim():
    while len(S.journal) > JOURNAL_MAX:
        S.journal.pop(0)
        S.journal_dropped += 1
    total = 0
    for e in reversed(S.journal):               # 새 것부터 세고, 상한을 넘는 오래된 파일은 바이트만 놓는다
        b = e.get("_bytes")
        if b is None:
            continue
        total += len(b)
        if total > JOURNAL_FILE_BYTES:
            e["_bytes"] = None
            e["file_dropped"] = True


def _journaled(path: str):
    """상태를 바꾸는 API에 붙인다. 요청(본문 또는 올린 파일)과 결과(오류 문구)를 S.journal에 남긴다.
    기록이 본 동작을 깨면 안 된다 — 기록 쪽 예외는 전부 삼킨다."""
    def deco(fn):
        JOURNALED[path] = fn.__name__

        @functools.wraps(fn)
        def wrapper(*args):
            entry = {"path": path}
            try:
                S.journal_seq += 1
                entry["n"] = S.journal_seq
                entry["t"] = round(time.time(), 1)
                arg = args[0] if args else None
                if isinstance(arg, (bytes, bytearray, memoryview)) or hasattr(arg, "to_py"):
                    data = bytes(arg.to_py()) if hasattr(arg, "to_py") else bytes(arg)
                    entry["_bytes"] = data
                    entry["size"] = len(data)
                elif isinstance(arg, str) and arg:
                    try:
                        entry["body"] = json.loads(arg)
                    except ValueError:
                        entry["body_raw"] = arg[:2000]
                if path == "/api/edit" and S.sch is not None and isinstance(entry.get("body"), dict):
                    sid, day = entry["body"].get("staff_id"), entry["body"].get("day")
                    if sid in S.sch.grid and isinstance(day, int) and not isinstance(day, bool) \
                            and 0 <= day < S.sch.num_days:
                        entry["was"] = str(S.pending_edits.get((sid, day), S.sch.grid[sid][day]))
            except Exception:
                pass
            out = fn(*args)
            try:
                if isinstance(out, str):
                    if out.startswith('{"error"'):
                        entry["error"] = json.loads(out).get("error")
                    elif path in _JOURNAL_SNAPSHOT:
                        st = json.loads(out)
                        if isinstance(st, dict) and "grid" in st:
                            entry["snapshot"] = {
                                "grid": st["grid"], "seed": st.get("current_seed"), "round": st.get("round"),
                                "hard_count": (st.get("report") or {}).get("hard_count"),
                                "fair_total": (st.get("fair") or {}).get("total"),
                            }
                elif out is None:
                    entry["error"] = "(빈 응답)"
                entry["round"] = S.round
                entry["pending"] = len(S.pending_edits)
                entry["locked"] = len(S.locked_cells)
                S.journal.append(entry)
                _journal_trim()
            except Exception:
                pass
            return out
        return wrapper
    return deco


def _strict_int(value) -> int:
    """설정 숫자칸을 '있는 그대로'만 정수로 읽는다 — 못 읽으면 ValueError.

    int()로 받으면 5.9가 5로, 3.9가 3으로 조용히 잘린다. 최소인력이 그렇게 잘리면 인원
    기준을 낮춰놓고도 "입력 기준을 모두 지켰습니다"라는 결과가 나온다. INF/NaN은 int()가
    OverflowError·ValueError를 서로 다르게 던져서 영어 예외가 화면까지 새 나갔다.
    사람 수·일수는 소수일 수 없으므로 반올림하지 말고 반려한다."""
    if isinstance(value, bool):
        raise ValueError("bool")
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        if value != value or value in (float("inf"), float("-inf")) or value != int(value):
            raise ValueError("정수가 아님")
        return int(value)
    if isinstance(value, str):
        t = value.strip()
        if not t or not re.fullmatch(r"[+-]?\d+", t):
            raise ValueError("정수 문자열이 아님")
        return int(t)
    raise ValueError("숫자가 아님")


#: 연속근무제한의 하한. 2 이하면 주간 블록 3~4일(H6-1)과 동시에 지킬 수 없어, 엔진은
#: 오류 없이 '근무 2일·쉼 1일'만 반복하는 근무표를 내놓는다 — 실제로 12월 근무표가 전원
#: 2일씩 끊기고 OFF가 늘어 잔휴가 -5씩 깎인 채 나왔다(샘플 재현: H6-1 9→83건, 최소인력
#: 미달 0→24건). 3·4처럼 일부러 엄격하게 쓰는 값은 받는다.
MIN_CONSECUTIVE_LIMIT = 3
CONSECUTIVE_LIMIT_WHY = ("2 이하면 주간 블록 3~4일(H6-1)을 지킬 수 없어 모든 근무가 2일씩 끊기고 "
                         "최소인력도 모자라게 됩니다. 보통은 5입니다.")


def _validate_params(params: dict):
    """설정 숫자칸(연속근무제한/월최대야간/야간목표/최소인력)에 음수 등 말이 안 되는
    값이 들어오면 조용히 받아 엔진에 넘기는 대신(연속근무제한이 음수면 하루짜리
    근무조차 매번 위반으로 잡혀 사실상 빈 근무표가 나온다) 여기서 먼저 막는다.
    화면 숫자칸의 min= 속성은 스핀 버튼에만 적용되고 직접 타이핑은 못 막기 때문에
    서버(여기선 워커) 쪽에서 한 번 더 검증해야 한다."""
    def _bad(key, label, min_val):
        if key not in params:
            return None
        try:
            iv = _strict_int(params[key])
        except ValueError:
            return f"{label} 값이 올바르지 않습니다 (입력값: {params[key]!r})."
        if iv < min_val:
            msg = f"{label}은(는) {min_val} 이상이어야 합니다 (입력값: {iv})."
            if key == "max_consecutive_work":
                msg += " " + CONSECUTIVE_LIMIT_WHY
            return msg
        return None

    for key, label, min_val in (
        ("max_consecutive_work", "연속근무제한", MIN_CONSECUTIVE_LIMIT),
        ("off_max_per_month", "월 최대야간", 0),
        ("night_quota_low", "야간목표하한", 0),
        ("night_quota_high", "야간목표상한", 0),
    ):
        err = _bad(key, label, min_val)
        if err:
            return err
    if "night_quota_low" in params and "night_quota_high" in params:
        try:
            low, high = int(params["night_quota_low"]), int(params["night_quota_high"])
            if high < low:
                return (f"야간목표상한({high})은 야간목표하한({low})보다 작을 수 없습니다.")
        except (TypeError, ValueError):
            pass  # 형식 오류는 위 _bad()에서 이미 걸러짐
    if "off_max_per_month" in params and "night_quota_low" in params:
        # 월 최대야간 0·2에 야간목표하한 4처럼 서로 모순되는 설정이 그대로 통과했다 — 결과는
        # 빨간 근무표(야간 분포 [0, 2, 15])인데 "설정이 모순"이라는 말은 어디에도 없었다
        # (v0.87 리뷰 F-4). 두 값을 어떻게 읽어야 할지 갈리므로 반려한다.
        try:
            cap, low = int(params["off_max_per_month"]), int(params["night_quota_low"])
            if cap < low:
                return (f"월 최대야간({cap})이 야간목표하한({low})보다 작습니다 — 한 사람이 야간을 "
                        f"적어도 {low}회 서야 하는데 {cap}회까지만 허용하는 모순이라 둘 중 하나를 "
                        "고쳐주세요(보통 월 최대야간 6, 야간목표 4~6).")
        except (TypeError, ValueError):
            pass
    def _check_min_staff_row(label: str, rows: dict):
        for shift_key, v in (rows or {}).items():
            try:
                # int()가 아니라 _strict_int() — int()면 5.9가 5로 조용히 잘려, 인원 기준을
                # 낮춰놓고도 "모두 지켰습니다"가 나온다. v0.81에서 옛 Flask판만 고치고 이쪽은
                # int()로 남아 있었다(화면 readMinStaffCell이 먼저 막아 실사용 피해는 없었다).
                iv = _strict_int(v)
                if iv < 0:
                    return f"최소인력({label}/{shift_key}) 값은 0 이상이어야 합니다 (입력값: {v})."
                # 글자로 온 숫자('6')는 숫자로 바꿔 둔다 — 검사는 통과하는데 값은 글자 그대로 남아, 뒤에서 더할 때
                # 파이썬 예외(unsupported operand type(s) for +: 'int' and 'str')가 화면까지 나갔다(2026-11-14).
                rows[shift_key] = iv
            except ValueError:
                return f"최소인력({label}/{shift_key}) 값이 올바르지 않습니다 (입력값: {v!r})."
        return None

    for period, rows in (params.get("min_staff") or {}).items():
        if period == "weekday_by_dow":
            # 평일을 요일별(월~금)로 따로 지정한 경우 — {"0": {...}, ..., "4": {...}}로
            # 한 단계 더 중첩돼 있어 다른 항목과 같은 루프로 못 돈다.
            for dow, day_rows in (rows or {}).items():
                err = _check_min_staff_row(f"평일·{dow}", day_rows)
                if err:
                    return err
            continue
        err = _check_min_staff_row(period, rows)
        if err:
            return err
    return None


def _param_warnings(params: dict, year: int, month: int) -> list:
    """반려는 아니지만 모르고 지나가면 이상한 근무표가 '정상 완료'로 나오는 설정 — 경고 문장들.

    - 최소인력이 전부 0: 39명 전원이 한 달 OFF(8A·NK만 배정)인 표가 경고 없이 나왔다(F-5).
      '저장한 설정 지우기' 뒤 0으로 채운 실수가 그대로 간다. 읽는 법은 하나(아무도 안 서는
      병동)라 막지 않고 알린다.
    - 연속근무제한·월 최대야간이 달 일수보다 큼: 사실상 제한이 없다는 뜻인데 그걸 모르고
      적었을 수 있다(F-18)."""
    import calendar as _cal
    out = []
    try:
        nd = _cal.monthrange(int(year), int(month))[1]
    except (TypeError, ValueError):
        return out
    rows = []
    for period, body in (params.get("min_staff") or {}).items():
        if period == "weekday_by_dow":
            rows.extend((body or {}).values())
        else:
            rows.append(body)
    vals = []
    for body in rows:
        for v in (body or {}).values():
            try:
                vals.append(_strict_int(v))
            except ValueError:
                pass
    if vals and all(v == 0 for v in vals):
        out.append("⚠ 최소인력이 모두 0입니다 — 아무도 근무하지 않는(전원 OFF) 근무표가 "
                   "그대로 만들어집니다. 근무인력 표의 D·E·N 칸을 채워주세요.")
    for key, label, unit, usual in (("max_consecutive_work", "연속근무제한", "일", 5),
                                    ("off_max_per_month", "월 최대야간", "회", 6)):
        try:
            v = _strict_int(params[key])
        except (KeyError, ValueError):
            continue
        if v > nd:
            out.append(f"⚠ {label} {v}{unit}은 이 달 일수({nd}일)보다 커서 사실상 제한이 없습니다 — "
                       f"의도한 값인지 확인해주세요(보통 {usual}).")
        elif key == "max_consecutive_work" and v > usual:
            # 6·7처럼 '말은 되는' 값은 아무 말 없이 받았다 — 5를 6으로 잘못 친 것과 일부러 늘린 것을 가를 수 없으니
            # 막지는 않고 한 줄 알린다(2026-11-14 오입력 검증). 그대로 두면 엿새 연속 근무가 든 표가 조용히 나간다.
            out.append(f"⚠ {label}이 {v}일입니다 — 보통 {usual}일입니다. {v}일 연속 근무까지 허용하는 값이 맞는지 "
                       "확인해주세요.")
    return out


def _date_input_problem(data: dict) -> str | None:
    """연·월·공휴일이 날짜로 성립하지 않으면 한국어로 — 예전엔 Generator가 던진 Python 원문
    ('bad month number 13; must be 1-12', 'day is out of range for month')이 그대로 화면에
    새 나갔다(v0.87 리뷰 F-13). 화면은 select·달력이라 드물지만, 영어 예외는 어떤 경로로도
    나가지 않아야 한다."""
    import calendar as _cal
    import datetime as _dt
    try:
        y, m = _strict_int(data.get("year")), _strict_int(data.get("month"))
    except ValueError:
        return f"연·월이 숫자가 아닙니다 (입력값: {data.get('year')!r}년 {data.get('month')!r}월)."
    if not (1 <= m <= 12):
        return f"월은 1~12 사이여야 합니다 (입력값: {m})."
    if not (2000 <= y <= 2100):
        return f"연도 {y}는 다룰 수 없는 값입니다 — 2000~2100 사이여야 합니다."
    nd = _cal.monthrange(y, m)[1]
    # 화면은 공휴일 표를 **한 해 전체**로 보낸다(엔진이 그 달 것만 골라 쓴다) — 다른 달의
    # 날짜는 정상이므로 '실제 날짜인가'만 본다.
    for key in ("holidays", "substitute_holidays"):
        for h in (data.get("params") or {}).get(key) or []:
            try:
                _dt.date.fromisoformat(str(h))
            except (TypeError, ValueError):
                return (f"공휴일 날짜 '{h}' — 실제 날짜로 읽을 수 없습니다. 'YYYY-MM-DD' 형식의 "
                        f"있는 날짜여야 합니다({y}년 {m}월은 1~{nd}일).")
    return None


def _require_generated():
    if S.gen is None or S.sch is None:
        raise ApiError("아직 생성된 근무표가 없습니다")


# ---------------------------------------------------------------- 상태 직렬화

def _display_grid() -> dict:
    """화면/편집용 값은 "OFF"를 그대로 유지한다(셀 편집·순환·드롭다운이 이 값을 기준으로
    동작하므로) — "X"/"/" 표시 변환은 export/annual_grid 등 출력 시점에만 적용한다."""
    out = {}
    for s in _ordered_staff_for_display():
        row = list(S.sch.grid[s.id])
        for d in range(S.sch.num_days):
            if (s.id, d) in S.pending_edits:
                row[d] = S.pending_edits[(s.id, d)]
        out[s.id] = [str(v) for v in row]
    return out


def _off_display(sid: str, day: int, code: str) -> str:
    """OFF는 "OFF" 대신 원티드오프="X" / 일반오프="/"로 표시(병원 표준 표기, §excel_export와 동일 규칙)."""
    if code != "OFF":
        return code
    return "X" if (sid, day) in S.sch.wanted else "/"


def _staff_meta():
    return [
        {"id": s.id, "role": s.role, "level": s.level,
         "allowed": [x.value for x in s.allowed_shifts],
         "is_partjang": s.is_partjang, "is_nk": s.is_nk,
         "no_night": s.no_night,
         # 화면이 이름 옆에 표시하고, 하단 '지정 인원' 행을 셀 때 쓴다.
         "is_designated": s.is_designated,
         "is_night_leader": s.is_night_leader,
         "night_block_pref": s.night_block_pref,
         "off_balance": S.sch.carryover[s.id].off_balance,
         # 화면 오른쪽 '부담' 열이 쓴다 — 야간 목표(4·6, 야간전담은 15)와 전월 말에서 이어진
         # 연속근무일수(1일부터 이어 세야 월초 연속근무가 실제보다 짧게 보이지 않는다).
         "night_target": (S.gen.nk_target if s.is_nk else S.sch.night_target.get(s.id)),
         "carry_run": (S.sch.carryover[s.id].consecutive_work_days
                       if S.sch.carryover[s.id].last_shift_type in WORK_SHIFTS else 0)}
        for s in _ordered_staff_for_display()
    ]


def _days_meta():
    _festival = lunar_festival_dates(S.sch.year)
    return [
        # min: 그 날의 최소인력. 화면 하단 '일별 인원' 줄이 미달을 빨갛게 칠할 때 쓴다 —
        # 요일별 지정(weekday_by_dow)까지 여기서 풀어 보내야 화면이 같은 규칙을 두 번
        # 구현하지 않는다.
        # festival: 설·추석 연휴인 날. 연간근무표의 '설/추석오프' 열이 이걸 보고 센다.
        # 요일이 아니라 실제 날짜로 판정한다 — 날짜 계산을 여기서 다시 하면 달력 규칙이
        # 두 벌이 되고, 그게 이 프로젝트가 반복해서 밟은 함정이다.
        {"n": i + 1, "dow": d.dow_name, "weekend": d.day_type != DAY_WEEKDAY,
         "substitute": d.is_substitute, "auto_8a": d.auto_8a,
         "festival": d.date in _festival,
         "min": min_staff_for(d, S.gen.params.min_staff)}
        for i, d in enumerate(S.gen.days)
    ]


def _days_meta_for(year: int, month: int, num_days: int):
    """생성된 달이 아닌 임의의 달의 날짜 메타(요일·주말·명절) — 출력②의 설/추석오프 열을
    세는 _count_shift_codes의 days 인자와 같은 모양. 위 _days_meta와 판정 규칙이 같다."""
    days = build_calendar(year, month, [], [])
    festival = lunar_festival_dates(year)
    return [{"n": i + 1, "dow": d.dow_name, "weekend": d.day_type != DAY_WEEKDAY,
             "festival": d.date in festival}
            for i, d in enumerate(days[:num_days])]


# [야간 먼저] 1단계에서 보이는 위반 — 야간 배치만으로 생기거나 풀리는 규칙. 1단계 표는 주간도 이미 짜여
# 있지만(화면이 가릴 뿐) 그 주간은 2단계에서 다시 짜이므로, 주간 위반 숫자를 보이면 파트장은 고칠 수도 없는
# 것을 세고 있게 된다. H2-8(야간 다음 날 주간)은 뺀다 — 2단계가 야간 뒤 칸에 주간을 넣지 않아 저절로 풀린다.
_NIGHT_RULES = {"H2-1", "H2-2", "H2-3", "H2-4", "H2-5", "H2-6", "H2-7", "H5-1", "H5-2", "H6-4", "H7-1",
                "S1", "S8", "S9", "S11", "S12"}
_NIGHT_DAY_RULES = {"H1-1", "H1-4", "H1-5"}          # 날짜별 인원 규칙 — 그중 야간(N) 조 것만
_NIGHT_MSG = re.compile(r"^\d+일 N\b")


def _is_night_violation(v: dict) -> bool:
    rule = v.get("rule") or ""
    if rule in _NIGHT_RULES:
        return True
    return rule in _NIGHT_DAY_RULES and bool(_NIGHT_MSG.match(v.get("message") or ""))


def _report_summary():
    report = build_report(S.sch, S.gen.days, S.gen.params, S.gen.requests)
    hidden = 0
    if S.night_stage:
        keep_h = [v for v in report["hard_violations"] if _is_night_violation(v)]
        keep_s = [v for v in report["soft_violations"] if _is_night_violation(v)]
        hidden = (len(report["hard_violations"]) - len(keep_h)) + (len(report["soft_violations"]) - len(keep_s))
        report = dict(report, hard_violations=keep_h, soft_violations=keep_s)
    requests_all = [
        {"staff_id": r.staff_id, "date": r.date, "type": str(r.type),
         "accepted": bool(r.accepted), "reason": r.reject_reason,
         "rule": r.reject_rule}
        for r in S.gen.requests
    ]
    bad_days = [d for d in report["daily"] if not d["ok"]]
    # H1-4/H1-5/H4-1/H4-2/H6-1/H6-4는 월경계 등에서 로컬 수리만으로 0건을 보장하기
    # 어려운 최선노력 규칙 — 상세 목록(hard)에는 그대로 남기되, 대표 카운트에서는
    # 제외한다. 화면에서 "정말 못 채운 것(빨강)"과 "거의 다 됐지만 최선노력 규칙만
    # 남은 것(노랑)"을 구분해서 보여줄 수 있도록 항목마다 best_effort 플래그를 단다.
    hard_list = [dict(v, best_effort=v["rule"] in _BEST_EFFORT_RULES)
                for v in report["hard_violations"]]
    strict_hard = [v for v in hard_list if not v["best_effort"]]
    # 재생성은 잠긴 칸(수기 수정·되올린 수정본)을 그대로 두고 나머지만 다시 짠다. 잠긴 칸이
    # 걸린 위반은 몇 번을 다시 돌려도 남는데, 예전엔 그 사실을 어디에도 적지 않아 파트장이
    # 33초짜리 재생성을 세 번 돌리고도 "왜 안 풀리나"에서 멈췄다(v0.87 리뷰 F-20).
    locked_pairs = set(S.locked_cells or {})
    locked_days = {d for (_sid, d) in locked_pairs}
    locked_hits = [
        v for v in strict_hard
        if v.get("day") is not None and (
            ((v.get("staff_id") or ""), v["day"] - 1) in locked_pairs
            or (not v.get("staff_id") and (v["day"] - 1) in locked_days))]
    locked_note = None
    if locked_pairs and strict_hard:
        locked_note = (
            f"잠긴 칸 {len(locked_pairs)}개(수기 수정·되올린 수정본)는 그대로 두고 나머지만 다시 "
            f"짰습니다 — 남은 필수 위반 {len(strict_hard)}건 중 {len(locked_hits)}건은 잠긴 칸이 "
            "있는 날·사람의 것이라 그 칸을 풀기 전에는 재생성으로 해소되지 않습니다.")
    return {
        "hard_count": len(strict_hard),
        "locked_count": len(locked_pairs),
        "locked_violations": len(locked_hits),
        "locked_note": locked_note,
        "hard": hard_list,
        "soft_count": len(report["soft_violations"]),
        "soft": report["soft_violations"],
        "off_range": report["off_range"],
        "per_person": report["per_person"],
        "requests": report["requests"],
        "requests_all": requests_all,
        "daily": report["daily"],
        "bad_days_count": len(bad_days),
        "night_block_hist": report["night_block_length_hist"],
        "night_gap_hist": report["night_gap_hist"],
        "logs": report["logs"],
        "timed_out": report["timed_out"],
        # 1단계(야간만 보기)면 True — 위 목록·숫자는 야간 관련 규칙만이고, hidden_count건은 2단계 뒤에 다시 센다.
        "night_view": bool(S.night_stage),
        "hidden_count": hidden,
    }


def _locked_keys():
    return [f"{sid}:{d}" for (sid, d) in S.locked_cells]


def _pending_keys():
    return [f"{sid}:{d}" for (sid, d) in S.pending_edits]


def _wanted_keys():
    return [f"{sid}:{d}" for (sid, d) in S.sch.wanted]


def _full_state():
    p = S.gen.params
    return {
        "ward_id": S.cfg.get("ward_id", ""),
        "year": S.gen.year, "month": S.gen.month,
        "num_days": S.sch.num_days,
        "staff": _staff_meta(),
        "days": _days_meta(),
        "grid": _display_grid(),
        "locked": _locked_keys(),
        "pending": _pending_keys(),
        "wanted": _wanted_keys(),
        # B팀(신입)은 스케줄링에 전혀 관여하지 않는 이름뿐인 목록이라 staff/grid에는
        # 안 넣는다 — 화면에는 이름만 빈칸 행으로 보여주고(파트장이 나중에 직접
        # 배정), 다운로드 파일(excel_export.py)과 같은 정보 소스(params.team_b_names)를 쓴다.
        "team_b": p.team_b_names,
        # B팀 근무는 엔진 grid에 없다 — 파트장이 화면에서 채운 값을 따로 실어 보낸다.
        "team_b_grid": S.team_b_grid,
        # 점수표 줄마다 표시점수(0~100)를 붙인다 — 엔진이 고른 시드와 표시점수 1등이 갈리는 자리를 한 표에서 보게.
        # 같은 산식(fairscore.score_from_components)이라 화면 '공정성 점수'와 숫자가 같다. 시드 선택 기준은 그대로다.
        "attempt_table": _attempt_table_with_display(),
        "current_seed": S.gen.seed,
        # 지난달 사람별 부담(연간근무표가 있을 때만) — 부담 열 툴팁과 부담 요약의 '지난달 대비' 줄
        "prev_burden": _prev_month_burden(),
        "round": S.round,
        "night_stage": S.night_stage,
        "nights_fixed": S.nights_fixed,
        "params_summary": {
            "min_staff": p.min_staff, "max_nights": p.max_nights,
            "max_consecutive_work": p.max_consecutive_work,
            "leader_8a_as_prn": p.leader_8a_as_prn,
            "holidays": p.holidays, "nk_count": p.nk_count,
        },
        "report": _report_summary(),
        # 공정성 점수(0~100, 축 다섯)와 사람별 '내 달 요약' — 정의는 nurse_scheduler/fairscore.py 한 곳.
        # 화면은 숫자를 그리기만 한다(화면이 따로 세면 점수표·보고서와 어긋난다).
        "fair": _fair(S.sch),
        # 미적용 편집을 얹은 표의 점수 — 파트장이 칸을 고치는 동안 "고치면 점수가 어떻게 되나"를 바로 본다.
        # 편집이 없으면 None(화면은 원래 점수만 보인다).
        "fair_edited": _fair(_sch_with_pending()) if S.pending_edits else None,
    }


def _attempt_table_with_display() -> list:
    rows = S.attempt_table or []
    if not rows or S.gen is None or S.sch is None:
        return list(rows)
    n_norm = sum(1 for s in S.gen.staff if not s.is_partjang)
    n_req = len(S.gen.requests)
    out = []
    for r in rows:
        d = dict(r)
        try:
            d["disp"] = fairscore_display(r, n_norm, S.sch.num_days, n_req, S.fair_weights)["total"]
        except Exception:
            d["disp"] = None
        out.append(d)
    return out


def _fair(sch) -> dict:
    """공정성 점수 한 벌(fairscore.summary) — 상태·엑셀·보고서가 같은 함수를 부른다."""
    return fairscore_summary(S.gen, sch, S.gen.days, staff_table=S.staff_table_in,
                             weights=S.fair_weights, fatigue_w=S.fatigue_weights, change=S.last_change)


def _sch_with_pending():
    """미적용 편집을 얹은 표의 복사본. grid 대입은 _TrackedRow가 가로채 증분 카운터(주말·야간 수)까지
    갱신하므로 fairscore가 그대로 센다(api_feedback과 같은 방법)."""
    temp = copy.deepcopy(S.sch)
    for (sid, d), shift in S.pending_edits.items():
        temp.grid[sid][d] = shift
    return temp


def _full_state_json() -> str:
    return json.dumps(_full_state(), ensure_ascii=False)


_OFF_CODES = ("OFF", "X", "/")  # "OFF"(구버전 파일 호환) / "X"(원티드오프) / "/"(일반오프)



def _night_block_counts(row: list) -> tuple:
    """근무 코드 리스트 하나(한 달치)에서 야간(N/NK) 연속블록 길이별 건수를 센다."""
    b2 = b3 = other = 0
    i, n = 0, len(row)
    while i < n:
        if row[i] in ("N", "NK"):
            j = i
            while j + 1 < n and row[j + 1] in ("N", "NK"):
                j += 1
            length = j - i + 1
            if length == 2:
                b2 += 1
            elif length == 3:
                b3 += 1
            else:
                other += 1
            i = j + 1
        else:
            i += 1
    return b2, b3, other


def _count_shift_codes(row: list, days: list) -> tuple:
    """행(한 달치 근무 코드)에서 D/E/prn(8A 포함) 개수와 주말·휴일 OFF 개수를 센다."""
    d_cnt = sum(1 for v in row if v == "D")
    e_cnt = sum(1 for v in row if v == "E")
    # 10A도 prn 계열이다 — 8A·9A와 시작시각만 다른 같은 근무인데 여기서만 빠져 있어,
    # (누적D + 누적E + 누적prn)이 누적근무일보다 작아지고 있었다(파트장 확인, 2026-08).
    prn_cnt = sum(1 for v in row if v in ("prn", "8A", "9A", "10A"))
    wh_off = sum(1 for v, d in zip(row, days) if v in _OFF_CODES and d.get("weekend"))
    # 설/추석 오프는 주말휴일오프와 '오프 판정'을 똑같이 쓴다 — 두 열을 나란히 놓고
    # 비교하는 열이라 기준이 다르면 파트장이 잘못 읽는다. 다른 건 세는 날짜뿐이다.
    fest_off = sum(1 for v, d in zip(row, days) if v in _OFF_CODES and d.get("festival"))
    return d_cnt, e_cnt, prn_cnt, wh_off, fest_off



def _ordered_staff_for_display():
    """연간근무표 등 사람이 눈으로 보는 목록의 인원 순서.

    S.sch.staff는 재시도(seed>0) 때 검색 다양성을 위해 무작위로 섞인 순서 그대로라
    화면/파일에 그대로 쓰면 뒤죽박죽으로 보인다 — 대신 원래 업로드/입력된 인원표
    순서(S.cfg["staff"])를 따르되, 파트장만 맨 위로 올린다."""
    orig_order = {s["id"]: i for i, s in enumerate(S.cfg["staff"])}
    return sorted(S.sch.staff,
                 key=lambda s: (0 if s.is_partjang else 1, orig_order.get(s.id, 10**9)))


def _build_updated_staff_table():
    """이번 달 생성 결과를 이전 연간근무표(S.staff_table_in)에 얹어 갱신본을 만든다.

    통계는 항상 "이번 달 실제 생성 결과"만 더해서 한 걸음씩 앞으로 나간다 —
    월간근무표(이어붙이기 규칙용)와는 별개로, 연간근무표 스스로 다음 입력이 된다.
    연간 그리드는 해가 바뀌면(1/1) 리셋한다.
    """
    import datetime

    prev = S.staff_table_in or {}
    prev_stats = prev.get("stats", {})
    prev_dates = prev.get("annual_dates", [])
    prev_grid = prev.get("annual_grid", {})

    grid = _display_grid()
    days = _days_meta()
    next_carry = S.gen.build_next_carryover()

    stats = {}
    for s in S.sch.staff:
        row = grid[s.id]
        b2, b3, _bo = _night_block_counts(row)
        # 공휴일도 주말과 같이 센다 — 평일 공휴일에 선 야간을 빼면 바로 아래 열인
        # 누적주말휴일오프(토·일·공휴일)와 기준이 달라, 두 열을 나란히 놓고 보는
        # 파트장이 잘못 읽는다(파트장 확인, 2026-08).
        weekend_night = sum(1 for v, d in zip(row, days)
                            if v in ("N", "NK") and d["weekend"])
        d_cnt, e_cnt, prn_cnt, wh_off, fest_off = _count_shift_codes(row, days)
        base = prev_stats.get(s.id, {})
        stats[s.id] = {
            "night": base.get("night", 0) + S.sch.nights_in_month(s.id),
            "workday": round(base.get("workday", 0)
                             + S.sch.workday_units_in_month(s.id), 2),
            "off": base.get("off", 0) + S.sch.offs_in_month(s.id),
            "weekend_night": base.get("weekend_night", 0) + weekend_night,
            "blocks_2": base.get("blocks_2", 0) + b2,
            "blocks_3": base.get("blocks_3", 0) + b3,
            "months": base.get("months", 0) + 1,
            "recent_night_score": next_carry.get(s.id, {}).get("recent_night_score", 0.0),
            "cum_d": base.get("cum_d", 0) + d_cnt,
            "cum_e": base.get("cum_e", 0) + e_cnt,
            "cum_prn": base.get("cum_prn", 0) + prn_cnt,
            "cum_weekend_holiday_off": base.get("cum_weekend_holiday_off", 0) + wh_off,
            "cum_festival_off": base.get("cum_festival_off", 0) + fest_off,
            # 전월잔휴/잔휴는 OCS 원본과 같은 짝이다 — 앞은 이번 달을 시작할 때의 잔여,
            # 뒤는 이번 달을 반영한 뒤의 잔여(=다음 달 시작값).
            "prev_off_balance": round(S.sch.carryover[s.id].off_balance, 2),
            "off_balance": next_carry.get(s.id, {}).get("off_balance", 0.0),
        }

    this_year = S.gen.year
    if prev_dates and prev_dates[0][:4] == str(this_year):
        base_dates = [datetime.date.fromisoformat(x) for x in prev_dates]
    else:
        base_dates = []
    # 이어붙일 과거 구간은 '이번 달 1일 전'까지만 — 이번 달 칸이 섞여 있으면 아래에서
    # 이번 달을 덧붙일 때 같은 날짜가 두 번 들어간다(전입자가 가져온 이번 달 기록이
    # 그런 경우다. 그 기록은 이월정보 계산에 이미 쓰였고 여기서는 역할이 끝났다).
    # 계속 근무자에게까지 이번 달이 채워진 파일은 set_config에서 미리 막는다.
    first_of_month = datetime.date(this_year, S.gen.month, 1)
    keep = len([d for d in base_dates if d < first_of_month])
    base_dates = base_dates[:keep]
    this_month_dates = [datetime.date(this_year, S.gen.month, d + 1)
                        for d in range(S.sch.num_days)]
    annual_dates = base_dates + this_month_dates

    # 전입자가 가져온 전 병동 기록은 이월정보·야간형평성 계산에 쓰고 나면 역할이 끝난다.
    # 우리 병동 연간 그리드에 그대로 남기면 그 사람이 없던 달의 날짜별 인력 통계
    # (듀티별 평균·고연차/저연차)에까지 섞여 들어가므로, 입사 이전 칸은 비워서 이어붙인다
    # (다음 달 이월은 '이번 달' 실적으로 계산되니 지워도 연속성에는 영향이 없다).
    transferred = set((S.staff_table_in or {}).get("transferred_in") or [])

    annual_grid = {}
    for s in S.sch.staff:
        if s.id in transferred:
            base_codes = []
        else:
            base_codes = (prev_grid.get(s.id, []) if base_dates else [])
        base_codes = (base_codes + [""] * len(base_dates))[:len(base_dates)]
        this_month_codes = [_off_display(s.id, d, c) for d, c in enumerate(grid[s.id])]
        annual_grid[s.id] = base_codes + this_month_codes

    # 전출자 이력 보존 — 이미 전출로 기록돼 있던 사람들을 그대로 이어받고, 이번 달에
    # 새로 빠진 사람(입력②에는 있는데 입력①에 없음)을 추가한다. 통계는 재직 마지막
    # 시점 값으로 동결하고, 연간 그리드는 빠진 달부터 빈칸으로 채운다.
    departed = []
    seen = set()
    for p in (prev.get("departed") or []):
        codes = (p.get("codes") or []) if base_dates else []
        codes = (codes + [""] * len(annual_dates))[:len(annual_dates)]
        departed.append({**p, "codes": codes})
        seen.add(p["id"])

    moves = S.roster_moves or {}
    left_tag = f"{S.gen.year}-{S.gen.month:02d}"
    roster_by_id = {s["id"]: s for s in (S.cfg or {}).get("staff", [])}
    # 지금 배정된 사람은 전출자가 될 수 없다 — 이 방어가 없으면 예전 대조 결과가
    # 남아 있을 때 같은 이름이 현재 인원과 '전출' 구역에 둘 다 찍히고, 그 파일은
    # 다음 달 입력②로 다시 올릴 때 '이름 중복'으로 반려돼 연동이 끊긴다.
    current_ids = {s.id for s in S.sch.staff}
    for sid in moves.get("outgoing", []):
        if sid in seen or sid in current_ids:
            continue
        base_codes = (prev_grid.get(sid, []) if base_dates else [])
        base_codes = (base_codes + [""] * len(annual_dates))[:len(annual_dates)]
        old = roster_by_id.get(sid, {})
        departed.append({
            "id": sid,
            "role": old.get("role", "간호사"),
            "level": old.get("level", 1),
            "allowed_shifts": old.get("allowed_shifts") or [],
            "left_at": left_tag,
            "stats": prev_stats.get(sid, {}),
            "codes": base_codes,
        })

    return stats, annual_dates, annual_grid, departed


# ================================================================ API 함수
# (경로 하나당 함수 하나 — pyworker.js의 경로표(callBridge)가 이어 준다)

def api_sample() -> str:
    """화면 첫 기본값 — 명단은 샘플 원티드표에서, 나머지는 코드 기본값에서."""
    try:
        cfg = sample_config_dict(SAMPLE_ROSTER_PATH)
    except Exception as e:
        return _err(f"샘플 로드 실패: {e}")
    return json.dumps(cfg, ensure_ascii=False)


def api_sample_requests(body_json=None) -> str:
    """화면 기본값의 예시 신청 — 샘플 원티드표의 신청(2026년 9월분)을 화면 연월로 옮겨 준다. 기본 입력으로 만든
    표에 원티드가 하나도 없어 "기본 입력에 원티드 없어?"가 됐다(2026-11-09). /api/sample에 싣지 않는 이유는
    sample_requests_for 참고. 본문 {year, month}; 없으면 '오늘의 다음 달'."""
    try:
        b = json.loads(body_json) if body_json else {}
    except ValueError:
        return _err("연월 본문을 읽을 수 없습니다")
    try:
        if isinstance(b, dict) and b.get("year") and b.get("month"):
            year, month = int(b["year"]), int(b["month"])
        else:
            from nurse_scheduler.sample_defaults import next_month
            year, month = next_month()
        if not (1 <= month <= 12):
            return _err("월은 1~12여야 합니다")
        reqs = sample_requests_for(SAMPLE_ROSTER_PATH, year, month)
    except Exception as e:
        return _err(f"예시 신청 로드 실패: {e}")
    return json.dumps({"year": year, "month": month, "requests": reqs, "sample": True}, ensure_ascii=False)


#: 임시 파일을 놓을 자리. 브라우저(Pyodide)에서는 가상 파일시스템이라 '/'에도 바로
#: 쓸 수 있어서 예전엔 "/tmp_prev.xlsx"처럼 최상위에 썼다. 그런데 이 파일은 파리티
#: 테스트에서 **진짜 파일시스템 위에서도** 그대로 불린다 — 일반 사용자 권한으로는
#: '/'에 못 써서 업로드가 전부 "Permission denied"로 반려됐고, CI가 그걸 잡을 때까지
#: 배포가 일곱 번 연속 실패했다(로컬에서는 root라 안 보였다).
#: gettempdir()은 Pyodide에서도 '/tmp'라 두 곳 다 안전하다.
def _tmp_path(name: str) -> str:
    return os.path.join(tempfile.gettempdir(), name)


def _write_temp_xlsx(file_bytes, path: str):
    data = bytes(file_bytes.to_py()) if hasattr(file_bytes, "to_py") else bytes(file_bytes)
    with open(path, "wb") as f:
        f.write(data)


# 병동인력표(옛 입력①) 업로드는 없앴다 — 설정·근무인력은 전부 화면에서 입력하고 브라우저에
# 저장한다. load_input_xlsx는 샘플 기본값을 읽는 데만 남는다.


def _unknown_grid_cells(grid, num_days, limit: int = 50):
    """근무표 그리드에서 파서가 모르는 칸을 '이름 N일 코드' 목록으로 모은다.

    조용히 OFF로 바꾸지 않는 이유 — 실제로 근무한 날이 쉰 날로 계산돼 연속근무일수·
    누적근무일·이월 야간블록이 전부 틀어진다. 반대로 예외로 터뜨리면 어디를 고칠지
    알 수 없다. 그래서 어느 사람 몇 일 어떤 코드인지 짚어서 돌려준다."""
    out = []
    for sid, row in (grid or {}).items():
        for d in range(min(num_days, len(row))):
            v = row[d]
            s = "" if v is None else str(v).strip()
            if not s:
                continue
            try:
                parse_shift(s)
            except ValueError:
                out.append(f"{sid} {d + 1}일 '{s}'")
                if len(out) >= limit:
                    return out
    return out




# ─────────────────────────────────────────────────────────────────────────────
# 업로드 결과 메시지는 세 단계로 나눈다. 섞어두면 파트장은 "지금 뭘 해야 하지"에
# 답을 못 얻는다 — 고쳐야 하는지, 봐두기만 하면 되는지가 안 보이기 때문이다.
#
#   ✔ 안내(초록)  "이해했고, 다음엔 이렇게 써주세요"  — 뜻대로 반영됨. 할 일 없음.
#   ? 확인(노랑)  "이건 무슨 의미인가요"            — 못 읽어서 그 칸만 빠짐. 고치면 반영.
#   ✕ 오류(빨강)  "이게 틀렸어요"                  — 파일을 못 쓴다. 고쳐서 다시 올려야 함.
#
# 오류는 예외로 올라가 기존 경로가 처리한다. 여기서는 앞의 둘을 만든다.
_NORMALIZED_MAX = 8
# 두 가지로 읽히는 값 — 짐작해서 넣으면 그 사람 근무·휴가 종류가 조용히 바뀌므로
# 일부러 안 받는다. 안 받는 이유를 말해주지 않으면 왜 반려됐는지 알 수가 없다.
_AMBIGUOUS_HINTS = {
    "휴가": "연차(연)인지 휴(휴가코드)인지 갈려서 받지 않습니다",
}


def _normalized_notice(items):
    """✔ 안내 — 관대하게 읽어준 값을 '무엇을 무엇으로' 보여준다."""
    if not items:
        return None
    head = items[:_NORMALIZED_MAX]
    parts = [f"{it['field']} '{it['typed']}'→'{it['read']}'"
             + (f"({it['count']}칸)" if it["count"] > 1 else "")
             for it in head]
    more = len(items) - len(head)
    tail = f" 외 {more}종" if more > 0 else ""
    return ("이렇게 읽었습니다 — " + ", ".join(parts) + tail
            + ". 뜻은 그대로 반영됐습니다. 다음 달에는 화살표 오른쪽 표준 표기로 "
              "적어주시면 더 확실합니다(표준 표기가 아닌 값은 언젠가 못 읽을 수 있습니다).")


def _join_notices(*parts):
    """여러 안내를 한 칸으로 합친다(빈 것은 버린다).

    ⚠ '야간리더 표시가 효과 없다'를 _unclear_notice 안에 넣지 않는다 — 그 함수의
    문장은 "무슨 뜻인지 정하지 못한 값이 있습니다 … 그 칸만 고쳐서 다시 올리세요"로
    끝난다. 야간리더 O는 **뜻을 못 알아본 값이 아니라 뜻은 분명한데 효과가 없는 값**
    이라, 그 틀에 넣으면 파트장이 표기를 고치려 든다.
    """
    return " ".join(p for p in parts if p) or None


def _unclear_notice(groups):
    """? 확인 — 뜻을 못 정한 값. 무엇이 안 들어갔는지까지 말해야 고칠 마음이 든다.

    groups는 (무엇을, [값들], 그래서 어떻게 됐는지) 목록이다."""
    parts = []
    for label, values, effect in groups:
        vals = sorted(set(str(v) for v in values if str(v).strip()))
        if not vals:
            continue
        shown = ", ".join(f"'{v}'" for v in vals[:6])
        more = f" 외 {len(vals) - 6}개" if len(vals) > 6 else ""
        parts.append(f"{label} {shown}{more} — {effect}")
    if not parts:
        return None
    # 왜 갈리는지 아는 값은 이유까지 말해준다 — "왜 안 되지"에 답이 없으면 파트장은
    # 같은 값을 다시 적거나, 뜻이 다른 코드로 아무거나 바꿔 적는다.
    flat = " ".join(str(v) for _, vs, _ in groups for v in vs)
    why = [f"'{k}'는 {v}" for k, v in _AMBIGUOUS_HINTS.items() if k in flat]
    tail = (" " + ", ".join(why) + ".") if why else ""
    return ("무슨 뜻인지 정하지 못한 값이 있습니다. "
            + " / ".join(parts) + "."
            + tail
            + " 그 칸만 고쳐서 다시 올리시면 됩니다.")


#: 다른 칸의 파일을 올렸을 때 — **올린 칸마다** 할 말이 다르다. 파서는 "어떤 파일로 보이는지"
#: (WrongInputSlotError.kind)만 알려주고, 어느 칸에 올렸는지는 여기서만 안다. 예전엔 원티드표를
#: 다른 칸에 올린 한 방향만 친절했고, 연간근무표를 입력①/수정 칸에 올리면 "2행에서 1일(숫자 1)
#: 열을 찾지 못했습니다"가 떴다 — 파일을 고치러 가지만 고칠 것이 없다(v0.87 리뷰 F-7).
WRONG_SLOT_WORDS = {
    "wanted": {      # 입력① 칸에 올렸는데…
        "staff_table": ("입력②(연간근무표) 파일로 보입니다 — 이 칸(입력①)에는 이번 달 원티드표를 "
                        "올려주세요. 지난달까지 반영된 연간근무표(출력②)는 입력② 칸입니다."),
        "month": ("지난달 근무표(출력① 또는 OCS 근무표) 파일로 보입니다 — 이 칸(입력①)에는 이번 달 "
                  "원티드표를 올려주세요. 지난달 근무표는 입력② 칸에 올리는 파일입니다."),
    },
    "month": {       # 수정 칸(출력① 되올리기)에 올렸는데…
        "wanted": ("입력①(원티드표) 파일로 보입니다 — 이 칸에는 내려받아 엑셀에서 고친 "
                   "출력① 월간근무표를 올려주세요. 원티드 신청을 바꾸려면 입력 화면의 "
                   "입력① 칸에 올린 뒤 다시 생성하시면 됩니다."),
        "staff_table": ("출력②(연간근무표) 파일로 보입니다 — 수정 칸에는 내려받아 고친 출력①"
                        "(월간근무표)을 올려주세요. 연간근무표(출력②)는 다음 달 입력② 칸에 "
                        "올리는 파일입니다."),
    },
}


def _wrong_slot_err(slot: str, e: WrongInputSlotError) -> str:
    return _err(WRONG_SLOT_WORDS.get(slot, {}).get(getattr(e, "kind", ""), str(e)))


@_journaled("/api/upload_wanted")
def api_upload_wanted(file_bytes) -> str:
    """원티드 신청 엑셀(월간근무표와 같은 모양, 별표·X 등 표기) → 신청 목록 자동 변환."""
    path = _tmp_path("wanted.xlsx")
    try:
        _write_temp_xlsx(file_bytes, path)
        data = load_wanted_grid_xlsx(path)
    except WrongInputSlotError as e:
        return _wrong_slot_err("wanted", e)
    except ExcelInputError as e:
        return _err(f"엑셀 오류: {e}")
    except Exception as e:
        return _err(f"파일을 읽을 수 없습니다: {e}")

    # 이 파일의 연월은 '생성할 달'이다(파트장이 OCS에서 그 달 날짜를 복붙해 만든다).
    # 이 파일의 연월이 곧 '만들 달'이다 — 화면 연월은 업로드 뒤 여기에 맞춰진다.
    # 예전엔 '지금 화면에 설정된 달'과 일수를 비교해 다르면 반려했는데, 그러면 9월을
    # 만든 뒤 10월 원티드표를 올리는 정상적인 다음 달 작업이 통째로 막혔다(9월 30일 vs
    # 10월 31일). 정작 위험한 것 — 제목은 9월인데 날짜 칸이 31개인 파일 — 은 파서가
    # 이미 제목 연월과 칸 수를 대조해 막고 있으므로, 여기서 또 볼 이유가 없다.
    # 못 읽은 값은 '오류'가 아니라 '확인'이다 — 파일은 쓸 수 있고, 그 칸만 안 들어갔다.
    warning = None
    unclear = _unclear_notice([
        ("'전입' 칸의", data.get("unknown_transfer_marks") or [],
         "전입자로 잡히지 않았습니다(비우거나 '전입'을 골라주세요)"),
        ("원티드 신청 칸의", data.get("unknown_marks") or [],
         "그 칸의 신청은 반영되지 않았습니다"),
        # 뜻을 못 알아본 것이 아니라 규칙상 받지 않는 칸이다. '인식 못 한 표시'와
        # 같은 줄에 넣으면 표기를 고치면 되는 줄 알고 계속 다시 올리게 된다.
        ("신청할 수 없는 근무가 적힌", data.get("blocked_marks") or [],
         "수면오프(S/)는 신청 대상이 아닙니다 — 월 야간 6회 이상이면 자동으로 붙습니다"),
    ])
    # 야간리더로 표시했는데 아무 일도 하지 않는 사람 — 반려가 아니라 안내다.
    # 표시만 하고 "채웠는데 왜 빨간가"에서 멈추는 것을 막는다(G-02/G-13).
    unclear = _join_notices(unclear, *(data.get("night_leader_noop") or []))
    return json.dumps({"ok": True, "year": data["year"], "month": data["month"],
                       "requests": data["requests"], "unknown_marks": data["unknown_marks"],
                    "blocked_marks": data.get("blocked_marks") or [],
                       "staff": data["staff"], "team_b_names": data.get("team_b_names") or [],
                       "transferred_in": data.get("transferred_in") or [],
                       "transfer_in_dates": data.get("transfer_in_dates") or {},
                       "normalized": data.get("normalized") or [],
                       "notice": _normalized_notice(data.get("normalized")),
                       "unclear": unclear,
                       "warning": warning}, ensure_ascii=False)


@_journaled("/api/upload_staff_table")
def api_upload_staff_table(file_bytes) -> str:
    """'연간근무표'(로스터+누적통계+연간그리드) 업로드 — 다월 자동 연동의 시작점.

    이 파일은 '과거'(지난달까지의 실적)다. 로스터는 입력①(원티드표)가 아직 없을 때만
    화면 명단의 출발점으로 쓰고, 입력①이 이미 있으면 덮어쓰지 않고 대조(전입·전출 판정)에만
    쓴다 — 화면 쪽에서 그렇게 처리한다.
    """
    path = _tmp_path("staff_table.xlsx")
    try:
        _write_temp_xlsx(file_bytes, path)
        data = load_staff_table_xlsx(path)
    except ExcelInputError as e:
        # 연간근무표가 아니면 '지난달 근무표 한 장'(병원 OCS 원본 또는 우리 월간근무표)
        # 으로 다시 읽어본다 — 이 앱을 처음 쓰는 달에는 아직 연간근무표가 없다.
        # 두 형태는 앞부분(시트 헤더)이 완전히 달라서 서로 오인될 여지가 없다.
        try:
            prev = load_prev_month_schedule_xlsx(path)
        except WrongInputSlotError as slot_err:
            # 파일이 깨진 게 아니라 칸을 헷갈린 것이다 — 연간근무표 형식 오류로
            # 덮어쓰면 "내 파일이 왜 깨졌지"를 찾느라 진짜 원인을 못 본다.
            # 단, "연간근무표로 보인다"는 판정은 여기선 뜻이 없다 — 이 칸이 바로 연간근무표
            # 칸이고, 그 파일이 못 읽힌 진짜 이유는 위의 연간근무표 오류(e)다.
            if slot_err.kind == "wanted":
                return _err(str(slot_err))
            return _err(f"연간근무표 엑셀 오류: {e}")
        except Exception:
            return _err(f"연간근무표 엑셀 오류: {e}")
        data = staff_table_from_prev_month(prev)
    except Exception as e:
        return _err(f"파일을 읽을 수 없습니다: {e}")

    S.staff_table_in = {"stats": data["stats"], "annual_dates": data["annual_dates"],
                        "annual_grid": data["annual_grid"],
                        "departed": data.get("departed") or [],
                        "transferred_in": data.get("transferred_in") or [],
                        "transfer_in_dates": data.get("transfer_in_dates") or {},
                        "unknown_transfer_marks": data.get("unknown_transfer_marks") or [],
                        "transfer_no_off_balance": data.get("transfer_no_off_balance") or [],
                        "rows_after_summary": data.get("rows_after_summary") or []}
    return json.dumps({"ok": True, "staff": data["staff"],
                       "source": data.get("source") or "staff_table",
                       "roster_names": data.get("roster_names")
                                       or [s["id"] for s in data["staff"]],
                       "team_b_names": data.get("team_b_names") or [],
                       "departed_names": [p["id"] for p in (data.get("departed") or [])],
                       "transferred_in": data.get("transferred_in") or [],
                       "transfer_in_dates": data.get("transfer_in_dates") or {},
                       "rows_after_summary": data.get("rows_after_summary") or [],
                       "off_balance_blank": data.get("off_balance_blank") or [],
                       # 전월잔휴는 근무표에서 계산할 수 없는 누적 잔액이라 코드가 채울 수
                       # 없다 — 비어 있으면 0으로 보고 진행하되 그 사실을 화면에 띄운다.
                       "prev_off_balance_missing": data.get("prev_off_balance_missing") or [],
                       "has_prev_off_balance_col": data.get("has_prev_off_balance_col", True),
                       "unknown_grid_marks": data.get("unknown_grid_marks") or [],
                       "normalized": data.get("normalized") or [],
                       "notice": _normalized_notice(data.get("normalized")),
                       "unclear": _join_notices(_unclear_notice([
                           ("'전입' 칸의", data.get("unknown_transfer_col") or [],
                            "전입자로 잡히지 않았습니다(비우거나 '전입'을 골라주세요)"),
                           ("전입자 근무기록의", data.get("unknown_transfer_marks") or [],
                            "우리 병동 코드가 아니라 빈칸(오프)으로 처리했습니다"),
                           ("근무표 칸의", data.get("unknown_grid_marks") or [],
                            "우리 병동 코드가 아니라 빈칸(오프)으로 처리했습니다"),
                       ]), *(data.get("night_leader_noop") or [])),
                       "annual_days": len(data["annual_dates"]),
                       "last_date": (data["annual_dates"][-1] if data["annual_dates"] else None)},
                      ensure_ascii=False)


def api_staff_table_status() -> str:
    """지금 서버에 연간근무표가 반영돼 있는지 — '생성'을 누르면 이게 계속 자동으로 쓰이므로,
    화면에서 리더가 잊지 않고 확인할 수 있게 상시 조회 가능하게 해둔다."""
    if not S.staff_table_in:
        return json.dumps({"loaded": False}, ensure_ascii=False)
    dates = S.staff_table_in.get("annual_dates") or []
    return json.dumps({"loaded": True, "staff_count": len(S.staff_table_in.get("stats") or {}),
                       "annual_days": len(dates), "last_date": (dates[-1] if dates else None)},
                      ensure_ascii=False)


@_journaled("/api/clear_staff_table")
def api_clear_staff_table() -> str:
    S.staff_table_in = None
    S.roster_moves = None
    return json.dumps({"ok": True}, ensure_ascii=False)


def _config_mismatch(data: dict):
    """화면이 보낸 입력이 서로 어긋나면 그 이유를 돌려준다(없으면 None).

    세 가지 다 "엔진은 받아주고, 결과 화면 어딘가에 흔적만 남는" 부류였다 —
    토스트는 '생성 완료'라고 말하고, 알아차리려면 옆 칸 표를 끝까지 읽어야 했다.

    - 신청 날짜가 만들려는 달이 아님: 입력①을 올린 뒤 화면의 연·월을 바꾸면 생긴다.
      엔진은 신청을 전부 '해당 월이 아님'으로 반려하고 근무표는 그냥 나온다 —
      원티드가 하나도 안 들어간 근무표가 정상처럼 보인다.
    - 신청한 이름이 명단에 없음: 옛 형식 원티드표(인원 칸 없음)의 이름이 화면 명단과
      다르면 그 사람 신청만 '존재하지 않는 직원'으로 빠진다.
    - B팀(신입) 이름이 정규 명단에도 있음: 화면의 B팀 칸은 손으로 적는 칸이라 업로드
      검사가 닿지 않는다. 그대로 두면 출력①에 같은 사람이 두 줄로 나가고, 그 출력②는
      다음 달 입력②에서야 반려된다 — 한 달 늦게 알게 된다.
    """
    roster_ids = {_norm_id(s.get("id")) for s in data.get("staff") or []}
    try:
        tag = f"{int(data['year']):04d}-{int(data['month']):02d}"
    except (TypeError, ValueError):
        return None   # 연·월 자체가 이상한 건 엔진 검증이 따로 알려준다
    reqs = [r for r in (data.get("requests") or []) if isinstance(r, dict)]
    off_month = sorted({str(r.get("date", ""))[:7] for r in reqs
                        if str(r.get("date", ""))[:7] != tag})
    if off_month:
        n = sum(1 for r in reqs if str(r.get("date", ""))[:7] in off_month)
        shown = ", ".join(f"{t[:4]}년 {int(t[5:7])}월" if len(t) == 7 and t[5:7].isdigit() else repr(t)
                          for t in off_month[:3])
        return (f"원티드 신청 {n}건이 {shown} 것인데, 만들려는 달은 {tag[:4]}년 "
                f"{int(tag[5:7])}월입니다 — 입력①을 올린 뒤 화면의 연·월을 바꾸신 것 "
                "같습니다. 그대로 만들면 신청이 하나도 반영되지 않은 근무표가 나옵니다. "
                "연·월을 파일에 맞추시거나, 그 달 원티드표를 다시 올려주세요.")
    ghosts = sorted({str(r.get("staff_id", "")).strip() for r in reqs
                     if _norm_id(r.get("staff_id")) not in roster_ids})
    if ghosts:
        head = ", ".join(ghosts[:5]) + (f" 외 {len(ghosts) - 5}명" if len(ghosts) > 5 else "")
        return (f"원티드 신청에 인원 명단에 없는 이름이 있습니다({head}) — 그 신청은 "
                "반영되지 않습니다. 입력①의 이름을 명단과 같게 맞춰 다시 올려주세요.")
    team_b = (data.get("params") or {}).get("team_b_names") or []
    dup = sorted({str(n).strip() for n in team_b if _norm_id(n) in roster_ids})
    if dup:
        return (f"B팀(신입) 칸의 '{', '.join(dup)}'이(가) 인원 명단에도 있습니다 — 같은 "
                "사람이 두 번 잡혀 출력①에 두 줄로 나갑니다. 신입이면 명단에서, 아니면 "
                "B팀 칸에서 지워주세요.")
    return None


def _norm_id(v) -> str:
    return unicodedata.normalize("NFC", str(v or "")).strip()


@_journaled("/api/set_config")
def api_set_config(body_json: str) -> str:
    data = json.loads(body_json)
    if not data or not all(k in data for k in ("year", "month", "staff", "params")):
        return _err("입력 형식이 올바르지 않습니다 (year/month/staff/params 필요)")
    date_err = _date_input_problem(data)
    if date_err:
        return _err(date_err)
    param_err = _validate_params(data.get("params") or {})
    if param_err:
        return _err(param_err)
    for s_ in data.get("staff") or []:
        if str(s_.get("role", "")).strip() == "파트장":
            # 입력①·② 파서가 같은 검사를 하지만 명단이 다른 길(저장된 설정·옛 형식)로 올 수도
            # 있다 — 어느 길이든 여기서 한 번 더 본다. 통과시키면 결과 전체가 빨강(F-1).
            _pj = partjang_allowed_problem(
                f"인원 명단({s_.get('id', '')})", list(s_.get("allowed_shifts") or []),
                ",".join(s_.get("allowed_shifts") or []))
            if _pj:
                return _err(_pj)
    if not (data.get("staff") or []):
        # 여기서 안 막으면 엔진 안쪽 검증에 걸려 "nk_count=2 이지만 NK 전담 인원은 0명"처럼
        # 실제 원인과 상관없는 문구가 나온다 — 무엇이 없는지 그대로 알려준다.
        return _err("인원 명단이 비어 있습니다 — 입력①(원티드표)에 인원(이름·직급·"
                    "숙련도·가능근무)을 채워서 올린 뒤 다시 시도해주세요.")
    mismatch = _config_mismatch(data)
    if mismatch:
        return _err(mismatch)
    warning = None
    if not S.staff_table_in:
        # 대조할 지난달 파일이 없으면 이전 대조 결과도 함께 버린다 — 둘이 짝이 안 맞으면
        # 예전 전출자가 이번 달 출력에 되살아난다.
        S.roster_moves = None
    if S.staff_table_in:
        stats = S.staff_table_in["stats"]
        annual_dates = S.staff_table_in.get("annual_dates") or []
        annual_grid = S.staff_table_in.get("annual_grid") or {}
        carry = {}
        if annual_dates:
            carry.update(carryover_from_staff_table(
                annual_dates, annual_grid, int(data["year"]), int(data["month"])))
            if not carry:
                # 연간근무표는 있는데 "이번 달의 바로 전달" 구간이 안 이어져 있음 —
                # 이월정보 없이 진행하는 대신, 조용히 넘어가지 않고 반드시 알려준다.
                cur_y, cur_m = int(data["year"]), int(data["month"])
                py, pm = (cur_y - 1, 12) if cur_m == 1 else (cur_y, cur_m - 1)
                last = str(annual_dates[-1])
                try:
                    ly, lm = int(last[:4]), int(last[5:7])
                except ValueError:
                    ly = lm = None
                if (ly, lm) == (py, pm) or ly is None:
                    # 전달이 들어 있긴 한데 말일까지 이어지지 않은 파일
                    warning = (
                        f"업로드된 연간근무표에 {py}년 {pm}월(이번 생성의 바로 전달) 전체가 "
                        f"이어져 있지 않아 전월이월(잔여 휴가·연속근무 등)이 반영되지 않았습니다 "
                        f"— 연간근무표의 마지막 날짜: {annual_dates[-1]}. "
                        f"{py}년 {pm}월분 출력②(연간근무표)를 다시 올려주세요."
                    )
                else:
                    # 다른 달까지의 파일 — "전체가 이어져 있지 않다"만으로는 무엇을 잘못 올렸는지 알 수 없었다
                    # (화면의 예시 파일을 그대로 올린 사람이 오류로 읽었다, 2026-11-13). 몇 월까지의 파일인지와 할 일을 적는다.
                    warning = (
                        f"입력②(연간근무표)가 {ly}년 {lm}월까지의 파일이라, 이번에 만드는 달의 바로 전달"
                        f"({py}년 {pm}월)과 이어지지 않습니다 — 전월이월(잔여 휴가·연속근무·야간 간격) 없이 만들었습니다. "
                        f"{py}년 {pm}월분 출력②(없으면 OCS {pm}월 근무표)를 입력②에 올려 다시 만들어 주세요. "
                        f"처음 쓰는 달이면 입력 화면에서 그 파일을 빼고('이 파일 빼기') 만드시면 됩니다."
                    )
        # 이번 달이 이미 들어 있는 파일인지 — 방금 만든 이번 달 출력②를 그대로 입력②로
        # 다시 올리면(같은 달을 다시 만들려고 흔히 한다) 연간 그리드에 같은 달이 두 번
        # 붙고 누적 통계도 한 달치 더 얹혀, 그 뒤로 계속 부풀어 오른 파일이 이어진다.
        # 전입자가 가져온 이번 달 기록(입사 전 구간)은 정상이므로 그 사람들은 제외하고,
        # 계속 근무자에게 이번 달 칸이 채워져 있으면 잘못 올린 것으로 보고 막는다.
        # 대상 월보다 '미래'까지 반영된 파일 — 12월까지 만든 연간근무표를 올려놓고 9월을
        # 생성하면, 날짜 그리드는 9월만 남기고 잘리는데 누적 통계는 12월치 위에 9월치가
        # 또 더해진다(시간이 거꾸로 흐른 누적). 그대로 다음 달로 이어지면 형평성 기준이
        # 영구히 오염되므로 받지 않는다. 월중 전입자가 가져온 이번 달 기록은 대상 월
        # 안쪽이라 여기에 걸리지 않는다.
        import calendar as _cal
        _last_day = _cal.monthrange(int(data["year"]), int(data["month"]))[1]
        _month_end = f"{int(data['year']):04d}-{int(data['month']):02d}-{_last_day:02d}"
        if annual_dates and annual_dates[-1] > _month_end:
            return _err(
                f"업로드된 연간근무표는 {annual_dates[-1]}까지 반영된 파일인데, 지금 만들려는 것은 "
                f"{int(data['year'])}년 {int(data['month'])}월입니다 — 이미 지난 뒤의 파일이라 "
                "누적 통계(야간·근무일 등)가 거꾸로 쌓여 형평성 기준이 틀어집니다. "
                f"{int(data['year'])}년 {int(data['month'])}월의 바로 전달까지 반영된 연간근무표를 "
                "올리시거나, 만들려는 달을 파일에 맞춰 바꿔주세요.")

        cur_tag = f"{int(data['year']):04d}-{int(data['month']):02d}"
        this_month_cols = [i for i, ds in enumerate(annual_dates) if ds[:7] == cur_tag]
        if this_month_cols:
            marked = set(S.staff_table_in.get("transferred_in") or [])
            filled = sorted(
                sid for sid, codes in annual_grid.items()
                if sid not in marked
                and any(str(codes[i]).strip() for i in this_month_cols if i < len(codes)))
            if filled:
                return _err(
                    f"이 연간근무표에는 이미 {int(data['year'])}년 {int(data['month'])}월 "
                    f"근무가 들어 있습니다({', '.join(filled[:3])}"
                    f"{' 외 %d명' % (len(filled) - 3) if len(filled) > 3 else ''}) — "
                    "이번 달 출력②를 그대로 입력②로 올리신 것 같습니다. "
                    "입력②에는 지난달까지 반영된 파일을 올려주세요. "
                    "같은 달을 다시 만드시려면 입력②를 새로 올리지 마시고 "
                    "'근무표 생성'을 다시 누르시면 됩니다.")

        for sid, v in (data.get("prev_month_carryover") or {}).items():
            carry[sid] = v
        # 비고에 '전입'이라 적힌 사람 중, 실제로 이번 달 명단(입력①)에 있는 사람만 대상.
        # 입력②에만 있고 입력①에 없으면 그건 전입이 아니라 명단 누락이므로 전출로 잡혀 드러난다.
        roster_ids = {str(s.get("id", "")).strip() for s in data["staff"]}
        # 전입 표시는 두 곳에서 올 수 있다 — 입력②(연간근무표의 '전입' 칸)과 입력①
        # (원티드표의 '전입' 칸). 입력②가 OCS 지난달 근무표로 들어오면 그 파일에는
        # 전입 칸 자체가 없으므로, 입력①이 유일한 출처가 된다. 둘 다 있으면 합집합이다.
        transferred = (set(S.staff_table_in.get("transferred_in") or [])
                       | set(data.get("wanted_transferred_in") or [])) & roster_ids
        transfer_no_history: list = []
        # 월중 전입자의 입사일 — 이번 달에 해당하는 것만 엔진에 넘긴다.
        all_join_dates = dict(S.staff_table_in.get("transfer_in_dates") or {})
        all_join_dates.update(data.get("wanted_transfer_in_dates") or {})
        join_dates = {sid: ds for sid, ds
                      in all_join_dates.items()
                      if sid in transferred
                      and ds[:7] == f"{int(data['year']):04d}-{int(data['month']):02d}"
                      and ds[8:10] != "01"}
        data["transfer_in_dates"] = join_dates
        # 누적 형평 보정(실험, 기본 꺼짐) — 지난 달들의 주말 '적정 몫 대비 초과'(기회 보정)를 ±1일로 잘라 이월정보에
        # 싣고, 생성기가 이번 달 주말 몫에 더해 본다(더 선 사람은 덜, 덜 선 사람은 더). 2026-11-09 12개월 전후 비교
        # (tools/ab_weekend_bias.py): 누적 편차 sd 3.50→3.45(문턱 2일이면 3.39), |초과|≥3 149→135명·달이지만 필수
        # 위반 1→4, 노랑 264→292, 11달 중 6달은 편차가 되레 커졌다 — 이번 달 균등을 깎아 지난달을 갚는 셈이라 순이득이
        # 없다. 그래서 켜지 않는다. NS_WEEKEND_BIAS=1로 켜서 다른 설계(창·문턱·감쇠)를 실험할 때만 쓴다.
        bias = {}
        if os.environ.get("NS_WEEKEND_BIAS", "0") == "1":
            _min = float(os.environ.get("NS_WEEKEND_BIAS_MIN", "1"))
            bias = {sid: weekend_bias_from_excess(e, min_excess=_min) for sid, e in
                    prior_weekend_excess(S.staff_table_in, data["staff"], int(data["year"]), int(data["month"])).items()}
        for sid, st in stats.items():
            entry = dict(carry.get(sid) or {})
            if bias.get(sid):
                entry["weekend_bias"] = bias[sid]
            join = join_dates.get(sid)
            if join:
                # 월중 전입 — 이월정보의 기준은 전월 말일이 아니라 '입사 전날'이다.
                # 2/15 입사자는 2/14까지 전 병동에서 근무했으므로, 전월 말일로 계산하면
                # 입사 직전 야간블록을 놓쳐 야간 후 휴식이 안 지켜진다(안전 문제).
                got = carryover_from_history_before(
                    annual_dates, annual_grid.get(sid) or [], join)
                if got:
                    entry.update(got)
            score = st.get("recent_night_score", 0.0)
            if sid in transferred and not score:
                # 전입자가 전 병동 근무기록을 가져온 경우 — 최근야간점수 칸이 비어 있으면
                # 붙여넣은 기록에서 직접 접어 계산한다(이 칸을 파트장이 채울 방법이 없으므로).
                # 이게 없으면 0으로 덮여 "야간을 한 번도 안 선 사람"이 돼 첫 달부터 야간
                # 상한을 받아버린다. 월중 전입이면 입사일이 경계다.
                #
                # '기록은 있는데 야간이 0회'와 '기록 자체가 없음'은 구분해야 한다 — 전자는
                # 0이 맞는 값이라 야간 우선권을 줘야 하고(형평성), 후자는 알 수 없으니
                # 중립값(중앙값)으로 둬야 한다. 역산 함수가 None으로 그 차이를 알려준다.
                derived = night_score_from_grid_history(
                    annual_dates, annual_grid.get(sid) or [],
                    int(data["year"]), int(data["month"]), before=join)
                if derived is not None:
                    score = derived
                else:
                    transfer_no_history.append(sid)
            entry["recent_night_score"] = score
            entry["off_balance"] = st.get("off_balance", 0.0)
            carry[sid] = entry

        # 입력①(이번 달 명단, 미래) vs 입력②(지난달 실적, 과거) 대조 — 차집합이 인사이동이다.
        # 전입자는 우리 병동 실적이 없으므로 야간 비교군(중앙값)에서 빼고 계산한다.
        moves = reconcile_roster(data["staff"], stats, transferred=transferred)
        # 입력①과 입력②의 이름이 하나도 안 겹치면 인사이동이 아니라 **파일이 다른 것**이다
        # (다른 병동의 입력②, 이름 형식이 다른 파일). 예전엔 전입 39명·전출 39명 이름 78개를
        # 나열한 거대 경고가 떴고 "명단이 안 겹친다"는 진단은 없었다(v0.87 리뷰 F-11).
        prev_names = set(stats)
        no_overlap = bool(prev_names) and bool(roster_ids) and not (prev_names & roster_ids)
        for sid in transfer_no_history:
            # '전입'이라 표시했지만 붙여넣은 근무기록이 아예 없는 경우 — 역산할 게 없어
            # 0으로 남는다. 그대로 두면 "야간을 한 번도 안 선 사람"이 돼 첫 달부터 야간
            # 상한을 받아버리므로(이력 없는 전입자와 같은 문제), 재직 중인 비교군의
            # 중앙값에서 출발시킨다.
            entry = dict(carry.get(sid) or {})
            entry["recent_night_score"] = moves["newcomer_night_score"]
            carry[sid] = entry
        for sid in moves["incoming"]:
            # 전입자는 이월정보가 없다. recent_night_score를 0으로 두면 "야간을 한 번도
            # 안 선 사람"이 돼 첫 달부터 야간 상한을 받아버리므로, 계속 근무 중인 야간
            # 비교군의 중앙값에서 출발시킨다(전 병동 이력을 모르니 가장 중립적인 추정).
            # 잔휴(off_balance)는 실제 정산 숫자라 임의로 지어내지 않고 0으로 둔다.
            entry = dict(carry.get(sid) or {})
            entry["recent_night_score"] = moves["newcomer_night_score"]
            carry[sid] = entry
        data["prev_month_carryover"] = carry
        S.roster_moves = moves
        move_msgs = []
        if no_overlap:
            move_msgs.append(
                f"⚠ 입력①과 입력②의 명단이 하나도 겹치지 않습니다(입력① {len(roster_ids)}명, "
                f"입력② {len(prev_names)}명) — 다른 병동의 파일이거나 이름 형식이 다른 파일이 "
                "아닌지 확인해주세요. 이대로 만들면 전원이 전입(이월정보 없음)으로 처리되고 "
                "입력②의 인원은 전부 전출로 기록됩니다.")
        if moves["incoming"] and not no_overlap:
            move_msgs.append(
                f"전입 {len(moves['incoming'])}명({', '.join(moves['incoming'])}) — "
                f"지난달 연간근무표에 없어 이월정보(잔휴·연속근무)가 없습니다. "
                f"야간 형평성은 재직자 중앙값({moves['newcomer_night_score']})에서 시작합니다. "
                f"이름 오타로 못 찾은 경우라면 입력①·②의 이름을 같게 맞춰주세요.")
        if moves["outgoing"] and not no_overlap:
            move_msgs.append(
                f"전출 {len(moves['outgoing'])}명({', '.join(moves['outgoing'])}) — "
                f"이번 달 배정에서 빠집니다. 누적 이력은 연간근무표의 '전출' 칸에 보존됩니다.")

        # 전 병동 기록을 가져온 전입자(연간근무표 비고에 '전입') — 이력이 실제로 쓰였는지,
        # 사람이 채워야만 하는 값(잔휴)이 비었는지를 조용히 넘기지 않고 알려준다.
        if transferred:
            # 기록이 없는 전입자(transfer_no_history)는 "이력 반영" 문장에서 뺀다 — 같은 사람을
            # 두고 "기록에서 계산했습니다"와 "기록이 없습니다"가 나란히 떴다(v0.87 리뷰 F-6).
            named = sorted(transferred - set(transfer_no_history))
            if named:
                move_msgs.append(
                    f"전입(이력 반영) {len(named)}명({', '.join(named)}) — 붙여넣은 전 병동 "
                    f"근무기록에서 이월정보·야간 형평성을 계산했습니다. 부서 누적 실적은 "
                    f"이번 달부터 0에서 시작합니다.")
            mid = [f"{sid}({join_dates[sid][5:].replace('-', '/')} 입사)"
                   for sid in sorted(join_dates)]
            if mid:
                move_msgs.append(
                    f"월중 전입 {len(mid)}명({', '.join(mid)}) — 입사 전 날짜는 배정에서 빼고"
                    f"('휴' 표시), 이월정보는 입사 전날 기준으로 계산했습니다. 잔휴는 전 병동이"
                    f" 정산해 넘긴 값에서 시작해 재직 기간의 휴일수만 적립합니다.")
            no_bal = [n for n in (S.staff_table_in.get("transfer_no_off_balance") or [])
                      if n in transferred]
            if no_bal:
                move_msgs.append(
                    f"⚠ 전입자 잔휴 미입력 {len(no_bal)}명({', '.join(no_bal)}) — 잔휴는 "
                    f"근무기록으로 계산할 수 없는 누적 잔액입니다. 전 병동에서 받은 숫자를 "
                    f"연간근무표의 '잔휴' 칸에 적어 다시 올려주세요(지금은 0으로 진행).")
            if transfer_no_history:
                move_msgs.append(
                    f"⚠ 전입자 근무기록 없음 {len(transfer_no_history)}명"
                    f"({', '.join(sorted(transfer_no_history))}) — '전입'으로 표시했지만 날짜 칸에"
                    f" 전 병동 근무기록이 없습니다. 이월정보(야간 후 휴식 등)를 계산할 수 없어"
                    f" 야간 형평성만 재직자 중앙값({moves['newcomer_night_score']})으로 맞췄습니다."
                    f" 기록이 있으면 붙여넣어 다시 올려주세요.")
            unknown = S.staff_table_in.get("unknown_transfer_marks") or []
            if unknown:
                move_msgs.append(
                    f"⚠ 전입자 기록에서 인식 못 한 표기 {len(unknown)}건"
                    f"({', '.join(unknown[:8])}{' 외' if len(unknown) > 8 else ''}) — 해당 칸은 "
                    f"빈칸(오프)으로 처리했습니다. 우리 병동 코드로 바꿔 적으면 정확해집니다.")
        # 파일 맨 아래 요약 블록(D 인원~N 고연차/저연차) 뒤에 사람을 덧붙이면 파서가 못 읽고
        # 지나간다 — 전입자 행을 넣다가 흔히 하는 실수라, 조용히 빠지지 않게 알려준다.
        # 라벨을 하나만 박아두지 않는 이유: 요약 블록 맨 위가 '레벨평균'이었다가
        # 'D 인원'으로 바뀐 적이 있고, 옛 라벨만 안내하면 그 줄 위에 넣고 또 걸린다.
        stranded = S.staff_table_in.get("rows_after_summary") or []
        if stranded:
            move_msgs.append(
                f"⚠ 연간근무표 맨 아래 통계 줄({STAFF_TABLE_SUMMARY_LABELS[0]}~{STAFF_TABLE_SUMMARY_LABELS[-1]}) 뒤에 있는 행 {len(stranded)}건"
                f"({', '.join(stranded)})은 읽지 못했습니다 — 사람 행은 통계 줄 위, "
                f"기존 인원 목록 바로 아래에 넣어주세요.")
        if move_msgs:
            joined = " / ".join(move_msgs)
            warning = f"{warning} {joined}" if warning else joined
    for pw in _param_warnings(data.get("params") or {}, data["year"], data["month"]):
        warning = f"{warning} {pw}" if warning else pw
    if not any(str(s.get("role", "")).strip() == "파트장" for s in data.get("staff", [])):
        # 엔진 자체는 파트장 없는 구성도 허용하지만(소규모 병동 등), 실사용에서는
        # 대부분 '직급' 칸 오타일 가능성이 높아 막지 않고 경고로만 알려준다.
        pj_warning = ("인원 명단에 '파트장' 직급을 가진 사람이 없습니다 — 오타가 있으면 8A "
                      "고정 배정 등 파트장 전용 처리가 전부 빠집니다. 의도적으로 파트장 없이 "
                      "운영하는 경우라면 무시해도 됩니다.")
        warning = f"{warning} {pj_warning}" if warning else pj_warning
    try:
        # 스키마 검증용으로 어차피 한 번 만든다 — 인력 압박 진단도 이 인스턴스로 같이
        # 뽑는다(run()을 하지 않으므로 추가 비용이 없다). 생성을 누르기 전에 "이 입력은
        # 오래 걸린다"를 미리 알려주려면 이 시점의 값이 필요하다.
        probe = Generator(data)
        pressure = probe.staffing_pressure()
    except InputError as e:
        return _err(str(e))
    except Exception as e:
        return _err(f"입력 오류: {e}")
    S.cfg = data
    S.gen = None
    S.sch = None
    S.last_change = None
    S.night_stage = False
    S.nights_fixed = False
    S.locked_cells = {}
    S.pending_edits = {}
    S.round = 0
    S.team_b_grid = {}   # 입력이 바뀌면 신입 명단도 바뀔 수 있다
    return json.dumps({"ok": True, "staff_count": len(data["staff"]), "warning": warning,
                       "staffing": pressure},
                      ensure_ascii=False)


def _sync_team_b_grid():
    """B팀 근무를 지금 근무표에 맞춰 정리하고 S.sch에 얹는다.

    명단에서 빠진 신입의 값은 버리고, 달이 바뀌어 일수가 달라지면 길이를 맞춘다.
    엔진이 새 MonthSchedule을 만들 때마다(생성·재생성) 다시 얹어야 한다 — 안 얹으면
    출력 엑셀에 빈칸으로 나간다."""
    if S.sch is None:
        return
    nd = S.sch.num_days
    fixed = {}
    for name in S.sch.team_b_names:
        row = list(S.team_b_grid.get(name) or [])
        fixed[name] = (row + [""] * nd)[:nd]
    S.team_b_grid = fixed
    S.sch.team_b_grid = fixed


def _edit_team_b(name, day, shift_str):
    """B팀(신입) 칸 편집 — 엔진을 거치지 않고 바로 반영한다.

    일반 인원의 편집과 달리 '미적용(pending)'으로 쌓지 않는다. 신입은 최소인력·레벨
    통계·제약검사 어디에도 안 들어가므로 다시 계산할 것이 없고, 그런데도 재생성을
    요구하면 파트장은 신입 한 칸 적으려고 표 전체를 다시 짜야 한다.
    빈 문자열은 '지우기'다."""
    if S.sch is None:
        return _err("아직 생성된 근무표가 없습니다")
    if name not in S.sch.team_b_names:
        return _err("B팀(신입) 명단에 없는 이름입니다")
    if isinstance(day, bool) or not isinstance(day, int) or not (0 <= day < S.sch.num_days):
        return _err("잘못된 날짜입니다")
    code = ""
    if shift_str not in (None, ""):
        if not isinstance(shift_str, str):
            return _err(f"알 수 없는 근무유형: {shift_str!r}")
        try:
            code = str(parse_shift(shift_str))
        except ValueError:
            return _err(f"알 수 없는 근무유형: {shift_str}")
    _sync_team_b_grid()
    S.team_b_grid[name][day] = code
    S.sch.team_b_grid = S.team_b_grid
    return _full_state_json()


@_journaled("/api/edit/team_b")
def api_edit_team_b(body_json: str) -> str:
    data = json.loads(body_json)
    return _edit_team_b(data.get("staff_id"), data.get("day"), data.get("shift"))


# ---------------------------------------------------------------- 병렬 생성(여러 코어)
# generate_best는 시드 0·1·2(전략 -,W,S — generator.py _STRATEGY_MIX)를 차례로 돌려 고른다. 코어가 넉넉한 PC에서는 platform.js가
# 도우미 Worker(같은 pyworker.js) 둘에 시드 1·2를 맡기고, 이 Worker는 시드 0을 돌려 상태를
# 만든다. 그 뒤 세 시도의 통계를 choose_attempt(순차와 같은 판정)에 넣어 고르고, 시드 0이
# 아니면 그 시드를 한 번 더 돌려 상태를 바꾼다. 어느 길로 가든 **같은 입력이면 같은 표**다 —
# 판정 함수가 한 벌이기 때문이다(tests/test_parallel_generate.py가 대조한다).
#
# 상태 없는 함수(generate_plan·generate_attempt·pick_attempt)는 도우미가 부르고, 상태를
# 바꾸는 것(generate/apply/regenerate의 seed 인자, generate_seed)은 주 Worker만 부른다.

# 화면이 보낼 수 있는 시도 수의 상한. 12개 실험(docs/report_v0.86/bench/baseline_seeds12_261030.json)에서
# 9→12는 운영 필수 83→82로 거의 평평했고, 그 위는 재지 않았다. 재지 않은 구간을 열어 두지 않는다.
MAX_ATTEMPTS = 12


def _gen_opts(body_json) -> dict:
    """생성 API 공통 옵션. seed: 그 시드 하나만(병렬 생성의 주 Worker 몫) · attempts: 시드 수.
    attempts는 화면의 '꼼꼼히 찾기'가 9를 보낸다(기본 3). 시간 안전판(time_budget)은 시도 수에
    비례시킨다 — 30초 그대로 두면 빠듯한 달의 9회 탐색이 4회쯤에서 조용히 잘려, 사용자는 '꼼꼼히'를
    눌렀는데 보통과 같은 표를 받는다(기준선 201개 실측: 시도 1회 최대 40초)."""
    out = {"seeds": None, "attempts": 3, "time_budget": 30.0}
    if not body_json:
        return out
    try:
        b = json.loads(body_json)
    except ValueError:
        return out
    if not isinstance(b, dict):
        return out
    if b.get("seed") is not None:
        out["seeds"] = [int(b["seed"])]
    if b.get("attempts"):
        out["attempts"] = max(1, min(MAX_ATTEMPTS, int(b["attempts"])))
        out["time_budget"] = 10.0 * out["attempts"]
    # 공정성 가중치는 화면이 기억해 생성 요청마다 실어 보낸다 — 새 탭에서도 같은 종합 점수가 나오게.
    if isinstance(b.get("fair_weights"), dict):
        S.fair_weights = dict(b["fair_weights"])
    if isinstance(b.get("fatigue_weights"), dict):
        S.fatigue_weights = dict(b["fatigue_weights"])
    return out


def _seed_of(body_json) -> int | None:
    return (_gen_opts(body_json)["seeds"] or [None])[0]


def _fixed_list(fixed: dict) -> list:
    return [[sid, d, str(v)] for (sid, d), v in fixed.items()]


def _fixed_from_list(items) -> dict:
    return {(str(sid), int(d)): parse_shift(v) for sid, d, v in (items or [])}


def _with_attempt(state: dict) -> dict:
    """응답에 이번 시도의 통계를 싣는다 — 병렬 생성의 주 Worker가 도우미 통계와 함께 고르는 데 쓴다.
    균등화 전 숫자여야 한다 — 도우미 Worker는 균등화 없이 센 통계를 보내므로, 여기서 균등화 뒤
    표를 다시 세면 같은 시드가 다른 숫자를 갖게 돼 고르는 결과가 순차와 어긋난다."""
    st = dict(S.sch.attempt_stats) if S.sch.attempt_stats else attempt_stats(S.gen, S.sch)
    st["h15_floor"] = S.gen.feasibility_bounds()["h15_floor"]
    state["attempt"] = st
    return state


def api_generate_plan(body_json=None) -> str:
    """병렬 생성 계획 — 도우미 Worker에 보낼 입력(설정·고정 칸·시드 목록·H1-5 하한)."""
    if S.cfg is None:
        return _err("먼저 입력을 확정하세요 (업로드 또는 직접입력 후 생성)")
    mode = "generate"
    if body_json:
        try:
            mode = json.loads(body_json).get("mode", "generate")
        except ValueError:
            pass
    attempts = _gen_opts(body_json)["attempts"]
    fixed: dict = {}
    if mode != "generate":
        try:
            _require_generated()
        except ApiError as e:
            return _err(str(e))
        fixed = dict(S.locked_cells)
        fixed.update(S.pending_edits)
    try:
        floor = Generator(S.cfg, fixed_cells=fixed).feasibility_bounds()["h15_floor"]
    except InputError as e:
        return _err(f"입력 검증 실패: {e}")
    # nights_fixed는 도우미 Worker에도 가야 한다(platform.js가 시도마다 실어 보낸다) — 안 보내면 도우미의
    # 시드만 야간을 새로 짜고, 그 시드가 점수표에서 이기면 확정한 야간이 바뀐 표가 화면에 뜬다.
    return json.dumps({"cfg": S.cfg, "fixed": _fixed_list(fixed), "seeds": list(range(attempts)),
                       "h15_floor": floor, "nights_fixed": bool(S.nights_fixed and mode != "generate")},
                      ensure_ascii=False)


def api_generate_attempt(body_json) -> str:
    """시드 하나를 돌리고 통계만 돌려준다 — 상태(S)는 읽지도 쓰지도 않는다(도우미 Worker용)."""
    import time as _time
    t0 = _time.perf_counter()
    try:
        b = json.loads(body_json)
        gen = Generator(b["cfg"], fixed_cells=_fixed_from_list(b.get("fixed")), seed=int(b["seed"]),
                        nights_fixed=bool(b.get("nights_fixed")))
        sch = gen.run()
    except InputError as e:
        return _err(f"입력 검증 실패: {e}")
    except Exception as e:
        return _err(f"생성 중 오류가 발생했습니다: {e}")
    st = attempt_stats(gen, sch)
    st["sec"] = round(_time.perf_counter() - t0, 3)     # 주 Worker의 시도와 같은 모양(점수표용)
    return json.dumps(st, ensure_ascii=False)


@_journaled("/api/pick_attempt")
def api_pick_attempt(body_json) -> str:
    """시도 통계 목록에서 순차 생성이 골랐을 시드 — 판정은 엔진(choose_attempt) 한 벌.
    점수표(전 시드의 통계 + 선택 표시)를 세션에 남겨 화면이 보여주게 한다."""
    try:
        b = json.loads(body_json)
        # 주 Worker 통계에는 안내용 h15_floor가 붙어 온다 — 점수표에는 시도 숫자만 남긴다
        stats = sorted(({k: v for k, v in x.items() if k != "h15_floor"} for x in b["stats"]),
                       key=lambda x: int(x["seed"]))
        seed = choose_attempt(stats, int(b.get("h15_floor") or 0))
    except Exception as e:
        return _err(f"시도 비교 실패: {e}")
    S.attempt_table = [dict(x, chosen=(int(x["seed"]) == seed)) for x in stats]
    return json.dumps({"seed": seed})


@_journaled("/api/generate_seed")
def api_generate_seed(body_json) -> str:
    """병렬 생성이 고른 시드를 다시 돌려 상태를 바꾼다. 회차·고정 칸·편집 목록은 그대로 —
    그것들은 앞서 seed=0으로 부른 generate/apply/regenerate가 이미 정리했다."""
    try:
        _require_generated()
    except ApiError as e:
        return _err(str(e))
    o = _gen_opts(body_json)
    try:
        gen, sch = generate_best(S.cfg, fixed_cells=dict(S.locked_cells) or None,
                                 seeds=o["seeds"], attempts=o["attempts"],
                                 time_budget=o["time_budget"], nights_fixed=S.nights_fixed)
    except InputError as e:
        return _err(f"생성 실패: {e}")
    except Exception as e:
        return _err(f"생성 중 오류가 발생했습니다: {e}")
    S.gen, S.sch = gen, sch
    if o["seeds"] is None:
        S.attempt_table = sch.attempt_table      # 순차로 다시 돈 경우만 — 병렬이면 pick이 남긴 표를 둔다
        S.candidates = dict(sch.candidates or {})
    else:
        S.candidates.update(sch.candidates or {})
    _sync_team_b_grid()
    return json.dumps(_with_attempt(_full_state()), ensure_ascii=False)


@_journaled("/api/select_attempt")
def api_select_attempt(body_json) -> str:
    """점수표에서 누른 시드의 표로 바꾼다. 미적용 편집은 버린다(화면이 먼저 묻는다). 회차·고정 칸은
    그대로 — 같은 입력·같은 고정에서 나온 다른 시도일 뿐이다. 병렬 생성이라 그 시드의 표가 없으면
    그 시드로 한 번 더 돌린다(결정적이라 도우미가 봤던 것과 같은 표)."""
    try:
        _require_generated()
    except ApiError as e:
        return _err(str(e))
    try:
        seed = int(json.loads(body_json).get("seed"))
    except Exception:
        return _err("시드를 읽지 못했습니다")
    if not any(int(a["seed"]) == seed for a in (S.attempt_table or [])):
        return _err(f"점수표에 없는 시드입니다: {seed}")
    if seed not in S.candidates:
        try:
            gen = Generator(S.cfg, fixed_cells=dict(S.locked_cells) or None, seed=seed,
                            nights_fixed=S.nights_fixed)
            sch = gen.run()
        except Exception as e:
            return _err(f"그 시드로 다시 계산하지 못했습니다: {e}")
        S.candidates[seed] = (gen, sch)
    gen, sch = S.candidates[seed]
    finish_candidate(gen, sch)
    S.gen, S.sch = gen, sch
    S.pending_edits = {}
    _sync_team_b_grid()
    return _full_state_json()


@_journaled("/api/generate")
def api_generate(body_json=None) -> str:
    if S.cfg is None:
        return _err("먼저 입력을 확정하세요 (업로드 또는 직접입력 후 생성)")
    o = _gen_opts(body_json)
    try:
        gen, sch = generate_best(S.cfg, seeds=o["seeds"], attempts=o["attempts"],
                                 time_budget=o["time_budget"])
    except InputError as e:
        return _err(f"입력 검증 실패: {e}")
    except Exception as e:
        return _err(f"생성 중 오류가 발생했습니다: {e}")
    S.gen, S.sch = gen, sch
    S.attempt_table = sch.attempt_table
    S.candidates = dict(sch.candidates or {})
    S.locked_cells = {}
    S.pending_edits = {}
    S.round = 1
    S.night_stage = False
    S.nights_fixed = False
    _sync_team_b_grid()
    if o["seeds"] is None:
        return _full_state_json()
    return json.dumps(_with_attempt(_full_state()), ensure_ascii=False)


def api_state() -> str:
    try:
        _require_generated()
    except ApiError as e:
        return _err(str(e))
    return _full_state_json()


# 파트장에게만 막는 근무. 나머지(상근·교육·휴가·휴직 계열)는 다 지정할 수 있다.
# 막는 이유는 인원 계산이다: 최소인력·레벨 통계가 파트장을 빼고 세므로, 파트장에게 D를
# 주면 그날 사람이 하나 더 있는 것처럼 보이지만 어느 숫자에도 안 잡힌다.
# NK는 야간전담이라 어디서나 N으로 센다.
#
# 목록은 엔진 한 벌(PARTJANG_BLOCKED_SHIFTS)을 그대로 쓴다 — 화면 피커가 막는 다섯에
# 같은 자리를 뜻하는 OCS 표기(DH·DP·RD·D◎ 등)를 더한 것이다. 여기에 숫자를 따로 적어
# 두면 업로드 검사와 편집 API가 갈라지고, 화면에서 막힌 값이 API로는 들어간다.
_PARTJANG_BLOCKED_SHIFTS = set(PARTJANG_BLOCKED_SHIFTS)


def _stage_edit(sid, day, shift_str) -> str | None:
    """한 칸을 미적용 편집으로 올린다. 문제가 있으면 한국어 사유를, 없으면 None을 돌려준다.
    api_edit와 api_swap_stage가 같은 검사를 지나게 하려고 한 벌로 뺐다 — 두 입구가 따로
    검사하면 한쪽에서 막힌 값이 다른 쪽으로 들어간다."""
    if sid not in S.sch.by_id:
        return "존재하지 않는 직원입니다"
    # bool은 int의 하위형이라 True가 2일로 통과한다. 근무유형이 문자열이 아니면
    # parse_shift가 AttributeError로 터져 Worker 예외(영어 추적문)가 화면에 떴다.
    if isinstance(day, bool) or not isinstance(day, int) or not (0 <= day < S.sch.num_days):
        return "잘못된 날짜입니다"
    if not isinstance(shift_str, str):
        return f"알 수 없는 근무유형: {shift_str!r}"
    try:
        shift = parse_shift(shift_str)
    except ValueError:
        return f"알 수 없는 근무유형: {shift_str}"
    # 파트장은 근무(D/E/N/NK/prn)를 서지 않는다 — 그 다섯만 막고 나머지는 다 열어둔다.
    # 화면(app.js의 PARTJANG_BLOCK)에서 이미 그렇게 보여주지만
    # 여기서 한 번 더 막는다 — 화면에만 있는 잠금은 잠금이 아니다(개발자도구나 잘못된
    # 클라이언트로 우회되고, 나중에 UI를 고치면 조용히 열린다).
    if S.sch.by_id[sid].is_partjang and shift.value in _PARTJANG_BLOCKED_SHIFTS:
        return (f"파트장에게는 {shift.value} 근무를 줄 수 없습니다 — 최소인력과 레벨 "
                "통계가 파트장을 빼고 세기 때문에, 그날 사람이 하나 더 있는 것처럼 "
                "보이지만 어느 숫자에도 잡히지 않습니다. "
                "상근(8A)·교육·연차·휴가는 지정할 수 있습니다")
    if S.night_stage:
        problem = _night_stage_edit_problem(sid, day, shift)
        if problem:
            return problem
    S.pending_edits[(sid, day)] = shift
    return None


def _night_stage_edit_problem(sid, day, shift) -> str | None:
    """야간 먼저 1단계에서 허용하는 편집 — 야간(N·NK)을 넣거나, 야간을 OFF로 빼는 것뿐.

    1단계 표는 전체를 짠 뒤 야간 외 칸을 가린 것이라, 가려진 주간 칸도 눌러 바꿀 수 있었다. 그 편집은
    '야간 확정' 때 함께 잠겨 2단계가 못 건드리는데, 파트장은 야간만 확정했다고 안다(GPT v0.88 검증 §04).
    화면(openPicker)도 같은 기준으로 고를 것을 줄이지만, 화면에만 있는 잠금은 잠금이 아니라 여기서 막는다."""
    old = S.pending_edits.get((sid, day), S.sch.grid[sid][day])
    if shift in NIGHT_SHIFTS:
        return None
    if shift == Shift.OFF and old in NIGHT_SHIFTS:
        return None
    return ("야간 먼저 1단계에서는 야간(N·NK)을 넣거나 빼는 것만 할 수 있습니다 — 다른 근무는 "
            "'야간 확정 → 나머지 짜기' 뒤에 고쳐 주세요")


@_journaled("/api/edit")
def api_edit(body_json: str) -> str:
    try:
        _require_generated()
    except ApiError as e:
        return _err(str(e))
    data = json.loads(body_json)
    problem = _stage_edit(data.get("staff_id"), data.get("day"), data.get("shift"))
    if problem:
        return _err(problem)
    return _full_state_json()


# ---------------------------------------------------------------- 수정 보조 (D-1·D-2)
# 둘 다 nurse_scheduler/edit_assist.py가 한다. 여기서는 "지금 화면에 보이는 표"(채택된
# 표 + 미적용 편집)를 만들어 넘기고, 잠긴 칸·편집 중인 칸을 상대에서 빼는 것만 한다.

def _displayed_schedule():
    temp = copy.deepcopy(S.sch)
    for (sid, d), shift in S.pending_edits.items():
        temp.grid[sid][d] = shift
    return temp


def _current_fragile():
    """지도가 지금 근무표의 것이면 돌려주고(부분만 차 있어도), 아니면 None — 낡은 지도로
    상대를 거르면 안 된다."""
    if S.fragile and S.fragile[0] == id(S.sch):
        return S.fragile[1]
    return None


def _fragile_cells_json(fm, keys=None):
    """화면에 보내는 것은 대안이 1개 이하인 칸만 — 나머지는 "자유롭게 고칠 수 있는 칸"이라
    표시할 것이 없고, 1,200칸 전부를 보내면 메시지가 쓸데없이 커진다."""
    items = fm.items() if keys is None else ((k, fm[k]) for k in keys if k in fm)
    return {f"{sid}:{d}": {"alts": v["alts"], "row": v["row_fragile"], "rules": v["blockers"]}
            for (sid, d), v in items if v["alts"] <= 1}


def api_fill_hints() -> str:
    """최소인력이 모자란 (날짜, 근무)마다 "누구를 넣으면 채워지나" — 그날 쉬는 사람 중 그 근무를
    설 수 있고, 넣어도 새 필수 위반이 없는 사람. 판정은 맞교환(D-1)과 같은 new_hard_keys다.

    파트장이 빨간 칸을 보고 명단을 위아래로 훑으며 "이 사람은 되나"를 하나씩 눌러 보던 자리.
    미적용 편집을 포함한 지금 화면 기준이고, 잠긴 칸(원티드·고정)은 후보에서 뺀다."""
    try:
        _require_generated()
    except ApiError as e:
        return _err(str(e))
    sch = _displayed_schedule()
    gen = S.gen
    report = build_report(sch, gen.days, gen.params, gen.requests)
    keys = {"D": Shift.D, "E": Shift.E, "N": Shift.N, "prn": Shift.PRN}
    locked = set(sch.locked) | set(S.locked_cells)
    items = []
    for day in report["daily"]:
        if day["ok"]:
            continue
        d = day["day"] - 1
        for key, shift in keys.items():
            need, have = day["min"].get(key, 0), day["counts"].get(key, 0)
            if have >= need:
                continue
            ok, blocked = [], []
            for s in sch.staff:
                if s.is_partjang or s.is_nk or (s.id, d) in locked:
                    continue
                v = sch.grid[s.id][d]
                if v not in (None, Shift.OFF) or not s.can(shift):
                    continue
                new_strict, new_soft = new_hard_keys(sch, gen.days, gen.params, {(s.id, d): shift})
                if new_strict:
                    blocked.append({"id": s.id, "rules": sorted({k[0] for k in new_strict})})
                else:
                    ok.append({"id": s.id, "level": s.level, "warnings": sorted({k[0] for k in new_soft})})
            ok.sort(key=lambda x: (len(x["warnings"]), -x["level"], x["id"]))
            items.append({"day": d + 1, "key": key, "need": need, "have": have,
                          "ok": ok, "blocked": blocked})
    return json.dumps({"items": items}, ensure_ascii=False)


def _prev_month_burden() -> dict:
    """연간근무표(입력②)가 있으면 지난달의 사람별 주말 근무·야간·D·E를 센다 — 이번 달과 견주려고.
    지난달 날짜가 연간 그리드에 다 있어야 하고, 없으면 빈 dict(화면이 그 줄을 안 그린다)."""
    tbl = S.staff_table_in
    if not tbl or S.gen is None:
        return {}
    dates = tbl.get("annual_dates") or []
    grid = tbl.get("annual_grid") or {}
    y, m = S.gen.year, S.gen.month
    py, pm = (y - 1, 12) if m == 1 else (y, m - 1)
    prefix = f"{py}-{pm:02d}-"
    idx = [i for i, ds in enumerate(dates) if str(ds)[:8] == prefix]
    if not idx:
        return {}
    import datetime as _dt
    hol, sub = kr_holidays_for_month(py, pm)
    holset = set(hol) | set(sub)
    weekend_idx = set()
    for i in idx:
        ds = str(dates[i])[:10]
        dt_ = _dt.date.fromisoformat(ds)
        if dt_.weekday() >= 5 or ds in holset:
            weekend_idx.add(i)
    rest = set(REST_SHIFTS) | {Shift.OFF}
    out = {}
    for s in S.gen.staff:
        row = grid.get(s.id)
        if not row:
            continue
        w = n = d = e = 0
        for i in idx:
            code = row[i] if i < len(row) else ""
            sh = parse_shift(code) if code not in (None, "", "/", "X") else Shift.OFF
            if sh is None:
                continue
            if sh in WORK_SHIFTS and i in weekend_idx:
                w += 1
            if sh in (Shift.N, Shift.NK):
                n += 1
            if sh == Shift.D:
                d += 1
            if sh == Shift.E:
                e += 1
        out[s.id] = {"weekend": w, "nights": n, "d": d, "e": e, "month": f"{py}-{pm:02d}"}
    return out


def api_fragile_map(body_json=None) -> str:
    """D-2: 칸마다 '새 필수 위반 없이 바꿀 수 있는 대안 개수'. 채택된 표 기준이다(미적용
    편집은 안 들어간다 — 적용되면 표가 새로 만들어지고 지도도 새로 만든다).

    본문 없이 부르면 전체를 한 번에 계산한다(테스트·소형 병동). 본문에
    {"staff_id", "day_from", "day_to"}를 주면 그 조각만 계산해 누적한다 — 40명 병동 전체가
    PC 3초, 브라우저는 그 서너 배라, 한 번에 돌리면 그 사이 누른 칸 편집이 Worker 뒤에서
    기다린다. 화면은 사람·반달 단위로 나눠 부른다. 조각이 다 모이면 합계를 함께 돌려준다."""
    try:
        _require_generated()
    except ApiError as e:
        return _err(str(e))
    fm = _current_fragile()
    if fm is None:
        fm = {}
        S.fragile = (id(S.sch), fm)
    data = json.loads(body_json) if body_json else {}
    total = len(S.sch.staff) * S.sch.num_days
    if data.get("staff_id") is not None:
        sid = data.get("staff_id")
        if sid not in S.sch.by_id:
            return _err("존재하지 않는 직원입니다")
        d0, d1 = data.get("day_from", 0), data.get("day_to", S.sch.num_days)
        if not (isinstance(d0, int) and isinstance(d1, int) and 0 <= d0 < d1 <= S.sch.num_days):
            return _err("잘못된 날짜 범위입니다")
        keys = [(sid, d) for d in range(d0, d1)]
        if any(k not in fm for k in keys):
            fm.update(fragile_map(S.sch, S.gen.days, S.gen.params, staff_ids=[sid], day_range=(d0, d1)))
        part = _fragile_cells_json(fm, keys)
    else:
        if len(fm) < total:
            fm.update(fragile_map(S.sch, S.gen.days, S.gen.params))
        part = _fragile_cells_json(fm)
    done = len(fm) >= total
    out = {"round": S.round, "total": total, "cells": part, "done": done}
    if done:
        fixed = sum(1 for v in fm.values() if v["alts"] == 0)
        row_fixed = sum(1 for v in fm.values() if v["row_fragile"])
        out.update({"fixed": fixed, "row_fixed": row_fixed, "swap_only": fixed - row_fixed})
    return json.dumps(out, ensure_ascii=False)


def api_swap_candidates(body_json: str) -> str:
    """D-1: 이 칸을 이 근무로 바꾸고 싶을 때, 그 날 그 근무를 가진 사람과 둘의 하루를
    맞바꿔도 새 필수 위반이 없는 상대를 형평·희망 보존 순으로."""
    try:
        _require_generated()
    except ApiError as e:
        return _err(str(e))
    data = json.loads(body_json)
    sid, day, shift_str = data.get("staff_id"), data.get("day"), data.get("shift")
    if sid not in S.sch.by_id:
        return _err("존재하지 않는 직원입니다")
    if isinstance(day, bool) or not isinstance(day, int) or not (0 <= day < S.sch.num_days):
        return _err("잘못된 날짜입니다")
    if not isinstance(shift_str, str):
        return _err(f"알 수 없는 근무유형: {shift_str!r}")
    try:
        want = parse_shift(shift_str)
    except ValueError:
        return _err(f"알 수 없는 근무유형: {shift_str}")
    temp = _displayed_schedule()
    locked = set(S.locked_cells) | set(S.pending_edits)
    res = swap_candidates(temp, S.gen.days, S.gen.params, sid, day, want,
                          requests=S.gen.requests, locked=locked, fragile=_current_fragile())
    return json.dumps(res, ensure_ascii=False)


@_journaled("/api/swap_stage")
def api_swap_stage(body_json: str) -> str:
    """D-1 채택: 고른 상대와의 맞교환을 미적용 편집 두 칸으로 올린다. 그 사이 표가 바뀌었을
    수 있으므로 올리기 직전에 '새 필수 위반 없음'을 한 번 더 확인한다 — 화면이 보여준
    후보 목록을 믿고 그냥 올리면, 다른 칸을 먼저 고친 뒤 눌렀을 때 위반이 생긴다."""
    try:
        _require_generated()
    except ApiError as e:
        return _err(str(e))
    data = json.loads(body_json)
    sid, day, partner = data.get("staff_id"), data.get("day"), data.get("partner")
    if sid not in S.sch.by_id or partner not in S.sch.by_id or sid == partner:
        return _err("존재하지 않는 직원입니다")
    if isinstance(day, bool) or not isinstance(day, int) or not (0 <= day < S.sch.num_days):
        return _err("잘못된 날짜입니다")
    temp = _displayed_schedule()
    mine, theirs = temp.grid[sid][day], temp.grid[partner][day]
    if mine is None or theirs is None or mine == theirs:
        return _err("두 사람의 그 날 근무가 같거나 비어 있어 바꿀 것이 없습니다")
    if (partner, day) in S.locked_cells or (partner, day) in S.pending_edits:
        return _err(f"{partner} {day + 1}일은 잠겨 있거나 편집 중이라 맞교환 상대로 쓸 수 없습니다")
    cells = {(sid, day): theirs, (partner, day): mine}
    new_strict, _ = new_hard_keys(temp, S.gen.days, S.gen.params, cells)
    if new_strict:
        rules = ", ".join(sorted({k[0] for k in new_strict}))
        return _err(f"그 사이 표가 바뀌어 이 맞교환은 새 필수 위반({rules})을 만듭니다 — 다시 찾아 주세요")
    for (s, d), v in cells.items():
        problem = _stage_edit(s, d, v.value)
        if problem:
            return _err(problem)
    return _full_state_json()


@_journaled("/api/edit/undo")
def api_edit_undo(body_json: str) -> str:
    data = json.loads(body_json)
    sid, day = data.get("staff_id"), data.get("day")
    S.pending_edits.pop((sid, day), None)
    return _full_state_json()


@_journaled("/api/discard")
def api_discard() -> str:
    S.pending_edits = {}
    return _full_state_json()


def api_feedback() -> str:
    try:
        _require_generated()
    except ApiError as e:
        return _err(str(e))
    if not S.pending_edits:
        return json.dumps({"hard": [], "soft": [], "edits": []}, ensure_ascii=False)

    temp = copy.deepcopy(S.sch)
    for (sid, d), shift in S.pending_edits.items():
        temp.grid[sid][d] = shift

    hard = all_hard_checks(temp, S.gen.days, S.gen.params)
    soft = [v for v in check_soft(temp, S.gen.days, S.gen.params) if v.severity == "soft"]

    def related(v):
        if v.staff_id:
            return any(sid == v.staff_id and (v.day is None or abs(v.day - d) <= 2)
                       for (sid, d) in S.pending_edits)
        if v.day is not None:
            return any(v.day == d for (_, d) in S.pending_edits)
        return False

    edits_list = [
        {"staff_id": sid, "day": d, "old": str(S.sch.grid[sid][d]), "new": str(shift)}
        for (sid, d), shift in sorted(S.pending_edits.items())
    ]
    return json.dumps({
        "hard": [{"rule": v.rule, "message": v.message} for v in hard if related(v)],
        "hard_other": len([v for v in hard if not related(v)]),
        "soft": [{"rule": v.rule, "message": v.message} for v in soft if related(v)],
        "edits": edits_list,
    }, ensure_ascii=False)


def _count_change(old_sch, new_sch, locked) -> dict:
    """직전 표와 새 표가 고정 칸 밖에서 다른 칸 수(사람 수) — 변경 최소성(fairscore)."""
    cells = 0
    people = set()
    for sid, row in new_sch.grid.items():
        old_row = (old_sch.grid.get(sid) if old_sch is not None else None) or []
        for d, v in enumerate(row):
            if (sid, d) in locked:
                continue
            ov = old_row[d] if d < len(old_row) else None
            if (ov or Shift.OFF) != (v or Shift.OFF):
                cells += 1
                people.add(sid)
    return {"cells": cells, "people": len(people), "locked": len(locked)}


@_journaled("/api/fair_weights")
def api_fair_weights(body_json: str) -> str:
    """공정성 점수 가중치(축 다섯·피로 셋)를 바꾸고 상태를 다시 보낸다. 숫자는 엔진이 0~5로 고른다
    (fairscore.clean_weights) — 화면은 돌려받은 값을 그대로 보여 주므로 잘린 값도 눈에 띈다."""
    try:
        _require_generated()
    except ApiError as e:
        return _err(str(e))
    try:
        b = json.loads(body_json or "{}")
    except ValueError:
        return _err("가중치 본문을 읽을 수 없습니다")
    if not isinstance(b, dict):
        return _err("가중치는 {axes:{…}, fatigue:{…}} 모양이어야 합니다")
    if "axes" in b and not isinstance(b["axes"], dict):
        return _err("축 가중치(axes)는 축 이름 → 숫자여야 합니다")
    if "fatigue" in b and not isinstance(b["fatigue"], dict):
        return _err("피로 가중치(fatigue)는 요소 이름 → 숫자여야 합니다")
    if "axes" in b:
        S.fair_weights = dict(b["axes"])
    if "fatigue" in b:
        S.fatigue_weights = dict(b["fatigue"])
    return _full_state_json()


@_journaled("/api/apply")
def api_apply(body_json=None) -> str:
    try:
        _require_generated()
    except ApiError as e:
        return _err(str(e))
    if not S.pending_edits:
        return _err("적용할 편집이 없습니다")

    S.locked_cells.update(S.pending_edits)
    o = _gen_opts(body_json)
    try:
        gen, sch = generate_best(S.cfg, fixed_cells=dict(S.locked_cells),
                                 seeds=o["seeds"], attempts=o["attempts"],
                                 time_budget=o["time_budget"], nights_fixed=S.nights_fixed)
    except InputError as e:
        return _err(f"재생성 실패: {e}")
    except Exception as e:
        return _err(f"재생성 중 오류가 발생했습니다: {e}")

    S.last_change = _count_change(S.sch, sch, S.locked_cells)
    S.gen, S.sch = gen, sch
    S.attempt_table = sch.attempt_table
    S.candidates = dict(sch.candidates or {})
    S.pending_edits = {}
    S.round += 1
    _sync_team_b_grid()
    if o["seeds"] is None:
        return _full_state_json()
    return json.dumps(_with_attempt(_full_state()), ensure_ascii=False)


@_journaled("/api/regenerate")
def api_regenerate(body_json=None) -> str:
    """지금 고정된 칸(수기 편집 + 올린 수정본)을 지키면서 나머지를 규칙에 맞게 다시 짠다.

    api_apply와 엔진은 같지만 입구가 다르다 — 저쪽은 '스테이징된 편집'이 있어야
    돌아가는데, 엑셀 수정본을 올린 뒤에는 스테이징이 비어 있어(파일이 곧 편집이므로)
    그 길로는 재생성을 못 한다.
    """
    try:
        _require_generated()
    except ApiError as e:
        return _err(str(e))
    # 미저장 수정이 있으면 버리지 말고 고정분에 합친다 — '재생성 적용'(api_apply)과
    # 같은 처리다. 예전엔 여기서 그냥 비워, 방금 화면에서 고친 칸이 확인도 없이
    # 원래 값으로 되돌아갔다.
    S.locked_cells.update(S.pending_edits)
    o = _gen_opts(body_json)
    try:
        gen, sch = generate_best(S.cfg, fixed_cells=dict(S.locked_cells),
                                 seeds=o["seeds"], attempts=o["attempts"],
                                 time_budget=o["time_budget"], nights_fixed=S.nights_fixed)
    except InputError as e:
        return _err(f"재생성 실패: {e}")
    except Exception as e:
        return _err(f"재생성 중 오류가 발생했습니다: {e}")
    S.last_change = _count_change(S.sch, sch, S.locked_cells)
    S.gen, S.sch = gen, sch
    S.attempt_table = sch.attempt_table
    S.candidates = dict(sch.candidates or {})
    S.pending_edits = {}
    S.round += 1
    _sync_team_b_grid()
    if o["seeds"] is None:
        return _full_state_json()
    return json.dumps(_with_attempt(_full_state()), ensure_ascii=False)


# ---------------------------------------------------------------- [야간 먼저] 두 단계 생성
# 1단계: 평소처럼 전체를 짠 뒤 화면이 야간만 보여 준다(night_stage). 파트장은 야간을 넣고·빼고·옮긴다.
# 2단계: api_confirm_nights가 야간과 그 뒤 휴식을 고정하고, 화면이 이어서 /api/regenerate를 부른다.
# 이때부터 nights_fixed — 엔진은 새 야간을 하나도 만들지 않는다(generator.Generator 참고).
# '전체 한 번에'(기본)는 이 길을 전혀 지나지 않는다.

@_journaled("/api/night_stage")
def api_night_stage(body_json=None) -> str:
    """야간만 보기 단계로 들어가거나(on=true) 나온다(on=false).

    다시 들어가면(야간을 확정한 뒤 '야간 다시 고치기') 확정을 푼다 — 고정해 둔 칸은 그대로라
    지금 야간은 유지되고, 파트장이 고친 만큼만 바뀐다."""
    try:
        _require_generated()
    except ApiError as e:
        return _err(str(e))
    on = True
    if body_json:
        try:
            on = bool(json.loads(body_json).get("on", True))
        except (ValueError, AttributeError):
            return _err("요청을 읽지 못했습니다")
    if on and S.pending_edits and not S.night_stage:
        # 적용 안 한 편집을 들고 들어가면 '야간 확정' 때 그 편집(주간 칸일 수 있다)까지 함께 잠긴다.
        return _err(f"적용하지 않은 편집 {len(S.pending_edits)}칸이 있습니다 — 먼저 '재생성 적용'하거나 "
                    "취소한 뒤 야간 단계로 돌아가 주세요")
    S.night_stage = on
    if on:
        S.nights_fixed = False
    return _full_state_json()


def _night_cells(sch, pending: dict) -> dict:
    """확정할 칸 — 야간(N·NK), 야간 블록 바로 뒤 이틀의 휴식(OFF·S/ 등), 그리고 달 어디든 S/.

    휴식까지 묶는 이유: 야간만 잠그면 2단계가 블록 바로 다음 날에 주간을 넣을 수 있고(H2-8 N→주간),
    S/는 야간 6회의 대가라 야간과 따로 움직이면 근거 없이 하루 덜 일하는 사람이 생긴다."""
    nd = sch.num_days
    out = {}
    for s in sch.staff:
        row = [pending.get((s.id, d), sch.grid[s.id][d]) for d in range(nd)]
        for d, v in enumerate(row):
            if v in NIGHT_SHIFTS or v == Shift.SLEEP_OFF:
                out[(s.id, d)] = v
            if v in NIGHT_SHIFTS and (d + 1 >= nd or row[d + 1] not in NIGHT_SHIFTS):
                for k in (1, 2):
                    if d + k < nd and row[d + k] in REST_SHIFTS:
                        out[(s.id, d + k)] = row[d + k]
    return out


@_journaled("/api/confirm_nights")
def api_confirm_nights(body_json=None) -> str:
    """지금 화면의 야간(미적용 편집 포함)을 고정한다. 나머지 짜기는 화면이 이어서 /api/regenerate로 한다.

    미적용 편집은 전부 고정분에 합친다 — 파트장이 야간을 지운 칸(N→OFF)도 여기 들어가야 2단계가
    그 자리에 야간을 되살리지 않는다(nights_fixed라 애초에 새 야간을 안 만들지만, 이중으로 막는다)."""
    try:
        _require_generated()
    except ApiError as e:
        return _err(str(e))
    cells = _night_cells(S.sch, S.pending_edits)
    S.locked_cells.update(S.pending_edits)
    S.locked_cells.update(cells)
    S.pending_edits = {}
    S.night_stage = False
    S.nights_fixed = True
    st = _full_state()
    st["confirmed_night_cells"] = sum(1 for v in cells.values() if v in NIGHT_SHIFTS)
    return json.dumps(st, ensure_ascii=False)


@_journaled("/api/upload_month")
def api_upload_month(file_bytes) -> str:
    """내려받아 엑셀에서 고친 월간근무표를 다시 올려 **화면에 그대로** 반영한다.

    재생성하지 않는다. '재생성 적용'은 표 전체를 다시 짜기 때문에(한 칸 수정에
    40명×30일 중 716칸이 움직인 사례) 엑셀에서 손으로 맞춰 놓은 배치가 통째로
    사라진다 — 그것이 이 기능이 필요해진 이유다. 올린 값을 그대로 넣고, 규칙 위반은
    막지 않고 화면에 표시만 한다(파트장이 알고 고친 것일 수 있다).

    바뀐 칸은 locked_cells에 넣어 '확정(고정)'으로 잠근다.
    """
    try:
        _require_generated()
    except ApiError as e:
        return _err(str(e))
    path = _tmp_path("month.xlsx")
    try:
        _write_temp_xlsx(file_bytes, path)
        data = load_prev_month_schedule_xlsx(path)
    except WrongInputSlotError as e:
        # 같은 파서를 입력② 칸과 나눠 쓰다 보니 원티드표를 여기 올리면 "입력② 칸에는
        # 지난달 파일을 올려주세요"가 떴다 — 이 칸은 입력②가 아니라 '수정 엑셀 되올리기'다.
        # 엉뚱한 칸 이름을 말하면 파트장은 입력② 칸으로 가서 또 올린다(2026-10-13 화면 훑기).
        return _wrong_slot_err("month", e)
    except ExcelInputError as e:
        return _err(f"엑셀 오류: {e}")
    except Exception as e:
        return _err(f"파일을 읽을 수 없습니다: {e}")

    bad = _unknown_grid_cells(data["grid"], data["num_days"])
    if bad:
        head = ", ".join(bad[:5]) + (f" 외 {len(bad) - 5}칸" if len(bad) > 5 else "")
        return _err(f"지원하지 않는 근무코드가 있습니다 — {head}. "
                    "해당 칸을 표준 코드로 고쳐서 다시 올려주세요.")
    team_b = set(S.sch.team_b_names or [])
    problems = month_upload_problems(
        data, S.gen.year, S.gen.month, S.sch.num_days,
        [s.id for s in S.sch.staff],
        [s.id for s in S.sch.staff if s.is_partjang], team_b)
    if problems:
        return _err(" / ".join(problems))

    # ⚠ 미저장 수정을 말없이 버리지 않는다. 파일이 화면 전체를 대신하므로 스테이징분은
    # 살릴 수 없는데, 예전엔 그것을 조용히 지웠다 — 파트장이 방금 화면에서 고친 칸이
    # 확인 한 번 없이 사라지고, 무엇이 없어졌는지 알 방법도 없었다.
    if S.pending_edits:
        return _err(
            f"화면에 아직 적용하지 않은 수정이 {len(S.pending_edits)}칸 있습니다 — "
            "파일을 올리면 그 수정은 사라집니다. \"재생성 적용\"으로 반영하시거나 "
            "\"전체 취소\"로 지우신 뒤에 올려주세요.")
    _sync_team_b_grid()
    # 반영 규칙은 엔진 한 벌(apply_month_upload)에 있다 — API에 따로 적으면 검사·
    # 테스트가 보는 규칙과 갈라진다(옛 Flask판과 두 벌이던 시절 실제로 그랬다).
    apply_month_upload(S.sch, data, S.team_b_grid, team_b,
                       S.locked_cells, S.gen.requests)
    S.sch.team_b_grid = S.team_b_grid
    S.round += 1
    return _full_state_json()



@_journaled("/api/baseline_month")
def api_baseline_month(file_bytes) -> str:
    """변경 안내 초안(GPT 11/2 보고서 N03)의 '공지 기준본' — 이미 공지한 출력①(월간근무표)을 읽기만 한다.

    화면 표는 바꾸지 않는다(되올리기 api_upload_month와 다른 점). 같은 파서로 읽고 근무 글자를 화면과 같은
    표준 글자로 바꿔 돌려주면, 비교는 화면이 지금 표와 한다. 다른 달·날수가 다른 파일은 반려한다 — 날짜가
    밀린 채로 비교하면 모든 사람이 '바뀐 사람'으로 나와 엉뚱한 안내가 나간다. 명단 차이(추가·삭제)는 반려하지
    않고 그대로 돌려줘 안내 목록에 '새로 들어온 사람/빠진 사람'으로 적게 한다.
    """
    try:
        _require_generated()
    except ApiError as e:
        return _err(str(e))
    path = _tmp_path("baseline.xlsx")
    try:
        _write_temp_xlsx(file_bytes, path)
        data = load_prev_month_schedule_xlsx(path)
    except WrongInputSlotError as e:
        return _wrong_slot_err("month", e)
    except ExcelInputError as e:
        return _err(f"엑셀 오류: {e}")
    except Exception as e:
        return _err(f"파일을 읽을 수 없습니다: {e}")
    if data.get("year") != S.gen.year or data.get("month") != S.gen.month:
        return _err(f"{data.get('year')}년 {data.get('month')}월 근무표입니다 — 지금 화면은 "
                    f"{S.gen.year}년 {S.gen.month}월입니다. 같은 달에 공지한 출력①을 올려주세요.")
    if data.get("num_days") != S.sch.num_days:
        return _err(f"날짜 칸이 {data.get('num_days')}일인데 이 달은 {S.sch.num_days}일입니다.")
    bad = _unknown_grid_cells(data["grid"], data["num_days"])
    if bad:
        head = ", ".join(bad[:5]) + (f" 외 {len(bad) - 5}칸" if len(bad) > 5 else "")
        return _err(f"지원하지 않는 근무코드가 있습니다 — {head}. 표준 코드로 고쳐서 다시 올려주세요.")
    team_b = set(data.get("team_b_names") or []) | set(S.sch.team_b_names or [])
    blanks = data.get("blanks") or {}
    grid = {}
    for sid, row in data["grid"].items():
        out, blank_row = [], blanks.get(sid) or []
        for d in range(S.sch.num_days):
            v = row[d] if d < len(row) else None
            raw = "" if v is None else str(v).strip()
            was_blank = blank_row[d] if d < len(blank_row) else False
            # 되올리기(apply_month_upload)와 같은 규칙 — B팀의 빈칸은 파서가 OFF로 채워 돌려주므로 blanks로
            # 되돌린다. 안 그러면 방금 내려받은 출력①을 기준본으로 올려도 B팀 둘이 '전부 바뀜'으로 나왔다.
            if sid in team_b:
                out.append("" if (was_blank or not raw) else str(parse_shift(raw)))
            else:
                out.append(str(parse_shift(raw)) if raw else str(Shift.OFF))
        grid[sid] = out
    return json.dumps({"year": data["year"], "month": data["month"], "grid": grid,
                       "team_b_names": sorted(team_b & set(grid))}, ensure_ascii=False)


# ---------------------------------------------------------------- 다운로드
# 브라우저에는 send_file이 없으므로 바이트/문자열을 그대로 반환하고,
# JS 쪽에서 Blob으로 감싸 다운로드를 띄운다.

@_journaled("/api/download/xlsx")
def api_download_xlsx():
    try:
        _require_generated()
    except ApiError as e:
        return None
    path = _tmp_path("out.xlsx")
    export_excel(S.sch, S.gen.days, path, fair=_fair(S.sch))
    with open(path, "rb") as f:
        return f.read()


@_journaled("/api/download/xlsx_ocs")
def api_download_xlsx_ocs():
    """병원 OCS 원본과 같은 모양(간호스케줄)으로 내보내기."""
    try:
        _require_generated()
    except ApiError as e:
        return None
    path = _tmp_path("out_ocs.xlsx")
    export_excel_ocs(S.sch, S.gen.days, path, violations=_report_summary()["hard"],
                         min_staff=S.gen.params.min_staff, fair=_fair(S.sch))
    with open(path, "rb") as f:
        return f.read()


@_journaled("/api/download/staff_table")
def api_download_staff_table():
    """'연간근무표' 갱신본 다운로드 — 다음 달엔 이 파일을 그대로 다시 업로드하면 된다."""
    try:
        _require_generated()
    except ApiError as e:
        return None
    stats, annual_dates, annual_grid, departed = _build_updated_staff_table()
    path = _tmp_path("staff_table_out.xlsx")
    export_staff_table_xlsx(_ordered_staff_for_display(), stats, annual_dates, annual_grid, path,
                            last_reflected=f"{S.gen.year}년 {S.gen.month}월",
                            team_b_names=S.gen.params.team_b_names,
                            departed=departed)
    with open(path, "rb") as f:
        return f.read()


def api_download_wanted_template(body_json: str):
    """입력① 원티드표 양식 — 화면에서 고른 연/월에 맞는 일수로, 지금 화면에 있는
    인원 목록(직급·숙련도·가능근무·비고 포함) 그대로 채워서 만들어준다.
    생성된 근무표(S.gen)와는 무관하게 항상 가능."""
    body = json.loads(body_json)
    year = int(body["year"])
    month = int(body["month"])
    staff = body.get("staff") or []
    team_b_names = body.get("team_b_names") or []
    path = _tmp_path("wanted_template.xlsx")
    generate_wanted_template_xlsx(year, month, staff, path, team_b_names=team_b_names)
    with open(path, "rb") as f:
        return f.read()


_FILENAME_UNSAFE = re.compile(r'[\\/:*?"<>|\s]+')


def _download_filename(kind: str) -> str:
    """다운로드 파일명 = {종류}_{병동명}_{연도}-{월}.xlsx (병동명 없으면 생략)."""
    ward = (S.cfg or {}).get("ward_id", "") if S.cfg else ""
    ward = _FILENAME_UNSAFE.sub("", str(ward or "").strip())
    parts = [kind] + ([ward] if ward else []) + [f"{S.gen.year}-{S.gen.month:02d}"]
    return "_".join(parts) + ".xlsx"


def download_filename_schedule() -> str:
    if S.gen is None:
        return "출력1_월간근무표.xlsx"
    name = _download_filename("출력1_월간근무표")
    return name[:-5] + f"_r{S.round}.xlsx"


def download_filename_schedule_ocs() -> str:
    if S.gen is None:
        return "출력1_월간근무표.xlsx"
    name = _download_filename("출력1_월간근무표")
    return name[:-5] + f"_r{S.round}.xlsx"


def download_filename_staff_table() -> str:
    if S.gen is None:
        return "출력2_연간근무표.xlsx"
    return _download_filename("출력2_연간근무표")


# ---------------------------------------------------------------- 문의 파일(VOC)
# 파트장이 "이거 이상해요"를 보낼 때 쓰는 한 묶음(zip). 이름·내용 + 그 화면에 이르기까지의 입력·출력·한 일을 앱이
# 넣어 준다 — 사람이 파일을 골라 붙이게 하면 빠지고, 말로 옮긴 조작 순서는 틀린다. 앱은 어디로도 보내지 않는다:
# 사용자가 이 파일을 받아 직접 메일에 붙여 보내고, 읽고 해결하는 것은 사람이 한다. "입력이 브라우저 밖으로
# 나가지 않는다"는 약속 때문이다. 받은 사람이 볼 것은 zip 안의 '문의내용.txt' — 그 화면을 다시 만들어 보려면
# python tools/voc_replay.py 문의.zip  (docs/voc/README.md)
VOC_FORMAT = 1
_VOC_SLOT_NAMES = {
    "/api/upload_wanted": "입력1_원티드표",
    "/api/upload_staff_table": "입력2_연간근무표",
    "/api/upload_month": "되올린_월간근무표",
    "/api/baseline_month": "공지기준_월간근무표",
}
_VOC_ACTION_NAMES = {
    "/api/upload_wanted": "입력① 올림", "/api/upload_staff_table": "입력② 올림",
    "/api/clear_staff_table": "입력② 반영 해제", "/api/set_config": "입력 확정",
    "/api/generate": "생성", "/api/pick_attempt": "시도 비교", "/api/generate_seed": "고른 시도로 다시 계산",
    "/api/select_attempt": "점수표에서 다른 시도 선택", "/api/edit": "칸 수정", "/api/edit/team_b": "B팀 칸 수정",
    "/api/edit/undo": "칸 수정 취소", "/api/swap_stage": "맞교환 올림", "/api/discard": "편집 전부 버림",
    "/api/apply": "편집 적용(재생성)", "/api/regenerate": "재생성", "/api/fair_weights": "형평성 가중치 변경",
    "/api/upload_month": "수정한 월간근무표 되올림", "/api/baseline_month": "공지 기준 월간근무표 올림",
    "/api/night_stage": "[야간 먼저] 야간만 보기", "/api/confirm_nights": "[야간 먼저] 야간 확정",
    "/api/download/xlsx": "출력①(색 표시 모양) 받음", "/api/download/xlsx_ocs": "출력① 받음",
    "/api/download/staff_table": "출력② 받음",
}


def _voc_clock(t, offset_min) -> str:
    """기록 시각(초) → 사용자의 기기 시각 글자. Worker에는 시간대가 없어(UTC) 화면이 보낸 차이를 더한다."""
    try:
        return time.strftime("%m-%d %H:%M:%S", time.gmtime(float(t) + 60 * int(offset_min or 0)))
    except Exception:
        return "?"


def _voc_action_line(e: dict, offset_min) -> str:
    what = _VOC_ACTION_NAMES.get(e.get("path"), e.get("path"))
    b = e.get("body") if isinstance(e.get("body"), dict) else {}
    extra = ""
    if e["path"] == "/api/edit":
        day = b.get("day")
        extra = f" {b.get('staff_id')} {day + 1 if isinstance(day, int) else day}일 {e.get('was', '?')}→{b.get('shift')}"
    elif e["path"] == "/api/edit/undo":
        day = b.get("day")
        extra = f" {b.get('staff_id')} {day + 1 if isinstance(day, int) else day}일"
    elif e["path"] == "/api/edit/team_b":
        day = b.get("day")
        extra = f" {b.get('name')} {day + 1 if isinstance(day, int) else day}일 →{b.get('shift')}"
    elif e["path"] == "/api/select_attempt":
        extra = f" 시드 {b.get('seed')}"
    elif e["path"] == "/api/night_stage":
        extra = " 단계로 들어감" if b.get("on", True) else " 단계에서 나옴"
    elif "size" in e:
        extra = f" ({e['size'] // 1024 or 1}KB)"
    snap = e.get("snapshot")
    tail = ""
    if e.get("error"):
        tail = " → 반려·오류: " + str(e["error"]).split("\n")[0][:160]
    elif snap:
        tail = f" → r{snap.get('round')} · 필수 위반 {snap.get('hard_count')}건 · 형평성 {snap.get('fair_total')}"
    return f"{e.get('n', '?'):>3}. {_voc_clock(e.get('t'), offset_min)}  {what}{extra}{tail}"


def _voc_state() -> dict | None:
    if S.gen is None or S.sch is None:
        return None
    rep = _report_summary()
    return {
        "ward_id": (S.cfg or {}).get("ward_id", ""),
        "year": S.gen.year, "month": S.gen.month, "num_days": S.sch.num_days,
        "round": S.round, "seed": S.gen.seed,
        "grid": _display_grid(),                    # 화면에 보이는 그대로(미적용 편집을 얹은 표)
        "grid_applied": {s.id: [str(v) for v in S.sch.grid[s.id]] for s in _ordered_staff_for_display()},
        "days": [{"n": d["n"], "dow": d["dow"], "weekend": d["weekend"]} for d in _days_meta()],
        "wanted": _wanted_keys(),
        "locked": _fixed_list(S.locked_cells), "pending": _fixed_list(S.pending_edits),
        "night_stage": bool(S.night_stage), "nights_fixed": bool(S.nights_fixed),
        "team_b_grid": S.team_b_grid,
        "fair_weights": S.fair_weights, "fatigue_weights": S.fatigue_weights,
        "last_change": S.last_change, "attempt_table": S.attempt_table,
        "hard_count": rep["hard_count"], "hard": rep["hard"],
        "soft_count": rep["soft_count"], "soft": rep["soft"],
        "requests_all": rep["requests_all"], "logs": rep["logs"], "timed_out": rep["timed_out"],
        "fair": _fair(S.sch),
    }


def _voc_text(report: dict, client: dict, state: dict | None, journal: list, files: dict, export_errors: dict) -> str:
    off = client.get("tz_offset_min")
    L = ["SMC Fair Shift 문의", "=" * 40,
         f"보낸 사람 : {str(report.get('name') or '(적지 않음)').strip()}",
         f"만든 때   : {client.get('time_local', '?')} (기기 시각) · {client.get('screen', '?')} 화면에서",
         f"앱        : {client.get('version', '?')} · {client.get('build', '?')}",
         "", "[내용]", str(report.get("text") or "(적지 않음)").strip(), "",
         "-" * 40, "지금 화면"]
    if state:
        L.append(f"  {state['ward_id'] or '(병동명 없음)'} · {state['year']}년 {state['month']}월 · {state['round']}회차 · 시드 {state['seed']}")
        L.append(f"  필수 위반 {state['hard_count']}건 · 권장 {state['soft_count']}건 · 형평성 점수 {state['fair'].get('total')}")
        L.append(f"  적용 안 한 편집 {len(state['pending'])}칸 · 고정된 칸 {len(state['locked'])}칸")
    else:
        L.append("  아직 생성된 근무표가 없음")
    L += ["", "-" * 40, f"한 일 (순서대로 {len(journal)}줄" + (f", 앞의 {S.journal_dropped}줄은 상한을 넘어 버림" if S.journal_dropped else "") + ")"]
    L += ["  " + _voc_action_line(e, off) for e in journal] or ["  (기록 없음)"]
    L += ["", "-" * 40, "들어 있는 파일"]
    L += [f"  {name} — {what}" for name, what in files.items()] or ["  (없음)"]
    if export_errors:
        L += ["", "출력 파일을 만들다 난 오류"] + [f"  {k}: {v}" for k, v in export_errors.items()]
    L += ["", "-" * 40, "기기",
          f"  브라우저 : {client.get('ua', '?')}",
          f"  화면     : {client.get('viewport', '?')} · 생성 방식 {client.get('gen_mode', '?')}"]
    notices = [str(x) for x in (client.get("notices") or []) if x]
    if notices:
        L += ["", "화면에 떠 있던 안내"] + [f"  {x.splitlines()[0][:300]}" for x in notices]
    form = client.get("form") if isinstance(client.get("form"), dict) else {}
    if form.get("unreadable"):
        L += ["", "입력 화면에서 못 읽은 칸"] + [f"  {str(x)[:200]}" for x in form["unreadable"][:20]]
    if form.get("error"):
        L += ["", f"입력 화면 값을 읽다 난 오류: {form['error']}"]
    toasts = client.get("toasts") or []
    if toasts:
        L += ["", "화면에 떴던 알림 (최근 것)"] + [f"  {t.get('at', '')} {'[오류] ' if t.get('err') else ''}{str(t.get('msg', '')).splitlines()[0][:200] if t.get('msg') else ''}" for t in toasts if isinstance(t, dict)]
    errs = client.get("js_errors") or []
    if errs:
        L += ["", "스크립트 오류"] + [f"  {str(x)[:300]}" for x in errs]
    return "\r\n".join(L) + "\r\n"       # 메모장에서 줄이 붙지 않게


#: zip 안에서 기계가 읽는 파일. 사람이 볼 것은 문의내용.txt와 검토용.xlsx, 입력/·출력/ 폴더의 엑셀이다.
VOC_DATA_NAME = "다시보기용_데이터.json"
_VOC_DATA_LEGACY = "문의.json"              # 2026-11-11 이전에 받은 문의 파일


def _voc_last_upload(path: str):
    """그 칸에 마지막으로 **정상 반영된** 업로드의 기록 줄(없으면 None)."""
    for e in reversed(S.journal):
        if e.get("path") == path and not e.get("error") and "size" in e:
            return e
    return None


def _voc_input_files(notes: dict) -> dict:
    """입력/ 폴더 — **올린 파일만, 원본 그대로.** 명단·신청은 파일로만 들어오므로(화면에서 고칠 수 없다) 올린 그 파일이
    곧 입력이다. 안 올린 칸은 넣지 않고 그렇다고 적는다: 입력②만 올렸으면 ②만, 아무것도 안 올렸으면 앱에 들어 있는
    예시 명단으로 만든 표다(그 파일은 templates/입력1_원티드표_샘플.xlsx — 문의마다 실을 이유가 없다).
    돌려주는 것: {기록 번호 n: zip 안의 이름} — 그 칸에 마지막으로 정상 반영된 업로드."""
    out = {}
    for path, name, label in (("/api/upload_wanted", "입력/입력1_원티드표.xlsx", "입력① 원티드표"),
                              ("/api/upload_staff_table", "입력/입력2_연간근무표.xlsx", "입력② 연간근무표")):
        e = _voc_last_upload(path)
        if path == "/api/upload_staff_table" and S.staff_table_in is None:
            e = None                                   # 올렸다가 '반영 해제'한 경우
        if e is None:
            notes[label] = "올리지 않음"
        elif e.get("_bytes") is None:
            notes[label] = "올렸지만 기록 용량 상한으로 원본이 빠졌습니다"
        else:
            out[e.get("n")] = name
            notes[name] = f"올린 파일 그대로(한 일 {e.get('n')}번)"
    if not out and not any("상한" in v for v in notes.values()):
        notes["입력 파일"] = "올린 파일 없음 — 앱에 들어 있는 예시 명단으로 만든 표입니다"
    return out


def _voc_first_table(journal: list):
    """마지막 '근무표 생성'으로 처음 본 표(그 뒤의 수정·재생성 전). 병렬 생성은 생성 → 시도 비교 → 고른 시드로
    다시 계산 순서라, 그 묶음의 마지막 표가 화면에 처음 뜬 표다."""
    start = None
    for i, e in enumerate(journal):
        if e.get("path") == "/api/generate" and e.get("snapshot"):
            start = i
    if start is None:
        return None
    snap = journal[start]["snapshot"]
    for e in journal[start + 1:]:
        if e.get("path") == "/api/pick_attempt":
            continue
        if e.get("path") == "/api/generate_seed" and e.get("snapshot"):
            snap = e["snapshot"]
            continue
        break
    return snap.get("grid")


def _voc_review_xlsx(report: dict, client: dict, state: dict | None, journal: list, notes: dict) -> bytes:
    """검토용.xlsx — 문의를 받은 사람이 엑셀만 열어도 무슨 일이 있었는지 보게. 시트: 문의 · 한 일 · 고친 칸 ·
    지금 표 · 생성 직후 표 · 위반 · 신청 · 명단 · 설정."""
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    bold = Font(bold=True)
    head_fill = PatternFill("solid", fgColor="DDEBE7")
    f_fixed = PatternFill("solid", fgColor="FFE08A")      # 직접 고쳐 고정된 칸
    f_pending = PatternFill("solid", fgColor="FFB480")    # 고쳤지만 아직 적용 안 한 칸
    f_regen = PatternFill("solid", fgColor="CFE3FA")      # 재생성하면서 엔진이 바꾼 칸
    wb = Workbook()

    made = []

    def sheet(title, headers=None, widths=None):
        ws = wb.create_sheet() if made else wb.active       # 새 통합문서의 빈 첫 시트부터 쓴다
        made.append(title)
        ws.title = title
        if headers:
            for c, h in enumerate(headers, 1):
                cell = ws.cell(1, c, h)
                cell.font, cell.fill = bold, head_fill
            ws.freeze_panes = "A2"
        for c, w in enumerate(widths or [], 1):
            ws.column_dimensions[get_column_letter(c)].width = w
        return ws

    off = client.get("tz_offset_min")
    form = client.get("form") if isinstance(client.get("form"), dict) else {}
    cfg = S.cfg or (form.get("cfg") if isinstance(form.get("cfg"), dict) else None) or {}

    # ---- 문의
    ws = sheet("문의", widths=[18, 90])
    rows = [("보낸 사람", str(report.get("name") or "")), ("내용", str(report.get("text") or "")),
            ("만든 때", f"{client.get('time_local', '?')} (기기 시각) · {client.get('screen', '?')} 화면에서"),
            ("앱", f"{client.get('version', '?')} · {client.get('build', '?')}"),
            ("브라우저", str(client.get("ua", "?")))]
    if state:
        rows += [("근무표", f"{state['ward_id'] or '(병동명 없음)'} · {state['year']}년 {state['month']}월 · "
                            f"{state['round']}회차 · 시드 {state['seed']}"),
                 ("검증", f"필수 위반 {state['hard_count']}건 · 추가 검토 {state['soft_count']}건 · "
                          f"형평성 점수 {state['fair'].get('total')}"),
                 ("손댄 칸", f"고정된 칸 {len(state['locked'])}칸 · 적용 안 한 편집 {len(state['pending'])}칸")]
    else:
        rows.append(("근무표", "아직 생성 전"))
    for x in (client.get("notices") or []):
        rows.append(("화면의 안내", str(x)))
    rows.append(("", ""))
    rows.append(("들어 있는 파일", ""))
    rows += [(k, v) for k, v in notes.items()]
    for r, (k, v) in enumerate(rows, 1):
        ws.cell(r, 1, k).font = bold
        ws.cell(r, 2, v).alignment = Alignment(wrap_text=True, vertical="top")

    # ---- 한 일
    ws = sheet("한 일", ["번호", "시각", "한 일", "누구", "며칠", "전", "후", "결과"], [6, 16, 26, 14, 7, 8, 8, 70])
    for e in journal:
        b = e.get("body") if isinstance(e.get("body"), dict) else {}
        who = b.get("staff_id") or b.get("name") or ""
        day = b.get("day")
        result = ""
        if e.get("error"):
            result = "반려·오류: " + str(e["error"])
        elif e.get("snapshot"):
            sn = e["snapshot"]
            result = f"{sn.get('round')}회차 · 필수 위반 {sn.get('hard_count')}건 · 형평성 {sn.get('fair_total')}"
        elif "size" in e:
            result = f"{e['size'] // 1024 or 1}KB" + (f" → {e.get('file')}" if e.get("file") else "")
        ws.append([e.get("n"), _voc_clock(e.get("t"), off), _VOC_ACTION_NAMES.get(e.get("path"), e.get("path")),
                   who if e.get("path", "").startswith(("/api/edit", "/api/swap")) else "",
                   day + 1 if isinstance(day, int) and not isinstance(day, bool) else "",
                   e.get("was", ""), b.get("shift", "") if e.get("path", "").startswith("/api/edit") else "",
                   result])

    # ---- 표 세 장(고친 칸 · 지금 표 · 생성 직후 표)
    if state:
        first = _voc_first_table(journal) or {}
        now = state["grid"]
        locked = {(sid, d) for sid, d, _v in state["locked"]}
        pending = {(sid, d) for sid, d, _v in state["pending"]}
        wanted = set(state.get("wanted") or [])
        days = state.get("days") or [{"n": i + 1, "dow": "", "weekend": False} for i in range(state["num_days"])]

        def show(sid, d, code):
            return ("X" if f"{sid}:{d}" in wanted else "/") if code == "OFF" else code

        # 고친 칸 — 사람이 손댄 칸만(고정된 것·아직 적용 안 한 것). 재생성하면서 엔진이 바꾼 칸은 수백 칸이라 여기 섞으면
        # 정작 손댄 칸이 묻힌다 — 그쪽은 수만 적고 '지금 표'의 파란 칸으로 본다.
        ws = sheet("고친 칸", ["누구", "며칠", "요일", "생성 직후", "지금", "구분"], [14, 7, 6, 10, 10, 40])
        n_hand = n_engine = 0
        for sid, row in now.items():
            base = first.get(sid)
            for d, v in enumerate(row):
                key = (sid, d)
                if key not in locked and key not in pending:
                    n_engine += 1 if (base is not None and d < len(base) and base[d] != v) else 0
                    continue
                ws.append([sid, d + 1, days[d]["dow"] if d < len(days) else "",
                           show(sid, d, base[d]) if base is not None and d < len(base) else "",
                           show(sid, d, v),
                           "직접 고침 · 아직 적용 안 함" if key in pending else "직접 고침(또는 되올린 수정본) · 고정"])
                ws.cell(ws.max_row, 6).fill = f_pending if key in pending else f_fixed
                n_hand += 1
        if not n_hand:
            ws.append(["(손으로 고친 칸 없음)"])
        ws.append([])
        ws.append([f"재생성하면서 바뀐 칸 {n_engine}칸 — '지금 표' 시트의 파란 칸('생성 직후 표'와 견준 것)"])

        def grid_sheet(title, grid, mark):
            ws = sheet(title, widths=[14])
            ws.cell(1, 1, "이름").font = bold
            for d, meta in enumerate(days):
                c = ws.cell(1, d + 2, f"{meta['n']}\n{meta['dow']}")
                c.font, c.alignment = bold, Alignment(wrap_text=True, horizontal="center")
                c.fill = PatternFill("solid", fgColor="F8D7DA") if meta.get("weekend") else head_fill
                ws.column_dimensions[get_column_letter(d + 2)].width = 4.6
            ws.row_dimensions[1].height = 30
            for r, (sid, row) in enumerate(grid.items(), 2):
                ws.cell(r, 1, sid)
                for d, v in enumerate(row):
                    c = ws.cell(r, d + 2, show(sid, d, v))
                    c.alignment = Alignment(horizontal="center")
                    if mark:
                        key = (sid, d)
                        base = first.get(sid)
                        if key in pending:
                            c.fill = f_pending
                        elif key in locked:
                            c.fill = f_fixed
                        elif base is not None and d < len(base) and base[d] != v:
                            c.fill = f_regen
            r = len(grid) + 3
            for sid, codes in (state.get("team_b_grid") or {}).items():
                ws.cell(r, 1, f"{sid} (B팀)")
                for d, v in enumerate(codes):
                    ws.cell(r, d + 2, v).alignment = Alignment(horizontal="center")
                r += 1
            if mark:
                r += 1
                for fill, label in ((f_fixed, "직접 고쳐 고정된 칸"), (f_pending, "고쳤지만 아직 적용 안 한 칸"),
                                    (f_regen, "재생성하면서 바뀐 칸(생성 직후 표와 다름)")):
                    ws.cell(r, 1).fill = fill
                    ws.cell(r, 2, label)
                    r += 1
            ws.freeze_panes = "B2"

        grid_sheet("지금 표", now, True)
        if first:
            grid_sheet("생성 직후 표", first, False)

        ws = sheet("위반", ["구분", "규칙", "며칠", "누구", "내용"], [14, 9, 7, 14, 90])
        for v in state.get("hard") or []:
            ws.append(["추가 검토(최선노력)" if v.get("best_effort") else "필수", v.get("rule"), v.get("day") or "",
                       v.get("staff_id") or "", v.get("message")])
        for v in state.get("soft") or []:
            ws.append(["권장", v.get("rule"), v.get("day") or "", v.get("staff_id") or "", v.get("message")])
        if ws.max_row == 1:
            ws.append(["(없음)"])

    # ---- 신청 · 명단 · 설정 — 생성 전이면 입력 화면 값으로
    ws = sheet("신청", ["누구", "날짜", "종류", "반영", "반영 안 된 이유"], [14, 13, 8, 8, 70])
    reqs = (state or {}).get("requests_all")
    if reqs is not None:
        for r in reqs:
            ws.append([r.get("staff_id"), r.get("date"), "OFF 희망" if r.get("type") == "OFF" else r.get("type"),
                       "반영" if r.get("accepted") else "반영 안 됨", r.get("reason") or ""])
    else:
        for r in cfg.get("requests") or []:
            ws.append([r.get("staff_id"), r.get("date"), "OFF 희망" if r.get("type") == "OFF" else r.get("type"),
                       "(생성 전)", ""])
    if ws.max_row == 1:
        ws.append(["(신청 없음)"])

    ws = sheet("명단", ["이름", "직급", "숙련도", "가능 근무", "표시"], [14, 9, 8, 22, 34])
    for row in cfg.get("staff") or []:
        if isinstance(row, dict):
            ws.append([row.get("id"), row.get("role"), row.get("level"), ", ".join(row.get("allowed_shifts") or []),
                       ", ".join(row.get("flags") or [])])
    for name in cfg.get("team_b_names") or (cfg.get("params") or {}).get("team_b_names") or []:
        ws.append([name, "B팀(신입)", "", "", ""])

    ws = sheet("설정", ["항목", "값"], [44, 60])
    ws.append(["병동", cfg.get("ward_id", "")])
    ws.append(["연월", f"{cfg.get('year', '?')}년 {cfg.get('month', '?')}월"])

    def flat(prefix, v):
        if isinstance(v, dict):
            for k, x in v.items():
                flat(f"{prefix}.{k}" if prefix else str(k), x)
        else:
            ws.append([prefix, json.dumps(v, ensure_ascii=False) if isinstance(v, (list, tuple, bool)) or v is None else v])
    flat("", cfg.get("params") or {})
    if form.get("unreadable"):
        ws.append(["", ""])
        for x in form["unreadable"]:
            ws.append(["입력 화면에서 못 읽은 칸", str(x)])

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def api_download_voc(body_json=None):
    """문의 파일(zip) — 적은 글, 입력·출력 엑셀, 사람이 볼 검토용 엑셀, 다시 보기용 데이터. 생성 전에도 만들 수 있다
    (입력을 올렸더니 반려됐다는 문의가 그 경우다)."""
    try:
        body = json.loads(body_json) if body_json else {}
    except ValueError:
        body = {}
    report = body.get("report") if isinstance(body.get("report"), dict) else {}
    client = body.get("client") if isinstance(body.get("client"), dict) else {}

    files: dict[str, bytes] = {}
    notes: dict[str, str] = {}                  # 파일 이름 → 무엇인지(문의내용.txt·검토용.xlsx의 '들어 있는 파일')
    export_errors: dict = {}
    # 지금 반영돼 있는 입력①②는 입력/에, 그 밖의 업로드(앞서 올린 것·반려된 것·되올린 수정본)는 올린파일/에 번호를 붙여.
    # 같은 파일을 두 폴더에 겹쳐 넣지 않는다 — 받은 사람이 "어느 게 진짜 입력이냐"를 묻게 된다.
    input_names: dict = {}
    try:
        input_names = _voc_input_files(notes)
    except Exception as e:
        export_errors["입력"] = f"{type(e).__name__}: {e}"
    journal = []
    for e in S.journal:
        j = {k: v for k, v in e.items() if k != "_bytes"}
        if e.get("_bytes") is not None:
            name = input_names.get(e.get("n"))
            if name is None:
                name = f"올린파일/{e.get('n', 0):03d}_{_VOC_SLOT_NAMES.get(e['path'], 'file')}.xlsx"
                notes[name] = ("올렸지만 반려된 파일" if e.get("error") else
                               "그 밖에 올린 파일(앞서 올린 것·되올린 수정본 등) — 한 일의 번호 순")
            files[name] = e["_bytes"]
            j["file"] = name
        journal.append(j)

    state = None
    try:
        state = _voc_state()
    except Exception as e:                       # 상태를 못 읽는 것 자체가 문의감이다 — 묶음은 만든다
        export_errors["state"] = f"{type(e).__name__}: {e}"
    if S.gen is not None and S.sch is not None:
        # 화면의 다운로드 버튼이 주는 것과 같은 두 파일(출력① = OCS 모양, 출력②)
        for name, fn in (("출력/출력1_월간근무표.xlsx", api_download_xlsx_ocs),
                         ("출력/출력2_연간근무표.xlsx", api_download_staff_table)):
            try:
                data = fn.__wrapped__()          # 기록(@_journaled)을 거치지 않게 — '받음'으로 적히면 거짓이다
                if data:
                    files[name] = data
                    notes[name] = ("지금 다운로드 버튼이 줬을 파일" +
                                   (" — 적용 안 한 편집은 들어 있지 않음(검토용.xlsx '지금 표'에는 있음)"
                                    if S.pending_edits and "출력1" in name else ""))
            except Exception as e:
                export_errors[name] = f"{type(e).__name__}: {e}"
    try:
        files["검토용.xlsx"] = _voc_review_xlsx(report, client, state, journal, dict(notes))
        notes["검토용.xlsx"] = "사람이 볼 요약 — 문의 · 한 일 · 고친 칸 · 지금 표 · 생성 직후 표 · 위반 · 신청 · 명단 · 설정"
    except Exception as e:
        export_errors["검토용.xlsx"] = f"{type(e).__name__}: {e}"
    notes[VOC_DATA_NAME] = "앱이 그 화면을 다시 띄울 때 읽는 파일(사람이 열 필요 없음)"

    doc = {
        "format": VOC_FORMAT, "report": report, "client": client, "state": state,
        "cfg": S.cfg, "staff_table_loaded": S.staff_table_in is not None,
        "journal": journal, "journal_dropped": S.journal_dropped,
        "export_errors": export_errors, "files": sorted(files),
    }
    text = _voc_text(report, client, state, journal, notes, export_errors)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("문의내용.txt", text)
        z.writestr(VOC_DATA_NAME, json.dumps(doc, ensure_ascii=False, indent=1, default=str))
        for name, data in files.items():
            z.writestr(name, data)

    stamp = re.sub(r"\D", "", str(client.get("time_local") or ""))[:12]      # 202611101423
    ward = _FILENAME_UNSAFE.sub("", str((S.cfg or {}).get("ward_id") or "").strip())
    ym = f"{S.gen.year}-{S.gen.month:02d}" if S.gen is not None else ""
    # 받는 사람이 메일함에서 가려 보게 — 누가·어느 병동·몇 월·언제. 이름의 못 쓰는 글자는 병동명과 같은 규칙으로 뺀다.
    who = _FILENAME_UNSAFE.sub("", str(report.get("name") or "").strip())[:20]
    S.voc_filename = "_".join(x for x in ("문의", who, ward, ym, stamp or f"{S.journal_seq:03d}") if x) + ".zip"
    return buf.getvalue()


def api_download_filename_voc() -> str:
    return S.voc_filename or "문의.zip"


# ---- 문의 파일 다시 보기 — 받은 zip을 올리면 그 사람이 보던 화면을 다시 만든다
# 기록된 요청을 같은 순서로 같은 함수에 다시 넣는다(엔진은 같은 입력·같은 시드에 같은 표를 낸다). 표를 통째로
# 덮어쓰지 않고 다시 밟는 이유: 화면은 표만이 아니다 — 원티드 반영 여부, 위반 목록, 점수표, 고정·미적용 칸, 회차가
# 전부 그 과정에서 나온다. 다 밟은 뒤 문의의 표와 칸 단위로 견주고, 다르면(판이 다르거나 느린 기기에서 시간
# 안전판에 끊긴 경우) 기록된 표로 맞춘 뒤 그 사실을 알린다. 받는 쪽 도구(tools/voc_replay.py)도 이 함수를 부른다.

def _voc_put_recorded(st: dict, everything: bool = False) -> int:
    """문의에 적힌 화면(표·고정 칸·미적용 편집·회차)을 지금 표 위에 얹는다. 돌려주는 것: 그러고도 다른 칸 수.
    칸 대입은 _TrackedRow가 주말·야간 수까지 다시 센다. everything이면 다시 밟지 않아 비어 있는 것(B팀 칸·가중치·
    점수표·야간 단계)까지 문의의 것으로 채운다."""
    applied = st.get("grid_applied") or st.get("grid") or {}
    for sid, row in applied.items():
        if sid in S.sch.grid:
            for d, v in enumerate(row[:S.sch.num_days]):
                if str(S.sch.grid[sid][d]) != v:
                    S.sch.grid[sid][d] = parse_shift(v)
    S.locked_cells = _fixed_from_list(st.get("locked"))
    S.pending_edits = {k: v for k, v in _fixed_from_list(st.get("pending")).items() if k[0] in S.sch.grid}
    if isinstance(st.get("round"), int):
        S.round = st["round"]
    if everything:
        if isinstance(st.get("team_b_grid"), dict):
            S.team_b_grid = st["team_b_grid"]
        S.fair_weights = dict(st.get("fair_weights") or {})
        S.fatigue_weights = dict(st.get("fatigue_weights") or {})
        S.attempt_table = st.get("attempt_table")
        S.last_change = st.get("last_change")
        S.night_stage, S.nights_fixed = bool(st.get("night_stage")), bool(st.get("nights_fixed"))
        S.candidates = {}
        # 생성 기록 글과 '시간 안전판에 끊겼나'도 그 사람이 본 것으로 — 틀은 시드 하나만 돌려서 '몇 개 중 몇 번 선택' 줄이 없다
        if isinstance(st.get("logs"), list):
            S.sch.logs = [str(x) for x in st["logs"]]
        if "timed_out" in st:
            S.sch.timed_out = bool(st["timed_out"])
        # 칸의 '신청·고정' 표시 — 틀을 만든 생성은 고정 칸 없이 돌았으므로 문의에 적힌 것으로 바꾼다
        if isinstance(st.get("wanted"), list):
            S.sch.wanted = type(S.sch.wanted)(
                (k.rsplit(":", 1)[0], int(k.rsplit(":", 1)[1])) for k in st["wanted"]
                if isinstance(k, str) and ":" in k and k.rsplit(":", 1)[1].isdigit() and k.rsplit(":", 1)[0] in S.sch.grid)
    S.fragile = None
    got, left = _display_grid(), 0
    for sid, row in (st.get("grid") or {}).items():
        other = got.get(sid)
        left += sum(1 for d, v in enumerate(row) if (other[d] if other is not None and d < len(other) else None) != v)
    return left


def _voc_rebuild(doc: dict, files: dict, out: dict, why: str) -> dict:
    """처음부터 다시 밟을 수 없는 문의(기록 앞이 잘림·올린 파일이 빠짐·이 판이 모르는 조작).

    **먼저 이 탭을 비운다.** 안 비우면 받은 사람이 만들어 둔 자기 표가 그대로 남아, 맨 위 띠에는 보낸 사람 이름이
    떠 있는데 화면의 표는 내 것인 상태가 된다 — 남의 문의를 내 표를 보며 답하게 된다.
    그다음 문의에 적힌 마지막 확정 입력으로 표 틀을 한 번 만들고, 적혀 있는 표·고정 칸·편집·회차를 그대로 얹는다.
    과정(어떤 순서로 눌렀나)은 재현하지 않았으므로 그 사실을 why로 알린다."""
    S.__init__()
    out.update(matched=False, forced=False, why=why)
    st, cfg = doc.get("state"), doc.get("cfg")
    if isinstance(st, dict) and isinstance(cfg, dict) and st.get("grid"):
        try:
            in2 = files.get("입력/입력2_연간근무표.xlsx")
            lost_in2 = bool(doc.get("staff_table_loaded")) and not in2
            if doc.get("staff_table_loaded") and in2:
                up = json.loads(api_upload_staff_table.__wrapped__(in2))
                lost_in2 = bool(up.get("error"))
            raw = api_set_config.__wrapped__(json.dumps(cfg, ensure_ascii=False))
            r = json.loads(raw)
            if r.get("error"):
                raise ApiError(r["error"])
            out["cfg_result"] = {"warning": r.get("warning"), "staffing": r.get("staffing")}
            # 틀은 그 사람의 마지막 표가 나온 조건 그대로 만든다 — 같은 시드, 같은 고정 칸, 같은 야간 확정. 오른쪽 패널의
            # 형평성·사람별 요약은 표만이 아니라 생성기가 들고 있는 목표값에서도 나와서, 아무 시드로 틀을 만들고 표만
            # 얹으면 표는 같은데 패널 숫자가 다르다(2026-11-12 시나리오 S33). 마지막 생성 뒤에 고정 칸이 더 생긴
            # 경우(야간 확정만 하고 문의)에는 그래도 표가 다를 수 있어, 그때는 아래에서 적힌 표를 얹는다.
            seed = st.get("seed") if isinstance(st.get("seed"), int) and not isinstance(st.get("seed"), bool) else 0
            locked = _fixed_from_list(st.get("locked"))
            pend = {k for k in _fixed_from_list(st.get("pending"))}
            fixed = {k: v for k, v in locked.items() if k not in pend}
            gen, sch = generate_best(S.cfg, fixed_cells=fixed or None, seeds=[seed], time_budget=30.0,
                                     nights_fixed=bool(st.get("nights_fixed")))
            S.gen, S.sch = gen, sch
            _sync_team_b_grid()
            left = _voc_put_recorded(st, everything=True)
            out["cells"] = sum(len(row) for row in st["grid"].values())
            out["forced"], out["rebuilt"] = not left, True
            out["why"] = (why + " — 문의에 적힌 마지막 입력과 표·고정 칸·편집을 그대로 얹어 보여 줍니다"
                          + ("(입력② 파일이 없어 달 경계의 위반 표시는 다를 수 있습니다)" if lost_in2 else "")
                          + (f". 다만 {left}칸은 맞추지 못했습니다(명단이 다릅니다)" if left else ""))
        except Exception as ex:
            S.__init__()
            out["why"] = why + f" — 적힌 표를 얹지도 못했습니다({type(ex).__name__}: {ex}). zip 안의 출력①·검토용.xlsx로 보세요"
    # 이 상태에서 다시 문의를 만들어도 원래 기록(과 '앞이 잘렸다'는 사실)이 이어지게
    S.journal = [dict(e) for e in (doc.get("journal") or []) if isinstance(e, dict)]
    S.journal_dropped = int(doc.get("journal_dropped") or 0)
    S.journal_seq = max([int(e.get("n") or 0) for e in S.journal] or [0])
    return out


def _voc_replay(doc: dict, files: dict) -> dict:
    import inspect
    out = {"steps": [], "error_mismatch": [], "cells": 0, "diff_count": 0, "diff": [], "matched": False,
           "forced": False, "why": None, "cfg_result": None}
    if doc.get("journal_dropped"):
        return _voc_rebuild(doc, files, out,
                            f"작업 기록의 앞 {doc['journal_dropped']}줄이 상한을 넘어 버려져 처음부터 다시 만들 수 없습니다")
    S.__init__()
    kept = []
    for e in doc.get("journal") or []:
        path = e.get("path")
        if not path or path.startswith("/api/download/"):
            continue                                   # 받기는 상태를 바꾸지 않는다
        fn = globals().get(JOURNALED.get(path, ""))
        if fn is None:
            return _voc_rebuild(doc, files, out, f"{e.get('n')}번째 요청({path})을 이 판의 앱이 모릅니다 — "
                                                 "문의를 만든 판이 더 새것일 수 있습니다")
        params = list(inspect.signature(fn.__wrapped__).parameters.values())
        try:
            if not params:
                raw = fn()
            elif "size" in e:
                if e.get("file") not in files:
                    return _voc_rebuild(doc, files, out, f"{e.get('n')}번째 요청({path})에 올린 파일이 문의 파일에 "
                                                         "없습니다(용량 상한으로 빠졌거나 zip에서 지워짐)")
                raw = fn(files[e["file"]])
            elif "body" in e:
                raw = fn(json.dumps(e["body"], ensure_ascii=False))
            elif "body_raw" in e:
                raw = fn(e["body_raw"])
            else:
                raw = fn(None) if params[0].default is not inspect.Parameter.empty else fn("{}")
        except Exception as ex:                        # 원래 화면에서도 예외였을 수 있다 — 오류로 적고 계속 간다
            raw = _err(f"{type(ex).__name__}: {ex}")
        got = None
        if isinstance(raw, str) and raw.startswith('{"error"'):
            got = json.loads(raw).get("error")
        elif path == "/api/set_config" and isinstance(raw, str):
            try:
                r = json.loads(raw)
                out["cfg_result"] = {"warning": r.get("warning"), "staffing": r.get("staffing")}
            except ValueError:
                pass
        out["steps"].append([e.get("n"), path, e.get("error"), got])
        if bool(got) != bool(e.get("error")):
            out["error_mismatch"].append([e.get("n"), path, e.get("error"), got])
        kept.append(e)
    # 다시 밟으면서 기록이 새로 쌓였다 — 시각만 원래 것으로 돌려 둔다(이 상태에서 다시 문의를 만들어도 그때 시각이 남게).
    for new, old in zip(S.journal, kept):
        if new.get("path") == old.get("path"):
            new["t"], new["n"] = old.get("t"), old.get("n")

    st = doc.get("state") or {}
    want = st.get("grid")
    if want is None:
        out["matched"] = not out["error_mismatch"] and S.sch is None
        return out
    if S.gen is None or S.sch is None:
        out["why"] = "다시 밟았지만 근무표가 만들어지지 않았습니다"
        return out

    def diff_now():
        got, diffs, cells = _display_grid(), [], 0
        for sid, row in want.items():
            other = got.get(sid)
            for d, v in enumerate(row):
                cells += 1
                w = other[d] if other is not None and d < len(other) else None
                if w != v:
                    diffs.append([sid, d, v, w])
        return cells, diffs

    out["cells"], diffs = diff_now()
    out["diff_count"], out["diff"] = len(diffs), diffs[:50]
    out["matched"] = not diffs
    if diffs:
        # 기록된 표로 맞춘다 — 사람이 보려는 것은 '그 사람이 본 표'다.
        try:
            left = _voc_put_recorded(st)
            out["forced"] = not left
            if left:
                out["why"] = f"기록된 표로 맞추려 했지만 {left}칸이 남았습니다(명단이 다릅니다)"
        except Exception as ex:
            out["why"] = f"기록된 표로 맞추지 못했습니다: {type(ex).__name__}: {ex}"
    return out


# 문의 파일 열기 상한 — 앱이 만드는 문의 zip은 기록이 붙든 파일 합계(JOURNAL_FILE_BYTES 8MB)에 엑셀 몇 개라
# 이 값들의 몇 분의 일이다. 상한이 없으면 큰 파일·압축 폭탄·항목이 수만 개인 zip을 고르는 순간 탭이 멈추거나
# 메모리가 바닥난다(GPT v0.88 검증 §04). 머리에 적힌 크기는 믿지 않고, 실제로 풀면서 센다.
VOC_ZIP_MAX_BYTES = 32_000_000        # 올린 zip 자체
VOC_ZIP_MAX_ENTRIES = 500             # 항목 수
VOC_ZIP_MAX_ENTRY = 32_000_000        # 항목 하나를 푼 크기
VOC_ZIP_MAX_TOTAL = 64_000_000        # 다 푼 크기 합


def _voc_unzip(data: bytes) -> dict:
    """문의 zip을 상한 안에서 푼다. 넘으면 ApiError(한국어 사유)."""
    mb = lambda n: f"{n / 1_000_000:.0f}MB"
    if len(data) > VOC_ZIP_MAX_BYTES:
        raise ApiError(f"문의 파일이 너무 큽니다({mb(len(data))}, 상한 {mb(VOC_ZIP_MAX_BYTES)}) — '문의 파일 받기'로 받은 zip이 맞는지 확인해 주세요")
    files, total = {}, 0
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        infos = [i for i in z.infolist() if not i.is_dir()]
        if len(infos) > VOC_ZIP_MAX_ENTRIES:
            raise ApiError(f"문의 파일 안의 항목이 너무 많습니다({len(infos)}개, 상한 {VOC_ZIP_MAX_ENTRIES}개)")
        for info in infos:
            with z.open(info) as f:
                body = f.read(VOC_ZIP_MAX_ENTRY + 1)
            if len(body) > VOC_ZIP_MAX_ENTRY:
                raise ApiError(f"문의 파일 안의 '{info.filename}'이 너무 큽니다(상한 {mb(VOC_ZIP_MAX_ENTRY)})")
            total += len(body)
            if total > VOC_ZIP_MAX_TOTAL:
                raise ApiError(f"문의 파일을 푼 크기가 너무 큽니다(상한 {mb(VOC_ZIP_MAX_TOTAL)})")
            files[info.filename] = body
    return files


def api_voc_load(file_bytes) -> str:
    """문의 파일(zip)을 열어 그 화면을 다시 만든다. 지금 탭의 상태는 통째로 그 문의의 것으로 바뀐다."""
    try:
        data = bytes(file_bytes.to_py()) if hasattr(file_bytes, "to_py") else bytes(file_bytes)
        files = _voc_unzip(data)
    except ApiError as e:
        return _err(str(e))
    except Exception:
        return _err("문의 파일(zip)이 아닙니다 — '문의 파일 받기'로 받은 zip을 그대로 올려 주세요")
    raw = files.get(VOC_DATA_NAME) or files.get(_VOC_DATA_LEGACY)
    if raw is None:
        return _err(f"문의 파일이 아닙니다 — zip 안에 '{VOC_DATA_NAME}'이 없습니다")
    try:
        doc = json.loads(raw.decode("utf-8"))
    except Exception as e:
        return _err(f"문의 파일의 데이터를 읽지 못했습니다: {e}")
    replay = _voc_replay(doc, files)
    state = None
    if S.gen is not None and S.sch is not None:
        try:
            state = _full_state()
        except Exception as e:
            replay["why"] = f"화면 상태를 만들지 못했습니다: {type(e).__name__}: {e}"
    client = doc.get("client") if isinstance(doc.get("client"), dict) else {}
    return json.dumps({
        "state": state, "replay": replay,
        "report": doc.get("report") or {},
        "client": {k: client.get(k) for k in ("time_local", "version", "build", "screen", "ua")},
        "text": files.get("문의내용.txt", b"").decode("utf-8", "replace"),
        "had_table": doc.get("state") is not None,
        # 그 사람의 입력 화면 값(문의를 만든 순간의 것). 관리자 모드가 입력 화면도 그 값으로 채운다 —
        # 표만 그 사람 것이고 입력 화면이 내 것이면, 거기서 다시 생성했을 때 두 사람의 입력이 섞인 표가 나온다.
        "form_cfg": (client.get("form") or {}).get("cfg") if isinstance(client.get("form"), dict) else None,
        # 생성 버튼 옆의 선택('꼼꼼히 만들기'·'야간 먼저') — 입력 화면 값(cfg)에는 없지만 다시 생성한 결과를 바꾼다
        "form_opts": (client.get("form") or {}).get("opts") if isinstance(client.get("form"), dict) else None,
        "last_cfg": doc.get("cfg"),
        "staff_table_loaded": S.staff_table_in is not None,
    }, ensure_ascii=False, default=str)

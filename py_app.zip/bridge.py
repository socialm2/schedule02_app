# -*- coding: utf-8 -*-
"""브라우저(Pyodide) 전용 브릿지.

webapp/app.py의 Flask 라우트 로직을 그대로 옮기되, HTTP 대신 JS에서 직접 호출하는
평범한 함수로 노출한다. 모든 함수는 JSON 문자열을 인자로 받고 JSON 문자열을
반환한다(다운로드용 바이너리 함수만 예외). 성공/실패는 HTTP 상태 코드 대신
반환 JSON에 "error" 키가 있는지로 구분한다 — JS 쪽 api() 어댑터가 이 규약을 안다.

로컬 파일 시스템이 없으므로(브라우저), 웹앱의 webapp/history/*.json 파일 저장은
브라우저 localStorage로 대체한다. 그 외 로직(생성/편집/피드백/재생성/누적 원장)은
webapp/app.py와 완전히 동일하다.

이 모듈은 Web Worker 안에서 실행되므로(메인 스레드가 생성 계산 중 멈추지 않게 하려고)
localStorage에 직접 접근할 수 없다(Worker에는 window.localStorage가 없음). 대신
메인 스레드가 현재 localStorage 스냅샷을 부팅 직후 `bootstrap_history()`로 넣어주고,
이 모듈은 그 내용을 메모리 캐시(_hist)에서 읽고 쓴다. 새로 쓴 값은 각 응답의
"_history_patch" 필드로 실어보내면, 메인 스레드가 그걸 받아 실제 localStorage에 반영한다.
"""
from __future__ import annotations

import calendar
import copy
import json
import re

from nurse_scheduler.calendar_utils import DAY_WEEKDAY, build_calendar
from nurse_scheduler.constraints import all_hard_checks, check_soft
from nurse_scheduler.excel_export import (
    export_excel, export_excel_ocs, export_staff_table_xlsx, generate_wanted_template_xlsx,
)
from nurse_scheduler.excel_input import (
    ExcelInputError, load_input_xlsx, load_prev_month_schedule_xlsx,
    staff_table_from_prev_month,
    load_staff_table_xlsx, load_wanted_grid_xlsx,
)
from nurse_scheduler.generator import (
    Generator, InputError, _BEST_EFFORT_RULES, carryover_from_grid,
    carryover_from_history_before, carryover_from_staff_table, generate_best,
    night_score_from_grid_history,
    reconcile_roster,
)
from nurse_scheduler.models import WORK_SHIFTS, Shift, parse_shift
from nurse_scheduler.reporting import build_report, format_text_report

SAMPLE_PATH = "/sample_input.xlsx"
HISTORY_PREFIX = "ns_history_"


class State:
    """프로세스(=탭) 전역 세션 상태 — webapp/app.py의 State와 동일한 역할."""

    def __init__(self):
        self.cfg: dict | None = None
        self.gen = None
        self.sch = None
        self.locked_cells: dict[tuple[str, int], Shift] = {}
        self.pending_edits: dict[tuple[str, int], Shift] = {}
        self.round: int = 0
        self.staff_table_in: dict | None = None
        # set_config에서 계산한 전입·전출 대조 결과 — 연간근무표 갱신본에서 전출자
        # 이력을 이어붙일 때 쓴다.
        self.roster_moves: dict | None = None


S = State()


class ApiError(Exception):
    pass


def _err(msg: str) -> str:
    return json.dumps({"error": msg}, ensure_ascii=False)


def _validate_params(params: dict):
    """설정 숫자칸(연속근무제한/월최대야간/야간목표/최소인력)에 음수 등 말이 안 되는
    값이 들어오면 조용히 받아 엔진에 넘기는 대신(연속근무제한이 음수면 하루짜리
    근무조차 매번 위반으로 잡혀 사실상 빈 근무표가 나온다) 여기서 먼저 막는다.
    화면 숫자칸의 min= 속성은 스핀 버튼에만 적용되고 직접 타이핑은 못 막기 때문에
    서버(여기선 워커) 쪽에서 한 번 더 검증해야 한다."""
    def _bad(key, label, min_val):
        if key not in params:
            return None
        try:
            iv = int(params[key])
        except (TypeError, ValueError):
            return f"{label} 값이 올바르지 않습니다 (입력값: {params[key]!r})."
        if iv < min_val:
            return f"{label}은(는) {min_val} 이상이어야 합니다 (입력값: {iv})."
        return None

    for key, label, min_val in (
        ("max_consecutive_work", "연속근무제한", 1),
        ("off_max_per_month", "월 최대야간", 0),
        ("night_quota_low", "야간목표하한", 0),
        ("night_quota_high", "야간목표상한", 0),
    ):
        err = _bad(key, label, min_val)
        if err:
            return err
    if "night_quota_low" in params and "night_quota_high" in params:
        try:
            low, high = int(params["night_quota_low"]), int(params["night_quota_high"])
            if high < low:
                return (f"야간목표상한({high})은 야간목표하한({low})보다 작을 수 없습니다.")
        except (TypeError, ValueError):
            pass  # 형식 오류는 위 _bad()에서 이미 걸러짐
    def _check_min_staff_row(label: str, rows: dict):
        for shift_key, v in (rows or {}).items():
            try:
                if int(v) < 0:
                    return f"최소인력({label}/{shift_key}) 값은 0 이상이어야 합니다 (입력값: {v})."
            except (TypeError, ValueError):
                return f"최소인력({label}/{shift_key}) 값이 올바르지 않습니다 (입력값: {v!r})."
        return None

    for period, rows in (params.get("min_staff") or {}).items():
        if period == "weekday_by_dow":
            # 평일을 요일별(월~금)로 따로 지정한 경우 — {"0": {...}, ..., "4": {...}}로
            # 한 단계 더 중첩돼 있어 다른 항목과 같은 루프로 못 돈다.
            for dow, day_rows in (rows or {}).items():
                err = _check_min_staff_row(f"평일·{dow}", day_rows)
                if err:
                    return err
            continue
        err = _check_min_staff_row(period, rows)
        if err:
            return err
    return None


def _require_generated():
    if S.gen is None or S.sch is None:
        raise ApiError("아직 생성된 근무표가 없습니다")


# ---------------------------------------------------------------- 상태 직렬화

def _display_grid() -> dict:
    """화면/편집용 값은 "OFF"를 그대로 유지한다(셀 편집·순환·드롭다운이 이 값을 기준으로
    동작하므로) — "X"/"/" 표시 변환은 export/annual_grid 등 출력 시점에만 적용한다."""
    out = {}
    for s in _ordered_staff_for_display():
        row = list(S.sch.grid[s.id])
        for d in range(S.sch.num_days):
            if (s.id, d) in S.pending_edits:
                row[d] = S.pending_edits[(s.id, d)]
        out[s.id] = [str(v) for v in row]
    return out


def _off_display(sid: str, day: int, code: str) -> str:
    """OFF는 "OFF" 대신 원티드오프="X" / 일반오프="/"로 표시(병원 표준 표기, §excel_export와 동일 규칙)."""
    if code != "OFF":
        return code
    return "X" if (sid, day) in S.sch.wanted else "/"


def _staff_meta():
    return [
        {"id": s.id, "role": s.role, "level": s.level,
         "allowed": [x.value for x in s.allowed_shifts],
         "is_partjang": s.is_partjang, "is_nk": s.is_nk,
         "no_night": s.no_night,
         "off_balance": S.sch.carryover[s.id].off_balance}
        for s in _ordered_staff_for_display()
    ]


def _days_meta():
    return [
        {"n": i + 1, "dow": d.dow_name, "weekend": d.day_type != DAY_WEEKDAY,
         "substitute": d.is_substitute, "allows_8a": d.allows_8a}
        for i, d in enumerate(S.gen.days)
    ]


def _report_summary():
    report = build_report(S.sch, S.gen.days, S.gen.params, S.gen.requests)
    requests_all = [
        {"staff_id": r.staff_id, "date": r.date, "type": str(r.type),
         "accepted": bool(r.accepted), "reason": r.reject_reason}
        for r in S.gen.requests
    ]
    bad_days = [d for d in report["daily"] if not d["ok"]]
    # H1-4/H1-5/H4-1/H4-2/H6-1/H6-4는 월경계 등에서 로컬 수리만으로 0건을 보장하기
    # 어려운 최선노력 규칙 — 상세 목록(hard)에는 그대로 남기되, 대표 카운트에서는
    # 제외한다. 화면에서 "정말 못 채운 것(빨강)"과 "거의 다 됐지만 최선노력 규칙만
    # 남은 것(노랑)"을 구분해서 보여줄 수 있도록 항목마다 best_effort 플래그를 단다.
    hard_list = [dict(v, best_effort=v["rule"] in _BEST_EFFORT_RULES)
                for v in report["hard_violations"]]
    strict_hard = [v for v in hard_list if not v["best_effort"]]
    return {
        "hard_count": len(strict_hard),
        "hard": hard_list,
        "soft_count": len(report["soft_violations"]),
        "soft": report["soft_violations"],
        "off_range": report["off_range"],
        "per_person": report["per_person"],
        "requests": report["requests"],
        "requests_all": requests_all,
        "daily": report["daily"],
        "bad_days_count": len(bad_days),
        "night_block_hist": report["night_block_length_hist"],
        "night_gap_hist": report["night_gap_hist"],
        "logs": report["logs"],
        "timed_out": report["timed_out"],
    }


def _locked_keys():
    return [f"{sid}:{d}" for (sid, d) in S.locked_cells]


def _pending_keys():
    return [f"{sid}:{d}" for (sid, d) in S.pending_edits]


def _wanted_keys():
    return [f"{sid}:{d}" for (sid, d) in S.sch.wanted]


def _full_state():
    p = S.gen.params
    return {
        "ward_id": S.cfg.get("ward_id", ""),
        "year": S.gen.year, "month": S.gen.month,
        "num_days": S.sch.num_days,
        "staff": _staff_meta(),
        "days": _days_meta(),
        "grid": _display_grid(),
        "locked": _locked_keys(),
        "pending": _pending_keys(),
        "wanted": _wanted_keys(),
        # B팀(신입)은 스케줄링에 전혀 관여하지 않는 이름뿐인 목록이라 staff/grid에는
        # 안 넣는다 — 화면에는 이름만 빈칸 행으로 보여주고(파트장이 나중에 직접
        # 배정), 다운로드 파일(excel_export.py)과 같은 정보 소스(params.team_b_names)를 쓴다.
        "team_b": p.team_b_names,
        "round": S.round,
        "params_summary": {
            "min_staff": p.min_staff, "max_nights": p.max_nights,
            "leader_8a_as_prn": p.leader_8a_as_prn,
            "holidays": p.holidays, "nk_count": p.nk_count,
        },
        "report": _report_summary(),
    }


def _full_state_json() -> str:
    return json.dumps(_full_state(), ensure_ascii=False)


# ---------------------------------------------------------------- 연간 근무표 히스토리
# webapp/app.py는 webapp/history/YYYY-MM.json 파일에 저장하지만, 브라우저에는
# 로컬 파일 시스템이 없으므로 localStorage 키(ns_history_YYYY-MM)로 대체한다.
# 이 모듈은 Worker 안에서 돌아 localStorage에 직접 접근할 수 없으므로, 메인 스레드가
# bootstrap_history()로 넣어준 스냅샷을 메모리 캐시(_hist)에 두고 그걸로 읽고 쓴다.
# 새로 쓴 값은 _pending_writes에 모아뒀다가 응답의 "_history_patch" 필드로 실어보낸다.

_hist: dict[str, str] = {}
_pending_writes: dict[str, str] = {}


def bootstrap_history(raw_json: str) -> str:
    """메인 스레드가 부팅 직후 현재 localStorage 스냅샷을 여기로 넣어준다."""
    _hist.update(json.loads(raw_json))
    return json.dumps({"ok": True}, ensure_ascii=False)


def _with_history_patch(payload: dict) -> dict:
    if _pending_writes:
        payload["_history_patch"] = dict(_pending_writes)
        _pending_writes.clear()
    return payload


def _ward_slug() -> str:
    """기록 키에 붙일 병동 표시. 병동명이 비어 있으면 빈 문자열(= 예전 키와 동일)."""
    name = str((S.cfg or {}).get("ward_id") or "").strip()
    return re.sub(r"[^0-9A-Za-z가-힣]+", "", name)


def _history_key(year: int, month: int, ward: str | None = None) -> str:
    """ns_history_{병동}_{YYYY-MM}. 병동을 안 붙이면 같은 기기에서 A병동과 B병동의
    같은 달 기록이 서로 덮어써지고, 다른 병동 이력이 연간 화면에 섞인다."""
    w = _ward_slug() if ward is None else ward
    return f"{HISTORY_PREFIX}{w}_{year:04d}-{month:02d}" if w else \
        f"{HISTORY_PREFIX}{year:04d}-{month:02d}"


def _history_keys_for_read(year: int, month: int) -> list:
    """읽을 때는 현재 병동 키를 먼저 보고, 없으면 병동 없이 저장하던 예전 키도 본다 —
    이 변경 전에 저장해둔 기록이 갑자기 사라지지 않도록."""
    keys = [_history_key(year, month)]
    legacy = f"{HISTORY_PREFIX}{year:04d}-{month:02d}"
    if legacy not in keys:
        keys.append(legacy)
    return keys


def _save_history_entry(entry: dict):
    key = _history_key(entry["year"], entry["month"])
    val = json.dumps(entry, ensure_ascii=False)
    _hist[key] = val
    _pending_writes[key] = val


def _load_history_entry(year: int, month: int) -> dict | None:
    for k in _history_keys_for_read(year, month):
        raw = _hist.get(k)
        if raw is not None:
            return json.loads(raw)
    return None


def _history_exists(year: int, month: int) -> bool:
    return any(k in _hist for k in _history_keys_for_read(year, month))


def _all_history_year_months():
    """현재 병동의 기록만 — 다른 병동 기록이 연간 화면에 섞이면 안 된다."""
    out = []
    w = _ward_slug()
    pat = re.compile(rf"^{HISTORY_PREFIX}{re.escape(w)}_(\d{{4}})-(\d{{2}})$") if w else None
    legacy = re.compile(rf"^{HISTORY_PREFIX}(\d{{4}})-(\d{{2}})$")
    for k in _hist:
        m = (pat.match(k) if pat else None) or legacy.match(k)
        if m:
            ym = (int(m.group(1)), int(m.group(2)))
            if ym not in out:
                out.append(ym)
    return out


def _days_meta_for(year: int, month: int, num_days: int):
    days = build_calendar(year, month, [], [])
    return [{"n": i + 1, "dow": d.dow_name, "weekend": d.day_type != DAY_WEEKDAY}
            for i, d in enumerate(days[:num_days])]


def _list_history_before(year: int, month: int, limit: int = 2):
    found = [(y, mo) for (y, mo) in _all_history_year_months() if (y, mo) < (year, month)]
    found.sort(reverse=True)
    out = []
    for y, mo in found[:limit]:
        entry = _load_history_entry(y, mo)
        if entry:
            entry["days"] = _days_meta_for(y, mo, entry["num_days"])
            out.append(entry)
    return out


_OFF_CODES = ("OFF", "X", "/")  # "OFF"(구버전 파일 호환) / "X"(원티드오프) / "/"(일반오프)


def _is_workday_code(v) -> bool:
    """그 칸이 '근무일'인지 — 엔진의 WORK_SHIFTS와 같은 기준으로 판정한다.

    예전에는 "OFF도 연차도 아니면 근무일"로 셌는데, 그러면 병가·공가·수면오프(S/)·
    경조·군·휴직·빈칸까지 전부 근무일로 잡혀 연간 화면의 누적 근무일이 부풀었다.
    """
    s = "" if v is None else str(v).strip()
    if not s or s in _OFF_CODES:
        return False
    try:
        return parse_shift(s) in WORK_SHIFTS
    except ValueError:
        return False   # 모르는 표기는 근무로 세지 않는다


def _summary_from_raw_grid(grid: dict, num_days: int):
    out = {}
    for sid, row in grid.items():
        out[sid] = {
            "off": sum(1 for v in row if v in _OFF_CODES),
            "night": sum(1 for v in row if v in ("N", "NK")),
            "workday": sum(1 for v in row if _is_workday_code(v)),
        }
    return out


def _current_history_entry():
    return {
        "year": S.gen.year, "month": S.gen.month,
        "staff": [{"id": s.id, "level": s.level, "is_nk": s.is_nk}
                 for s in _ordered_staff_for_display()],
        "num_days": S.sch.num_days,
        "grid": _display_grid(),
        "days": _days_meta(),
        "summary": {
            s.id: {"off": S.sch.offs_in_month(s.id),
                   "night": S.sch.nights_in_month(s.id),
                   "workday": S.sch.workdays_in_month(s.id)}
            for s in S.sch.staff
        },
    }


def _night_block_counts(row: list) -> tuple:
    """근무 코드 리스트 하나(한 달치)에서 야간(N/NK) 연속블록 길이별 건수를 센다."""
    b2 = b3 = other = 0
    i, n = 0, len(row)
    while i < n:
        if row[i] in ("N", "NK"):
            j = i
            while j + 1 < n and row[j + 1] in ("N", "NK"):
                j += 1
            length = j - i + 1
            if length == 2:
                b2 += 1
            elif length == 3:
                b3 += 1
            else:
                other += 1
            i = j + 1
        else:
            i += 1
    return b2, b3, other


def _count_shift_codes(row: list, days: list) -> tuple:
    """행(한 달치 근무 코드)에서 D/E/prn(8A 포함) 개수와 주말·휴일 OFF 개수를 센다."""
    d_cnt = sum(1 for v in row if v == "D")
    e_cnt = sum(1 for v in row if v == "E")
    prn_cnt = sum(1 for v in row if v in ("prn", "8A", "9A"))
    wh_off = sum(1 for v, d in zip(row, days) if v in _OFF_CODES and d.get("weekend"))
    return d_cnt, e_cnt, prn_cnt, wh_off


def _cumulative_summary(entries: list, staff_ids: list):
    out = {}
    for sid in staff_ids:
        off = night = workday = months = 0
        weekend_night = 0
        blocks_2 = blocks_3 = blocks_other = 0
        for e in entries:
            s = e["summary"].get(sid)
            if s:
                off += s["off"]; night += s["night"]; workday += s["workday"]
                months += 1
            row = e.get("grid", {}).get(sid)
            days = e.get("days")
            if row and days:
                weekend_night += sum(1 for v, d in zip(row, days)
                                     if v in ("N", "NK") and d.get("dow") in ("토", "일"))
                b2, b3, bo = _night_block_counts(row)
                blocks_2 += b2; blocks_3 += b3; blocks_other += bo
        out[sid] = {"off": off, "night": night, "workday": workday, "months": months,
                    "weekend_night": weekend_night, "blocks_2": blocks_2,
                    "blocks_3": blocks_3, "blocks_other": blocks_other}
    return out


def _ordered_staff_for_display():
    """연간근무표 등 사람이 눈으로 보는 목록의 인원 순서.

    S.sch.staff는 재시도(seed>0) 때 검색 다양성을 위해 무작위로 섞인 순서 그대로라
    화면/파일에 그대로 쓰면 뒤죽박죽으로 보인다 — 대신 원래 업로드/입력된 인원표
    순서(S.cfg["staff"])를 따르되, 파트장만 맨 위로 올린다."""
    orig_order = {s["id"]: i for i, s in enumerate(S.cfg["staff"])}
    return sorted(S.sch.staff,
                 key=lambda s: (0 if s.is_partjang else 1, orig_order.get(s.id, 10**9)))


def _build_updated_staff_table():
    """이번 달 생성 결과를 이전 연간근무표(S.staff_table_in)에 얹어 갱신본을 만든다.

    통계는 항상 "이번 달 실제 생성 결과"만 더해서 한 걸음씩 앞으로 나간다 —
    월간근무표(이어붙이기 규칙용)와는 별개로, 연간근무표 스스로 다음 입력이 된다.
    연간 그리드는 해가 바뀌면(1/1) 리셋한다.
    """
    import datetime

    prev = S.staff_table_in or {}
    prev_stats = prev.get("stats", {})
    prev_dates = prev.get("annual_dates", [])
    prev_grid = prev.get("annual_grid", {})

    grid = _display_grid()
    days = _days_meta()
    next_carry = S.gen.build_next_carryover()

    stats = {}
    for s in S.sch.staff:
        row = grid[s.id]
        b2, b3, _bo = _night_block_counts(row)
        weekend_night = sum(1 for v, d in zip(row, days)
                            if v in ("N", "NK") and d["dow"] in ("토", "일"))
        d_cnt, e_cnt, prn_cnt, wh_off = _count_shift_codes(row, days)
        base = prev_stats.get(s.id, {})
        stats[s.id] = {
            "night": base.get("night", 0) + S.sch.nights_in_month(s.id),
            "workday": base.get("workday", 0) + S.sch.workdays_in_month(s.id),
            "off": base.get("off", 0) + S.sch.offs_in_month(s.id),
            "weekend_night": base.get("weekend_night", 0) + weekend_night,
            "blocks_2": base.get("blocks_2", 0) + b2,
            "blocks_3": base.get("blocks_3", 0) + b3,
            "months": base.get("months", 0) + 1,
            "recent_night_score": next_carry.get(s.id, {}).get("recent_night_score", 0.0),
            "cum_d": base.get("cum_d", 0) + d_cnt,
            "cum_e": base.get("cum_e", 0) + e_cnt,
            "cum_prn": base.get("cum_prn", 0) + prn_cnt,
            "cum_weekend_holiday_off": base.get("cum_weekend_holiday_off", 0) + wh_off,
            # 전월잔휴/잔휴는 OCS 원본과 같은 짝이다 — 앞은 이번 달을 시작할 때의 잔여,
            # 뒤는 이번 달을 반영한 뒤의 잔여(=다음 달 시작값).
            "prev_off_balance": round(S.sch.carryover[s.id].off_balance, 2),
            "off_balance": next_carry.get(s.id, {}).get("off_balance", 0.0),
        }

    this_year = S.gen.year
    if prev_dates and prev_dates[0][:4] == str(this_year):
        base_dates = [datetime.date.fromisoformat(x) for x in prev_dates]
    else:
        base_dates = []
    # 이어붙일 과거 구간은 '이번 달 1일 전'까지만 — 이번 달 칸이 섞여 있으면 아래에서
    # 이번 달을 덧붙일 때 같은 날짜가 두 번 들어간다(전입자가 가져온 이번 달 기록이
    # 그런 경우다. 그 기록은 이월정보 계산에 이미 쓰였고 여기서는 역할이 끝났다).
    # 계속 근무자에게까지 이번 달이 채워진 파일은 set_config에서 미리 막는다.
    first_of_month = datetime.date(this_year, S.gen.month, 1)
    keep = len([d for d in base_dates if d < first_of_month])
    base_dates = base_dates[:keep]
    this_month_dates = [datetime.date(this_year, S.gen.month, d + 1)
                        for d in range(S.sch.num_days)]
    annual_dates = base_dates + this_month_dates

    # 전입자가 가져온 전 병동 기록은 이월정보·야간형평성 계산에 쓰고 나면 역할이 끝난다.
    # 우리 병동 연간 그리드에 그대로 남기면 그 사람이 없던 달의 날짜별 인력 통계
    # (레벨평균·Lv4-5·Lv1-3)에까지 섞여 들어가므로, 입사 이전 칸은 비워서 이어붙인다
    # (다음 달 이월은 '이번 달' 실적으로 계산되니 지워도 연속성에는 영향이 없다).
    transferred = set((S.staff_table_in or {}).get("transferred_in") or [])

    annual_grid = {}
    for s in S.sch.staff:
        if s.id in transferred:
            base_codes = []
        else:
            base_codes = (prev_grid.get(s.id, []) if base_dates else [])
        base_codes = (base_codes + [""] * len(base_dates))[:len(base_dates)]
        this_month_codes = [_off_display(s.id, d, c) for d, c in enumerate(grid[s.id])]
        annual_grid[s.id] = base_codes + this_month_codes

    # 전출자 이력 보존 — 이미 전출로 기록돼 있던 사람들을 그대로 이어받고, 이번 달에
    # 새로 빠진 사람(입력②에는 있는데 입력①에 없음)을 추가한다. 통계는 재직 마지막
    # 시점 값으로 동결하고, 연간 그리드는 빠진 달부터 빈칸으로 채운다.
    departed = []
    seen = set()
    for p in (prev.get("departed") or []):
        codes = (p.get("codes") or []) if base_dates else []
        codes = (codes + [""] * len(annual_dates))[:len(annual_dates)]
        departed.append({**p, "codes": codes})
        seen.add(p["id"])

    moves = S.roster_moves or {}
    left_tag = f"{S.gen.year}-{S.gen.month:02d}"
    roster_by_id = {s["id"]: s for s in (S.cfg or {}).get("staff", [])}
    # 지금 배정된 사람은 전출자가 될 수 없다 — 이 방어가 없으면 예전 대조 결과가
    # 남아 있을 때 같은 이름이 현재 인원과 '전출' 구역에 둘 다 찍히고, 그 파일은
    # 다음 달 입력②로 다시 올릴 때 '이름 중복'으로 반려돼 연동이 끊긴다.
    current_ids = {s.id for s in S.sch.staff}
    for sid in moves.get("outgoing", []):
        if sid in seen or sid in current_ids:
            continue
        base_codes = (prev_grid.get(sid, []) if base_dates else [])
        base_codes = (base_codes + [""] * len(annual_dates))[:len(annual_dates)]
        old = roster_by_id.get(sid, {})
        departed.append({
            "id": sid,
            "role": old.get("role", "간호사"),
            "level": old.get("level", 1),
            "allowed_shifts": old.get("allowed_shifts") or [],
            "left_at": left_tag,
            "stats": prev_stats.get(sid, {}),
            "codes": base_codes,
        })

    return stats, annual_dates, annual_grid, departed


# ================================================================ API 함수
# (경로 하나당 함수 하나 — webapp/app.py의 라우트와 1:1 대응)

def api_sample() -> str:
    try:
        cfg = load_input_xlsx(SAMPLE_PATH)
    except Exception as e:
        return _err(f"샘플 로드 실패: {e}")
    return json.dumps(cfg, ensure_ascii=False)


def _write_temp_xlsx(file_bytes, path: str):
    data = bytes(file_bytes.to_py()) if hasattr(file_bytes, "to_py") else bytes(file_bytes)
    with open(path, "wb") as f:
        f.write(data)


# 병동인력표(옛 입력①) 업로드는 없앴다 — 설정·근무인력은 전부 화면에서 입력하고 브라우저에
# 저장한다. load_input_xlsx는 샘플 기본값을 읽는 데만 남는다.


def api_upload_prev_month(file_bytes) -> str:
    path = "/tmp_prev.xlsx"
    try:
        _write_temp_xlsx(file_bytes, path)
        data = load_prev_month_schedule_xlsx(path)
    except ExcelInputError as e:
        return _err(f"엑셀 오류: {e}")
    except Exception as e:
        return _err(f"파일을 읽을 수 없습니다: {e}")

    carry = carryover_from_grid(data["grid"], data["num_days"])
    for sid, bal in data.get("off_balance", {}).items():
        if sid in carry:
            carry[sid]["off_balance"] = bal

    if not _history_exists(data["year"], data["month"]):
        summary = _summary_from_raw_grid(data["grid"], data["num_days"])
        _save_history_entry({
            "year": data["year"], "month": data["month"],
            "staff": [{"id": sid, "level": None} for sid in data["grid"]],
            "num_days": data["num_days"], "grid": data["grid"], "summary": summary,
        })

    warning = None
    if S.cfg is not None:
        cur_y, cur_m = int(S.cfg["year"]), int(S.cfg["month"])
        prev_y, prev_m = (cur_y - 1, 12) if cur_m == 1 else (cur_y, cur_m - 1)
        if (data["year"], data["month"]) != (prev_y, prev_m):
            warning = (f"업로드한 파일은 {data['year']}년 {data['month']}월 근무표인데, "
                       f"현재 설정된 달({cur_y}년 {cur_m}월)의 바로 전달({prev_y}년 {prev_m}월)이 "
                       "아닙니다 — 그래도 이월값은 반영합니다.")
    payload = _with_history_patch({"ok": True, "year": data["year"], "month": data["month"],
                                   "carryover": carry, "warning": warning})
    return json.dumps(payload, ensure_ascii=False)


def api_upload_wanted(file_bytes) -> str:
    """원티드 신청 엑셀(월간근무표와 같은 모양, 별표·X 등 표기) → 신청 목록 자동 변환."""
    path = "/tmp_wanted.xlsx"
    try:
        _write_temp_xlsx(file_bytes, path)
        data = load_wanted_grid_xlsx(path)
    except ExcelInputError as e:
        return _err(f"엑셀 오류: {e}")
    except Exception as e:
        return _err(f"파일을 읽을 수 없습니다: {e}")

    # 이 파일의 연월은 '생성할 달'이다(파트장이 OCS에서 그 달 날짜를 복붙해 만든다).
    # 화면 연월과 다르더라도 일수가 같으면 그대로 받는다 — 화면 쪽에서 파일의 연월로
    # 맞춰주므로 어긋날 일이 거의 없고, 남는 건 표기 차이뿐이라 반려하면 번거롭기만 하다.
    # 다만 일수가 다르면 그냥 넘길 수 없다: 31일치 신청이 30일 달에 붙으면 말일 신청이
    # 조용히 사라지고, 반대면 있지도 않은 날에 신청이 생긴다.
    warning = None
    if S.cfg is not None:
        cur_y, cur_m = int(S.cfg["year"]), int(S.cfg["month"])
        cur_days = calendar.monthrange(cur_y, cur_m)[1]
        file_days = calendar.monthrange(data["year"], data["month"])[1]
        if file_days != cur_days:
            return _err(
                f"업로드한 파일은 {data['year']}년 {data['month']}월({file_days}일)인데 "
                f"현재 설정된 달은 {cur_y}년 {cur_m}월({cur_days}일)입니다 — 일수가 달라 "
                "신청 날짜가 어긋납니다. 화면의 연월을 파일과 같은 달로 맞추거나, "
                "그 달의 양식을 새로 받아 채워주세요.")
    bad_dates = data.get("transfer_bad_dates") or []
    unknown_tr = data.get("unknown_transfer_marks") or []
    out_of_month = data.get("transfer_date_out_of_month") or []
    notes = []
    if bad_dates:
        notes.append(f"⚠ 전입일을 못 읽음 {len(bad_dates)}건({', '.join(bad_dates)}) — "
                     "달력에 없는 날짜이거나 알아볼 수 없는 값입니다. 1일자 전입으로 "
                     "처리했으니, 월중 전입이면 '전입일' 칸을 고쳐 다시 올려주세요.")
    if out_of_month:
        # 적어놓고 안 먹은 줄 모르면 파트장은 월중 전입 처리가 된 줄로 안다.
        notes.append(f"⚠ 이 달 밖의 전입일 {len(out_of_month)}건({', '.join(out_of_month)}) — "
                     f"{data['year']}년 {data['month']}월 배정에는 반영되지 않습니다. "
                     "월중 전입이라면 이 달 안의 날짜로 고쳐주세요.")
    if unknown_tr:
        notes.append(f"⚠ '전입' 칸에서 알아볼 수 없는 값 {len(unknown_tr)}건"
                     f"({', '.join(unknown_tr)}) — 전입자로 잡히지 않았습니다. "
                     "그 칸은 비우거나 '전입'을 골라주세요.")
    if notes:
        warning = " / ".join(notes)
    return json.dumps({"ok": True, "year": data["year"], "month": data["month"],
                       "requests": data["requests"], "unknown_marks": data["unknown_marks"],
                       "staff": data["staff"], "team_b_names": data.get("team_b_names") or [],
                       "transferred_in": data.get("transferred_in") or [],
                       "transfer_in_dates": data.get("transfer_in_dates") or {},
                       "warning": warning}, ensure_ascii=False)


def api_upload_staff_table(file_bytes) -> str:
    """'연간근무표'(로스터+누적통계+연간그리드) 업로드 — 다월 자동 연동의 시작점.

    이 파일은 '과거'(지난달까지의 실적)다. 로스터는 입력①(원티드표)가 아직 없을 때만
    화면 명단의 출발점으로 쓰고, 입력①이 이미 있으면 덮어쓰지 않고 대조(전입·전출 판정)에만
    쓴다 — 화면 쪽에서 그렇게 처리한다.
    """
    path = "/tmp_staff_table.xlsx"
    try:
        _write_temp_xlsx(file_bytes, path)
        data = load_staff_table_xlsx(path)
    except ExcelInputError as e:
        # 연간근무표가 아니면 '지난달 근무표 한 장'(병원 OCS 원본 또는 우리 월간근무표)
        # 으로 다시 읽어본다 — 이 앱을 처음 쓰는 달에는 아직 연간근무표가 없다.
        # 두 형태는 앞부분(시트 헤더)이 완전히 달라서 서로 오인될 여지가 없다.
        try:
            prev = load_prev_month_schedule_xlsx(path)
        except Exception:
            return _err(f"연간근무표 엑셀 오류: {e}")
        data = staff_table_from_prev_month(prev)
    except Exception as e:
        return _err(f"파일을 읽을 수 없습니다: {e}")

    S.staff_table_in = {"stats": data["stats"], "annual_dates": data["annual_dates"],
                        "annual_grid": data["annual_grid"],
                        "departed": data.get("departed") or [],
                        "transferred_in": data.get("transferred_in") or [],
                        "transfer_in_dates": data.get("transfer_in_dates") or {},
                        "transfer_bad_dates": data.get("transfer_bad_dates") or [],
                        "unknown_transfer_marks": data.get("unknown_transfer_marks") or [],
                        "transfer_no_off_balance": data.get("transfer_no_off_balance") or [],
                        "rows_after_summary": data.get("rows_after_summary") or []}
    return json.dumps({"ok": True, "staff": data["staff"],
                       "source": data.get("source") or "staff_table",
                       "roster_names": data.get("roster_names")
                                       or [s["id"] for s in data["staff"]],
                       "team_b_names": data.get("team_b_names") or [],
                       "departed_names": [p["id"] for p in (data.get("departed") or [])],
                       "transferred_in": data.get("transferred_in") or [],
                       "transfer_in_dates": data.get("transfer_in_dates") or {},
                       "transfer_bad_dates": data.get("transfer_bad_dates") or [],
                       "rows_after_summary": data.get("rows_after_summary") or [],
                       "off_balance_blank": data.get("off_balance_blank") or [],
                       # 전월잔휴는 근무표에서 계산할 수 없는 누적 잔액이라 코드가 채울 수
                       # 없다 — 비어 있으면 0으로 보고 진행하되 그 사실을 화면에 띄운다.
                       "prev_off_balance_missing": data.get("prev_off_balance_missing") or [],
                       "has_prev_off_balance_col": data.get("has_prev_off_balance_col", True),
                       "unknown_grid_marks": data.get("unknown_grid_marks") or [],
                       "annual_days": len(data["annual_dates"]),
                       "last_date": (data["annual_dates"][-1] if data["annual_dates"] else None)},
                      ensure_ascii=False)


def api_staff_table_status() -> str:
    """지금 서버에 연간근무표가 반영돼 있는지 — '생성'을 누르면 이게 계속 자동으로 쓰이므로,
    화면에서 리더가 잊지 않고 확인할 수 있게 상시 조회 가능하게 해둔다."""
    if not S.staff_table_in:
        return json.dumps({"loaded": False}, ensure_ascii=False)
    dates = S.staff_table_in.get("annual_dates") or []
    return json.dumps({"loaded": True, "staff_count": len(S.staff_table_in.get("stats") or {}),
                       "annual_days": len(dates), "last_date": (dates[-1] if dates else None)},
                      ensure_ascii=False)


def api_clear_staff_table() -> str:
    S.staff_table_in = None
    S.roster_moves = None
    return json.dumps({"ok": True}, ensure_ascii=False)


def api_set_config(body_json: str) -> str:
    data = json.loads(body_json)
    if not data or not all(k in data for k in ("year", "month", "staff", "params")):
        return _err("입력 형식이 올바르지 않습니다 (year/month/staff/params 필요)")
    param_err = _validate_params(data.get("params") or {})
    if param_err:
        return _err(param_err)
    if not (data.get("staff") or []):
        # 여기서 안 막으면 엔진 안쪽 검증에 걸려 "nk_count=2 이지만 NK 전담 인원은 0명"처럼
        # 실제 원인과 상관없는 문구가 나온다 — 무엇이 없는지 그대로 알려준다.
        return _err("인원 명단이 비어 있습니다 — 입력①(원티드표)에 인원(이름·직급·"
                    "숙련도·가능근무)을 채워서 올린 뒤 다시 시도해주세요.")
    warning = None
    if not S.staff_table_in:
        # 대조할 지난달 파일이 없으면 이전 대조 결과도 함께 버린다 — 둘이 짝이 안 맞으면
        # 예전 전출자가 이번 달 출력에 되살아난다.
        S.roster_moves = None
    if S.staff_table_in:
        stats = S.staff_table_in["stats"]
        annual_dates = S.staff_table_in.get("annual_dates") or []
        annual_grid = S.staff_table_in.get("annual_grid") or {}
        carry = {}
        if annual_dates:
            carry.update(carryover_from_staff_table(
                annual_dates, annual_grid, int(data["year"]), int(data["month"])))
            if not carry:
                # 연간근무표는 있는데 "이번 달의 바로 전달" 구간이 안 이어져 있음 —
                # 이월정보 없이 진행하는 대신, 조용히 넘어가지 않고 반드시 알려준다.
                cur_y, cur_m = int(data["year"]), int(data["month"])
                py, pm = (cur_y - 1, 12) if cur_m == 1 else (cur_y, cur_m - 1)
                warning = (
                    f"업로드된 연간근무표에 {py}년 {pm}월(이번 생성의 바로 전달) 전체가 "
                    f"이어져 있지 않아 전월이월(잔여 휴가·연속근무 등)이 반영되지 않았습니다 "
                    f"— 연간근무표의 마지막 날짜: {annual_dates[-1]}. "
                    f"{py}년 {pm}월분 출력②(연간근무표)를 다시 올려주세요."
                )
        # 이번 달이 이미 들어 있는 파일인지 — 방금 만든 이번 달 출력②를 그대로 입력②로
        # 다시 올리면(같은 달을 다시 만들려고 흔히 한다) 연간 그리드에 같은 달이 두 번
        # 붙고 누적 통계도 한 달치 더 얹혀, 그 뒤로 계속 부풀어 오른 파일이 이어진다.
        # 전입자가 가져온 이번 달 기록(입사 전 구간)은 정상이므로 그 사람들은 제외하고,
        # 계속 근무자에게 이번 달 칸이 채워져 있으면 잘못 올린 것으로 보고 막는다.
        # 대상 월보다 '미래'까지 반영된 파일 — 12월까지 만든 연간근무표를 올려놓고 9월을
        # 생성하면, 날짜 그리드는 9월만 남기고 잘리는데 누적 통계는 12월치 위에 9월치가
        # 또 더해진다(시간이 거꾸로 흐른 누적). 그대로 다음 달로 이어지면 형평성 기준이
        # 영구히 오염되므로 받지 않는다. 월중 전입자가 가져온 이번 달 기록은 대상 월
        # 안쪽이라 여기에 걸리지 않는다.
        import calendar as _cal
        _last_day = _cal.monthrange(int(data["year"]), int(data["month"]))[1]
        _month_end = f"{int(data['year']):04d}-{int(data['month']):02d}-{_last_day:02d}"
        if annual_dates and annual_dates[-1] > _month_end:
            return _err(
                f"업로드된 연간근무표는 {annual_dates[-1]}까지 반영된 파일인데, 지금 만들려는 것은 "
                f"{int(data['year'])}년 {int(data['month'])}월입니다 — 이미 지난 뒤의 파일이라 "
                "누적 통계(야간·근무일 등)가 거꾸로 쌓여 형평성 기준이 틀어집니다. "
                f"{int(data['year'])}년 {int(data['month'])}월의 바로 전달까지 반영된 연간근무표를 "
                "올리시거나, 만들려는 달을 파일에 맞춰 바꿔주세요.")

        cur_tag = f"{int(data['year']):04d}-{int(data['month']):02d}"
        this_month_cols = [i for i, ds in enumerate(annual_dates) if ds[:7] == cur_tag]
        if this_month_cols:
            marked = set(S.staff_table_in.get("transferred_in") or [])
            filled = sorted(
                sid for sid, codes in annual_grid.items()
                if sid not in marked
                and any(str(codes[i]).strip() for i in this_month_cols if i < len(codes)))
            if filled:
                return _err(
                    f"이 연간근무표에는 이미 {int(data['year'])}년 {int(data['month'])}월 "
                    f"근무가 들어 있습니다({', '.join(filled[:3])}"
                    f"{' 외 %d명' % (len(filled) - 3) if len(filled) > 3 else ''}) — "
                    "이번 달 출력②를 그대로 입력②로 올리신 것 같습니다. "
                    "입력②에는 지난달까지 반영된 파일을 올려주세요. "
                    "같은 달을 다시 만드시려면 입력②를 새로 올리지 마시고 "
                    "'근무표 생성'을 다시 누르시면 됩니다.")

        for sid, v in (data.get("prev_month_carryover") or {}).items():
            carry[sid] = v
        # 비고에 '전입'이라 적힌 사람 중, 실제로 이번 달 명단(입력①)에 있는 사람만 대상.
        # 입력②에만 있고 입력①에 없으면 그건 전입이 아니라 명단 누락이므로 전출로 잡혀 드러난다.
        roster_ids = {str(s.get("id", "")).strip() for s in data["staff"]}
        # 전입 표시는 두 곳에서 올 수 있다 — 입력②(연간근무표의 '전입' 칸)과 입력①
        # (원티드표의 '전입' 칸). 입력②가 OCS 지난달 근무표로 들어오면 그 파일에는
        # 전입 칸 자체가 없으므로, 입력①이 유일한 출처가 된다. 둘 다 있으면 합집합이다.
        transferred = (set(S.staff_table_in.get("transferred_in") or [])
                       | set(data.get("wanted_transferred_in") or [])) & roster_ids
        transfer_no_history: list = []
        # 월중 전입자의 입사일 — 이번 달에 해당하는 것만 엔진에 넘긴다.
        all_join_dates = dict(S.staff_table_in.get("transfer_in_dates") or {})
        all_join_dates.update(data.get("wanted_transfer_in_dates") or {})
        join_dates = {sid: ds for sid, ds
                      in all_join_dates.items()
                      if sid in transferred
                      and ds[:7] == f"{int(data['year']):04d}-{int(data['month']):02d}"
                      and ds[8:10] != "01"}
        data["transfer_in_dates"] = join_dates
        for sid, st in stats.items():
            entry = dict(carry.get(sid) or {})
            join = join_dates.get(sid)
            if join:
                # 월중 전입 — 이월정보의 기준은 전월 말일이 아니라 '입사 전날'이다.
                # 2/15 입사자는 2/14까지 전 병동에서 근무했으므로, 전월 말일로 계산하면
                # 입사 직전 야간블록을 놓쳐 야간 후 휴식이 안 지켜진다(안전 문제).
                got = carryover_from_history_before(
                    annual_dates, annual_grid.get(sid) or [], join)
                if got:
                    entry.update(got)
            score = st.get("recent_night_score", 0.0)
            if sid in transferred and not score:
                # 전입자가 전 병동 근무기록을 가져온 경우 — 최근야간점수 칸이 비어 있으면
                # 붙여넣은 기록에서 직접 접어 계산한다(이 칸을 파트장이 채울 방법이 없으므로).
                # 이게 없으면 0으로 덮여 "야간을 한 번도 안 선 사람"이 돼 첫 달부터 야간
                # 상한을 받아버린다. 월중 전입이면 입사일이 경계다.
                #
                # '기록은 있는데 야간이 0회'와 '기록 자체가 없음'은 구분해야 한다 — 전자는
                # 0이 맞는 값이라 야간 우선권을 줘야 하고(형평성), 후자는 알 수 없으니
                # 중립값(중앙값)으로 둬야 한다. 역산 함수가 None으로 그 차이를 알려준다.
                derived = night_score_from_grid_history(
                    annual_dates, annual_grid.get(sid) or [],
                    int(data["year"]), int(data["month"]), before=join)
                if derived is not None:
                    score = derived
                else:
                    transfer_no_history.append(sid)
            entry["recent_night_score"] = score
            entry["off_balance"] = st.get("off_balance", 0.0)
            carry[sid] = entry

        # 입력①(이번 달 명단, 미래) vs 입력②(지난달 실적, 과거) 대조 — 차집합이 인사이동이다.
        # 전입자는 우리 병동 실적이 없으므로 야간 비교군(중앙값)에서 빼고 계산한다.
        moves = reconcile_roster(data["staff"], stats, transferred=transferred)
        for sid in transfer_no_history:
            # '전입'이라 표시했지만 붙여넣은 근무기록이 아예 없는 경우 — 역산할 게 없어
            # 0으로 남는다. 그대로 두면 "야간을 한 번도 안 선 사람"이 돼 첫 달부터 야간
            # 상한을 받아버리므로(이력 없는 전입자와 같은 문제), 재직 중인 비교군의
            # 중앙값에서 출발시킨다.
            entry = dict(carry.get(sid) or {})
            entry["recent_night_score"] = moves["newcomer_night_score"]
            carry[sid] = entry
        for sid in moves["incoming"]:
            # 전입자는 이월정보가 없다. recent_night_score를 0으로 두면 "야간을 한 번도
            # 안 선 사람"이 돼 첫 달부터 야간 상한을 받아버리므로, 계속 근무 중인 야간
            # 비교군의 중앙값에서 출발시킨다(전 병동 이력을 모르니 가장 중립적인 추정).
            # 잔휴(off_balance)는 실제 정산 숫자라 임의로 지어내지 않고 0으로 둔다.
            entry = dict(carry.get(sid) or {})
            entry["recent_night_score"] = moves["newcomer_night_score"]
            carry[sid] = entry
        data["prev_month_carryover"] = carry
        S.roster_moves = moves
        move_msgs = []
        if moves["incoming"]:
            move_msgs.append(
                f"전입 {len(moves['incoming'])}명({', '.join(moves['incoming'])}) — "
                f"지난달 연간근무표에 없어 이월정보(잔휴·연속근무)가 없습니다. "
                f"야간 형평성은 재직자 중앙값({moves['newcomer_night_score']})에서 시작합니다. "
                f"이름 오타로 못 찾은 경우라면 입력①·②의 이름을 같게 맞춰주세요.")
        if moves["outgoing"]:
            move_msgs.append(
                f"전출 {len(moves['outgoing'])}명({', '.join(moves['outgoing'])}) — "
                f"이번 달 배정에서 빠집니다. 누적 이력은 연간근무표의 '전출' 칸에 보존됩니다.")

        # 전 병동 기록을 가져온 전입자(연간근무표 비고에 '전입') — 이력이 실제로 쓰였는지,
        # 사람이 채워야만 하는 값(잔휴)이 비었는지를 조용히 넘기지 않고 알려준다.
        if transferred:
            named = sorted(transferred)
            move_msgs.append(
                f"전입(이력 반영) {len(named)}명({', '.join(named)}) — 붙여넣은 전 병동 "
                f"근무기록에서 이월정보·야간 형평성을 계산했습니다. 부서 누적 실적은 "
                f"이번 달부터 0에서 시작합니다.")
            mid = [f"{sid}({join_dates[sid][5:].replace('-', '/')} 입사)"
                   for sid in sorted(join_dates)]
            if mid:
                move_msgs.append(
                    f"월중 전입 {len(mid)}명({', '.join(mid)}) — 입사 전 날짜는 배정에서 빼고"
                    f"('휴' 표시), 이월정보는 입사 전날 기준으로 계산했습니다. 잔휴는 전 병동이"
                    f" 정산해 넘긴 값에서 시작해 재직 기간의 휴일수만 적립합니다.")
            no_bal = [n for n in (S.staff_table_in.get("transfer_no_off_balance") or [])
                      if n in transferred]
            if no_bal:
                move_msgs.append(
                    f"⚠ 전입자 잔휴 미입력 {len(no_bal)}명({', '.join(no_bal)}) — 잔휴는 "
                    f"근무기록으로 계산할 수 없는 누적 잔액입니다. 전 병동에서 받은 숫자를 "
                    f"연간근무표의 '잔휴' 칸에 적어 다시 올려주세요(지금은 0으로 진행).")
            if transfer_no_history:
                move_msgs.append(
                    f"⚠ 전입자 근무기록 없음 {len(transfer_no_history)}명"
                    f"({', '.join(sorted(transfer_no_history))}) — '전입'으로 표시했지만 날짜 칸에"
                    f" 전 병동 근무기록이 없습니다. 이월정보(야간 후 휴식 등)를 계산할 수 없어"
                    f" 야간 형평성만 재직자 중앙값({moves['newcomer_night_score']})으로 맞췄습니다."
                    f" 기록이 있으면 붙여넣어 다시 올려주세요.")
            bad_dates = S.staff_table_in.get("transfer_bad_dates") or []
            if bad_dates:
                move_msgs.append(
                    f"⚠ 전입일을 못 읽음 {len(bad_dates)}건({', '.join(bad_dates)}) — 달력에 없는"
                    f" 날짜이거나 알아볼 수 없는 값입니다. 그 사람은 1일자 전입으로 처리했으니,"
                    f" 월중 전입이면 '전입일' 칸을 고쳐 다시 올려주세요.")
            unknown = S.staff_table_in.get("unknown_transfer_marks") or []
            if unknown:
                move_msgs.append(
                    f"⚠ 전입자 기록에서 인식 못 한 표기 {len(unknown)}건"
                    f"({', '.join(unknown[:8])}{' 외' if len(unknown) > 8 else ''}) — 해당 칸은 "
                    f"빈칸(오프)으로 처리했습니다. 우리 병동 코드로 바꿔 적으면 정확해집니다.")
        # 파일 맨 아래(레벨평균 요약 블록 뒤)에 사람을 덧붙이면 파서가 못 읽고 지나간다 —
        # 전입자 행을 넣다가 흔히 하는 실수라, 조용히 빠지지 않게 반드시 알려준다.
        stranded = S.staff_table_in.get("rows_after_summary") or []
        if stranded:
            move_msgs.append(
                f"⚠ 연간근무표 맨 아래 통계 줄(레벨평균) 뒤에 있는 행 {len(stranded)}건"
                f"({', '.join(stranded)})은 읽지 못했습니다 — 사람 행은 통계 줄 위, "
                f"기존 인원 목록 바로 아래에 넣어주세요.")
        if move_msgs:
            joined = " / ".join(move_msgs)
            warning = f"{warning} {joined}" if warning else joined
    if not any(str(s.get("role", "")).strip() == "파트장" for s in data.get("staff", [])):
        # 엔진 자체는 파트장 없는 구성도 허용하지만(소규모 병동 등), 실사용에서는
        # 대부분 '직급' 칸 오타일 가능성이 높아 막지 않고 경고로만 알려준다.
        pj_warning = ("인원 명단에 '파트장' 직급을 가진 사람이 없습니다 — 오타가 있으면 8A "
                      "고정 배정 등 파트장 전용 처리가 전부 빠집니다. 의도적으로 파트장 없이 "
                      "운영하는 경우라면 무시해도 됩니다.")
        warning = f"{warning} {pj_warning}" if warning else pj_warning
    try:
        Generator(data)
    except InputError as e:
        return _err(str(e))
    except Exception as e:
        return _err(f"입력 오류: {e}")
    S.cfg = data
    S.gen = None
    S.sch = None
    S.locked_cells = {}
    S.pending_edits = {}
    S.round = 0
    return json.dumps({"ok": True, "staff_count": len(data["staff"]), "warning": warning},
                      ensure_ascii=False)


def api_generate() -> str:
    if S.cfg is None:
        return _err("먼저 입력을 확정하세요 (업로드 또는 직접입력 후 생성)")
    try:
        gen, sch = generate_best(S.cfg)
    except InputError as e:
        return _err(f"입력 검증 실패: {e}")
    except Exception as e:
        return _err(f"생성 중 오류가 발생했습니다: {e}")
    S.gen, S.sch = gen, sch
    S.locked_cells = {}
    S.pending_edits = {}
    S.round = 1
    return _full_state_json()


def api_state() -> str:
    try:
        _require_generated()
    except ApiError as e:
        return _err(str(e))
    return _full_state_json()


def api_edit(body_json: str) -> str:
    try:
        _require_generated()
    except ApiError as e:
        return _err(str(e))
    data = json.loads(body_json)
    sid, day, shift_str = data.get("staff_id"), data.get("day"), data.get("shift")
    if sid not in S.sch.by_id:
        return _err("존재하지 않는 직원입니다")
    if not isinstance(day, int) or not (0 <= day < S.sch.num_days):
        return _err("잘못된 날짜입니다")
    try:
        shift = parse_shift(shift_str)
    except ValueError:
        return _err(f"알 수 없는 근무유형: {shift_str}")
    S.pending_edits[(sid, day)] = shift
    return _full_state_json()


def api_edit_undo(body_json: str) -> str:
    data = json.loads(body_json)
    sid, day = data.get("staff_id"), data.get("day")
    S.pending_edits.pop((sid, day), None)
    return _full_state_json()


def api_discard() -> str:
    S.pending_edits = {}
    return _full_state_json()


def api_feedback() -> str:
    try:
        _require_generated()
    except ApiError as e:
        return _err(str(e))
    if not S.pending_edits:
        return json.dumps({"hard": [], "soft": [], "edits": []}, ensure_ascii=False)

    temp = copy.deepcopy(S.sch)
    for (sid, d), shift in S.pending_edits.items():
        temp.grid[sid][d] = shift

    hard = all_hard_checks(temp, S.gen.days, S.gen.params)
    soft = [v for v in check_soft(temp, S.gen.days, S.gen.params) if v.severity == "soft"]

    def related(v):
        if v.staff_id:
            return any(sid == v.staff_id and (v.day is None or abs(v.day - d) <= 2)
                       for (sid, d) in S.pending_edits)
        if v.day is not None:
            return any(v.day == d for (_, d) in S.pending_edits)
        return False

    edits_list = [
        {"staff_id": sid, "day": d, "old": str(S.sch.grid[sid][d]), "new": str(shift)}
        for (sid, d), shift in sorted(S.pending_edits.items())
    ]
    return json.dumps({
        "hard": [{"rule": v.rule, "message": v.message} for v in hard if related(v)],
        "hard_other": len([v for v in hard if not related(v)]),
        "soft": [{"rule": v.rule, "message": v.message} for v in soft if related(v)],
        "edits": edits_list,
    }, ensure_ascii=False)


def api_apply() -> str:
    try:
        _require_generated()
    except ApiError as e:
        return _err(str(e))
    if not S.pending_edits:
        return _err("적용할 편집이 없습니다")

    S.locked_cells.update(S.pending_edits)
    try:
        gen, sch = generate_best(S.cfg, fixed_cells=dict(S.locked_cells))
    except InputError as e:
        return _err(f"재생성 실패: {e}")
    except Exception as e:
        return _err(f"재생성 중 오류가 발생했습니다: {e}")

    S.gen, S.sch = gen, sch
    S.pending_edits = {}
    S.round += 1
    return _full_state_json()


def api_finalize() -> str:
    try:
        _require_generated()
    except ApiError as e:
        return _err(str(e))
    if S.pending_edits:
        return _err(
            f"아직 적용하지 않은 편집 {len(S.pending_edits)}칸이 남아 있습니다 — "
            "'재생성 적용'으로 확정하거나 편집을 취소한 뒤 저장해주세요. "
            "지금 저장하면 근무표 칸은 바꾼 값으로, OFF·야간·근무일 통계는 바꾸기 전 "
            "값으로 저장돼 서로 어긋납니다.")
    _save_history_entry(_current_history_entry())
    payload = _with_history_patch({"ok": True, "saved": f"{S.gen.year}-{S.gen.month:02d}"})
    return json.dumps(payload, ensure_ascii=False)


def api_annual() -> str:
    try:
        _require_generated()
    except ApiError as e:
        return _err(str(e))
    current = _current_history_entry()
    history = _list_history_before(S.gen.year, S.gen.month, limit=2)
    staff_ids = [s.id for s in _ordered_staff_for_display()]
    cumulative = _cumulative_summary([current] + history, staff_ids)
    return json.dumps({"current": current, "history": history, "cumulative": cumulative},
                      ensure_ascii=False)


# ---------------------------------------------------------------- 다운로드
# 브라우저에는 send_file이 없으므로 바이트/문자열을 그대로 반환하고,
# JS 쪽에서 Blob으로 감싸 다운로드를 띄운다.

def api_download_xlsx():
    try:
        _require_generated()
    except ApiError as e:
        return None
    path = "/tmp_out.xlsx"
    export_excel(S.sch, S.gen.days, path)
    with open(path, "rb") as f:
        return f.read()


def api_download_xlsx_ocs():
    """병원 OCS 원본과 같은 모양(간호스케줄)으로 내보내기."""
    try:
        _require_generated()
    except ApiError as e:
        return None
    path = "/tmp_out_ocs.xlsx"
    export_excel_ocs(S.sch, S.gen.days, path, violations=_report_summary()["hard"])
    with open(path, "rb") as f:
        return f.read()


def api_download_staff_table():
    """'연간근무표' 갱신본 다운로드 — 다음 달엔 이 파일을 그대로 다시 업로드하면 된다."""
    try:
        _require_generated()
    except ApiError as e:
        return None
    stats, annual_dates, annual_grid, departed = _build_updated_staff_table()
    path = "/tmp_staff_table_out.xlsx"
    export_staff_table_xlsx(_ordered_staff_for_display(), stats, annual_dates, annual_grid, path,
                            last_reflected=f"{S.gen.year}년 {S.gen.month}월",
                            team_b_names=S.gen.params.team_b_names,
                            departed=departed)
    with open(path, "rb") as f:
        return f.read()


def api_download_wanted_template(body_json: str):
    """입력① 원티드표 양식 — 화면에서 고른 연/월에 맞는 일수로, 지금 화면에 있는
    인원 목록(직급·숙련도·가능근무·비고 포함) 그대로 채워서 만들어준다.
    생성된 근무표(S.gen)와는 무관하게 항상 가능."""
    body = json.loads(body_json)
    year = int(body["year"])
    month = int(body["month"])
    staff = body.get("staff") or []
    team_b_names = body.get("team_b_names") or []
    path = "/tmp_wanted_template.xlsx"
    generate_wanted_template_xlsx(year, month, staff, path, team_b_names=team_b_names)
    with open(path, "rb") as f:
        return f.read()


_FILENAME_UNSAFE = re.compile(r'[\\/:*?"<>|\s]+')


def _download_filename(kind: str) -> str:
    """다운로드 파일명 = {종류}_{병동명}_{연도}-{월}.xlsx (병동명 없으면 생략)."""
    ward = (S.cfg or {}).get("ward_id", "") if S.cfg else ""
    ward = _FILENAME_UNSAFE.sub("", str(ward or "").strip())
    parts = [kind] + ([ward] if ward else []) + [f"{S.gen.year}-{S.gen.month:02d}"]
    return "_".join(parts) + ".xlsx"


def download_filename_schedule() -> str:
    if S.gen is None:
        return "출력1_월간근무표.xlsx"
    name = _download_filename("출력1_월간근무표")
    return name[:-5] + f"_r{S.round}.xlsx"


def download_filename_schedule_ocs() -> str:
    if S.gen is None:
        return "출력1_월간근무표.xlsx"
    name = _download_filename("출력1_월간근무표")
    return name[:-5] + f"_r{S.round}.xlsx"


def download_filename_staff_table() -> str:
    if S.gen is None:
        return "출력2_연간근무표.xlsx"
    return _download_filename("출력2_연간근무표")
